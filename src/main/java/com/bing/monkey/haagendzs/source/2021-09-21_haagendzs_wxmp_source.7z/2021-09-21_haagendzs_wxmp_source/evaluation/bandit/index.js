// evaluation/bandit/index.js
Page({data: {}})