// newStore/redCover/index.js
Page({data: {}})