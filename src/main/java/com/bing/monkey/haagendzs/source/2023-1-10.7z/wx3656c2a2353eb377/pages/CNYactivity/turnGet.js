(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/CNYactivity/turnGet" ], {
    "073d": function(e, o, t) {
        var n = t("7ff8");
        t.n(n).a;
    },
    "1a87": function(e, o, t) {
        (function(e) {
            var n = t("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var i = n(t("f3d4")), a = n(t("3724")), c = {
                data: function() {
                    return {
                        textareaValue: "",
                        imgUrl: i.default.assetsRoot,
                        showloginDialog: !1,
                        showRead: !1,
                        isShowSharePopup: !1,
                        helpinfo: "",
                        nickName: "",
                        checkCodeState: !1,
                        isLovePink: !1,
                        activityType: "",
                        isLoveGold: !1,
                        imgurl: i.default.assetsRoot + "/oss/wxapp/20210127/static",
                        imgBase: i.default.assetsRoot + "/oss/evaluation/"
                    };
                },
                onLoad: function(o) {
                    this.textid = o.textid, this.activityType = o.activityType;
                    var t = "#48080f";
                    "newYearType" == this.activityType || ("lovePink" == this.activityType ? (t = "#e5848d", 
                    this.isLovePink = !0) : "loveGolden" == this.activityType && (t = "#caa684", this.isLoveGold = !0)), 
                    e.setNavigationBarColor({
                        frontColor: "#ffffff",
                        backgroundColor: t,
                        animation: {
                            duration: 400,
                            timingFunc: "easeIn"
                        }
                    }), this.getTextInfo();
                },
                onShow: function() {},
                components: {
                    loginDialog: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/loginDialog") ]).then(function() {
                            return resolve(t("d6e5"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                destroyed: function() {
                    console.log("销毁了");
                },
                onHide: function() {
                    console.log("关闭了"), e.removeStorageSync("successInfo");
                },
                methods: {
                    closepopup: function() {
                        this.checkCodeState ? (this.isShowSharePopup = !1, e.redirectTo({
                            url: "/pages/mine/mycard"
                        })) : this.isShowSharePopup = !1;
                    },
                    getTextInfo: function() {
                        var e = this;
                        a.default.ebuyTransferDetail(this.textid).then(function(o) {
                            console.log(o), e.textareaValue = o.data.remark, e.couponCode = o.data.couponCode, 
                            e.openid = o.data.openid, e.nickName = o.data.nickName;
                        });
                    },
                    readrule: function() {
                        this.showRead = !1, e.removeStorageSync("successInfo"), this.getCard();
                    },
                    sendCard: function() {
                        0 == Object.keys(e.getStorageSync("logininfo")).length ? this.showloginDialog = !0 : this.getCard();
                    },
                    getCard: function() {
                        var o = this;
                        if (this.openid == e.getStorageSync("openId")) return this.isShowSharePopup = !0, 
                        this.helpinfo = "请勿领取自己的券", !1;
                        a.default.ebuyReceiveTransfer({
                            toOpenid: e.getStorageSync("openId"),
                            toUnionid: e.getStorageSync("unionId"),
                            toSocialHubid: e.getStorageSync("socialhubId"),
                            mobile: e.getStorageSync("logininfo").mobilePhone,
                            couponKey: this.textid
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (o.isShowSharePopup = !0, o.helpinfo = '成功领取好友赠送的\n哈根达斯产品兑换券一张\n快去小程序哈根达斯会员中心\n"个人中心-我的券包"看看吧', 
                            o.checkCodeState = !0) : "502" == e.code ? (o.isShowSharePopup = !0, o.helpinfo = '您已成功领取\n快去小程序哈根达斯会员中心\n"个人中心-我的券包"看看吧', 
                            o.checkCodeState = !0) : "702" == e.code ? (o.isShowSharePopup = !0, o.helpinfo = "请勿重复领取", 
                            o.checkCodeState = !0) : "703" == e.code ? (o.isShowSharePopup = !1, o.helpinfo = "您的礼物已被领取或被好友撤回", 
                            o.checkCodeState = !0) : (o.isShowSharePopup = !0, o.helpinfo = "您的礼物已被好友取回\n快去联系TA吧");
                        });
                    }
                }
            };
            o.default = c;
        }).call(this, t("543d").default);
    },
    "1ea2": function(e, o, t) {
        (function(e) {
            var o = t("4ea4");
            t("a1ea"), o(t("66fd"));
            var n = o(t("aa24"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("543d").createPage);
    },
    "3de0": function(e, o, t) {
        t.r(o);
        var n = t("1a87"), i = t.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(o, e, function() {
                return n[e];
            });
        }(a);
        o.default = i.a;
    },
    "7ff8": function(e, o, t) {},
    aa24: function(e, o, t) {
        t.r(o);
        var n = t("eda9"), i = t("3de0");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(o, e, function() {
                return i[e];
            });
        }(a);
        t("073d");
        var c = t("f0c5"), r = Object(c.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        o.default = r.exports;
    },
    eda9: function(e, o, t) {
        t.d(o, "b", function() {
            return n;
        }), t.d(o, "c", function() {
            return i;
        }), t.d(o, "a", function() {});
        var n = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    }
}, [ [ "1ea2", "common/runtime", "common/vendor" ] ] ]);