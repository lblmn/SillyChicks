(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/info" ], {
    "0ce1": function(e, t, o) {
        o.r(t);
        var n = o("b514"), i = o("6190");
        for (var a in i) "default" !== a && function(e) {
            o.d(t, e, function() {
                return i[e];
            });
        }(a);
        o("8690");
        var r = o("f0c5"), l = Object(r.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = l.exports;
    },
    "0ef2": function(e, t, o) {},
    4373: function(e, t, o) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = l(o("500b")), i = l(o("1246")), a = l(o("b5b1")), r = l(o("234f"));
            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            getApp();
            var c = {
                components: {},
                data: function() {
                    return {
                        isdisabled: !1,
                        showphone: !1,
                        form: {
                            fullName: e.getStorageSync("logininfo").fullName,
                            genderCode: "" + e.getStorageSync("logininfo").genderCode,
                            birthDate: e.getStorageSync("logininfo").birthDate,
                            phone: e.getStorageSync("logininfo").mobilePhone,
                            detailAddress: e.getStorageSync("logininfo").detailAddress,
                            email: e.getStorageSync("logininfo").email,
                            tierName: e.getStorageSync("logininfo").tier.tierName,
                            area: ""
                        },
                        cityvalue: [ e.getStorageSync("logininfo").provinceName, e.getStorageSync("logininfo").cityName ]
                    };
                },
                mounted: function() {
                    var t = e.getStorageSync("logininfo").provinceCode, o = e.getStorageSync("logininfo").cityCode, n = e.getStorageSync("logininfo").provinceName;
                    e.getStorageSync("logininfo").cityName, this.form.area = "" == t || "0" == t || "" == o || "0" == o || null == n || "null" == n ? "" : [ t, o ], 
                    "100000001" == e.getStorageSync("logininfo").genderCode || "100000002" == e.getStorageSync("logininfo").genderCode ? this.isdisabled = !0 : this.isdisabled = !1;
                },
                onShow: function() {
                    r.default.recordPv();
                },
                methods: {
                    nameChange: function(e) {
                        var t = e.detail;
                        this.form.fullName = t;
                    },
                    addressChange: function(e) {
                        var t = e.detail;
                        this.form.detailAddress = t;
                    },
                    onSexChange: function(e) {
                        var t = e.detail;
                        this.form.genderCode = t;
                    },
                    emailChange: function(e) {
                        var t = e.detail;
                        this.form.email = t;
                    },
                    getLocation: function() {
                        var t = this;
                        e.getLocation({
                            type: "gcj02",
                            success: function(o) {
                                var n, a;
                                e.showLoading({
                                    title: "正在获取位置"
                                }), console.log(o), n = o.latitude.toString(), a = o.longitude.toString(), e.request({
                                    header: {
                                        "Content-Type": "application/text"
                                    },
                                    url: "https://apis.map.qq.com/ws/geocoder/v1/?location=" + n + "," + a + "&key=WR5BZ-7XBCI-JJBGM-5WIGM-6E4V6-XRF6I",
                                    success: function(e) {
                                        200 === e.statusCode ? (console.log("获取中文街道地理位置成功"), t.cityvalue = [ e.data.result.ad_info.province, e.data.result.ad_info.city ], 
                                        t.form.area = [], t.cityvalue.map(function(e, o) {
                                            return 0 == o ? t.form.area.push(i.default.province.filter(function(t) {
                                                return t[1] == e;
                                            })[0][0]) : 1 == o ? t.form.area.push(i.default.city.filter(function(t) {
                                                return t[1] == e;
                                            })[0][0]) : void 0;
                                        })) : console.log("获取信息失败，请重试！");
                                    },
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            },
                            fail: function() {
                                e.showToast({
                                    title: "您拒绝了授权，请在右上角设置中打开地理位置授权",
                                    icon: "none"
                                }), console.log("你拒绝了授权，无法获得周边信息");
                            }
                        });
                    },
                    gophone: function(t) {
                        if ("other" == t) {
                            if (!this.isdisabled || 1 != this.isdisabled) return !1;
                            e.showToast({
                                title: "如需修改，请致电客服热线400-820-7917更改",
                                icon: "none",
                                duration: 3e3
                            });
                        } else e.showToast({
                            title: "如需修改，请致电客服热线400-820-7917更改",
                            icon: "none",
                            duration: 3e3
                        });
                    },
                    goclose: function() {
                        this.showphone = !1;
                    },
                    doSave: function() {
                        var t = this;
                        if (this.form.fullName) {
                            if (!this.form.email || /\@/g.test(this.form.email)) {
                                var o = this.form, i = o.fullName, r = o.genderCode, l = o.birthDate, c = o.detailAddress, f = o.email;
                                a.default.info({
                                    idType: 1,
                                    id: e.getStorageSync("socialhubId"),
                                    fullName: i,
                                    genderCode: Number(r),
                                    birthDate: l,
                                    provinceCode: this.form.area[0],
                                    provinceName: this.cityvalue[0],
                                    cityCode: this.form.area[1],
                                    cityName: this.cityvalue[1],
                                    detailAddress: c,
                                    email: f
                                }).then(function(o) {
                                    0 == o.resultCode ? (getApp().hxt.sendAction("correct_profilesave", {
                                        name: i,
                                        city: t.cityvalue[0] + "" + t.cityvalue[1],
                                        address: c,
                                        email: f
                                    }), n.default.getmember({
                                        idType: "1",
                                        id: e.getStorageSync("socialhubId")
                                    }).then(function(o) {
                                        e.setStorageSync("logininfo", o.data), t.$store.commit("userinfo", o.data), e.showToast({
                                            title: "更新成功"
                                        }), setTimeout(function() {
                                            e.switchTab({
                                                url: "/pages/mine/mine"
                                            });
                                        }, 800);
                                    })) : e.showToast({
                                        title: "请求异常请稍后重试",
                                        icon: "none"
                                    });
                                });
                            } else e.showToast({
                                title: "邮箱格式不正确",
                                icon: "none"
                            });
                        } else e.showToast({
                            title: "姓名不能为空",
                            icon: "none"
                        });
                    }
                }
            };
            t.default = c;
        }).call(this, o("543d").default);
    },
    6190: function(e, t, o) {
        o.r(t);
        var n = o("4373"), i = o.n(n);
        for (var a in n) "default" !== a && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(a);
        t.default = i.a;
    },
    8690: function(e, t, o) {
        var n = o("0ef2");
        o.n(n).a;
    },
    b514: function(e, t, o) {
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {});
        var n = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    bb19: function(e, t, o) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            o("c0e2"), t(o("66fd")), e(t(o("0ce1")).default);
        }).call(this, o("543d").createPage);
    }
}, [ [ "bb19", "common/runtime", "common/vendor" ] ] ]);