// blindBox/member/index.js
Page({data: {}})