// appointment/distribution/orderDetail.js
Page({data: {}})