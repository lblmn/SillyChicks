// cardExchange/qtsjActivity/index.js
Page({data: {}})