(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/couponTel/couponTel" ], {
    "0b43": function(e, n, t) {},
    "202b": function(e, n, t) {
        var o = t("0b43");
        t.n(o).a;
    },
    "705a": function(e, n, t) {
        t.r(n);
        var o = t("cb58"), i = t("ac59");
        for (var l in i) "default" !== l && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(l);
        t("202b");
        var c = t("f0c5"), a = Object(c.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = a.exports;
    },
    ac59: function(e, n, t) {
        t.r(n);
        var o = t("d5c2"), i = t.n(o);
        for (var l in o) "default" !== l && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(l);
        n.default = i.a;
    },
    cb58: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(n) {
                e.confirmVisible = !0;
            }, e.e1 = function(n) {
                e.showObtain = !1;
            }, e.e2 = function(n) {
                e.showObtain = !1;
            });
        }, i = [];
    },
    d4ef: function(e, n, t) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            t("f4aa"), n(t("66fd")), e(n(t("705a")).default);
        }).call(this, t("543d").createPage);
    },
    d5c2: function(e, n, t) {
        (function(e) {
            function o(e, n, t) {
                return n in e ? Object.defineProperty(e, n, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = t, e;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(t("d19a")), l = {
                data: function() {
                    var e;
                    return e = {
                        giftId: "",
                        tel: "",
                        placeholderTel: "",
                        errorMsg: "",
                        confirmVisible: !1,
                        showObtain: !1
                    }, o(e, "errorMsg", ""), o(e, "selectCityVisible", !1), o(e, "cityShow", !1), o(e, "cityObj", {
                        text: "",
                        code: ""
                    }), o(e, "canChange", !0), e;
                },
                onLoad: function(n) {
                    this.giftId = n.giftId, this.placeholderTel = e.getStorageSync("logininfo").mobilePhone ? e.getStorageSync("logininfo").mobilePhone : "请输入手机号", 
                    console.log(this.placeholderTel);
                },
                onShow: function() {},
                onHide: function() {
                    this.confirmVisible = !1, this.selectCityVisible = !1;
                },
                methods: {
                    handleIndex: function() {
                        e.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    goBack: function() {
                        e.navigateBack({
                            delta: 1
                        });
                    },
                    goSubmit: function() {
                        var n = this, t = "";
                        if ("请输入手机号" != this.placeholderTel) {
                            if ("" == this.tel && this.placeholderTel && "请输入手机号" != this.placeholderTel) t = this.placeholderTel; else if ("" != this.tel) {
                                if (!/^1(5[56]|3[021]|4[56]|66|7[0561]|8[56]|96)\d{8}$/.test(this.tel)) return e.showToast({
                                    title: "请输入联通手机号",
                                    icon: "none"
                                }), !1;
                                t = this.tel;
                            }
                            var o = {
                                mobile: t,
                                openId: e.getStorageSync("openId"),
                                unionId: e.getStorageSync("unionId"),
                                giftId: this.giftId
                            };
                            console.log(o), i.default.exchange(o).then(function(e) {
                                0 == e.code ? n.confirmVisible = !0 : ("fail" == e.msg ? n.errorMsg = "兑换失败，请确认联通手机号码" : n.errorMsg = e.msg, 
                                n.showObtain = !0);
                            });
                        } else e.showToast({
                            title: "手机号不能为空",
                            icon: "none"
                        });
                    }
                }
            };
            n.default = l;
        }).call(this, t("543d").default);
    }
}, [ [ "d4ef", "common/runtime", "common/vendor" ] ] ]);