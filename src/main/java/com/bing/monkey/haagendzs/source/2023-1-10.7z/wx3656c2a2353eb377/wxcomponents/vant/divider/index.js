(0, require("../common/component").VantComponent)({
    props: {
        dashed: {
            type: Boolean,
            value: !1
        },
        hairline: {
            type: Boolean,
            value: !1
        },
        contentPosition: {
            type: String,
            value: ""
        },
        fontSize: {
            type: Number,
            value: ""
        },
        borderColor: {
            type: String,
            value: ""
        },
        textColor: {
            type: String,
            value: ""
        },
        customStyle: {
            type: String,
            value: ""
        }
    }
});