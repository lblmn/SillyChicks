(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/rule" ], {
    "12b7": function(e, n, o) {
        o.r(n);
        var t = o("d14d"), c = o.n(t);
        for (var a in t) "default" !== a && function(e) {
            o.d(n, e, function() {
                return t[e];
            });
        }(a);
        n.default = c.a;
    },
    3421: function(e, n, o) {
        o.d(n, "b", function() {
            return t;
        }), o.d(n, "c", function() {
            return c;
        }), o.d(n, "a", function() {});
        var t = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, c = [];
    },
    "36dd": function(e, n, o) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            o("f4aa"), n(o("66fd")), e(n(o("69a3")).default);
        }).call(this, o("543d").createPage);
    },
    "69a3": function(e, n, o) {
        o.r(n);
        var t = o("3421"), c = o("12b7");
        for (var a in c) "default" !== a && function(e) {
            o.d(n, e, function() {
                return c[e];
            });
        }(a);
        o("8c56");
        var u = o("f0c5"), i = Object(u.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        n.default = i.exports;
    },
    "8c56": function(e, n, o) {
        var t = o("ba1f");
        o.n(t).a;
    },
    ba1f: function(e, n, o) {},
    d14d: function(e, n, o) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var c = t(o("1d54")), a = t(o("d7df")), u = t(o("811a")), i = t(o("57d0")), r = {
                data: function() {
                    return {
                        ruleDesc: "",
                        showloginDialog: !1,
                        showRead: !1
                    };
                },
                onLoad: function(e) {
                    u.default.setSource(e), this.getRuleDesc();
                },
                onShow: function() {
                    "all" == e.getStorageSync("successInfo") && (this.showRead = !0);
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("a81e"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                destroyed: function() {},
                onHide: function() {
                    e.removeStorageSync("successInfo");
                },
                methods: {
                    getRecord: function() {
                        i.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: e.getStorageSync("smsSource")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        c.default.getRuledesc({
                            type: 4
                        }).then(function(n) {
                            console.log(n), n.data.length <= 0 ? e.ruleDesc = "暂无会员规则信息" : e.ruleDesc = n.data[0].content;
                        });
                    },
                    backtoMine: function() {
                        0 == Object.keys(e.getStorageSync("logininfo")).length ? this.showloginDialog = !0 : (this.shareRecord(), 
                        this.getRecord());
                    },
                    readrule: function() {
                        this.showRead = !1, e.removeStorageSync("successInfo"), this.shareRecord(), this.getRecord();
                    },
                    shareRecord: function() {
                        a.default.shareRecord({
                            aid: "",
                            unionId: e.getStorageSync("unionId"),
                            openid: e.getStorageSync("openId"),
                            path: "pages/mine/rule",
                            button: "pages/mine/rule",
                            invitedOpenid: "",
                            type: "2"
                        }).then(function(e) {
                            console.log(e);
                        }).catch(function(e) {
                            console.log(e);
                        });
                        var n = getCurrentPages();
                        console.log(n), n.length - 1 <= 0 ? e.switchTab({
                            url: "./mine"
                        }) : e.navigateBack({});
                    }
                }
            };
            n.default = r;
        }).call(this, o("543d").default);
    }
}, [ [ "36dd", "common/runtime", "common/vendor" ] ] ]);