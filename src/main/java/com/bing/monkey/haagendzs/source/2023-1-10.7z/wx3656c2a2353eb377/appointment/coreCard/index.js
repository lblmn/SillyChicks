// appointment/coreCard/index.js
Page({data: {}})