// activity/canvasGame/index.js
Page({data: {}})