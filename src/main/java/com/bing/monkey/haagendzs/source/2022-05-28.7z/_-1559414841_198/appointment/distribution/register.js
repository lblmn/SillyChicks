// appointment/distribution/register.js
Page({data: {}})