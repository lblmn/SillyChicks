// blindBox/makeup/index.js
Page({data: {}})