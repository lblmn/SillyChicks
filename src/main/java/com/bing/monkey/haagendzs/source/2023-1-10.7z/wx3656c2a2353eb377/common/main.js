var e = require("../@babel/runtime/helpers/interopRequireDefault")(require("../@babel/runtime/regenerator")), t = require("../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    "1e70": function(e, t, n) {
        var o = n("c4fe");
        n.n(o).a;
    },
    "5fee": function(e, t, n) {
        (function(e, t) {
            var o = n("4ea4"), r = n("7037"), a = o(n("9523"));
            n("a1ea");
            var i = o(n("66fd")), c = o(n("68c3"));
            n("28ec");
            var u = o(n("7b7f")), l = o(n("4b31")), s = o(n("7d43")), f = o(n("f3d4")), d = o(n("d98d")), p = function(e, t) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== r(e) && "function" != typeof e) return {
                    default: e
                };
                var n = function(e) {
                    if ("function" != typeof WeakMap) return null;
                    var t = new WeakMap(), n = new WeakMap();
                    return function(e) {
                        return e ? n : t;
                    }(e);
                }(t);
                if (n && n.has(e)) return n.get(e);
                var o = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
                    var c = a ? Object.getOwnPropertyDescriptor(e, i) : null;
                    c && (c.get || c.set) ? Object.defineProperty(o, i, c) : o[i] = e[i];
                }
                return o.default = e, n && n.set(e, o), o;
            }(n("5c63")), g = o(n("d505")), h = o(n("5e73"));
            function m(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n;
            var b = e.getAccountInfoSync().miniProgram.envVersion;
            "trial" != b && "release" != b || p.init({
                dsn: "https://139ce576166a4574b0f4f09a8b44513f@newsentry.smarket.com.cn/2"
            }), i.default.config.productionTip = !1, i.default.component("commonRule", function() {
                Promise.all([ n.e("common/vendor"), n.e("components/common_rule/index") ]).then(function() {
                    return resolve(n("7a9b"));
                }.bind(null, n)).catch(n.oe);
            }), i.default.prototype.$toast = g.default, i.default.prototype.$dialog = h.default, 
            c.default.mpType = "app", i.default.prototype.$onLaunched = new Promise(function(e) {
                i.default.prototype.$isResolve = e;
            }), i.default.prototype.$http = l.default, i.default.prototype.$util = s.default, 
            i.default.prototype.$env = f.default, i.default.prototype.$store = u.default, i.default.prototype.$STATUS = d.default, 
            console.log("进来了");
            var y = new i.default(function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? m(Object(n), !0).forEach(function(t) {
                        (0, a.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : m(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({
                store: u.default
            }, c.default));
            t(y).$mount();
        }).call(this, n("543d").default, n("543d").createApp);
    },
    "68c3": function(e, t, n) {
        n.r(t);
        var o = n("bff1");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n("1e70");
        var a = n("f0c5"), i = Object(a.a)(o.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = i.exports;
    },
    bff1: function(e, t, n) {
        n.r(t);
        var o = n("e355"), r = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = r.a;
    },
    c4fe: function(e, t, n) {},
    e355: function(n, o, r) {
        (function(n) {
            var a = r("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var i, c = a(r("7037")), u = a(r("9296")), l = a(r("f3d4")), s = {
                globalData: {
                    PointAccountResult: [],
                    PointAccount: 0,
                    PointJidou: 0,
                    deadHeart: 0,
                    deadBean: 0,
                    scene: Number,
                    N_ENV: {},
                    isbackfromSaveWXCard: "",
                    istransfer: !1,
                    globalNetWork: "",
                    isnewMember: !1,
                    getFirstTip: !1,
                    height: 44,
                    navbarHeight: 0
                },
                methods: {
                    login: function() {
                        return new Promise(function(e, t) {
                            n.getStorageSync("token") ? e(n.getStorageSync("token")) : n.request({
                                url: "https://uatscrm-haagendazs.smarket.com.cn/v1/api/wxapp/banner/getList",
                                method: "get",
                                header: {
                                    Authorization: "Bearer " + n.getStorageSync("token")
                                }
                            }).then(function(e) {
                                console.log("??", e);
                            });
                        });
                    },
                    loadFontFace: function() {
                        n.loadFontFace({
                            family: "Bitstream",
                            source: 'url("https://haagendazs-oss.smarket.com.cn/Pacifico.ttf")',
                            success: function() {
                                console.log("success");
                            }
                        });
                    },
                    showBaffle: function() {
                        u.default.baffleGetByType("homeIndex").then(function(e) {
                            console.log(e);
                        });
                    },
                    doLogin: function() {
                        return new Promise(function(e, t) {
                            n.login({
                                success: function(t) {
                                    console.log(t), e(t);
                                },
                                fail: function(e) {
                                    console.log(e), t(e);
                                }
                            });
                        });
                    },
                    getUserOpenid: function(e) {
                        u.default.login({
                            code: e.code,
                            appId: l.default.appId
                        }).then(function(e) {
                            0 == e.code && (n.setStorageSync("ceUserOpenid", e.data.openid), n.setStorageSync("ceUserUnionId", e.data.unionId));
                        });
                    },
                    getDeviceSize: function() {
                        return new Promise(function(e, t) {
                            n.getSystemInfo({
                                success: function(t) {
                                    console.log("用户手机型号:", t);
                                    var n, o = t.screenHeight, r = t.safeArea, a = t.statusBarHeight, i = t.windowHeight, c = t.windowWidth, u = t.screenWidth, l = t.pixelRatio, s = o - r.bottom, f = t.windowHeight, d = 750 / t.windowWidth, p = f * d, g = t.model;
                                    n = -1 != g.search("iPhone X") ? p + 68 - a * d : p - a * d, e({
                                        bottomLift: s,
                                        statusBarHeight: a,
                                        sHeight: n,
                                        screenHeight: o,
                                        windowHeight: i,
                                        windowWidth: c,
                                        screenWidth: u,
                                        modelmes: g,
                                        pixelRatio: l
                                    });
                                }
                            });
                        });
                    }
                },
                onLaunch: (i = t(e.default.mark(function t() {
                    var o, r;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            o = this, console.log("App Launch"), this.getDeviceSize().then(function(e) {
                                var t = e;
                                console.log(t), console.log(o.$store.state);
                            }), console.log(this.globalData.height), console.log(n.getSystemInfoSync().statusBarHeight), 
                            r = n.getSystemInfoSync().statusBarHeight + this.globalData.height, console.log(r), 
                            this.$store.commit("navbarHeight", r), this.$store.dispatch("isHeightPhone");

                          case 5:
                          case "end":
                            return e.stop();
                        }
                    }, t, this);
                })), function() {
                    return i.apply(this, arguments);
                }),
                onShow: function(e) {
                    var t = e.path;
                    this.$store.commit("appPath", t), console.log("App Show", e, (0, c.default)(e.scene)), 
                    this.globalData.scene = e.scene, console.log(e.scene), this.globalData.N_ENV = this.$env, 
                    n.request({
                        url: l.default.apiRoot + "/api/wxapp/baffle/getByType/homeIndex",
                        success: function(e) {
                            console.log(e), e.data.data.length > 0 && n.reLaunch({
                                url: "/pages/baffle/index"
                            });
                        }
                    });
                },
                onHide: function() {
                    n.removeStorageSync("detailinfo"), n.removeStorageSync("refreash"), n.removeStorageSync("token");
                }
            };
            o.default = s;
        }).call(this, r("543d").default);
    }
}, [ [ "5fee", "common/runtime", "common/vendor" ] ] ]);