// activity/friendHelpGame/friendHelpGame.js
Page({data: {}})