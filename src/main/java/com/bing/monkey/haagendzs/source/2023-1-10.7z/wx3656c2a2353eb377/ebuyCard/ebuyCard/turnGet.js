// ebuyCard/ebuyCard/turnGet.js
Page({data: {}})