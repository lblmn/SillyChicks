var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/winterMenu/index" ], {
    "2e50": function(e, n, t) {},
    "4db3": function(t, o, i) {
        (function(t) {
            var a = i("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var s, r = a(i("448a")), c = a(i("ac3e")), u = a(i("f3d4")), h = a(i("e8ab")), d = a(i("9296")), l = a(i("7d43")), g = a(i("8865")), f = {
                data: function() {
                    return {
                        imgoss: u.default.ossurl + "images/home",
                        isGongGao: !0,
                        isHeightScreen: !1,
                        showRead: !1,
                        listArr: [],
                        imgUrl: u.default.assetsRoot,
                        imgUrl2: u.default.assetsRoot + "/oss/wxapp/20210127/static/",
                        isFirstMenu: !1,
                        isShowBtn: !1,
                        showloginDialog: !1,
                        openid: "",
                        unionId: "",
                        aid: "",
                        showbtn: "",
                        isShowSharePopup: !1,
                        helpinfo: "Hi,还是你自己哦\n分享好友获得限量好礼哦~",
                        isShareBtn: !0,
                        isShowShareBack: !1,
                        helpinfoBack: "",
                        gobackText: ""
                    };
                },
                onLoad: function(e) {
                    var n = this;
                    l.default.isHeightPhone().then(function(e) {
                        n.isHeightScreen = e;
                    }).catch(function(e) {
                        n.isHeightScreen = e;
                    }), console.log(e), t.removeStorageSync("fromHome"), this.type = e.type, this.fromHome = e.fromHome, 
                    "fromTask" != this.type ? t.hideShareMenu() : ("all" != e.showbtn && ("all" == t.getStorageSync("isFirstMenu") ? this.isFirstMenu = !1 : (t.setStorageSync("isFirstMenu", "all"), 
                    this.isFirstMenu = !0)), this.openid = e.openid, this.unionId = e.unionId, this.showbtn = e.showbtn, 
                    "all" == e.showbtn && (this.isShowBtn = !0), this.aid = e.aid), this.getBycategory();
                },
                onShow: function() {
                    "all" == t.getStorageSync("successInfo") && (this.showRead = !0), this.isShowSharePopup = !1, 
                    "home" == t.getStorageSync("fromHome") ? (this.isShowShareBack = !0, this.helpinfoBack = "分享成功\n快去成为测评官吧，\n完成不同任务享不同好礼~", 
                    this.gobackText = "成为测评官") : "task" == t.getStorageSync("fromHome") && (this.isShowShareBack = !0, 
                    this.helpinfoBack = "分享成功\n快去完成其他任务\n享更多任务好礼~", this.gobackText = "前往任务中心");
                },
                mounted: (s = n(e.default.mark(function n() {
                    var o;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (0 != Object.keys(t.getStorageSync("logininfo")).length) {
                                e.next = 9;
                                break;
                            }
                            return console.log("微信登录"), e.next = 4, this.doLogin();

                          case 4:
                            return this.loginRes = e.sent, e.next = 7, this.getOpenid(this.loginRes);

                          case 7:
                            (o = e.sent).data.unionId && t.setStorageSync("unionId", o.data.unionId), t.setStorageSync("openId", o.data.openid);

                          case 9:
                          case "end":
                            return e.stop();
                        }
                    }, n, this);
                })), function() {
                    return s.apply(this, arguments);
                }),
                components: {
                    loginDialog: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/loginDialog") ]).then(function() {
                            return resolve(i("d6e5"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                destroyed: function() {},
                onHide: function() {},
                methods: {
                    beginAct: function() {
                        "all" == t.getStorageSync("successInfo") && (this.showRead = !0), this.isShowSharePopup = !1, 
                        "home" == t.getStorageSync("fromHome") ? (this.isShowShareBack = !0, this.helpinfoBack = "分享成功\n快去成为测评官吧，\n完成不同任务享不同好礼~", 
                        this.gobackText = "成为测评官") : "task" == t.getStorageSync("fromHome") && (this.isShowShareBack = !0, 
                        this.helpinfoBack = "分享成功\n快去完成其他任务\n享更多任务好礼~", this.gobackText = "前往任务中心");
                    },
                    gongGao: function() {
                        var e = this;
                        g.default.switches().then(function(n) {
                            console.log(n), 0 == n.code ? e.isGongGao = !0 : 500 == n.code && (e.isGongGao = !1, 
                            e.beginAct());
                        });
                    },
                    gotoBack: function() {
                        t.navigateBack({
                            delta: -1
                        });
                    },
                    readrule: function() {
                        this.showRead = !1, t.removeStorageSync("successInfo"), this.gotoHomeIndex();
                    },
                    gotoAct: function() {
                        t.redirectTo({
                            url: "../../evaluation/home/index?aid=" + this.aid
                        });
                    },
                    gotoHomeIndex: function() {
                        this.openid == t.getStorageSync("openId") ? this.isShowSharePopup = !0 : t.getStorageSync("unionId") ? (t.showLoading({
                            mask: !0,
                            title: "加载中..."
                        }), "all" == this.showbtn && (this.shareFun(), this.isShareBtn = !1, this.isShowSharePopup = !0, 
                        this.helpinfo = "赞！\n会员奢宠礼包你也可以有~", t.hideLoading())) : this.showloginDialog = !0;
                    },
                    shareFun: function() {
                        console.log(this.openid), console.log(this.unionId), console.log(t.getStorageSync("openId")), 
                        console.log(t.getStorageSync("unionId")), h.default.shareFun({
                            openId: this.openid,
                            unionId: this.unionId,
                            clickOpenId: t.getStorageSync("openId"),
                            clickUnionId: t.getStorageSync("unionId")
                        });
                    },
                    doLogin: function() {
                        return new Promise(function(e, n) {
                            t.login({
                                success: function(n) {
                                    e(n);
                                }
                            });
                        });
                    },
                    getOpenid: function(e) {
                        return d.default.login({
                            code: e.code,
                            appId: this.$env.appId
                        });
                    },
                    triggerItem: function(e) {
                        console.log(e);
                        var n = (0, r.default)(this.listArr), t = e.currentTarget.dataset.index;
                        console.log(t), 0 == this.listArr[t].height ? (n[t].height = "auto", n[t].openicon = "0", 
                        this.listArr = n) : (n[t].height = 0, n[t].openicon = "1", this.listArr = n);
                    },
                    changeContent: function(e) {
                        return e.content ? e.content : "";
                    },
                    getBycategory: function() {
                        var e = this;
                        c.default.bycategory("11").then(function(n) {
                            console.log(n), n.data.length <= 0 ? e.ruleDesc = "暂无冬季菜单信息" : (e.listArr = n.data, 
                            e.listArr.map(function(e) {
                                return e.height = "0", e.openicon = "1", e;
                            }));
                        });
                    },
                    shareRecord: function() {
                        d.default.shareRecord({
                            aid: "",
                            unionId: t.getStorageSync("unionId"),
                            openid: t.getStorageSync("openId"),
                            path: "pages/mine/rule",
                            button: "pages/mine/rule",
                            invitedOpenid: "",
                            type: "2"
                        }).then(function(e) {
                            console.log(e);
                        }).catch(function(e) {
                            console.log(e);
                        });
                    }
                },
                onShareAppMessage: function() {
                    var e = "".concat(u.default.assetsRoot, "/oss/wxapp/20210127/static/hdShare/share.png"), n = t.getStorageSync("openId"), o = t.getStorageSync("unionId");
                    return "home" == this.fromHome ? t.setStorageSync("fromHome", "home") : "task" == this.fromHome && t.setStorageSync("fromHome", "task"), 
                    console.log("pages/winterMenu/index?type=fromTask&openid=".concat(n, "&unionId=").concat(o, "&aid=").concat(this.aid)), 
                    {
                        title: "春季测评官任务进行中，为好友赢取免费赏味券和积心~",
                        path: "pages/winterMenu/index?type=fromTask&openid=".concat(n, "&unionId=").concat(o, "&aid=").concat(this.aid, "&showbtn=all"),
                        imageUrl: e
                    };
                }
            };
            o.default = f;
        }).call(this, i("543d").default);
    },
    7558: function(e, n, t) {
        (function(e) {
            var n = t("4ea4");
            t("a1ea"), n(t("66fd"));
            var o = n(t("9fd9"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(o.default);
        }).call(this, t("543d").createPage);
    },
    "9cbd": function(e, n, t) {
        t.r(n);
        var o = t("4db3"), i = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = i.a;
    },
    "9fd9": function(e, n, t) {
        t.r(n);
        var o = t("edff"), i = t("9cbd");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(a);
        t("fd19");
        var s = t("f0c5"), r = Object(s.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = r.exports;
    },
    edff: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this, n = (e.$createElement, e._self._c, e.__map(e.listArr, function(n, t) {
                return {
                    $orig: e.__get_orig(n),
                    l0: e.__map(n.gifts, function(n, t) {
                        return {
                            $orig: e.__get_orig(n),
                            m0: e.changeContent(n),
                            g0: n.ruleDesc.replace(/\n/g, "<br/>")
                        };
                    })
                };
            }));
            e._isMounted || (e.e0 = function(n) {
                n.stopPropagation(), e.isFirstMenu = !1;
            }, e.e1 = function(n) {
                e.isShowSharePopup = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    l1: n
                }
            });
        }, i = [];
    },
    fd19: function(e, n, t) {
        var o = t("2e50");
        t.n(o).a;
    }
}, [ [ "7558", "common/runtime", "common/vendor" ] ] ]);