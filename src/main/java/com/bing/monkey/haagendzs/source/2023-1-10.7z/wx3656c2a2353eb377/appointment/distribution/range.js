// appointment/distribution/range.js
Page({data: {}})