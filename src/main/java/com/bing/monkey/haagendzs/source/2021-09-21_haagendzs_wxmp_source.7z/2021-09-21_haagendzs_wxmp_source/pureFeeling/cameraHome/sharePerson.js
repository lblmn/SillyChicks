// pureFeeling/cameraHome/sharePerson.js
Page({data: {}})