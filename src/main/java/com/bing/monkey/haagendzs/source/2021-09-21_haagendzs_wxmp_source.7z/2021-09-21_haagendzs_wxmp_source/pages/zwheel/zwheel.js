(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/zwheel/zwheel" ], {
    "3af3": function(t, e, n) {},
    4057: function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return s;
        }), n.d(e, "a", function() {
            return o;
        });
        var o = {
            myTurntableDraw: function() {
                return n.e("components/my-turntable-draw/my-turntable-draw").then(n.bind(null, "b926"));
            }
        }, i = function() {
            var t = this, e = (t.$createElement, t._self._c, 0 != t.giftsRecord.length ? t.__map(t.giftsRecord, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    g0: e.createTime.substring(0, 11)
                };
            }) : null);
            t._isMounted || (t.e0 = function(e) {
                t.showJoin = !1;
            }, t.e1 = function(e) {
                t.showWinner = !1;
            }, t.e2 = function(e) {
                t.showRegret = !1;
            }, t.e3 = function(e) {
                t.showObtain = !1;
            }, t.e4 = function(e) {
                t.showclose = !1;
            }, t.e5 = function(e) {
                t.showMessage = !1;
            }, t.e6 = function(e) {
                t.showCity = !0;
            }, t.e7 = function(e) {
                t.showclose = !1;
            }, t.e8 = function(e) {
                t.showCity = !1;
            }, t.e9 = function(e) {
                t.showRecord = !1;
            }, t.e10 = function(e) {
                t.showDetail = !1;
            }, t.e11 = function(e) {
                t.showDetail = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, s = [];
    },
    5960: function(t, e, n) {
        (function(t) {
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            n("f4aa"), e(n("66fd")), t(e(n("f5ac")).default);
        }).call(this, n("543d").createPage);
    },
    "77ee": function(t, e, n) {
        var o = n("3af3");
        n.n(o).a;
    },
    "8e0c": function(t, e, n) {
        n.r(e);
        var o = n("d837"), i = n.n(o);
        for (var s in o) "default" !== s && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(s);
        e.default = i.a;
    },
    d837: function(t, e, n) {
        (function(t) {
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function i(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function s(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? i(Object(n), !0).forEach(function(e) {
                        r(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function r(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            function a(t, e, n, o, i, s, r) {
                try {
                    var a = t[s](r), c = a.value;
                } catch (t) {
                    return void n(t);
                }
                a.done ? e(c) : Promise.resolve(c).then(o, i);
            }
            function c(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(o, i) {
                        function s(t) {
                            a(c, o, i, s, r, "next", t);
                        }
                        function r(t) {
                            a(c, o, i, s, r, "throw", t);
                        }
                        var c = t.apply(e, n);
                        s(void 0);
                    });
                };
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var u = o(n("a34a")), l = o(n("428a")), h = o(n("c1b5"));
            o(n("54de"));
            var d = getApp().globalData.N_ENV.assetsRoot, f = {
                name: "zwheel",
                components: {
                    myTurntableDraw: function() {
                        n.e("components/my-turntable-draw/my-turntable-draw").then(function() {
                            return resolve(n("b926"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("a81e"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        resultMsg: "积心余额不足",
                        showJoin: !1,
                        showWinner: !1,
                        showRegret: !1,
                        showObtain: !1,
                        showMessage: !1,
                        showCity: !1,
                        showclose: !1,
                        showcloses: !1,
                        showbuild: !1,
                        form: {
                            username: "",
                            address: "",
                            phone: "",
                            area: ""
                        },
                        cityvalue: "",
                        areaList: h.default,
                        boxData: {
                            width: 560,
                            height: 560
                        },
                        prizeList: [],
                        targetIndex: 0,
                        lotteryId: "",
                        requiredPoints: 0,
                        showRecord: !1,
                        giftsRecord: [],
                        showDetail: !1,
                        giftObj: {},
                        recordButton: !1,
                        activeName: "",
                        isEdit: !1,
                        editName: "",
                        showloginDialog: !1,
                        rulebtn: !1,
                        ruleInfo: "",
                        isshowEntity: !1,
                        isshowGotoCardBtn: !1,
                        lotteryRecordId: ""
                    };
                },
                onLoad: function(t) {
                    var e = this;
                    return c(u.default.mark(function n() {
                        return u.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                e.lotteryId = t.id, e.recordButton = 1 == t.record;

                              case 2:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                onShow: function() {
                    this.getGiftList(), this.showloginDialog = !0;
                },
                onHide: function() {
                    this.showloginDialog = !1;
                },
                methods: {
                    oncityConfirm: function(t) {
                        var e = t.detail.values;
                        console.log(e), this.cityvalue = e, this.form.area = "", this.cityvalue[0].name == this.cityvalue[1].name ? this.form.area = this.cityvalue[0].name : this.form.area = this.cityvalue[0].name + this.cityvalue[1].name, 
                        console.log(this.form.area), this.showCity = !1;
                    },
                    getActivelist: function() {
                        return l.default.getList({
                            id: this.lotteryId
                        });
                    },
                    getGiftList: function() {
                        var t = this;
                        return c(u.default.mark(function e() {
                            var n;
                            return u.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, t.getActivelist();

                                  case 2:
                                    (n = e.sent).data[0].ruleDesc && n.data[0].ruleDesc.length > 0 && (t.rulebtn = !0, 
                                    t.ruleInfo = n.data[0].ruleDesc.replace(/\n/g, "<br/>")), t.requiredPoints = n.data[0].requiredPoints, 
                                    t.activeName = n.data[0].name, l.default.getGiftList({
                                        lotteryId: t.lotteryId
                                    }).then(function(e) {
                                        if (0 != e.data.length) e.data.forEach(function(e) {
                                            t.prizeList.push(s(s({}, e), {}, {
                                                name: 1 == e.type ? "谢谢惠顾" : e.lotteryLevel ? e.lotteryLevel + "-" + e.name : "-" + e.name
                                            })), t.prizeList.forEach(function(t) {
                                                "谢谢惠顾" == t.name ? t.image = d + "/oss/coffee.png" : t.image = d + t.imgUrl;
                                            });
                                        }); else for (var n = 0; n < 6; n++) t.prizeList.push({
                                            name: "谢谢惠顾",
                                            image: d + "/oss/coffee.png"
                                        });
                                    });

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    goattendance: function() {
                        t.navigateTo({
                            url: "/pages/attendance/attendance"
                        });
                    },
                    goToCard: function() {
                        t.navigateTo({
                            url: "/pages/mine/mycard"
                        });
                    },
                    befoterClick: function(t) {
                        "start" == t.type && t.callback && t.callback(this.targetIndex);
                    },
                    afterClick: function(t) {
                        console.log(t), "end" == t.type && (console.log(this.targetIndex), "1" == this.prizeList[this.targetIndex].type ? this.showWinner = !0 : ("0" == this.prizeList[this.targetIndex].type ? this.isshowEntity = !0 : this.isshowGotoCardBtn = !0, 
                        this.showRegret = !0), t.callback && t.callback());
                    },
                    doWheel: function() {
                        if (this.$refs.wheel.isClick) {
                            var e = this;
                            t.requestSubscribeMessage({
                                tmplIds: [ "k7IePaN3GhM_le23Smb1B9io6h96gOT5jEO6jz_wH78" ],
                                complete: function(t) {
                                    console.log("getSubscribe success"), e.showJoin = !0;
                                }
                            });
                        } else t.showToast({
                            title: "正在抽奖请稍后",
                            icon: "none"
                        });
                    },
                    confirmHandler: function(e) {
                        var n = this;
                        e && l.default.draw({
                            openid: t.getStorageSync("openId"),
                            unionId: t.getStorageSync("unionId")
                        }, this.lotteryId).then(function(t) {
                            console.log(JSON.stringify(t)), -1 == t.code ? (n.resultMsg = t.msg, n.showObtain = !0) : 0 == t.code && (n.isEdit = !1, 
                            n.targetIndex = t.data.sort - 1, n.lotteryRecordId = t.data.lotteryRecordId ? t.data.lotteryRecordId : "", 
                            n.$refs.wheel.handleAction());
                        }), this.showJoin = !1, this.showWinner = !1, this.showRegret = !1, this.showObtain = !1, 
                        this.showMessage = !1, this.showclose = !1, this.showcloses = !1, this.showbuild = !1, 
                        this.isshowEntity = !1, this.isshowGotoCardBtn = !1;
                    },
                    gohome: function() {
                        var e = this, n = /^1\d{10}$/;
                        this.form.username ? this.form.phone ? n.test(this.form.phone) ? this.form.area ? this.form.address ? (this.showMessage = !1, 
                        l.default.giftSendMessageNew(this.lotteryRecordId, {
                            giftName: this.isEdit ? this.editName : this.prizeList[this.targetIndex].name,
                            userName: this.form.username,
                            mobile: this.form.phone,
                            address: this.form.area + this.form.address,
                            unionId: t.getStorageSync("unionId"),
                            lotteryId: this.lotteryId
                        }).then(function(n) {
                            0 == n.code && (e.form = {
                                username: "",
                                address: "",
                                phone: "",
                                area: ""
                            }, t.showToast({
                                title: "提交成功……",
                                mask: !0,
                                duration: 1e3
                            }));
                        })) : t.showToast({
                            title: "请输入详细地址",
                            icon: "none"
                        }) : t.showToast({
                            title: "请选择地址",
                            icon: "none"
                        }) : t.showToast({
                            title: "手机号格式不正确",
                            icon: "none"
                        }) : t.showToast({
                            title: "手机号不能为空",
                            icon: "none"
                        }) : t.showToast({
                            title: "姓名不能为空",
                            icon: "none"
                        });
                    },
                    guize: function() {
                        var e = this;
                        return c(u.default.mark(function n() {
                            var o;
                            return u.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, l.default.getRule(e.lotteryId);

                                  case 2:
                                    (o = n.sent).data.ruleDesc && o.data.ruleDesc.length > 0 ? (e.ruleInfo = o.data.ruleDesc.replace(/\n/g, "<br/>"), 
                                    e.showbuild = !0) : t.showToast({
                                        title: "请求错误",
                                        icon: "none"
                                    });

                                  case 4:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    goquxiao: function() {
                        this.showclose = !1;
                    },
                    goquxiaos: function() {
                        this.showcloses = !1, this.showMessage = !0;
                    },
                    popupclose: function() {
                        this.isshowGotoCardBtn ? this.showRegret = !1 : this.showclose = !0;
                    },
                    closebutton: function() {
                        this.showcloses = !0;
                    },
                    goToInfoPage: function() {
                        this.showRegret = !1, this.showMessage = !0;
                    },
                    nameChange: function(t) {
                        var e = t.detail;
                        this.form.username = e;
                    },
                    phoneChange: function(t) {
                        var e = t.detail;
                        this.form.phone = e;
                    },
                    descInput: function(t) {
                        var e = t.detail;
                        this.form.address = e.value;
                    },
                    addressChange: function(t) {
                        var e = t.detail;
                        this.form.address = e;
                    },
                    getLotteryRecord: function() {
                        var e = this;
                        this.showRecord = !0, l.default.lotteryRecord({
                            unionId: t.getStorageSync("unionId"),
                            lotteryId: this.lotteryId
                        }).then(function(n) {
                            0 == n.code ? (e.giftsRecord = n.data, e.lotteryRecordId = n.data[0].id ? n.data[0].id : "") : t.showToast({
                                title: "中奖列表请求异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    showGiftObj: function(e) {
                        "2" == e.type ? t.navigateTo({
                            url: "/pages/mine/mycard"
                        }) : e.winningRecord ? (this.giftObj = s({}, e.winningRecord), this.showDetail = !0) : (this.isEdit = !0, 
                        this.editName = e.name, this.showRecord = !1, this.showMessage = !0);
                    }
                }
            };
            e.default = f;
        }).call(this, n("543d").default);
    },
    f5ac: function(t, e, n) {
        n.r(e);
        var o = n("4057"), i = n("8e0c");
        for (var s in i) "default" !== s && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(s);
        n("77ee");
        var r = n("f0c5"), a = Object(r.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = a.exports;
    }
}, [ [ "5960", "common/runtime", "common/vendor" ] ] ]);