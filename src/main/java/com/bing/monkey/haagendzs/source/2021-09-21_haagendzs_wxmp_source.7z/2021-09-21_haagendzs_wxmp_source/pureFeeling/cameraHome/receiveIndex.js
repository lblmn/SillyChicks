// pureFeeling/cameraHome/receiveIndex.js
Page({data: {}})