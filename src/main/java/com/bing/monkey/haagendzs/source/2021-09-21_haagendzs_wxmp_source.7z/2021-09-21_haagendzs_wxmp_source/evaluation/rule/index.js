// evaluation/rule/index.js
Page({data: {}})