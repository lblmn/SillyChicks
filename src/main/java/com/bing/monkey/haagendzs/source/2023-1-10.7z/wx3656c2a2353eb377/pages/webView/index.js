(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webView/index" ], {
    "2d49": function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    3383: function(e, n, t) {
        (function(e) {
            var n = t("4ea4");
            t("a1ea"), n(t("66fd"));
            var o = n(t("e4c8"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(o.default);
        }).call(this, t("543d").createPage);
    },
    "44c3": function(e, n, t) {
        t.r(n);
        var o = t("7795"), r = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = r.a;
    },
    7795: function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var o = {
            data: function() {
                return {
                    webviewStyles: {
                        progress: {
                            color: "#FF3333"
                        }
                    },
                    url: ""
                };
            },
            onLoad: function(e) {
                console.log(e), console.log(Object.keys(e));
                var n = "https://www.gmfs-ecoupon.com/hgdz_delivery/doEntry", t = "";
                if (Object.keys(e).length > 0) {
                    for (var o in e) t += "".concat(o, "=").concat(e[o], "&");
                    t = t.substring(0, t.length - 1), this.url = n + "?serviceMethod=deliveryEntry&" + t;
                } else this.url = n + "?serviceMethod=deliveryEntry";
                console.log(this.url);
            }
        };
        n.default = o;
    },
    e4c8: function(e, n, t) {
        t.r(n);
        var o = t("2d49"), r = t("44c3");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        var u = t("f0c5"), i = Object(u.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = i.exports;
    }
}, [ [ "3383", "common/runtime", "common/vendor" ] ] ]);