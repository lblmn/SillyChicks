// blindBox/member/home.js
Page({data: {}})