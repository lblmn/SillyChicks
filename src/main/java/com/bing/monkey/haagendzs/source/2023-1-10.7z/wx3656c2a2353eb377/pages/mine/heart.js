var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/heart" ], {
    "042a": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this, t = (e.$createElement, e._self._c, e.__map(e.cardList, function(t, n) {
                return {
                    $orig: e.__get_orig(t),
                    g0: 2 == e.index ? t.num.replace("+", "") : null
                };
            }));
            e._isMounted || (e.e0 = function(t) {
                e.showbuild = !1;
            }, e.e1 = function(t) {
                e.showbuild = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    l0: t
                }
            });
        }, i = [];
    },
    4468: function(e, t, n) {
        n.r(t);
        var o = n("042a"), i = n("8db6");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("b151");
        var a = n("f0c5"), c = Object(a.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    "5df6": function(n, o, i) {
        (function(n) {
            var r = i("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a = r(i("9523")), c = r(i("f3d4")), u = r(i("8cab")), s = r(i("0098")), d = r(i("7d43")), l = i("26cb"), f = r(i("5db4"));
            function g(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function h(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? g(Object(n), !0).forEach(function(t) {
                        (0, a.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : g(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var p, b = {
                components: {
                    uniIcons: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(i("6093"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    Zdetail: function() {
                        i.e("components/Zdetail").then(function() {
                            return resolve(i("73ef"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/loginDialog_new") ]).then(function() {
                            return resolve(i("5972"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    Loading: function() {
                        i.e("components/loading").then(function() {
                            return resolve(i("64ff"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                data: function() {
                    return {
                        showbuild: !1,
                        cardList: [],
                        nextId: "",
                        pageSize: 50,
                        noMore: !1,
                        ruleDesc: "",
                        imgux: c.default.ossurl + "UX/mine/heart/",
                        index: 0,
                        showloginDialog: !1
                    };
                },
                onLoad: (p = t(e.default.mark(function t(n) {
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            console.log(n), n.index && (this.index = n.index ? n.index : 0), d.default.setSource(n);

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, t, this);
                })), function(e) {
                    return p.apply(this, arguments);
                }),
                computed: h({}, (0, l.mapState)([ "points", "pointAccountId" ])),
                watch: {
                    pointAccountId: {
                        handler: function(e, t) {
                            e && this.getList();
                        },
                        deep: !0
                    }
                },
                onShow: function() {
                    Object.keys(n.getStorageSync("logininfo")).length > 0 ? (d.default.recordPv(), this.getRecord(), 
                    this.$store.dispatch("getPoint"), this.cardList.length <= 0 && this.getList(), this.$refs.Loading.hideLoading()) : (this.$refs.Loading.showLoading(), 
                    this.showloginDialog = !0);
                },
                methods: {
                    getmemberSuccess: function(e) {
                        console.log(e), "all" == e ? (this.showloginDialog = !1, d.default.recordPv(), this.getRecord(), 
                        this.$store.dispatch("getPoint"), this.$refs.Loading.hideLoading()) : "error" == e && this.$refs.Loading.hideLoading();
                    },
                    getRecord: function(e) {
                        f.default.saveLoginRecord({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId"),
                            source: e || n.getStorageSync("smsSource")
                        }, !1);
                    },
                    changeIndex: function(e) {
                        this.index = e, this.cardList = [], this.nextId = "", this.getList();
                    },
                    gobuild: function() {
                        this.getRuleDesc();
                    },
                    getList: function() {
                        var e = this, t = "";
                        0 == this.index ? t = {
                            idType: 1,
                            id: n.getStorageSync("socialhubId"),
                            pointAccountId: n.getStorageSync("pointAccountId"),
                            operationType: 0,
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        } : 1 == this.index ? t = {
                            idType: 1,
                            id: n.getStorageSync("socialhubId"),
                            pointAccountId: n.getStorageSync("pointAccountId"),
                            operationType: 0,
                            nextId: this.nextId,
                            direction: 100000001,
                            pageSize: this.pageSize
                        } : 2 == this.index && (t = {
                            idType: 1,
                            id: n.getStorageSync("socialhubId"),
                            pointAccountId: n.getStorageSync("pointAccountId"),
                            operationType: 200000001,
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        }), "" == this.nextId && delete t.nextId, u.default.pointList(t).then(function(t) {
                            if (n.hideLoading(), 0 == t.resultCode) {
                                if (t.data.nextId && (e.nextId = t.data.nextId), 0 == t.data.list.length) return void (e.noMore = !0);
                                t.data.list.forEach(function(t) {
                                    e.cardList.push(h(h({}, t), {}, {
                                        name: e.filterName(t.operationType, t.name),
                                        num: e.numFun(t.point)
                                    }));
                                });
                            }
                        });
                    },
                    numFun: function(e) {
                        var t = "";
                        return (t = parseInt(e) == parseFloat(e) ? e : parseFloat(e).toFixed(2)) >= 0 && (t = "+" + t), 
                        t;
                    },
                    getRuleDesc: function() {
                        var e = this;
                        s.default.getRuledesc({
                            type: 2
                        }).then(function(t) {
                            e.ruleDesc = t.data[0].content, e.showbuild = !0;
                        });
                    },
                    filterName: function(e, t) {
                        switch (e) {
                          case 1e8:
                            return "交易积心";

                          case 100000001:
                            return "交易促销积心";

                          case 100000002:
                            return "人工积心调整增加";

                          case 100000003:
                            return "人工积心调整积心减少";

                          case 100000004:
                            return "积心兑换礼品";

                          case 100000005:
                            return "积心兑换优惠券";

                          case 100000006:
                            return "行为增加积心";

                          case 100000007:
                            switch (t) {
                              case "抽奖活动->月饼金字塔盲盒":
                                return "中秋抽盒减少积心";

                              default:
                                return "行为减少积心";
                            }

                          case 100000008:
                            return "退货积心冲销";

                          case 100000009:
                            return "积心兑换取消积心返回";

                          case 100000010:
                            return "积心过期";

                          case 100000013:
                            return "中秋积心";

                          default:
                            return "交易积心";
                        }
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (n.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), this.getList());
                    }
                }
            };
            o.default = b;
        }).call(this, i("543d").default);
    },
    "8db6": function(e, t, n) {
        n.r(t);
        var o = n("5df6"), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = i.a;
    },
    "96aa": function(e, t, n) {
        (function(e) {
            var t = n("4ea4");
            n("a1ea"), t(n("66fd"));
            var o = t(n("4468"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(o.default);
        }).call(this, n("543d").createPage);
    },
    b151: function(e, t, n) {
        var o = n("da8c");
        n.n(o).a;
    },
    da8c: function(e, t, n) {}
}, [ [ "96aa", "common/runtime", "common/vendor" ] ] ]);