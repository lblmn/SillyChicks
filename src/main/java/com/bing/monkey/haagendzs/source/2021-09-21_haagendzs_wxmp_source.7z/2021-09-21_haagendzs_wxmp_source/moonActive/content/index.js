// moonActive/content/index.js
Page({data: {}})