// moonActive/ranking/lastIndex.js
Page({data: {}})