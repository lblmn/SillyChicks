var e = require("../@babel/runtime/helpers/interopRequireDefault")(require("../@babel/runtime/helpers/typeof"));

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    "1cf6": function(e, t, o) {
        o.r(t);
        var n = o("6244"), r = o.n(n);
        for (var a in n) "default" !== a && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(a);
        t.default = r.a;
    },
    "33fc": function(e, t, o) {
        o.r(t);
        var n = o("1cf6");
        for (var r in n) "default" !== r && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(r);
        o("d41f");
        var a = o("f0c5"), i = Object(a.a)(n.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = i.exports;
    },
    6244: function(t, o, n) {
        (function(t) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var r = i(n("500b")), a = i(n("f0fd"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var c = {
                globalData: {
                    PointAccountResult: [],
                    PointAccount: 0,
                    PointJidou: 0,
                    deadHeart: 0,
                    deadBean: 0,
                    scene: Number,
                    N_ENV: {},
                    isbackfromSaveWXCard: "",
                    istransfer: !1,
                    globalNetWork: "",
                    isnewMember: !1,
                    getFirstTip: !1,
                    height: 44,
                    navbarHeight: 0
                },
                methods: {
                    login: function() {
                        return new Promise(function(e, o) {
                            t.getStorageSync("token") ? e(t.getStorageSync("token")) : t.request({
                                url: "https://uatscrm-haagendazs.smarket.com.cn/v1/api/wxapp/banner/getList",
                                method: "get",
                                header: {
                                    Authorization: "Bearer " + t.getStorageSync("token")
                                }
                            }).then(function(e) {
                                console.log("??", e);
                            });
                        });
                    },
                    loadFontFace: function() {
                        t.loadFontFace({
                            family: "Bitstream",
                            source: 'url("https://haagendazs-oss.smarket.com.cn/Pacifico.ttf")',
                            success: function() {
                                console.log("success");
                            }
                        });
                    },
                    showBaffle: function() {
                        r.default.baffleGetByType("homeIndex").then(function(e) {
                            console.log(e);
                        });
                    },
                    getDeviceSize: function() {
                        return new Promise(function(e, o) {
                            t.getSystemInfo({
                                success: function(t) {
                                    console.log("用户手机型号:", t);
                                    var o, n = t.screenHeight, r = t.safeArea, a = t.statusBarHeight, i = t.windowHeight, c = t.windowWidth, u = t.screenWidth, l = t.pixelRatio, f = n - r.bottom, s = t.windowHeight, d = 750 / t.windowWidth, p = s * d, g = t.model;
                                    o = -1 != g.search("iPhone X") ? p + 68 - a * d : p - a * d, e({
                                        bottomLift: f,
                                        statusBarHeight: a,
                                        sHeight: o,
                                        screenHeight: n,
                                        windowHeight: i,
                                        windowWidth: c,
                                        screenWidth: u,
                                        modelmes: g,
                                        pixelRatio: l
                                    });
                                }
                            });
                        });
                    }
                },
                onLaunch: function() {
                    var e = this;
                    console.log("App Launch");
                    var o = this;
                    this.getDeviceSize().then(function(t) {
                        var o = t;
                        console.log(o), console.log(e.$store.state);
                    }), console.log(o.globalData.height), console.log(t.getSystemInfoSync().statusBarHeight);
                    var n = t.getSystemInfoSync().statusBarHeight + o.globalData.height;
                    console.log(n), o.$store.commit("navbarHeight", n), o.$store.dispatch("isHeightPhone");
                },
                onShow: function(o) {
                    var n = o.path;
                    this.$store.commit("appPath", n), console.log("App Show", o, (0, e.default)(o.scene)), 
                    this.globalData.scene = o.scene, console.log(o.scene), this.globalData.N_ENV = this.$env, 
                    t.request({
                        url: a.default.apiRoot + "/api/wxapp/baffle/getByType/homeIndex",
                        success: function(e) {
                            console.log(e), e.data.data.length > 0 && t.reLaunch({
                                url: "/pages/baffle/index"
                            });
                        }
                    });
                },
                onHide: function() {
                    t.removeStorageSync("detailinfo"), t.removeStorageSync("refreash"), t.removeStorageSync("token");
                }
            };
            o.default = c;
        }).call(this, n("543d").default);
    },
    7815: function(t, o, n) {
        (function(t, o) {
            n("c0e2");
            var r = g(n("66fd")), a = g(n("33fc"));
            n("0ca3");
            var i = g(n("5a1c")), c = g(n("eb5f")), u = g(n("234f")), l = g(n("f0fd")), f = function(t) {
                if (t && t.__esModule) return t;
                if (null === t || "object" !== (0, e.default)(t) && "function" != typeof t) return {
                    default: t
                };
                var o = p();
                if (o && o.has(t)) return o.get(t);
                var n = {}, r = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in t) if (Object.prototype.hasOwnProperty.call(t, a)) {
                    var i = r ? Object.getOwnPropertyDescriptor(t, a) : null;
                    i && (i.get || i.set) ? Object.defineProperty(n, a, i) : n[a] = t[a];
                }
                return n.default = t, o && o.set(t, n), n;
            }(n("c8e8")), s = g(n("f322")), d = g(n("19b2"));
            function p() {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap();
                return p = function() {
                    return e;
                }, e;
            }
            function g(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function h(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function b(e, t, o) {
                return t in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e;
            }
            var m = t.getAccountInfoSync().miniProgram.envVersion;
            "trial" != m && "release" != m || f.init({
                dsn: "https://139ce576166a4574b0f4f09a8b44513f@newsentry.smarket.com.cn/2"
            }), r.default.config.productionTip = !1, r.default.prototype.$toast = s.default, 
            r.default.prototype.$dialog = d.default, a.default.mpType = "app", r.default.prototype.$onLaunched = new Promise(function(e) {
                r.default.prototype.$isResolve = e;
            }), r.default.prototype.$http = c.default, r.default.prototype.$util = u.default, 
            r.default.prototype.$env = l.default, r.default.prototype.$store = i.default, console.log("进来了");
            var v = new r.default(function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? h(Object(o), !0).forEach(function(t) {
                        b(e, t, o[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : h(Object(o)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
                    });
                }
                return e;
            }({
                store: i.default
            }, a.default));
            o(v).$mount();
        }).call(this, n("543d").default, n("543d").createApp);
    },
    d41f: function(e, t, o) {
        var n = o("ef04");
        o.n(n).a;
    },
    ef04: function(e, t, o) {}
}, [ [ "7815", "common/runtime", "common/vendor" ] ] ]);