// moonActive/luckDraw/index.js
Page({data: {}})