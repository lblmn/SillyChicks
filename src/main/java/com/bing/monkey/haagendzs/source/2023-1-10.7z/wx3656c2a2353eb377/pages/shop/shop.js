(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/shop/shop" ], {
    "4fc6": function(e, t, n) {
        n.r(t);
        var o = n("d7cb"), i = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    },
    8892: function(e, t, n) {
        (function(e) {
            var t = n("4ea4");
            n("a1ea"), t(n("66fd"));
            var o = t(n("a33b"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(o.default);
        }).call(this, n("543d").createPage);
    },
    a33b: function(e, t, n) {
        n.r(t);
        var o = n("f2c1"), i = n("4fc6");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("adc8");
        var s = n("f0c5"), c = Object(s.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    aba8: function(e, t, n) {},
    adc8: function(e, t, n) {
        var o = n("aba8");
        n.n(o).a;
    },
    d7cb: function(e, t, n) {
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n("9523")), a = (o(n("f9e2")), o(n("0098"))), s = (o(n("9296")), o(n("5db4"))), c = o(n("7d43")), r = o(n("f3d4")), u = o(n("8865")), d = (o(n("bed4")), 
            n("26cb"));
            function l(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function h(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(n), !0).forEach(function(t) {
                        (0, i.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var g = getApp(), f = g.globalData.N_ENV.assetsRoot, p = {
                name: "shop",
                components: {
                    Zcard: function() {
                        n.e("components/Zcard").then(function() {
                            return resolve(n("0e95"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("d6e5"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    Loading: function() {
                        n.e("components/loading").then(function() {
                            return resolve(n("64ff"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    headerimg: function() {
                        n.e("components/headerimg").then(function() {
                            return resolve(n("09c2"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        imgoss: r.default.ossurl + "images/home",
                        imgshop: r.default.ossurl + "UX/shop",
                        isGongGao: !0,
                        isHeightScreen: !1,
                        showType: 0,
                        searchValue: "",
                        tabs: [],
                        tabActive: "",
                        mainTabs: [ {
                            title: "积心兑好礼",
                            name: 0
                        }, {
                            title: "集豆兑好礼",
                            name: 1
                        } ],
                        mainTabActive: 0,
                        cardList: [],
                        offset: 0,
                        limit: 10,
                        noMore: !1,
                        channel: 1,
                        showloginDialog: !1,
                        pointAccount: 0,
                        PointJidou: 0,
                        deadHeart: 0,
                        deadBean: 0,
                        remberActive: "",
                        ruleDesc: "<p><b>积心规则</b></p><p>消费1元积1心，积心当天到账</p><p><br/></p><p><b>积心有效期</b></p><p>自该笔积心获得当日起1年内有效，每笔积心有效期单独计算。例:2020年6月1日获得的积心将在2021年5月31日到期。积心有效期不会因会籍的升降而受到影响。</p><p><br/></p><p><b>积心条件</b></p><p>在哈根达斯门店或线上点单小程序，出示会员身份后，使用现金、银行卡、支付宝、微信支付方式所进行的购买可实时获得积心；</p><p>通过官方合作的第三方平台（如哈根达斯天猫旗舰店、美团团购、大众点评等）以会员身份购买的电子券，到店使用时出示会员码后的1~3个工作日内积心到账；</p><p>在积心商城“积心+现金”兑购产品时，支付现金部分皆不可参与积心；</p><p>尊礼卡、代金券、月饼提领券（含电子兑换券/纸质兑换券）到门店或提领点核销使用均不能累积（获得）积心。（因尊礼卡、代金券购买时已获得积心、月饼提领券为特殊商品，购买时已享受对应优惠或获得积心，故核销时不能累计获得积心）。</p><p><br/></p><p><b>积心兑换规则</b></p><p>在积心商城选择兑换产品，选择兑换数量并提交，兑换成功后电子券将发放至 “我的券包”。</p><p>如选择的兑换产品需支付现金，兑换提交且支付成功后，兑换成功后电子券将发放至 “我的券包”。</p><p>在积心商城兑换的电子券一旦兑换成功，不予退换。</p><p>电子兑换券（除月饼冰淇淋电子券）适用于中国大陆地区哈根达斯冰淇淋专卖店（机场店，高铁店，景点店，联营店除外）。</p><p>所有电子券兑换码为唯一码且仅限使用一次，请在有效期内使用，过期视为自动放弃。</p><p><br/></p><p><b>当季月饼冰淇淋兑换注意事项</b></p><p>月饼冰淇淋兑换券一经选择电子券提领或纸质券提领，无法变更；</p><p>月饼冰淇淋兑换券一经兑换，不退不换；</p><p>部分地区不参与，请先参考兑换详情对应规则；</p><p>月饼冰淇淋兑换券可由用户在积心+现金兑购时自行选择电子兑换券或者纸质兑换券，若选择电子兑换券，将会于兑购成功后发放至“我的券包”；</p><p>如需兑购纸质兑换券，务必在填写收货信息时正确填写地址及联系方式，并自行支付寄送物流费（上海市内10元，其他省市地区20元，同一用户一天内下单同一收货地址将只收取一次运费）；品牌将于5-10个工作日内安排寄送纸质兑换券，届时请自行关注物流信息，无法加急；纸质券数量有限，先到先得；</p><p>若因联系方式或地址填写错误导致的丢件或寄送失败，品牌将不予安排补发；</p><p>纸质券提领城市默认上海，若需变更提领地点，请在兑换后前往哈根达斯公众号-月饼专区-异地换券进行变更提领城市处理；异地换券需在9/14前完成；</p><p>需凭相应电子或纸质兑换券在有效期内至指定城市指定提领点进行兑换（具体提领信息可参见“哈根达斯”微信公众号-“月饼专区”-“月饼|提领点查询”）；</p><p>在积心商城“积心+现金”兑购月饼冰淇淋兑换券时，每个系列上限20套；</p><p>购买月饼冰淇淋若需开票请联系客服-会员热线：400-820-7917；</p><p>具体兑换规则见券面详情。</p><p><br/></p>",
                        noScroll: !1,
                        showbuild: !1,
                        tabFrom: "",
                        ruleDesc_a: "",
                        showbuild_a: !1,
                        showIcon: !0,
                        aid_a: "",
                        showIcon_btn: !1,
                        isHasHeadimg: !1,
                        widthXP: 0,
                        ruleDesc_a_title: "",
                        qycode: ""
                    };
                },
                onLoad: function(t) {
                    var n = this;
                    c.default.isHeightPhone().then(function(e) {
                        n.isHeightScreen = e;
                    }).catch(function(e) {
                        n.isHeightScreen = e;
                    }), c.default.setSource(t);
                    var o = e.getStorageSync("qycode"), i = t.code;
                    this.qycode = o, i && (this.qycode = i, o && o != i && e.removeStorageSync("qyStartTime"));
                    var a = t.tabFrom ? t.tabFrom : "pointA";
                    this.tabFrom = a, "pointA" == a ? (this.tabActive = 1, this.remberActive = 1) : "pointB" == a ? (this.tabActive = 2, 
                    this.remberActive = 2) : "pointC" == a && (this.tabActive = 3, this.remberActive = 3), 
                    this.getGiftCategory();
                },
                onShow: function() {
                    var t = this;
                    if (e.getBackgroundAudioManager().stop(), this.$refs.Loading.showLoading(), Object.keys(e.getStorageSync("logininfo")).length > 0) {
                        this.getPoint().then(function(e) {
                            t.$refs.Loading.hideLoading();
                        }).catch(function() {
                            t.$refs.Loading.hideLoading();
                        }), this.$store.dispatch("existsSignIn"), c.default.recordPv(), this.getRecord(), 
                        this.getList(), this.isqyTimeOver();
                        var n = new Date(), o = c.default.dateFormat("YYYY-mm-dd", n);
                        c.default.timeDiffAll(o, "2022-08-15", "2022-09-10") ? this.showIcon_btn = !0 : this.showIcon_btn = !1;
                    } else this.showloginDialog = !0;
                },
                computed: h(h({}, (0, d.mapState)([ "points", "nextMonthExpiredPoints", "userinfo", "wxuserinfoAvatar", "signInCount" ])), (0, 
                d.mapGetters)([ "userinfoBg", "userinfoType", "signInCountNum", "signAgain" ])),
                onHide: function() {
                    this.showFlag = !1, this.showObtain = !1;
                },
                methods: h(h({}, (0, d.mapActions)([ "getPoint" ])), {}, {
                    beginAct: function() {
                        var t = this;
                        e.getBackgroundAudioManager().stop(), this.$refs.Loading.showLoading(), Object.keys(e.getStorageSync("logininfo")).length > 0 ? (this.getPoint().then(function(e) {
                            console.log(e), t.$refs.Loading.hideLoading();
                        }).catch(function() {
                            t.$refs.Loading.hideLoading();
                        }), c.default.recordPv(), this.getRecord()) : this.showloginDialog = !0;
                    },
                    gongGao: function() {
                        var e = this;
                        u.default.switches().then(function(t) {
                            console.log(t), 0 == t.code ? e.isGongGao = !0 : 500 == t.code && (e.isGongGao = !1, 
                            e.beginAct());
                        });
                    },
                    isqyTimeOver: function() {
                        if (this.qycode) if (e.setStorageSync("qycode", this.qycode), e.getStorageSync("qyStartTime")) {
                            var t = e.getStorageSync("qyStartTime"), n = new Date().getTime() - t;
                            n >= 36e5 && (e.removeStorageSync("qyStartTime"), e.removeStorageSync("qycode")), 
                            console.log("已过时间", n);
                        } else {
                            var o = new Date().getTime();
                            e.setStorageSync("qyStartTime", o);
                        }
                    },
                    showRule: function() {
                        g.hxt.sendAction("point_rule_clk"), this.getRuleDesc();
                    },
                    buildhide: function() {
                        this.showbuild = !1, this.noScroll = !1;
                    },
                    buildhide_a: function() {
                        this.showbuild_a = !1, this.noScroll = !1, this.showIcon_btn = !0;
                    },
                    userInfoSuccess: function(t) {
                        "all" == t && (this.$store.dispatch("existsSignIn"), this.getRecord(), c.default.recordPv(), 
                        e.removeStorageSync("successInfo"), this.isqyTimeOver(), this.getList(), this.$refs.Loading.hideLoading());
                    },
                    gotoAtten: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 7;
                        g.hxt.sendAction("checkin_progress_bar_clk"), e.navigateTo({
                            url: "../attendance/attendance?from=shop"
                        }), console.log(t);
                    },
                    getRecord: function() {
                        s.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: e.getStorageSync("smsSource")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getGiftCategory: function() {
                        var t = this;
                        a.default.sortList().then(function(n) {
                            console.log(n), 0 == n.code ? t.tabs = n.data : e.showToast({
                                title: "类别获取失败",
                                icon: "none"
                            });
                        });
                    },
                    getList: function() {
                        var t, n = this;
                        t = 0 == this.showType ? {
                            channel: this.channel,
                            offset: this.offset,
                            limit: this.limit,
                            pointGearId: this.tabActive,
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId")
                        } : {
                            channel: this.channel,
                            offset: this.offset,
                            limit: this.limit
                        }, a.default.getList(t).then(function(t) {
                            e.hideLoading(), 0 == t.code ? (0 == t.data.length && (n.noMore = !0), t.data.forEach(function(e) {
                                n.cardList.push(h(h({}, e), {}, {
                                    name: e.giftName,
                                    imgUrl: f + e.couponPicUrl,
                                    descObj: {
                                        ruleCount: (null == e ? void 0 : e.ruleCount) > 1 ? e.ruleCount : "",
                                        dec: e.requiredPoints,
                                        type: 0 == n.showType ? "积心" : "集豆",
                                        price: e.requiredAmount > 0 ? "".concat(e.requiredAmount) : ""
                                    },
                                    subname: e.subName,
                                    time: "".concat(n.$util.dateFormat("YYYY年mm月dd日", new Date(e.startTime.replace(/-/g, "/"))), "- ").concat(n.$util.dateFormat("YYYY年mm月dd日", new Date(e.endTime.replace(/-/g, "/"))))
                                }));
                            }), n.$refs.Loading.hideLoading()) : (n.$refs.Loading.hideLoading(), e.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }));
                        }).catch(function() {
                            n.$refs.Loading.hideLoading(), e.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    docheck: function(t) {
                        console.log(t);
                        var n = t.couponRuleId;
                        g.hxt.sendAction("couponkv_clk", {
                            coupon_id: t.id,
                            coupon_account: t.requiredPoints + "积分" + (t.requiredAmount > 0 ? t.requiredAmount + "元" : ""),
                            coupon_name: t.giftName
                        }), e.navigateTo({
                            url: "/pages/newCoupondetail/index?couponRuleId=" + n
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        a.default.getRuledesc({
                            type: 2
                        }).then(function(t) {
                            e.ruleDesc = t.data[0].content, e.showbuild = !0, e.noScroll = !0;
                        }).catch(function() {
                            e.ruleDesc = "暂无活动规则", e.showbuild = !0, e.noScroll = !0;
                        });
                    },
                    getRuleDesc_a: function() {
                        var t = this;
                        "release" == r.default.envVersion ? this.aid_a = "120" : this.aid_a = "78", u.default.activityGet(this.aid_a, {
                            openId: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            console.log(e), t.ruleDesc_a = e.data.activity.ruleDesc ? e.data.activity.ruleDesc.replace(/\n/g, "<br/>") : "暂无活动规则", 
                            t.ruleDesc_a_title = e.data.activity.name, t.showIcon_btn = !1, t.showbuild_a = !0;
                        }).catch(function() {
                            t.ruleDesc_a = "暂无活动规则", t.showIcon_btn = !1, t.showbuild_a = !0;
                        });
                    },
                    onChangeMain: function(e) {
                        this.$refs.Loading.showLoading(), console.log("主页切换"), this.mainTabActive = e.detail.name, 
                        this.showType = e.detail.index, this.channel = 0 == e.detail.index ? 1 : 2, console.log("channel", this.channel), 
                        this.cardList = [], this.offset = 0, this.noMore = !1, 0 == this.showType && (this.tabActive = this.remberActive), 
                        this.getList();
                    },
                    onChange: function(e) {
                        console.log("内页切换"), this.$refs.Loading.showLoading(), this.searchValue = "", this.cardList = [], 
                        this.offset = 0, this.noMore = !1, this.tabActive = e.detail.name, this.getList();
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (this.$refs.Loading.showLoading(), this.offset = this.offset + this.limit, 
                        this.getList());
                    },
                    gotoRecords: function() {
                        g.hxt.sendAction("point_detail_clk"), 0 == this.showType ? e.navigateTo({
                            url: "/pages/mine/heart"
                        }) : 1 == this.showType && e.navigateTo({
                            url: "/pages/coffee/jidou"
                        });
                    },
                    gosign: function() {
                        this.showObtain = !1, e.navigateTo({
                            url: "/pages/attendance/attendance"
                        });
                    }
                }),
                onShareAppMessage: function(e) {
                    var t = new Date("2021/9/21 23:59:59").valueOf(), n = new Date().valueOf();
                    console.log(t, n);
                    var o = "金秋礼盒套系会员独享限时福利购~", i = "pages/shop/shop?channelLabel=Points-mall&source=Points-mall&tabFrom=" + this.tabFrom, a = "".concat(r.default.ossurl, "/images/home/shop.jpg");
                    return n > t && (o = "哈根达斯会员中心小程序", a = "".concat(r.default.assetsRoot, "/oss/wxapp/miniprogram.jpg")), 
                    console.log(i), {
                        title: o,
                        path: i,
                        imageUrl: a
                    };
                }
            };
            t.default = p;
        }).call(this, n("543d").default);
    },
    f2c1: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.showIcon_btn = !1;
            });
        }, i = [];
    }
}, [ [ "8892", "common/runtime", "common/vendor" ] ] ]);