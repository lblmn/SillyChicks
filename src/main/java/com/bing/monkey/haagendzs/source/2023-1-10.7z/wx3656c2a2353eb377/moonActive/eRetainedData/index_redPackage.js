// moonActive/eRetainedData/index_redPackage.js
Page({data: {}})