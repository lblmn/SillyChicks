// summerEvaluate/exchangeActivity/index.js
Page({data: {}})