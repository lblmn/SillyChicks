(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webView/index_ebuy" ], {
    "1b6d": function(n, e, t) {
        t.r(e);
        var u = t("710f"), o = t("a5f1");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        var r = t("f0c5"), f = Object(r.a)(o.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        e.default = f.exports;
    },
    2336: function(n, e, t) {
        (function(n) {
            var e = t("4ea4");
            t("a1ea"), e(t("66fd"));
            var u = e(t("1b6d"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, n(u.default);
        }).call(this, t("543d").createPage);
    },
    "4d0b": function(n, e, t) {
        var u = t("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, u(t("f3d4"));
        var o = {
            data: function() {
                return {
                    webviewStyles: {
                        progress: {
                            color: "#FF3333"
                        }
                    },
                    url: "",
                    urlLink: ""
                };
            },
            onLoad: function(n) {
                this.url = decodeURIComponent(n.url);
            },
            onShow: function() {}
        };
        e.default = o;
    },
    "710f": function(n, e, t) {
        t.d(e, "b", function() {
            return u;
        }), t.d(e, "c", function() {
            return o;
        }), t.d(e, "a", function() {});
        var u = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    a5f1: function(n, e, t) {
        t.r(e);
        var u = t("4d0b"), o = t.n(u);
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(a);
        e.default = o.a;
    }
}, [ [ "2336", "common/runtime", "common/vendor" ] ] ]);