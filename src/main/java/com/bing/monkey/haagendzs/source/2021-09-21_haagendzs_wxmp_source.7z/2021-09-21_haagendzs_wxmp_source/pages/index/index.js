var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    "01f7": function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("f4aa"), t(n("66fd")), e(t(n("9e07")).default);
        }).call(this, n("543d").createPage);
    },
    "0f2c": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.showindex = !1;
            }, e.e1 = function(t) {
                e.showindex = !1;
            }, e.e2 = function(t) {
                e.showLogin = !1;
            }, e.e3 = function(t) {
                e.showFlag = !1;
            }, e.e4 = function(t) {
                e.showFlag = !1;
            }, e.e5 = function(t) {
                e.showActivity = !1;
            });
        }, i = [];
    },
    "2c85": function(e, t, n) {},
    5989: function(e, t, n) {
        var o = n("2c85");
        n.n(o).a;
    },
    "8b95": function(e, t, n) {
        n.r(t);
        var o = n("c089"), i = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = i.a;
    },
    "9e07": function(e, t, n) {
        n.r(t);
        var o = n("0f2c"), i = n("8b95");
        for (var r in i) "default" !== r && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("5989");
        var a = n("f0c5"), c = Object(a.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    c089: function(t, n, o) {
        (function(t) {
            function i() {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap();
                return i = function() {
                    return e;
                }, e;
            }
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? a(Object(n), !0).forEach(function(t) {
                        s(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function s(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function u(e, t, n, o, i, r, a) {
                try {
                    var c = e[r](a), s = c.value;
                } catch (e) {
                    return void n(e);
                }
                c.done ? t(s) : Promise.resolve(s).then(o, i);
            }
            function l(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(o, i) {
                        function r(e) {
                            u(c, o, i, r, a, "next", e);
                        }
                        function a(e) {
                            u(c, o, i, r, a, "throw", e);
                        }
                        var c = e.apply(t, n);
                        r(void 0);
                    });
                };
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var g = r(o("a34a")), d = r(o("d7df")), f = r(o("1328")), h = r(o("1d54")), p = r(o("57d0")), y = r(o("9b6d")), m = r(o("811a"));
            !function(t) {
                if (t && t.__esModule) return t;
                if (null === t || "object" !== (void 0 === t ? "undefined" : e(t)) && "function" != typeof t) return {
                    default: t
                };
                var n = i();
                if (n && n.has(t)) return n.get(t);
                var o = {}, r = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in t) if (Object.prototype.hasOwnProperty.call(t, a)) {
                    var c = r ? Object.getOwnPropertyDescriptor(t, a) : null;
                    c && (c.get || c.set) ? Object.defineProperty(o, a, c) : o[a] = t[a];
                }
                o.default = t, n && n.set(t, o);
            }(o("9b5d"));
            var S = {
                components: {
                    uniIcons: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(o("349f"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Zswiper: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/Zswiper") ]).then(function() {
                            return resolve(o("f95d"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    hansTabber: function() {
                        o.e("components/hans-tabbar/hans-tabbar").then(function() {
                            return resolve(o("fcda"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        imgUrl: f.default.assetsRoot + "/oss",
                        imgoss: f.default.ossurl + "/images/home/",
                        phone: "",
                        isLogin: !0,
                        avatarUrl: "",
                        showLogin: !1,
                        points: 0,
                        tierName: "",
                        cardNum: -1,
                        showindex: !1,
                        showLoading: !1,
                        ruleDesc: "",
                        wxgetPhone: !1,
                        loginRes: {},
                        isnoUnionid: !1,
                        swiper: {
                            imgUrls: [],
                            indicatorDots: !0,
                            autoplay: !0,
                            interval: 3e3,
                            duration: 500,
                            current: 0
                        },
                        showFlag: !1,
                        showActivity: !1,
                        isHeightScreen: !1,
                        canIUseGetUserProfile: !1,
                        imgActivityUrl: "",
                        pictype: "",
                        isHasUserInfo: !1,
                        iserror: !1,
                        my_voucher: "",
                        points_mall: "",
                        check_in: "",
                        home_delivery: ""
                    };
                },
                onLoad: function(e) {
                    var n = this;
                    t.removeStorageSync("hdAid"), t.removeStorageSync("shareback"), t.removeStorageSync("successInfo"), 
                    t.removeStorageSync("detailinfo"), t.removeStorageSync("refreash"), m.default.setSource(e), 
                    this.pictype = e.pictype ? e.pictype : "", console.log(this.pictype), m.default.isHeightPhone().then(function(e) {
                        n.isHeightScreen = e;
                    }).catch(function(e) {
                        n.isHeightScreen = e;
                    }), t.getUserProfile && (this.canIUseGetUserProfile = !0);
                },
                onShow: function() {
                    var e = this;
                    return l(g.default.mark(function n() {
                        var o, i, r, a, c, s, u, l, h;
                        return g.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                if ((o = t.getBackgroundAudioManager()).stop(), e.pictype || e.getPopupList(), m.default.recordPv(), 
                                e.getList(), e.getHome_delivery(), !(Object.keys(t.getStorageSync("logininfo")).length > 0)) {
                                    n.next = 40;
                                    break;
                                }
                                if (console.log("获取信息"), e.isHasUserInfo = !0, t.getStorageSync("startTime")) {
                                    n.next = 14;
                                    break;
                                }
                                e.getMemberinfo(), t.setStorageSync("startTime", new Date().getTime()), n.next = 36;
                                break;

                              case 14:
                                if (i = t.getStorageSync("startTime"), r = new Date().getTime(), a = r - i, c = a / 1e3 / 60 / 60 / 24, 
                                s = Math.floor(c), u = a / 1e3 / 60 / 60 - 12 * s, l = Math.floor(u), console.log("天数", s), 
                                console.log("小时", l), !(l >= 12)) {
                                    n.next = 28;
                                    break;
                                }
                                e.getMemberinfo(), t.setStorageSync("startTime", new Date().getTime()), n.next = 36;
                                break;

                              case 28:
                                return e.tierName = t.getStorageSync("logininfo").tier.tierName, n.next = 31, e.getPoints();

                              case 31:
                                return n.sent, n.next = 34, e.getCardnum();

                              case 34:
                                n.sent, e.getRecord();

                              case 36:
                                e.pictype && e.getByType(), t.showTabBar(), n.next = 48;
                                break;

                              case 40:
                                return e.isHasUserInfo = !1, t.hideTabBar(), n.next = 44, e.doLogin();

                              case 44:
                                e.loginRes = n.sent, console.log(e.loginRes), h = e, setTimeout(function() {
                                    d.default.login({
                                        code: h.loginRes.code,
                                        appId: f.default.appId
                                    }).then(function(e) {
                                        console.log(e), 0 == e.code ? (t.setStorageSync("openId", e.data.openid), h.iserror = !1, 
                                        e.data.unionId ? (console.log("有unionid"), t.setStorageSync("unionId", e.data.unionId), 
                                        h.getMemberinfo()) : (t.hideTabBar(), console.log("没unionid"), setTimeout(function() {
                                            h.isnoUnionid = !0, h.isLogin = !1;
                                        }, 150))) : (t.showToast({
                                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                                            icon: "none"
                                        }), h.iserror = !0);
                                    }).catch(function(e) {
                                        t.showToast({
                                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                                            icon: "none"
                                        }), h.iserror = !0;
                                    });
                                }, 300);

                              case 48:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                onShareAppMessage: function(e) {
                    return "button" === e.from && console.log(e.target), {
                        title: "哈根达斯会员中心小程序",
                        path: "pages/index/index",
                        imageUrl: "".concat(f.default.assetsRoot, "/oss/wxapp/miniprogram.jpg")
                    };
                },
                methods: {
                    getHome_delivery: function() {
                        var e = this;
                        d.default.home_delivery().then(function(t) {
                            if (console.log(t), 0 == t.code && t.data.length > 0) {
                                e.my_voucher = "", e.points_mall = "", e.check_in = "", e.home_delivery = "";
                                for (var n = 0; n < t.data.length; n++) "home_delivery" == t.data[n].type ? e.home_delivery = t.data[n].name : "my_voucher" == t.data[n].type ? e.my_voucher = t.data[n].name : "points_mall" == t.data[n].type ? e.points_mall = t.data[n].name : "check_in" == t.data[n].type && (e.check_in = t.data[n].name);
                            }
                        });
                    },
                    navigateToNo: function(e) {
                        t.navigateTo({
                            url: e
                        });
                    },
                    gotoMiniProgram: function() {
                        t.navigateToMiniProgram({
                            appId: "wxf83dc13b5390d17b",
                            path: "pages/index/index",
                            success: function(e) {}
                        });
                    },
                    gotoLink: function() {
                        this.imgActiveLink.indexOf("/coffee/coffee") > 0 || this.imgActiveLink.indexOf("/mine/mine") > 0 ? t.switchTab({
                            url: this.imgActiveLink
                        }) : this.pictype ? Object.keys(t.getStorageSync("logininfo")).length > 0 && (this.showActivity = !1, 
                        this.getRecord("HD-618")) : this.imgActiveLink.indexOf("moonActive/rule/index") > 0 && "success" == t.getStorageSync("isGetMoonRule") ? t.navigateTo({
                            url: "/pages/shop/shop"
                        }) : t.navigateTo({
                            url: this.imgActiveLink
                        });
                    },
                    closeActivity: function() {
                        this.pictype && Object.keys(t.getStorageSync("logininfo")).length > 0 && this.getRecord("HD-618"), 
                        this.showActivity = !1;
                    },
                    getPopupList: function() {
                        var e = this;
                        d.default.getPopupList().then(function(n) {
                            if (console.log(n), 0 == n.code && n.data.length > 0) if (n.data[0].frequency = 3, 
                            "1" == n.data[0].frequency) t.removeStorageSync("isFirstPopupList"), e.imgActivityUrl = f.default.assetsRoot + n.data[0].picUrl, 
                            e.imgActiveLink = n.data[0].linkUrl, e.showActivity = !0; else if ("3" == n.data[0].frequency) new Date().getHours() > 12 ? (1 == t.getStorageSync("unionid_back") && t.removeStorageSync("unionid_back"), 
                            t.getStorageSync("unionid_back") || (e.imgActivityUrl = f.default.assetsRoot + n.data[0].picUrl, 
                            e.imgActiveLink = n.data[0].linkUrl, e.showActivity = !0, t.setStorageSync("unionid_back", 2))) : (2 == t.getStorageSync("unionid_back") && t.removeStorageSync("unionid_back"), 
                            t.getStorageSync("unionid_back") || (e.imgActivityUrl = f.default.assetsRoot + n.data[0].picUrl, 
                            e.imgActiveLink = n.data[0].linkUrl, e.showActivity = !0, t.setStorageSync("unionid_back", 1))); else {
                                var o = new Date(new Date(new Date().toLocaleDateString()).getTime() + 864e5 - 1), i = new Date().getTime(), r = new Date(o).getTime();
                                console.log(r, "........"), r - i <= 0 && t.removeStorageSync("isFirstPopupList"), 
                                t.getStorageSync("isFirstPopupList") || (e.imgActivityUrl = f.default.assetsRoot + n.data[0].picUrl, 
                                e.imgActiveLink = n.data[0].linkUrl, e.showActivity = !0, t.setStorageSync("isFirstPopupList", !0));
                            }
                        });
                    },
                    getByType: function() {
                        var e = this;
                        d.default.getByType(this.pictype).then(function(t) {
                            console.log(t), 0 == t.code && (e.imgActivityUrl = f.default.assetsRoot + t.data.picUrl, 
                            e.imgActiveLink = t.data.linkUrl, e.showActivity = !0);
                        });
                    },
                    gotoWebView: function() {
                        t.navigateTo({
                            url: "../webView/index"
                        });
                    },
                    newInfo: function() {
                        var e = this;
                        return l(g.default.mark(function n() {
                            var o, i;
                            return g.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, e.getNewUserInfo();

                                  case 2:
                                    return o = n.sent, console.log(o), t.setStorageSync("wxinfo", o.userInfo), n.next = 7, 
                                    e.getUnionid(o);

                                  case 7:
                                    i = n.sent, t.setStorageSync("unionId", i.data.unionId), e.getMemberinfo();

                                  case 10:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getNewUserInfo: function() {
                        return new Promise(function(e, n) {
                            t.getUserProfile({
                                desc: "会员信息",
                                success: function(t) {
                                    console.log(t), e(t);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    gotoAct: function() {
                        t.redirectTo({
                            url: "../../evaluation/list/index"
                        });
                    },
                    getRecord: function(e) {
                        p.default.saveLoginRecord({
                            unionId: t.getStorageSync("unionId"),
                            openId: t.getStorageSync("openId"),
                            source: e || t.getStorageSync("smsSource")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getList: function() {
                        var e = this;
                        y.default.getList().then(function(t) {
                            0 == t.code && (e.swiper.imgUrls = t.data.map(function(e) {
                                return c(c({}, e), {}, {
                                    newpicUrl: f.default.assetsRoot + e.picUrl
                                });
                            }));
                        });
                    },
                    prevImg: function() {
                        this.swiper.current = this.swiper.current > 0 ? this.swiper.current - 1 : this.swiper.imgUrls.length - 1;
                    },
                    nextImg: function() {
                        this.swiper.current = this.swiper.current < this.swiper.imgUrls.length - 1 ? this.swiper.current + 1 : 0;
                    },
                    onGetUserInfo: function() {
                        var e = this;
                        return l(g.default.mark(function n() {
                            var o, i;
                            return g.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, e.getUserinfo(e.loginRes);

                                  case 2:
                                    return o = n.sent, t.setStorageSync("wxinfo", o.userInfo), n.next = 6, e.getUnionid(o);

                                  case 6:
                                    i = n.sent, t.setStorageSync("unionId", i.data.unionId), e.getMemberinfo();

                                  case 9:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    onGetPhoneNumber: function(e) {
                        var n = this;
                        "getPhoneNumber:fail user deny" == e.detail.errMsg ? console.log("取消授权") : d.default.decrypt({
                            encryptedData: e.detail.encryptedData,
                            openId: t.getStorageSync("openId"),
                            iv: e.detail.iv
                        }).then(function(e) {
                            n.phone = e.data.phoneNumber, t.setStorageSync("userinfoPhone", e.data.phoneNumber), 
                            n.bindQuery();
                        });
                    },
                    doLogin: function() {
                        return new Promise(function(e, n) {
                            t.login({
                                success: function(t) {
                                    console.log(t), e(t);
                                },
                                fail: function(e) {
                                    console.log(e), n(e);
                                }
                            });
                        });
                    },
                    getUserinfo: function(e) {
                        return console.log(e), new Promise(function(n, o) {
                            e.code ? t.getUserInfo({
                                success: function(e) {
                                    console.log(e), n(e);
                                }
                            }) : (o("登录失败！" + e.errMsg), console.log("登录失败！" + e.errMsg));
                        });
                    },
                    getOpenid: function(e) {},
                    getUnionid: function(e) {
                        return d.default.decrypt({
                            encryptedData: e.encryptedData,
                            openId: t.getStorageSync("openId"),
                            iv: e.iv
                        });
                    },
                    bindQuery: function() {
                        var e = this, n = t.getStorageSync("unionId"), o = t.getStorageSync("openId");
                        d.default.bindquery({
                            thirdPartyId: n,
                            openid: o,
                            source: 2,
                            mobilePhone: this.phone
                        }).then(function(i) {
                            console.log("会员绑定查询入参" + JSON.stringify({
                                thirdPartyId: n,
                                openid: o,
                                source: 2,
                                mobilePhone: e.phone
                            })), console.log("会员绑定查询返回" + JSON.stringify(i)), 0 == i.resultCode ? "E000101" == i.resultDesc ? t.navigateTo({
                                url: "/pages/register/register?fromUrl=index"
                            }) : "E000102" == i.resultDesc ? d.default.bind({
                                thirdPartyId: t.getStorageSync("unionId"),
                                thirdPartyName: t.getStorageSync("wxinfo").nickName,
                                openid: t.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: e.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: t.getStorageSync("unionId"),
                                    thirdPartyName: t.getStorageSync("wxinfo").nickName,
                                    openid: t.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: e.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (e.iserror = !1, 
                                t.setStorageSync("socialhubId", n.data.socialhubId), e.getMemberinfo()) : (t.showToast({
                                    title: "访问异常，小哈正在努力恢复，请稍后重试",
                                    icon: "none"
                                }), that.iserror = !0);
                            }) : "E000103" == i.resultDesc ? (t.setStorageSync("socialhubId", i.data.socialhubId), 
                            e.getMemberinfo()) : e.showFlag = !0 : 1 == i.resultCode ? "E000107" == i.resultDesc ? (e.iserror = !1, 
                            d.default.bind({
                                thirdPartyId: t.getStorageSync("unionId"),
                                thirdPartyName: t.getStorageSync("wxinfo").nickName,
                                openid: t.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: e.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: t.getStorageSync("unionId"),
                                    thirdPartyName: t.getStorageSync("wxinfo").nickName,
                                    openid: t.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: e.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (e.iserror = !1, 
                                t.setStorageSync("socialhubId", n.data.socialhubId), e.getMemberinfo()) : (t.showToast({
                                    title: "访问异常，小哈正在努力恢复，请稍后重试",
                                    icon: "none"
                                }), that.iserror = !0);
                            })) : (t.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), that.iserror = !0) : t.showToast({
                                title: "请求异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    getMemberinfo: function() {
                        var e = this;
                        d.default.getmember({
                            idType: "2",
                            id: t.getStorageSync("unionId")
                        }).then(function() {
                            var n = l(g.default.mark(function n(o) {
                                return g.default.wrap(function(n) {
                                    for (;;) switch (n.prev = n.next) {
                                      case 0:
                                        if (console.log(o), 0 != o.resultCode) {
                                            n.next = 17;
                                            break;
                                        }
                                        return t.setStorageSync("logininfo", o.data), t.setStorageSync("socialhubId", o.data.socialhubId), 
                                        e.tierName = t.getStorageSync("logininfo").tier.tierName, n.next = 7, e.getPoints();

                                      case 7:
                                        return n.sent, n.next = 10, e.getCardnum();

                                      case 10:
                                        n.sent, e.getRecord(), e.isLogin = !0, e.pictype && (e.isHasUserInfo = !0, e.getByType()), 
                                        t.showTabBar(), n.next = 21;
                                        break;

                                      case 17:
                                        e.isLogin = !1, e.iserror = !1, e.isLogin ? (e.isLogin = !1, t.hideTabBar(), t.showToast({
                                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                                            icon: "none"
                                        }), that.iserror = !0) : e.wxgetPhone = !0, e.pictype && (e.isHasUserInfo = !1, 
                                        e.getByType());

                                      case 21:
                                      case "end":
                                        return n.stop();
                                    }
                                }, n);
                            }));
                            return function(e) {
                                return n.apply(this, arguments);
                            };
                        }()).catch(function(n) {
                            console.log("接口出错了"), e.isLogin = !1, t.hideTabBar(), t.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), that.iserror = !0;
                        });
                    },
                    plusPoints: function() {
                        d.default.plusPoints(t.getStorageSync("unionId")).then(function(e) {
                            console.log(e);
                        });
                    },
                    getPoints: function(e) {
                        var n = this;
                        return new Promise(function(e, o) {
                            h.default.point({
                                idType: "1",
                                id: t.getStorageSync("socialhubId")
                            }).then(function(i) {
                                if (0 == i.resultCode) {
                                    getApp().globalData.PointAccountResult = i.data;
                                    var r = i.data.filter(function(e) {
                                        return e.pointAccountName.indexOf("积心") > -1;
                                    })[0];
                                    n.points = r.availablePoint, t.setStorageSync("pointAccountId", r.pointAccountId), 
                                    n.beans = i.data.filter(function(e) {
                                        return e.pointAccountName.indexOf("集豆") > -1;
                                    })[0], t.setStorageSync("beansAccountId", n.beans.pointAccountId), e(i);
                                } else n.points = "--", o(i);
                            }).catch(function() {
                                n.points = "--";
                            });
                        });
                    },
                    getCardnum: function() {
                        var e = this;
                        return new Promise(function(n, o) {
                            h.default.indexCouponList({
                                idType: 1,
                                id: t.getStorageSync("socialhubId"),
                                state: 1e8,
                                pageSize: 100
                            }).then(function(t) {
                                0 == t.resultCode ? (e.cardNum = t.data >= 100 ? "99+" : t.data, n(t)) : o(t);
                            });
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        h.default.getRuledesc({
                            type: 1
                        }).then(function(t) {
                            e.ruleDesc = t.data[0].content, e.showindex = !0;
                        });
                    },
                    tabChange: function(e) {
                        console.log(e);
                    },
                    tabbarClick: function() {
                        this.wxgetPhone ? t.showToast({
                            title: "请点击登录验证",
                            icon: "none"
                        }) : this.showLogin = !0;
                    },
                    navigateTo: function(e) {
                        if (!this.iserror) return this.isLogin ? void (e.includes("/mine/mine") || e.includes("/code/code") ? t.switchTab({
                            url: e
                        }) : e.indexOf("moonActive/rule/index") > 0 && "success" == t.getStorageSync("isGetMoonRule") ? t.navigateTo({
                            url: "/pages/shop/shop"
                        }) : t.navigateTo({
                            url: e
                        })) : this.wxgetPhone ? void t.showToast({
                            title: "请点击登录验证",
                            icon: "none"
                        }) : void (this.showLogin = !0);
                        t.showToast({
                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                            icon: "none"
                        });
                    },
                    switchTab: function(e) {
                        if (console.log("switchTab"), !this.isLogin) return this.wxgetPhone ? void t.showToast({
                            title: "请点击登录验证",
                            icon: "none"
                        }) : void (this.showLogin = !0);
                        t.switchTab({
                            url: e
                        });
                    },
                    gopupop: function() {
                        this.getRuleDesc();
                    }
                }
            };
            n.default = S;
        }).call(this, o("543d").default);
    }
}, [ [ "01f7", "common/runtime", "common/vendor" ] ] ]);