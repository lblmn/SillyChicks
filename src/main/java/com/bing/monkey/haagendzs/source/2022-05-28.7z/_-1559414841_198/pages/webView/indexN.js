(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webView/indexN" ], {
    "4b1b": function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return i;
        }), o.d(e, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    "4dfd": function(n, e, o) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("c0e2"), e(o("66fd")), n(e(o("eaf2")).default);
        }).call(this, o("543d").createPage);
    },
    e63d: function(n, e, o) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(o("f0fd"));
            var i = {
                data: function() {
                    return {
                        webviewStyles: {
                            progress: {
                                color: "#FF3333"
                            }
                        },
                        url: "",
                        urlLink: "",
                        showloginDialog: !1
                    };
                },
                onLoad: function(n) {
                    console.log(n), this.url = decodeURIComponent(n.url), console.log(this.url);
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("3761"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                onShow: function() {
                    Object.keys(n.getStorageSync("logininfo")).length > 0 ? this.url.indexOf("reserveHome?scene=1") > 0 ? this.urlLink = this.url + "&openid=" + n.getStorageSync("openId") + "&unionid=" + n.getStorageSync("unionId") + "&nickname=" + n.getStorageSync("logininfo").fullName : (n.hideShareMenu(), 
                    this.urlLink = this.url) : this.showloginDialog = !0;
                },
                onShareAppMessage: function(n) {
                    var e = "pages/webView/indexN?url=" + encodeURIComponent(this.url);
                    return "button" === n.from && console.log(n.target), {
                        title: "相聚乐享空间，一起空间自由",
                        path: e,
                        imageUrl: "".concat(t.default.ossurl, "/images/home/share.png")
                    };
                }
            };
            e.default = i;
        }).call(this, o("543d").default);
    },
    eaf2: function(n, e, o) {
        o.r(e);
        var t = o("4b1b"), i = o("f1d7");
        for (var l in i) "default" !== l && function(n) {
            o.d(e, n, function() {
                return i[n];
            });
        }(l);
        var u = o("f0c5"), r = Object(u.a)(i.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = r.exports;
    },
    f1d7: function(n, e, o) {
        o.r(e);
        var t = o("e63d"), i = o.n(t);
        for (var l in t) "default" !== l && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(l);
        e.default = i.a;
    }
}, [ [ "4dfd", "common/runtime", "common/vendor" ] ] ]);