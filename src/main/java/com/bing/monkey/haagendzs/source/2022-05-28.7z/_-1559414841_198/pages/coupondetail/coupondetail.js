(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/coupondetail/coupondetail" ], {
    "12a7": function(e, t, o) {
        o.r(t);
        var n = o("bb38"), i = o.n(n);
        for (var s in n) "default" !== s && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(s);
        t.default = i.a;
    },
    "31e5": function(e, t, o) {
        var n = o("fb83");
        o.n(n).a;
    },
    "681e": function(e, t, o) {
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {});
        var n = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.confirmVisible = !1;
            }, e.e1 = function(t) {
                e.confirmVisible = !1;
            }, e.e2 = function(t) {
                e.showObtain = !1;
            }, e.e3 = function(t) {
                e.showObtain = !1;
            }, e.e4 = function(t) {
                e.selectCityVisible = !1;
            }, e.e5 = function(t) {
                e.cityShow = !0;
            }, e.e6 = function(t) {
                e.selectCityVisible = !1;
            }, e.e7 = function(t) {
                e.cityShow = !1;
            }, e.e8 = function(t) {
                e.cityShow = !1;
            }, e.e9 = function(t) {
                e.provinceShow = !1;
            }, e.e10 = function(t) {
                e.provinceShow = !1;
            }, e.e11 = function(t) {
                e.cityListShow = !1;
            }, e.e12 = function(t) {
                e.cityListShow = !1;
            }, e.e13 = function(t) {
                e.typeShow = !1;
            }, e.e14 = function(t) {
                e.typeShow = !1;
            }, e.e15 = function(t) {
                e.showDeleteAddress = !1;
            }, e.e16 = function(t) {
                e.showDeleteAddress = !1;
            }, e.e17 = function(t) {
                e.nouseCards = !1;
            }, e.e18 = function(t) {
                e.nouseCards = !1;
            }, e.e19 = function(t) {
                e.showSumbit = !1;
            }, e.e20 = function(t) {
                e.showSumbit = !1;
            });
        }, i = [];
    },
    "8e06": function(e, t, o) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            o("c0e2"), t(o("66fd")), e(t(o("bfb8")).default);
        }).call(this, o("543d").createPage);
    },
    bb38: function(e, t, o) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = h(o("c344")), i = h(o("7d86")), s = h(o("ec2e")), c = (h(o("500b")), h(o("c917"))), d = h(o("aa8c")), a = h(o("c1f6")), r = h(o("234f")), u = h(o("f0fd")), l = h(o("f3d6"));
            function h(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function f(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function p(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(o), !0).forEach(function(t) {
                        y(e, t, o[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : f(Object(o)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
                    });
                }
                return e;
            }
            function y(e, t, o) {
                return t in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e;
            }
            h(o("f322"));
            var g = getApp().globalData.N_ENV.assetsRoot, b = "", m = {
                data: function() {
                    return {
                        imgoss: u.default.ossurl + "images/home",
                        obj: {},
                        confirmVisible: !1,
                        showObtain: !1,
                        errorShowBtn: !1,
                        showShopCard: !1,
                        shopCodeInfo: "",
                        errorMsg: "",
                        selectCityVisible: !1,
                        cityShow: !1,
                        cityObj: {
                            text: "",
                            code: ""
                        },
                        cityArr: s.default,
                        cityAddress: c.default,
                        canChange: !0,
                        couponCode: "",
                        selectAddress: !1,
                        province: "请选择省份",
                        city: "请选择城市",
                        provinceShow: !1,
                        cityList: "",
                        cityListShow: !1,
                        typeShow: !1,
                        addressDetailShow: !1,
                        addressDetaillist: [],
                        addressId: "",
                        showDeleteAddress: !1,
                        deleteId: "",
                        showSumbit: !1,
                        pickType: "",
                        cityAddressGet: "",
                        cityAddObj: "",
                        moonTypeList: [ {
                            name: "电子券",
                            selected: !0,
                            ispay: !1
                        }, {
                            name: "纸质券",
                            selected: !1,
                            ispay: !0
                        } ],
                        today: "",
                        nouseCards: !1,
                        moonGetWarming: "",
                        ruleDesc_a: "",
                        showbuild_a: !1,
                        showIcon_btn: !1,
                        qty: 1,
                        showPick: !1
                    };
                },
                onLoad: function(e) {
                    var t = JSON.parse(decodeURIComponent(e.obj));
                    this.obj = p(p({}, t), {}, {
                        giftPicUrl: t.giftPicUrl ? g + t.giftPicUrl : g + "/oss/wxapp/big.jpg",
                        ruleDesc: t.ruleDesc ? t.ruleDesc.replace(/\n/g, "<br/>") : "",
                        requireAll: t.requiredPoints + (1 == t.channel ? "积心" : "集豆"),
                        points: t.requiredPoints,
                        channelType: 1 == t.channel ? "积心" : "集豆"
                    }), this.getCity(), r.default.recordPv("/pages/coupondetail/coupondetail?idpv=" + this.obj.id);
                },
                onShow: function() {
                    this.addressList(), console.log("重新加载");
                    var t = new Date();
                    this.today = r.default.dateFormat("YYYY-mm-dd", t), e.getStorageSync("isDuihuan") && e.removeStorageSync("isDuihuan"), 
                    "1" == this.obj.moonType && (r.default.timeDiff(this.today, "2021-09-13") ? this.showIcon_btn = !1 : this.showIcon_btn = !0);
                },
                onHide: function() {
                    this.confirmVisible = !1, this.selectCityVisible = !1, this.showObtain = !1;
                },
                methods: {
                    reduceFun: function() {
                        if (this.qty <= 1) return e.showToast({
                            title: "不能再减啦~",
                            icon: "none",
                            mask: !0
                        }), !1;
                        this.qty = this.qty - 1;
                    },
                    addFun: function() {
                        return console.log(this.qty, this.obj.canNum), this.obj.canNum >= 20 && this.qty >= 20 ? (this.qty = 20, 
                        e.showToast({
                            title: "单次兑换上限是" + this.qty + "张",
                            icon: "none",
                            mask: !0
                        }), !1) : this.qty >= this.obj.canNum && this.obj.canNum <= 20 ? (e.showToast({
                            title: "单次兑换上限是" + this.obj.canNum + "张",
                            icon: "none",
                            mask: !0
                        }), !1) : void (this.qty = this.qty + 1);
                    },
                    getRuleDesc_a: function() {
                        var t = this;
                        "release" == u.default.envVersion ? this.aid_a = "49" : this.aid_a = "54", l.default.activityGet(this.aid_a, {
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            console.log(e), e.data.length <= 0 ? (t.ruleDesc_a = "1、活动时间：2021年9月3日-9月12日<br/>2、活动内容：<br/>活动期间，哈根达斯会员在哈根达斯积心商城兑购任意月饼券的前800位会员可获得哈根达斯限量定制的爱心口红包（淡粉、粉、红）一个，三种颜色随机发货。*每位会员仅限领取一次<br/>3、活动奖品：<br/>哈根达斯限量定制爱心口红包（淡粉、粉、红）一份，共800份。<br/>4、奖品领取：<br/>（1）前800位下单的会员在兑购月饼券后一个工作日内，需注意查收手机短信，根据短信提示，点击短信中跳转链接后进入信息填写页面，填写并提交相应礼品寄送地址。<br/>（2）会员需在手机短信发送后的24小时内填写并提交地址信息，否则视为会员自动放弃。<br/>（3）礼品将于会员提交地址信息后的3个工作日内快递发出（不支持加急配送），若因个人原因（例如：收件信息填写错误等）导致配送失败，品牌将不予补发。<br/>5、活动说明：<br/>除非另行说明，本次月饼季口红包活动条款和条件(包括全部附件，以下合称“本条款和条件”)适用于中国境内的哈根达斯俱乐部活动，并且将构成您与特定的运营哈根达斯品牌的公司(以下简称“哈根达斯”)之间的法律协议。本条款和条件中的某些用词具有下述“定义及用语”部分所规定的特定含义(在本条款和条件中另有定义的除外)。<br/>通过哈根达斯天猫官方旗舰店、哈根达斯微信公众号等哈根达斯会员规则中所列明的注册渠道提供的入会表单内，填入相关个人信息并点击“提交”按钮或其他哈根达斯所认可的方式(以下简称“会员注册”)，您将确认您已经阅读、理解并同意接受本条款和条件。如果您不同意本条款和条件，请关闭前述窗口并且不要进行注册。<br/>您确认、声明且保证您的年龄不小于18周岁(或者虽小于18周岁但已经征得您父母或法定监护人的同意)，并且完全有能力确认与接受本条款和条件并遵守和符合其规定。您同意按照哈根达斯的要求提供准确完整的信息(例如在您向哈根达斯注册您的哈根达斯俱乐部帐户时)，包括您的真实姓名、生日信息、电子邮箱地址、邮寄地址和联系手机。此外，您同意维护并及时更新您的哈根达斯俱乐部帐户信息，确保该等信息均为准确的、最新的和完整的。<br/>哈根达斯尊重您的隐私权并重视您与哈根达斯的关系。隐私权条款对于哈根达斯通过哈根达斯官网、哈根达斯移动应用(例如哈根达斯微信公众号)以及哈根达斯在中国运营的其他包含隐私权条款链接的网站(统称为“哈根达斯网站”)提供的服务中所收集的信息、通过哈根达斯俱乐部或中国境内的其他哈根达斯活动所收集的信息、以及通过在中国的零售渠道的销售系统所收集的信息作出了说明，也对哈根达斯如何使用该等信息作出了说明。隐私权条款还说明了对于哈根达斯如何收集和使用您的信息您可以做出的选择。如果您注册了哈根达斯俱乐部账户、参加了哈根达斯活动、浏览了哈根达斯网站和/或向哈根达斯提供了您的任何个人信息，您将被视为同意隐私权条款项下所描述的信息收集、使用以及披露的做法，特别是您同意：哈根达斯已经充分明示披露了哈根达斯收集、使用您个人信息的目的、方式和范围，相关收集、使用行为是合法、正当且必要的，哈根达斯没有收集与其服务无关的个人信息，哈根达斯已经向您提供了保护您个人信息的充分手段。<br/>当您参与活动时，代表您同意哈根达斯对您上传的个人肖像通过技术手段进行符合活动主题的改动和加工，但哈根达斯不会自己进行，或授权第三方进行将带有您肖像的图片﹑底片或者照片保存或传播，或修改成任何不符合法律规定的图片的行为；哈根达斯将保护您的肖像和个人资料，未经您同意哈根达斯不会透露您的任何有关资料；您同意哈根达斯及代表哈根达斯利益的人和单位在制作或改动此次活动中的作品时，不再因肖像权、使用权而承担法律责任。<br/>如需了解详情请致电咨询会员热线：400-820-7917（周一至周日10:00-20:00）。", 
                            t.showIcon_btn = !1, t.showbuild_a = !0) : (t.ruleDesc_a = e.data.activity.ruleDesc ? e.data.activity.ruleDesc.replace(/\n/g, "<br/>") : "暂无会员日规则", 
                            t.showIcon_btn = !1, t.showbuild_a = !0);
                        }).catch(function() {
                            t.ruleDesc_a = "1、活动时间：2021年9月3日-9月12日<br/>2、活动内容：<br/>活动期间，哈根达斯会员在哈根达斯积心商城兑购任意月饼券的前800位会员可获得哈根达斯限量定制的爱心口红包（淡粉、粉、红）一个，三种颜色随机发货。*每位会员仅限领取一次<br/>3、活动奖品：<br/>哈根达斯限量定制爱心口红包（淡粉、粉、红）一份，共800份。<br/>4、奖品领取：<br/>（1）前800位下单的会员在兑购月饼券后一个工作日内，需注意查收手机短信，根据短信提示，点击短信中跳转链接后进入信息填写页面，填写并提交相应礼品寄送地址。<br/>（2）会员需在手机短信发送后的24小时内填写并提交地址信息，否则视为会员自动放弃。<br/>（3）礼品将于会员提交地址信息后的3个工作日内快递发出（不支持加急配送），若因个人原因（例如：收件信息填写错误等）导致配送失败，品牌将不予补发。<br/>5、活动说明：<br/>除非另行说明，本次月饼季口红包活动条款和条件(包括全部附件，以下合称“本条款和条件”)适用于中国境内的哈根达斯俱乐部活动，并且将构成您与特定的运营哈根达斯品牌的公司(以下简称“哈根达斯”)之间的法律协议。本条款和条件中的某些用词具有下述“定义及用语”部分所规定的特定含义(在本条款和条件中另有定义的除外)。<br/>通过哈根达斯天猫官方旗舰店、哈根达斯微信公众号等哈根达斯会员规则中所列明的注册渠道提供的入会表单内，填入相关个人信息并点击“提交”按钮或其他哈根达斯所认可的方式(以下简称“会员注册”)，您将确认您已经阅读、理解并同意接受本条款和条件。如果您不同意本条款和条件，请关闭前述窗口并且不要进行注册。<br/>您确认、声明且保证您的年龄不小于18周岁(或者虽小于18周岁但已经征得您父母或法定监护人的同意)，并且完全有能力确认与接受本条款和条件并遵守和符合其规定。您同意按照哈根达斯的要求提供准确完整的信息(例如在您向哈根达斯注册您的哈根达斯俱乐部帐户时)，包括您的真实姓名、生日信息、电子邮箱地址、邮寄地址和联系手机。此外，您同意维护并及时更新您的哈根达斯俱乐部帐户信息，确保该等信息均为准确的、最新的和完整的。<br/>哈根达斯尊重您的隐私权并重视您与哈根达斯的关系。隐私权条款对于哈根达斯通过哈根达斯官网、哈根达斯移动应用(例如哈根达斯微信公众号)以及哈根达斯在中国运营的其他包含隐私权条款链接的网站(统称为“哈根达斯网站”)提供的服务中所收集的信息、通过哈根达斯俱乐部或中国境内的其他哈根达斯活动所收集的信息、以及通过在中国的零售渠道的销售系统所收集的信息作出了说明，也对哈根达斯如何使用该等信息作出了说明。隐私权条款还说明了对于哈根达斯如何收集和使用您的信息您可以做出的选择。如果您注册了哈根达斯俱乐部账户、参加了哈根达斯活动、浏览了哈根达斯网站和/或向哈根达斯提供了您的任何个人信息，您将被视为同意隐私权条款项下所描述的信息收集、使用以及披露的做法，特别是您同意：哈根达斯已经充分明示披露了哈根达斯收集、使用您个人信息的目的、方式和范围，相关收集、使用行为是合法、正当且必要的，哈根达斯没有收集与其服务无关的个人信息，哈根达斯已经向您提供了保护您个人信息的充分手段。<br/>当您参与活动时，代表您同意哈根达斯对您上传的个人肖像通过技术手段进行符合活动主题的改动和加工，但哈根达斯不会自己进行，或授权第三方进行将带有您肖像的图片﹑底片或者照片保存或传播，或修改成任何不符合法律规定的图片的行为；哈根达斯将保护您的肖像和个人资料，未经您同意哈根达斯不会透露您的任何有关资料；您同意哈根达斯及代表哈根达斯利益的人和单位在制作或改动此次活动中的作品时，不再因肖像权、使用权而承担法律责任。<br/>如需了解详情请致电咨询会员热线：400-820-7917（周一至周日10:00-20:00）。", 
                            t.showIcon_btn = !1, t.showbuild_a = !0;
                        });
                    },
                    addressDetailShowFun: function() {
                        this.addressDetailShow = !1, this.showIcon_btn = !0;
                    },
                    nousePopup: function() {
                        this.nouseCards = !1, this.addressDetailShow = !1, this.moonTypeList[0].selected = !0, 
                        this.moonTypeList.length > 1 && (this.moonTypeList[1].selected = !1), this.pickType = 1, 
                        e.setStorageSync("pickType", 1);
                    },
                    buildhide_a: function() {
                        this.showbuild_a = !1, this.showIcon_btn = !0;
                    },
                    PaperMoonSubmit: function() {
                        var t = new Date().getTime(), o = {
                            unionId: e.getStorageSync("unionId"),
                            channel: this.obj.channel,
                            openId: e.getStorageSync("openId"),
                            cityName: "021",
                            pickType: this.pickType,
                            addressId: this.addressId,
                            qty: this.qty,
                            couponRuleId: this.obj.couponRuleId,
                            sign: r.default.mdString(t, {
                                openId: e.getStorageSync("openId"),
                                unionId: e.getStorageSync("unionId"),
                                couponRuleId: this.obj.couponRuleId,
                                channel: this.obj.channel
                            }),
                            timestamp: t
                        };
                        this.exchangeFun(o);
                    },
                    sumbitMoon: function() {
                        if ("" == this.addressId) return e.showToast({
                            icon: "none",
                            title: "选择寄送纸质券地址"
                        }), !1;
                        this.showSumbit = !0;
                    },
                    selectAddressF: function() {
                        this.selectAddress = !1, this.pickType = "", this.moonTypeList[0].selected = !0, 
                        this.moonTypeList.length > 1 && (this.moonTypeList[1].selected = !1), this.cityAddObj = "", 
                        this.city = "请选择城市", this.confirmVisible = !1, e.removeStorageSync("pickType");
                    },
                    selectMoonType: function(t, o) {
                        console.log(t), this.moonTypeList.length > 1 ? 0 == o ? (this.moonTypeList[0].selected = !0, 
                        this.moonTypeList[1].selected = !1, this.pickType = 1, e.setStorageSync("pickType", 1)) : (this.moonTypeList[0].selected = !1, 
                        this.moonTypeList[1].selected = !0, this.pickType = 2, e.setStorageSync("pickType", 2)) : (this.moonTypeList[0].selected = !0, 
                        this.pickType = 1, e.setStorageSync("pickType", 1));
                    },
                    getCityByRuleId: function() {
                        var e = this;
                        i.default.getCityByRuleId(this.obj.couponRuleId).then(function(t) {
                            console.log(t), 0 == t.code ? e.cityAddressGet = t.data : (e.cityAddressGet = d.default.cityArrMoon, 
                            e.filterMoonCity());
                        }).catch(function() {
                            e.cityAddressGet = d.default.cityArrMoon, e.filterMoonCity();
                        });
                    },
                    getCity: function() {
                        var e = this;
                        i.default.getCity().then(function(t) {
                            console.log(t), 0 == t.code ? (e.cityAddressGet = t.data, e.filterMoonCity()) : (e.cityAddressGet = d.default.cityArrMoon, 
                            e.filterMoonCity());
                        }).catch(function() {
                            e.cityAddressGet = d.default.cityArrMoon, e.filterMoonCity();
                        });
                    },
                    filterMoonCity: function() {
                        var e = [ "312", "315", "311" ];
                        "CS03" != this.obj.couponRuleId && "jfsc003" != this.obj.couponRuleId || (this.cityAddressGet = this.cityAddressGet.filter(function(t) {
                            return -1 == e.indexOf(t.codeSn);
                        }));
                    },
                    accout: function() {
                        a.default.point({
                            idType: "1",
                            id: e.getStorageSync("socialhubId")
                        }).then(function(t) {
                            0 == t.resultCode ? (getApp().globalData.PointAccount = t.data, t.data.filter(function(e) {
                                return e.pointAccountName.indexOf("积心") > -1;
                            })[0]) : e.showToast({
                                title: "请求积分异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    gotoAttend: function() {
                        e.navigateTo({
                            url: "/pages/attendance/attendance",
                            complete: function() {}
                        });
                    },
                    deleteAddress: function(e) {
                        this.deleteId = e, this.showDeleteAddress = !0;
                    },
                    deleteAddressF: function() {
                        var e = this;
                        i.default.removeAddress(this.deleteId).then(function(t) {
                            console.log(t), 0 == t.code ? (e.addressList(), e.deleteId = "", e.showDeleteAddress = !1) : e.showDeleteAddress = !1;
                        });
                    },
                    addressList: function() {
                        var t = this;
                        i.default.addressList({
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            if (404 == e.code) t.addressDetaillist = []; else if (0 == e.code) {
                                var o = e.data;
                                o.forEach(function(e) {
                                    e.selected = !1;
                                }), t.addressDetaillist = o;
                            }
                        });
                    },
                    navigateTo: function(t, o) {
                        o && (t = t + "?addressId=" + o + "&from=coupondetail"), e.navigateTo({
                            url: t + "?from=coupondetail"
                        }), console.log(t);
                    },
                    onRuleChange: function(e, t) {
                        console.log(e), console.log(t);
                        var o = this;
                        o.addressId == e.id ? (o.addressDetaillist[t].selected = !1, o.addressId = "") : (o.addressDetaillist.forEach(function(e) {
                            e.selected = !1;
                        }), r.default.timeDiff(o.today, "2021-09-10") ? e.cityName.indexOf("上海") > -1 ? (o.addressDetaillist[t].selected = !e.selected, 
                        o.addressId = e.id) : o.nouseCards = !0 : (o.addressDetaillist[t].selected = !e.selected, 
                        o.addressId = e.id));
                    },
                    selectProvince: function() {
                        this.provinceShow = !0;
                    },
                    onprovinceConfirm: function(e) {
                        console.log(e), this.province = e.detail.value, this.city = "请选择城市", this.provinceShow = !1;
                    },
                    selectCity: function() {
                        var e = this, t = [];
                        this.cityAddressGet.forEach(function(o) {
                            ("jfsc003" == e.obj.couponRuleId || "jfsc003_01" == e.obj.couponRuleId || "jfsc003_02" == e.obj.couponRuleId || "jfsc003_03" == e.obj.couponRuleId || "CS03_03" == e.obj.couponRuleId || "CS03_02" == e.obj.couponRuleId || "CS03" == e.obj.couponRuleId) && ("石家庄" == o.name || "唐山" == o.name || "保定" == o.name) || t.push(o.name);
                        }), console.log(t), this.cityList = t, this.cityListShow = !0;
                    },
                    onCityConfirm: function(e) {
                        var t = this;
                        console.log(e), this.city = e.detail.value, this.cityAddressGet.forEach(function(o) {
                            o.name == e.detail.value && (t.cityAddObj = o);
                        }), this.cityListShow = !1;
                    },
                    closeShowShopCard: function() {
                        this.showShopCard = !1, this.confirmVisible = !1;
                    },
                    confirmExchange: function() {
                        var e = this;
                        getApp().hxt.sendAction("redeem_clk", {
                            cost_point: e.obj.requiredPoints + "积分" + (e.obj.requiredAmount > 0 ? e.obj.requiredAmount + "元" : ""),
                            coupon_id: e.obj.id,
                            coupon_num: e.qty,
                            coupon_name: e.obj.giftName
                        }), "10" == e.obj.giftClass ? e.confirmVisible = !0 : e.obj.requiredAmount > 0 ? "1" == e.obj.useAddress ? e.selectCityVisible = !0 : (e.obj.moonType, 
                        e.confirmVisible = !0) : e.confirmVisible = !0;
                    },
                    handleExchange: function() {
                        var t = this;
                        if (getApp().hxt.sendAction("redeem_confirm"), "10" == this.obj.giftClass) {
                            var o = getApp().globalData.PointAccount.filter(function(e) {
                                return e.pointAccountName.indexOf("心") > -1;
                            })[0];
                            return console.log(o), console.log(this.obj), o.availablePoint >= this.obj.requiredPoints ? e.navigateTo({
                                url: "/pages/couponTel/couponTel?giftId=" + this.obj.id
                            }) : (this.confirmVisible = !1, this.errorMsg = "积心不足", this.errorShowBtn = !0, 
                            this.showObtain = !0), !1;
                        }
                        if (this.obj.requiredAmount > 0 && "" == this.cityObj.code && "1" == this.obj.useAddress) e.showToast({
                            title: "请选择领取城市",
                            icon: "none"
                        }); else if ("1" == this.obj.moonType) {
                            if (!this.canChange) return;
                            this.canChange = !1, this.$toast.loading({
                                mask: !0,
                                message: "正在加载...",
                                duration: 1e4
                            }), n.default.isbuy({
                                id: this.obj.id,
                                unionId: e.getStorageSync("unionId"),
                                channel: this.obj.channel
                            }).then(function(o) {
                                0 == o.code ? (r.default.timeDiff(t.today, "2021-09-17") && (t.moonTypeList = [ {
                                    name: "电子券",
                                    selected: !0,
                                    ispay: !1
                                } ]), t.selectAddress = !0, t.pickType = 1, t.showPick = !0, e.setStorageSync("pickType", 1)) : 407 == o.code ? (t.moonTypeList = [ {
                                    name: "电子券",
                                    selected: !0,
                                    ispay: !1
                                } ], t.selectAddress = !0, t.pickType = 1, t.showPick = !0, e.setStorageSync("pickType", 1)) : (o.msg.includes("E000115") ? (t.errorMsg = "您已达到限购次数", 
                                t.selectAddressF()) : o.msg.includes("E000113") ? (t.errorMsg = "积心余额不足，无法支付", t.selectAddressF()) : -1 == o.code ? (t.errorShowBtn = !0, 
                                t.errorMsg = o.msg, t.selectAddressF()) : (t.errorMsg = o.msg, t.selectAddressF()), 
                                t.showObtain = !0);
                            }).finally(function(e) {
                                t.canChange = !0, t.selectCityVisible = !1, t.$toast.clear();
                            });
                        } else {
                            if (!this.canChange) return;
                            var i = new Date().getTime(), s = {
                                unionId: e.getStorageSync("unionId"),
                                channel: this.obj.channel,
                                openId: e.getStorageSync("openId"),
                                qty: this.qty,
                                couponRuleId: this.obj.couponRuleId,
                                sign: r.default.mdString(i, {
                                    openId: e.getStorageSync("openId"),
                                    unionId: e.getStorageSync("unionId"),
                                    couponRuleId: this.obj.couponRuleId,
                                    channel: this.obj.channel
                                }),
                                timestamp: i
                            };
                            this.exchangeFun(s);
                        }
                    },
                    exchangeMoon: function() {
                        if (1 == this.pickType) {
                            if ("" == this.cityAddObj) return e.showToast({
                                icon: "none",
                                title: "请选择提领地址"
                            }), !1;
                            var t = new Date().getTime(), o = {
                                unionId: e.getStorageSync("unionId"),
                                channel: this.obj.channel,
                                openId: e.getStorageSync("openId"),
                                cityName: this.cityAddObj.codeSn,
                                pickType: this.pickType,
                                addressId: this.addressId,
                                qty: this.qty,
                                couponRuleId: this.obj.couponRuleId,
                                sign: r.default.mdString(t, {
                                    openId: e.getStorageSync("openId"),
                                    unionId: e.getStorageSync("unionId"),
                                    couponRuleId: this.obj.couponRuleId,
                                    channel: this.obj.channel
                                }),
                                timestamp: t
                            };
                            this.exchangeFun(o);
                        } else 2 == this.pickType && (this.showIcon_btn = !1, this.addressDetailShow = !0);
                    },
                    exchangeFun: function(t) {
                        var o = this;
                        this.canChange = !1, this.$toast.loading({
                            mask: !0,
                            message: "正在加载...",
                            duration: 1e4
                        }), n.default.exchange(p({}, t)).then(function(t) {
                            if (console.log("兑换月饼券返回参数天正", t), 0 == t.code) e.showToast({
                                title: "兑换成功..."
                            }), b = Array.isArray(t.data) ? t.data[0] : t.data, "2" == o.obj.orderType || t.data.length > 1 ? setTimeout(function() {
                                e.redirectTo({
                                    url: "../mine/mycard"
                                });
                            }, 500) : setTimeout(function() {
                                e.redirectTo({
                                    url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(o.obj)) + "&couponCode=" + b.couponCode + "&couponRuleId=" + b.couponRuleId + "&effectEnd=" + b.effectEnd
                                });
                            }, 500); else if (200 == t.code) {
                                console.log(t);
                                var n = t.data, s = n.timeStamp, c = n.nonceStr, d = n.signType, a = n.paySign, u = n.couponRuleId, l = n.giftExchangeRecordId, h = n.orderCode, f = n.pointRecordId;
                                e.requestPayment({
                                    provider: "wxpay",
                                    timeStamp: s,
                                    nonceStr: c,
                                    package: t.data.package,
                                    signType: d,
                                    paySign: a,
                                    success: function(t) {
                                        console.log("success:" + JSON.stringify(t)), o.$toast.loading({
                                            mask: !0,
                                            message: "正在生成...",
                                            duration: 1e4
                                        });
                                        var n = new Date().getTime();
                                        i.default.exchangeSave({
                                            couponRuleId: u,
                                            giftExchangeRecordId: l,
                                            orderCode: h,
                                            pointRecordId: f,
                                            provinceCode: "",
                                            cityCode: o.cityObj.code,
                                            id: e.getStorageSync("unionId"),
                                            pickType: o.pickType,
                                            addressId: o.addressId,
                                            openid: e.getStorageSync("openId"),
                                            unionId: e.getStorageSync("unionId"),
                                            sign: r.default.mdString(n, {
                                                openid: e.getStorageSync("openId"),
                                                unionId: e.getStorageSync("unionId"),
                                                giftExchangeRecordId: l
                                            }),
                                            timestamp: n
                                        }).then(function(t) {
                                            console.log("save", JSON.stringify(t));
                                            var n = o;
                                            0 == t.code ? (n.obj.cityCode = n.cityObj.code, "3" == n.obj.moonType ? e.navigateTo({
                                                url: "../mine/mycard"
                                            }) : "1" == n.obj.moonType ? 1 == e.getStorageSync("pickType") ? Array.isArray(t.data) ? (e.navigateTo({
                                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(o.obj)) + "&couponCode=" + t.data[0].couponCode + "&couponRuleId=" + t.data[0].couponRuleId + "&effectEnd=" + t.data[0].effectEnd + "&typeFrom=mooncard"
                                            }), n.selectAddressF()) : (e.navigateTo({
                                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(o.obj)) + "&couponCode=" + t.data.couponCode + "&couponRuleId=" + t.data.couponRuleId + "&effectEnd=" + t.data.effectEnd
                                            }), n.selectAddressF()) : 2 == e.getStorageSync("pickType") && (e.navigateTo({
                                                url: "../mine/order"
                                            }), n.selectAddressF()) : Array.isArray(t.data) ? t.data.length > 1 ? setTimeout(function() {
                                                e.redirectTo({
                                                    url: "../mine/mycard"
                                                });
                                            }, 500) : e.navigateTo({
                                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(o.obj)) + "&couponCode=" + t.data[0].couponCode + "&couponRuleId=" + t.data[0].couponRuleId + "&effectEnd=" + t.data[0].effectEnd
                                            }) : e.navigateTo({
                                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(o.obj)) + "&couponCode=" + t.data.couponCode + "&couponRuleId=" + t.data.couponRuleId + "&effectEnd=" + t.data.effectEnd
                                            })) : (console.log("save接口出错了"), e.showToast({
                                                title: "兑换失败，请重试"
                                            }));
                                        }).finally(function() {
                                            o.$toast.clear();
                                        });
                                    },
                                    fail: function(t) {
                                        console.log("fail:" + JSON.stringify(t)), o.selectAddressF(), e.showToast({
                                            title: "支付失败，请重试"
                                        });
                                    }
                                });
                            } else t.msg.includes("E000115") ? o.errorMsg = "您已达到限购次数" : t.msg.includes("E000113") ? o.errorMsg = "积心余额不足，无法支付" : -1 == t.code ? (o.errorMsg = "积心不足!", 
                            o.errorShowBtn = !0, o.errorMsg = t.msg, o.selectAddressF()) : (o.errorMsg = t.msg, 
                            o.selectAddressF()), "2" == o.obj.channel && (o.errorShowBtn = !1), o.showObtain = !0;
                        }).finally(function(e) {
                            o.canChange = !0, o.selectCityVisible = !1, o.$toast.clear(), o.addressDetailShow = !1, 
                            o.showSumbit = !1, o.addressId = "", o.addressDetaillist.forEach(function(e) {
                                e.selected = !1;
                            });
                        });
                    }
                }
            };
            t.default = m;
        }).call(this, o("543d").default);
    },
    bfb8: function(e, t, o) {
        o.r(t);
        var n = o("681e"), i = o("12a7");
        for (var s in i) "default" !== s && function(e) {
            o.d(t, e, function() {
                return i[e];
            });
        }(s);
        o("31e5");
        var c = o("f0c5"), d = Object(c.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = d.exports;
    },
    fb83: function(e, t, o) {}
}, [ [ "8e06", "common/runtime", "common/vendor" ] ] ]);