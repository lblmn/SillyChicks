// evaluation/exchangeActivity/turnGet.js
Page({data: {}})