var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/code/code" ], {
    "4ecd": function(n, o, a) {
        (function(n) {
            var i = a("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var r = i(a("9523")), c = i(a("fa26")), s = i(a("0098")), u = i(a("9296")), l = i(a("7d43")), d = i(a("f3d4")), f = a("26cb");
            function m(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function h(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? m(Object(n), !0).forEach(function(t) {
                        (0, r.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : m(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var g, v = getApp(), p = {
                components: {
                    uniIcons: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(a("6093"));
                        }.bind(null, a)).catch(a.oe);
                    },
                    headerimg: function() {
                        a.e("components/headerimg").then(function() {
                            return resolve(a("09c2"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        qrcode: n.getStorageSync("logininfo").cardNumber,
                        textDemo: "",
                        imgUX: d.default.ossurl + "UX",
                        showFlag: !1,
                        ruleDesc: "",
                        showCanvas: !0,
                        canvasImg: "",
                        timeObj: "",
                        dynamicCode: "",
                        showLoad: !1,
                        codetime: 30,
                        sevtime: "",
                        desname: "",
                        expiryTimeEnd: "",
                        startTime: "",
                        endTime: "",
                        dtime: "",
                        timeTZ: "",
                        hasWxtX: !0,
                        avatarUrl: "",
                        isRefeash: !1,
                        isENV: "release" != d.default.envVersion,
                        isError: !1
                    };
                },
                onLoad: function() {
                    this.getRuleDesc();
                },
                onShow: function() {
                    v.hxt.sendAction("member_clk"), l.default.recordPv(), n.getStorageSync("wxuserinfoAvatar") ? (this.hasWxtX = !1, 
                    this.avatarUrl = n.getStorageSync("wxuserinfoAvatar")) : this.hasWxtX = !0, "release" == d.default.envVersion ? (this.textDemo = n.getStorageSync("logininfo").cardNumber, 
                    this.make()) : this.getdynamiccode();
                },
                computed: h(h({}, (0, f.mapState)([ "points", "navbarHeight_a" ])), (0, f.mapGetters)([ "userinfoBg" ])),
                onHide: function() {
                    console.log("关闭"), this.clearGetCode(), this.showLoad = !0;
                },
                onUnload: function() {
                    this.clearGetCode();
                },
                methods: {
                    newInfoA: (g = t(e.default.mark(function t() {
                        var o;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.getNewUserInfo();

                              case 2:
                                o = e.sent, console.log(o), n.setStorageSync("wxuserinfoAvatar", o.userInfo.avatarUrl), 
                                this.avatarUrl = o.userInfo.avatarUrl, this.hasWxtX = !1;

                              case 4:
                              case "end":
                                return e.stop();
                            }
                        }, t, this);
                    })), function() {
                        return g.apply(this, arguments);
                    }),
                    getNewUserInfo: function() {
                        return new Promise(function(e, t) {
                            n.getUserProfile({
                                desc: "会员信息",
                                success: function(t) {
                                    console.log(t), e(t);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    refreash: function() {
                        this.clearGetCode(), this.showLoad = !0, this.isRefeash || this.getdynamiccode();
                    },
                    clearGetCode: function() {
                        console.log("清除"), clearTimeout(this.timeObj), clearInterval(this.sevtime), console.log(this.sevtime), 
                        this.timeObj = "", this.sevtime = "", this.codetime = 30;
                    },
                    getdynamiccode: function() {
                        var e = this;
                        this.showLoad = !0, this.isRefeash = !0, u.default.getdynamiccode({
                            idType: "2",
                            id: n.getStorageSync("unionId"),
                            flag: 1
                        }).then(function(t) {
                            console.log(t), 0 == t.resultCode ? (e.dynamicCode = t.data.dynamicCode, e.textDemo = t.data.dynamicCode, 
                            e.showCanvas = !0, e.canvasImg = "", e.desname = t.data.dynamicCode, e.expiryTimeEnd = l.default.getMyDate(t.data.expiryTimeEnd), 
                            e.timeTZ = l.default.getMyDate(t.data.time), e.make(), e.getCode(t.data.expiryTimeEnd, t.data.time), 
                            e.codeTimeFun(), e.showLoad = !1, e.isRefeash = !1, e.isError = !1) : (e.isRefeash = !1, 
                            e.isError = !0);
                        }).catch(function() {
                            e.isRefeash = !1, e.isError = !0;
                        });
                    },
                    getCode: function(e, t) {
                        var n = this;
                        clearTimeout(n.timeObj), n.timeObj = "";
                        var o = new Date().getTime();
                        console.log(e - o);
                        var a = e - t;
                        console.log(a), this.startTime = l.default.getMyDate(o), console.log("开始时间:", o), 
                        this.dtime = a, n.timeObj = setTimeout(function() {
                            var e = new Date().getTime();
                            console.log("结束时间:", e);
                            var t = e - o;
                            console.log("时间差", t), clearInterval(n.sevtime), n.codetime = 30, clearTimeout(n.timeObj), 
                            n.getdynamiccode(), n.showLoad = !0;
                        }, a);
                    },
                    codeTimeFun: function() {
                        var e = this;
                        clearInterval(this.sevtime), this.sevtime = "", this.sevtime = setInterval(function() {
                            e.codetime = e.codetime - 1;
                        }, 1e3);
                    },
                    make: function() {
                        var e = this;
                        c.default.make({
                            canvasId: "qrcode",
                            componentInstance: this,
                            text: this.textDemo,
                            size: n.upx2px(336),
                            margin: 10,
                            backgroundColor: "#ffffff",
                            foregroundColor: "#000000",
                            fileType: "jpg",
                            correctLevel: c.default.defaults.correctLevel,
                            success: function(t) {
                                console.log(t), e.canvasImg = t, e.showCanvas = !1;
                            }
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        s.default.getRuledesc({
                            type: 1
                        }).then(function(t) {
                            e.ruleDesc = t.data[0].content;
                        });
                    },
                    gocode: function() {
                        this.showFlag = !0, this.showCanvas = !1;
                    },
                    navigateTo: function(e) {
                        v.hxt.sendAction("point_go"), n.navigateTo({
                            url: e
                        });
                    },
                    switchTab: function(e) {
                        n.switchTab({
                            url: e
                        });
                    }
                }
            };
            o.default = p;
        }).call(this, a("543d").default);
    },
    "890f": function(e, t, n) {
        (function(e) {
            var t = n("4ea4");
            n("a1ea"), t(n("66fd"));
            var o = t(n("b3f0"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(o.default);
        }).call(this, n("543d").createPage);
    },
    adce: function(e, t, n) {
        var o = n("d34c");
        n.n(o).a;
    },
    b3f0: function(e, t, n) {
        n.r(t);
        var o = n("c5ef"), a = n("e57e");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        n("adce");
        var r = n("f0c5"), c = Object(r.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = c.exports;
    },
    c5ef: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.showFlag = !1;
            }, e.e1 = function(t) {
                e.showFlag = !1;
            });
        }, a = [];
    },
    d34c: function(e, t, n) {},
    e57e: function(e, t, n) {
        n.r(t);
        var o = n("4ecd"), a = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        t.default = a.a;
    }
}, [ [ "890f", "common/runtime", "common/vendor" ] ] ]);