// activity/activity_index/activity_index.js
Page({data: {}})