(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/Zdetail" ], {
    "26a7": function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        e.default = {
            name: "Zdetail",
            props: {
                name: "",
                num: "",
                time: ""
            },
            methods: {}
        };
    },
    "84cc": function(n, e, t) {
        var o = t("d1ae");
        t.n(o).a;
    },
    9789: function(n, e, t) {
        t.r(e);
        var o = t("a87d"), a = t("d9e0");
        for (var c in a) "default" !== c && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        t("84cc");
        var u = t("f0c5"), l = Object(u.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = l.exports;
    },
    a87d: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    d1ae: function(n, e, t) {},
    d9e0: function(n, e, t) {
        t.r(e);
        var o = t("26a7"), a = t.n(o);
        for (var c in o) "default" !== c && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = a.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/Zdetail-create-component", {
    "components/Zdetail-create-component": function(n, e, t) {
        t("543d").createComponent(t("9789"));
    }
}, [ [ "components/Zdetail-create-component" ] ] ]);