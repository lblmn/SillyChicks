// pureFeeling/hdShare/turnGet.js
Page({data: {}})