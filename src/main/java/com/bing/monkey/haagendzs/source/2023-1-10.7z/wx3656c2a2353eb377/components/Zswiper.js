(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/Zswiper" ], {
    "0254": function(n, e, t) {
        t.r(e);
        var i = t("8166"), o = t.n(i);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(a);
        e.default = o.a;
    },
    "05e0": function(n, e, t) {
        t.d(e, "b", function() {
            return i;
        }), t.d(e, "c", function() {
            return o;
        }), t.d(e, "a", function() {});
        var i = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    4483: function(n, e, t) {
        t.r(e);
        var i = t("05e0"), o = t("0254");
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        t("d84b");
        var r = t("f0c5"), c = Object(r.a)(o.default, i.b, i.c, !1, null, "53cdc6f8", null, !1, i.a, void 0);
        e.default = c.exports;
    },
    "6ae4": function(n, e, t) {},
    8166: function(n, e, t) {
        var i = t("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, i(t("12ab")), getApp();
        var o = {
            name: "Zswiper",
            data: function() {
                return {
                    newSwiper: this.swiper,
                    currentIndex: 0
                };
            },
            props: {
                swiper: {
                    type: Object,
                    default: function() {
                        return {
                            imgUrls: [],
                            indicatorDots: !0,
                            autoplay: !0,
                            interval: 3e3,
                            duration: 500,
                            current: 0
                        };
                    }
                }
            },
            watch: {
                "swiper.imgUrls": {
                    handler: function(n, e) {
                        this.newSwiper.imgUrls = n;
                    },
                    deep: !0
                }
            },
            methods: {
                animationfinish: function(n) {},
                changeCurrent: function(n) {
                    this.currentIndex = n.detail.current;
                },
                goWheel: function(n, e, t) {
                    console.log(t), t.isBottom ? getApp().hxt.sendAction("dibubanner_clk", {
                        bottom_banner_campaign_name: t.title,
                        bottom_banner_campaign_id: t.id
                    }) : getApp().hxt.sendAction("homekv_clk", {
                        homekv_name: t.title,
                        kvcampaign_id: t.id
                    }), n && (e ? this.$emit("navigateTo", {
                        url: n,
                        outAppid: e
                    }) : this.$emit("navigateTo", n));
                }
            }
        };
        e.default = o;
    },
    d84b: function(n, e, t) {
        var i = t("6ae4");
        t.n(i).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/Zswiper-create-component", {
    "components/Zswiper-create-component": function(n, e, t) {
        t("543d").createComponent(t("4483"));
    }
}, [ [ "components/Zswiper-create-component" ] ] ]);