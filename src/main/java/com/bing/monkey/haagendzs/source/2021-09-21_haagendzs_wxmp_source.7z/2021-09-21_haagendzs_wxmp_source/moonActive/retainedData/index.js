// moonActive/retainedData/index.js
Page({data: {}})