// newStore/birthAct/index.js
Page({data: {}})