// moonActive/lifecycle/index_new.js
Page({data: {}})