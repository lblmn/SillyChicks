(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/coffee/jidou" ], {
    "08f3": function(n, t, e) {
        e.r(t);
        var o = e("6ddf"), c = e("d39c");
        for (var i in c) "default" !== i && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(i);
        e("e323");
        var r = e("f0c5"), u = Object(r.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    "6ddf": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, c = [];
    },
    "9a3b": function(n, t, e) {},
    bbce: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("f4aa"), t(e("66fd")), n(t(e("08f3")).default);
        }).call(this, e("543d").createPage);
    },
    c244: function(n, t, e) {
        (function(n) {
            function o(n, t) {
                var e = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(n);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable;
                    })), e.push.apply(e, o);
                }
                return e;
            }
            function c(n) {
                for (var t = 1; t < arguments.length; t++) {
                    var e = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(e), !0).forEach(function(t) {
                        i(n, t, e[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : o(Object(e)).forEach(function(t) {
                        Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t));
                    });
                }
                return n;
            }
            function i(n, t, e) {
                return t in n ? Object.defineProperty(n, t, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[t] = e, n;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(e("3dbc")), u = {
                name: "jidou",
                components: {
                    Zduihuan: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/Zduihuan") ]).then(function() {
                            return resolve(e("b1d9"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    uniIcons: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(e("349f"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        cardList: [],
                        nextId: "",
                        pageSize: 10,
                        noMore: !1
                    };
                },
                onLoad: function() {
                    var n = getApp().globalData.PointAccountResult.filter(function(n) {
                        return n.pointAccountName.indexOf("集豆") > -1;
                    })[0];
                    this.pointAccountId = n.pointAccountId, this.getList();
                },
                methods: {
                    getList: function() {
                        var t = this, e = {
                            idType: 1,
                            id: n.getStorageSync("socialhubId"),
                            pointAccountId: this.pointAccountId,
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        };
                        "" == this.nextId && delete e.nextId, r.default.pointexchangeList(e).then(function(e) {
                            n.hideLoading(), 0 == e.resultCode && (e.data.nextId && (t.nextId = e.data.nextId), 
                            e.data.list.forEach(function(n) {
                                t.cardList.push(c(c({}, n), {}, {
                                    value: n.score + " 集豆",
                                    num: n.qty
                                }));
                            }), e.data.nextId || (t.noMore = !0));
                        });
                    },
                    goCoffee: function() {
                        n.navigateBack();
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (n.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), this.getList());
                    }
                }
            };
            t.default = u;
        }).call(this, e("543d").default);
    },
    d39c: function(n, t, e) {
        e.r(t);
        var o = e("c244"), c = e.n(o);
        for (var i in o) "default" !== i && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = c.a;
    },
    e323: function(n, t, e) {
        var o = e("9a3b");
        e.n(o).a;
    }
}, [ [ "bbce", "common/runtime", "common/vendor" ] ] ]);