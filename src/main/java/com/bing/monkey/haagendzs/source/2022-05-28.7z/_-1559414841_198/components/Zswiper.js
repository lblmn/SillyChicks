(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/Zswiper" ], {
    1586: function(n, e, t) {
        var o = t("ee97");
        t.n(o).a;
    },
    2521: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, function(n) {
            n && n.__esModule;
        }(t("394d")), getApp();
        var o = {
            name: "Zswiper",
            data: function() {
                return {
                    newSwiper: this.swiper,
                    currentIndex: 0
                };
            },
            props: {
                swiper: {
                    type: Object,
                    default: function() {
                        return {
                            imgUrls: [],
                            indicatorDots: !0,
                            autoplay: !0,
                            interval: 3e3,
                            duration: 500,
                            current: 0
                        };
                    }
                }
            },
            watch: {
                "swiper.imgUrls": {
                    handler: function(n, e) {
                        this.newSwiper.imgUrls = n;
                    },
                    deep: !0
                }
            },
            methods: {
                animationfinish: function(n) {},
                changeCurrent: function(n) {
                    this.currentIndex = n.detail.current;
                },
                goWheel: function(n, e, t) {
                    console.log(t), getApp().hxt.sendAction("homekv_clk", {
                        homekv_name: t.title,
                        kvcampaign_id: t.id
                    }), n && (e ? this.$emit("navigateTo", {
                        url: n,
                        outAppid: e
                    }) : this.$emit("navigateTo", n));
                }
            }
        };
        e.default = o;
    },
    "5d9b": function(n, e, t) {
        t.r(e);
        var o = t("6bb2"), i = t("ab2e");
        for (var r in i) "default" !== r && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(r);
        t("1586");
        var a = t("f0c5"), c = Object(a.a)(i.default, o.b, o.c, !1, null, "21af4bc8", null, !1, o.a, void 0);
        e.default = c.exports;
    },
    "6bb2": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return i;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    ab2e: function(n, e, t) {
        t.r(e);
        var o = t("2521"), i = t.n(o);
        for (var r in o) "default" !== r && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(r);
        e.default = i.a;
    },
    ee97: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/Zswiper-create-component", {
    "components/Zswiper-create-component": function(n, e, t) {
        t("543d").createComponent(t("5d9b"));
    }
}, [ [ "components/Zswiper-create-component" ] ] ]);