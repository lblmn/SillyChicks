// ebuyCard/hhswActivity/index_ebuy.js
Page({data: {}})