(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/luckbag/turnGet" ], {
    1787: function(e, n, o) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            o("f4aa"), n(o("66fd")), e(n(o("ed6e")).default);
        }).call(this, o("543d").createPage);
    },
    "584e": function(e, n, o) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = t(o("1328")), i = t(o("11e1")), c = {
                data: function() {
                    return {
                        textareaValue: "",
                        imgUrl: a.default.assetsRoot,
                        showloginDialog: !1,
                        showRead: !1,
                        isShowSharePopup: !1,
                        helpinfo: "",
                        nickName: "",
                        checkCodeState: !1
                    };
                },
                onLoad: function(e) {
                    this.textid = e.textid, this.getTextInfo();
                },
                onShow: function() {},
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("a81e"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                destroyed: function() {
                    console.log("销毁了");
                },
                onHide: function() {
                    console.log("关闭了"), e.removeStorageSync("successInfo");
                },
                methods: {
                    closepopup: function() {
                        this.checkCodeState ? (this.isShowSharePopup = !1, e.redirectTo({
                            url: "/pages/mine/mycard"
                        })) : this.isShowSharePopup = !1;
                    },
                    getTextInfo: function() {
                        var e = this;
                        i.default.transferGet(this.textid).then(function(n) {
                            console.log(n), e.textareaValue = n.data.remark, e.couponCode = n.data.couponCode, 
                            e.openid = n.data.openid, e.nickName = n.data.nickName;
                        });
                    },
                    readrule: function() {
                        this.showRead = !1, e.removeStorageSync("successInfo"), this.getCard();
                    },
                    sendCard: function() {
                        0 == Object.keys(e.getStorageSync("logininfo")).length ? this.showloginDialog = !0 : this.getCard();
                    },
                    getCard: function() {
                        var n = this;
                        if (this.openid == e.getStorageSync("openId")) return this.isShowSharePopup = !0, 
                        this.helpinfo = "请勿领取自己的券", !1;
                        i.default.transfer({
                            openid: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "3",
                            remark: this.textareaValue
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (n.isShowSharePopup = !0, n.helpinfo = '成功领取好友赠送的\n哈根达斯产品兑换券一张\n快去小程序哈根达斯会员中心\n"个人中心-我的券包"看看吧', 
                            n.checkCodeState = !0) : "502" == e.code ? (n.isShowSharePopup = !0, n.helpinfo = '您已成功领取\n快去小程序哈根达斯会员中心\n"个人中心-我的券包"看看吧', 
                            n.checkCodeState = !0) : (n.isShowSharePopup = !0, n.helpinfo = "您的礼物已被好友取回\n快去联系TA吧");
                        });
                    }
                }
            };
            n.default = c;
        }).call(this, o("543d").default);
    },
    "944b": function(e, n, o) {
        o.r(n);
        var t = o("584e"), a = o.n(t);
        for (var i in t) "default" !== i && function(e) {
            o.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = a.a;
    },
    afc1: function(e, n, o) {
        var t = o("e3e1");
        o.n(t).a;
    },
    e3e1: function(e, n, o) {},
    ed6e: function(e, n, o) {
        o.r(n);
        var t = o("fe97"), a = o("944b");
        for (var i in a) "default" !== i && function(e) {
            o.d(n, e, function() {
                return a[e];
            });
        }(i);
        o("afc1");
        var c = o("f0c5"), u = Object(c.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        n.default = u.exports;
    },
    fe97: function(e, n, o) {
        o.d(n, "b", function() {
            return t;
        }), o.d(n, "c", function() {
            return a;
        }), o.d(n, "a", function() {});
        var t = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, a = [];
    }
}, [ [ "1787", "common/runtime", "common/vendor" ] ] ]);