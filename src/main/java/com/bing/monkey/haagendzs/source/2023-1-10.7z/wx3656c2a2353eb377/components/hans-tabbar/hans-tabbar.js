(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/hans-tabbar/hans-tabbar" ], {
    "0eb0": function(e, t, n) {
        n.r(t);
        var a = n("75b3"), c = n("77a5");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(o);
        n("fbb7");
        var r = n("f0c5"), s = Object(r.a)(c.default, a.b, a.c, !1, null, "78dbafe2", null, !1, a.a, void 0);
        t.default = s.exports;
    },
    "5eff": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, getApp();
        var a = {
            props: {
                list: {
                    type: Array,
                    default: function() {
                        return [ {
                            iconPath: "../../static/shouye/home_unselected.png",
                            selectedIconPath: "../../static/shouye/home_selected.png",
                            text: "首页"
                        }, {
                            iconPath: "../../static/shouye/clock_in_unselected.png",
                            selectedIconPath: "../../static/shouye/clock_in_selected.png",
                            text: "积心打卡"
                        }, {
                            iconPath: "../../static/shouye/member_code.png"
                        }, {
                            iconPath: "../../static/shouye/order_unselected.png",
                            selectedIconPath: "../../static/shouye/order_selected.png",
                            text: "我的订单"
                        }, {
                            iconPath: "../../static/shouye/center_unselected.png",
                            selectedIconPath: "../../static/shouye/center_selected.png",
                            text: "个人中心"
                        } ];
                    }
                },
                current: {
                    type: Number || String,
                    default: 0
                }
            },
            mounted: function() {},
            data: function() {
                return {
                    currentIndex: this.current
                };
            },
            watch: {
                current: function(e) {
                    console.log(e), this.currentIndex = e;
                }
            },
            methods: {
                tabChange: function(e) {
                    e !== this.currentIndex && this.$emit("tabChange", e);
                }
            }
        };
        t.default = a;
    },
    "75b3": function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return c;
        }), n.d(t, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    "77a5": function(e, t, n) {
        n.r(t);
        var a = n("5eff"), c = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = c.a;
    },
    f7e8: function(e, t, n) {},
    fbb7: function(e, t, n) {
        var a = n("f7e8");
        n.n(a).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/hans-tabbar/hans-tabbar-create-component", {
    "components/hans-tabbar/hans-tabbar-create-component": function(e, t, n) {
        n("543d").createComponent(n("0eb0"));
    }
}, [ [ "components/hans-tabbar/hans-tabbar-create-component" ] ] ]);