// shareStyle/share_moon/turnGet.js
Page({data: {}})