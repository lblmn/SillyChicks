// summerEvaluate/exchangeActivity/turnIndex.js
Page({data: {}})