var e = require("../../@babel/runtime/helpers/interopRequireDefault");

require("../../@babel/runtime/helpers/Arrayincludes");

var t = e(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    "22e0": function(e, t, n) {},
    "43ae": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.showindex = !1;
            }, e.e1 = function(t) {
                e.showindex = !1;
            }, e.e2 = function(t) {
                e.showLogin = !1;
            }, e.e3 = function(t) {
                e.showFlag = !1;
            }, e.e4 = function(t) {
                e.showFlag = !1;
            }, e.e5 = function(t) {
                e.showActivity = !1;
            }, e.e6 = function(t) {
                e.showBannerAct = !1;
            }, e.e7 = function(t) {
                e.showBannerAct = !1;
            }, e.e8 = function(t) {
                e.showrulePop = !1;
            }, e.e9 = function(t) {
                e.showIcon_btn = !1;
            });
        }, i = [];
    },
    a6eb: function(e, o, i) {
        (function(e) {
            var a = i("4ea4"), r = i("7037");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var s = a(i("9523")), c = a(i("9296")), u = a(i("f3d4")), l = a(i("0098")), d = a(i("5db4")), g = a(i("12ab")), h = a(i("7d43")), f = (function(e, t) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== r(e) && "function" != typeof e) return {
                    default: e
                };
                var n = function(e) {
                    if ("function" != typeof WeakMap) return null;
                    var t = new WeakMap(), n = new WeakMap();
                    return function(e) {
                        return e ? n : t;
                    }(e);
                }(t);
                if (n && n.has(e)) return n.get(e);
                var o = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in e) if ("default" !== a && Object.prototype.hasOwnProperty.call(e, a)) {
                    var s = i ? Object.getOwnPropertyDescriptor(e, a) : null;
                    s && (s.get || s.set) ? Object.defineProperty(o, a, s) : o[a] = e[a];
                }
                o.default = e, n && n.set(e, o);
            }(i("5c63")), a(i("bed4"))), p = a(i("9292")), y = a(i("6e7d")), m = a(i("8865")), S = i("26cb");
            function v(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function w(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? v(Object(n), !0).forEach(function(t) {
                        (0, s.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : v(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            var b, x, I, _, P, k, A, T = getApp(), U = {
                components: {
                    uniIcons: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(i("6093"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    Zswiper: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/Zswiper") ]).then(function() {
                            return resolve(i("4483"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    hansTabber: function() {
                        i.e("components/hans-tabbar/hans-tabbar").then(function() {
                            return resolve(i("0eb0"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    headerimg: function() {
                        i.e("components/headerimg").then(function() {
                            return resolve(i("09c2"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    Loading: function() {
                        i.e("components/loading").then(function() {
                            return resolve(i("64ff"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                data: function() {
                    return {
                        isShow_flag14: !1,
                        tzQueryType: "2,3,7,8,11",
                        backQqueryType: "",
                        textinfo: "《隐私政策》",
                        img_home_shouye: y.default.img_home_shouye,
                        imgUrl: u.default.assetsRoot + "/oss",
                        imgoss: u.default.ossurl + "/images/home/",
                        imgossBath: u.default.ossurl + "/images",
                        imgUx: u.default.ossurl + "/UX/index",
                        imgNews: u.default.ossurl + "/newsList/",
                        phone: "",
                        isLogin: !0,
                        hasWxtX: !0,
                        avatarUrl: "",
                        showLogin: !1,
                        cardNum: -1,
                        showindex: !1,
                        showLoading: !1,
                        ruleDesc: "",
                        wxgetPhone: !1,
                        loginRes: {},
                        isnoUnionid: !1,
                        swiper: {
                            imgUrls: [],
                            indicatorDots: !0,
                            autoplay: !0,
                            interval: 3e3,
                            duration: 500,
                            current: 0
                        },
                        swiper2: {
                            imgUrls: [],
                            indicatorDots: !1,
                            autoplay: !0,
                            interval: 2500,
                            duration: 500,
                            current: 0,
                            radius: 20
                        },
                        showFlag: !1,
                        showActivity: !1,
                        isHeightScreen: !1,
                        canIUseGetUserProfile: !1,
                        imgActivityUrl: "",
                        pictype: "",
                        isHasUserInfo: !1,
                        iserror: !1,
                        my_voucher: "",
                        points_mall: "",
                        check_in: "",
                        home_delivery: "",
                        isshowFirst: !1,
                        isGongGao: !1,
                        cangoNext: !1,
                        showIndexRule: !1,
                        showrulePop: !1,
                        ruleDescRule: "",
                        updateScoreValue2: 0,
                        showBannerAct: !1,
                        typeList: [ 2, 7 ],
                        typeVal: [],
                        isBuyCount: -1,
                        backStartDate: "",
                        backEndDate: "",
                        noticeinfoList: [],
                        noticeInfoCount: 0,
                        noticeConfig: {
                            autoplay: !0,
                            interval: 3e3,
                            duration: 500
                        },
                        ishotAct: !1,
                        showIcon_btn: !1,
                        ruleDesc_a: "",
                        ruleDesc_a_title: "",
                        showbuild_a: !1,
                        popupListObj: "",
                        grayStyle: !0
                    };
                },
                onLoad: (A = n(t.default.mark(function n(o) {
                    var i;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            i = this, e.removeStorageSync("hdAid"), e.removeStorageSync("shareback"), e.removeStorageSync("successInfo"), 
                            e.removeStorageSync("detailinfo"), e.removeStorageSync("refreash"), h.default.setSource(o), 
                            this.pictype = o.pictype ? o.pictype : "", console.log(this.pictype), h.default.isHeightPhone().then(function(e) {
                                i.isHeightScreen = e;
                            }).catch(function(e) {
                                i.isHeightScreen = e;
                            }), e.getUserProfile && (this.canIUseGetUserProfile = !0);

                          case 2:
                          case "end":
                            return t.stop();
                        }
                    }, n, this);
                })), function(e) {
                    return A.apply(this, arguments);
                }),
                onShow: (k = n(t.default.mark(function n() {
                    var o;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (e.getBackgroundAudioManager().stop(), !e.getStorageSync("isFirstGoIndex")) {
                                t.next = 13;
                                break;
                            }
                            if (this.isshowFirst = !1, t.t0 = Object.keys(e.getStorageSync("logininfo")).length <= 0, 
                            !t.t0) {
                                t.next = 9;
                                break;
                            }
                            return t.next = 9, this.getList();

                          case 9:
                            this.mainFun(), this.showIconFun(), t.next = 21;
                            break;

                          case 13:
                            return t.next = 15, this.isDie();

                          case 15:
                            return t.next = 17, this.getList();

                          case 17:
                            return t.next = 19, this.getBottomBanner();

                          case 19:
                            this.isshowFirst = !0, e.hideTabBar();

                          case 21:
                            e.getStorageSync("unionId") && -1 != [ "onoRB5iIf1YVsAhd9P1pePeZHO8g", "onoRB5iSDGHsSpyMTbF3Hx8azhwQ", "onoRB5lJFOBlQpzTqngHW50SYK-s" ].indexOf(e.getStorageSync("unionId")) && ((o = e.getUpdateManager()).onCheckForUpdate(function(e) {
                                console.log(e.hasUpdate);
                            }), o.onUpdateReady(function() {
                                e.showModal({
                                    title: "更新提示",
                                    content: "新版本已经准备好，是否重启应用？",
                                    success: function(e) {
                                        e.confirm && o.applyUpdate();
                                    }
                                });
                            }));

                          case 22:
                          case "end":
                            return t.stop();
                        }
                    }, n, this);
                })), function() {
                    return k.apply(this, arguments);
                }),
                onShareAppMessage: function(e) {
                    return "button" === e.from && console.log(e.target), {
                        title: "哈根达斯会员中心小程序",
                        path: "pages/index/index",
                        imageUrl: "".concat(u.default.assetsRoot, "/oss/wxapp/miniprogram.jpg")
                    };
                },
                computed: w(w(w({}, (0, S.mapState)([ "points", "navbarHeight_a", "wxuserinfoAvatar", "updateAmountValue", "updateScoreValue", "serviceTime", "currentTime", "updateCalculateDate", "updateCountValue" ])), (0, 
                S.mapGetters)([ "userinfoBg", "userinfoType", "signInCountNum", "signAgain", "prograss" ])), {}, {
                    newPoints: function() {
                        return this.$store.state.points;
                    },
                    endOverTime: function() {
                        console.log("xxx", this.$store.state.updateCalculateDate);
                        var e = new Date(this.$store.state.updateCalculateDate);
                        if (console.log(e), e) return h.default.dateFormat("YYYY年mm月dd日", e);
                    }
                }),
                methods: w(w({}, (0, S.mapActions)([ "getPoint" ])), {}, {
                    onChooseAvatar: function(e) {
                        console.log(e);
                    },
                    newFun: function(e) {
                        return h.default.getMyDate(e);
                    },
                    gotoNotice: function() {
                        var t = this;
                        t.$refs.Loading.showLoading(), e.navigateTo({
                            url: "/news/list/index",
                            complete: function() {
                                t.$refs.Loading.hideLoading();
                            }
                        });
                    },
                    allPoints: function() {
                        T.hxt.sendAction("all_point_clk");
                        var t;
                        t = !this.newPoints || this.newPoints <= 199 ? "pointA" : this.newPoints > 199 && this.newPoints <= 499 ? "pointB" : this.newPoints > 499 ? "pointC" : "pointA", 
                        e.navigateTo({
                            url: "/pages/shop/shop?tabFrom=" + t
                        });
                    },
                    myCard_coupon: function() {
                        T.hxt.sendAction("coupon_clk"), e.navigateTo({
                            url: "/pages/mine/mycard"
                        });
                    },
                    indexSiteMessage: function() {
                        var t = this;
                        c.default.indexSiteMessage({
                            idType: "1",
                            id: e.getStorageSync("socialhubId"),
                            pageSize: "3"
                        }).then(function(e) {
                            console.log(e), 0 == e.code ? (t.noticeInfoCount = e.data.unReadCount, t.noticeinfoList = e.data.list) : t.noticeinfoList = [];
                        }).catch(function() {
                            t.noticeinfoList = [];
                        });
                    },
                    gotoRights: function(t) {
                        var n;
                        n = "a" == t ? 0 : "b" == t ? 1 : "c" == t ? 2 : "d" == t ? 3 : 0, T.hxt.sendAction("member_benefit_clk"), 
                        e.navigateTo({
                            url: "/evaluation/interests/index?current=" + n
                        });
                    },
                    widthFun: function(e, t) {
                        return -1 == t ? 100 : 100 * parseFloat((t - e) / t).toFixed(2);
                    },
                    showIndexRuleFun: function() {
                        var t = this, n = "69";
                        u.default.envVersion, n = "69", m.default.activityGet(n, {
                            openId: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            console.log(e), 0 == e.code ? (t.ruleDescRule = e.data.activity.ruleDesc ? e.data.activity.ruleDesc.replace(/\n/g, "<br/>") : "暂无规则", 
                            t.showrulePop = !0) : (t.ruleDescRule = "暂无规则", t.showrulePop = !0);
                        }).catch(function() {
                            t.ruleDescRule = "暂无规则", t.showrulePop = !0;
                        });
                    },
                    buildhide_a: function() {
                        this.allPoints(), this.showbuild_a = !1, this.showIcon_btn = !0;
                    },
                    getRuleDesc_a: function() {
                        var t = this;
                        "release" == u.default.envVersion ? this.aid_a = "120" : this.aid_a = "78", m.default.activityGet(this.aid_a, {
                            openId: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            console.log(e), t.ruleDesc_a = e.data.activity.ruleDesc ? e.data.activity.ruleDesc.replace(/\n/g, "<br/>") : "暂无活动规则", 
                            t.ruleDesc_a_title = e.data.activity.name, t.showIcon_btn = !1, t.showbuild_a = !0;
                        }).catch(function() {
                            t.ruleDesc_a = "暂无活动规则", t.showIcon_btn = !1, t.showbuild_a = !0;
                        });
                    },
                    hotAct: function() {
                        var t = this;
                        e.showLoading({
                            mask: !0,
                            title: "Loading"
                        }), this.ishotAct || (this.ishotAct = !0, getApp().hxt.sendAction("lastestcam_clk"), 
                        c.default.hotHome().then(function(t) {
                            console.log(t), 0 == t.code ? "h5" == t.data.type ? (h.default.recordPv(t.data.redirectUrl + "?url=" + t.data.redirectParams + "&hot=h5"), 
                            e.navigateTo({
                                url: t.data.redirectUrl + "?url=" + t.data.redirectParams
                            })) : "ext_mini" == t.data.type ? (h.default.recordPv(t.data.redirectUrl + "?extAppId=" + t.data.extAppId + "&hot=ext_mini"), 
                            e.hideLoading(), e.navigateToMiniProgram({
                                appId: t.data.extAppId,
                                path: t.data.redirectUrl,
                                success: function(e) {
                                    getApp().hxt.sendAction("hd_allow");
                                },
                                fail: function() {
                                    getApp().hxt.sendAction("hd_cancel");
                                }
                            })) : "my_mini" == t.data.type ? (t.data.redirectUrl.indexOf("?") > -1 ? h.default.recordPv(t.data.redirectUrl + "&hot=my_mini") : h.default.recordPv(t.data.redirectUrl + "?hot=my_mini"), 
                            e.navigateTo({
                                url: t.data.redirectUrl,
                                complete: function() {
                                    e.hideLoading();
                                }
                            })) : (h.default.recordPv("/pages/index/noHot"), e.navigateTo({
                                url: "/pages/index/noHot"
                            })) : (h.default.recordPv("/pages/index/noHot"), e.navigateTo({
                                url: "/pages/index/noHot"
                            }));
                        }).catch(function() {
                            h.default.recordPv("/pages/index/noHot"), e.navigateTo({
                                url: "/pages/index/noHot"
                            });
                        }).finally(function() {
                            t.ishotAct = !1;
                        }));
                    },
                    gotoH5: function(t) {
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + encodeURIComponent(t)
                        });
                    },
                    isDie: function() {
                        var e = this;
                        p.default.isDie().then(function(t) {
                            0 == t.code ? e.grayStyle = !1 : e.grayStyle = !0;
                        }).catch(function() {
                            e.grayStyle = !0;
                        });
                    },
                    getBottomBanner: function() {
                        var e = this;
                        p.default.getBanner("btm").then(function(t) {
                            0 == t.code && (e.swiper2.imgUrls = t.data.map(function(e) {
                                return w(w({}, e), {}, {
                                    newpicUrl: u.default.assetsRoot + e.picUrl,
                                    swiperheight: 210,
                                    isBottom: !0
                                });
                            }));
                        });
                    },
                    checkIn: function() {
                        var e = [ "onoRB5iIf1YVsAhd9P1pePeZHO8g" ];
                        for (var t in e) {
                            var n = new Date().getTime();
                            f.default.signIn({
                                unionId: e[t],
                                sign: h.default.mdString(n, {
                                    unionId: e[t]
                                }),
                                timestamp: n
                            }).then(function(e) {
                                console.log(e);
                            });
                        }
                    },
                    gotorule: function() {
                        e.navigateTo({
                            url: "/pages/mine/rule?frompath=index"
                        });
                    },
                    showAgain: function() {
                        getApp().hxt.sendAction("private_accept"), this.isshowFirst = !1, e.setStorageSync("isFirstGoIndex", !0), 
                        this.mainFun(), this.showIconFun();
                    },
                    mainFun: (P = n(t.default.mark(function n() {
                        var o, i, a, r, s, l, d, g;
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return h.default.recordPv(), t.next = 3, this.isDie();

                              case 3:
                                return t.next = 5, this.getBottomBanner();

                              case 5:
                                if (this.getHome_delivery(), !(Object.keys(e.getStorageSync("logininfo")).length > 0)) {
                                    t.next = 23;
                                    break;
                                }
                                if (console.log(T.hxt), T.hxt.identify({
                                    openid: e.getStorageSync("openId"),
                                    unionid: e.getStorageSync("unionId")
                                }), T.hxt.setUserInfo({
                                    cust_id: e.getStorageSync("socialhubId"),
                                    phone: e.getStorageSync("logininfo").mobilePhone
                                }), T.hxt.sendAction("menu_home_clk"), console.log("获取信息"), this.isHasUserInfo = !0, 
                                !e.getStorageSync("startTime")) {
                                    t.next = 19;
                                    break;
                                }
                                if (o = e.getStorageSync("startTime"), i = new Date().getTime(), r = (a = i - o) / 1e3 / 60 / 60 / 24, 
                                s = Math.floor(r), l = a / 1e3 / 60 / 60 - 12 * s, d = Math.floor(l), console.log("天数", s), 
                                console.log("小时", d), !(d >= 12)) {
                                    t.next = 13;
                                    break;
                                }
                                this.getMemberinfo(), e.setStorageSync("startTime", new Date().getTime()), t.next = 17;
                                break;

                              case 13:
                                return this.typeParamList(), this.indexSiteMessage(), this.getPoint(), t.next = 16, 
                                this.getCardnum();

                              case 16:
                                this.getRecord();

                              case 17:
                                t.next = 20;
                                break;

                              case 19:
                                this.getMemberinfo(), e.setStorageSync("startTime", new Date().getTime());

                              case 20:
                                this.pictype && this.getByType(), e.showTabBar(), this.cangoNext = !0, t.next = 31;
                                break;

                              case 23:
                                return this.isHasUserInfo = !1, e.hideTabBar(), t.next = 27, this.doLogin();

                              case 27:
                                this.loginRes = t.sent, console.log(this.loginRes), g = this, setTimeout(function() {
                                    c.default.login({
                                        code: g.loginRes.code,
                                        appId: u.default.appId
                                    }).then(function(t) {
                                        console.log(t), 0 == t.code ? (e.setStorageSync("openId", t.data.openid), e.setStorageSync("sessionKey", t.data.sessionKey), 
                                        g.iserror = !1, t.data.unionId ? (console.log("有unionid"), e.setStorageSync("unionId", t.data.unionId), 
                                        g.getMemberinfo()) : (e.hideTabBar(), console.log("没unionid"), setTimeout(function() {
                                            g.isnoUnionid = !0, g.isLogin = !1;
                                        }, 150))) : (e.showToast({
                                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                                            icon: "none"
                                        }), g.iserror = !0);
                                    }).catch(function(t) {
                                        e.showToast({
                                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                                            icon: "none"
                                        }), g.iserror = !0;
                                    });
                                }, 300);

                              case 31:
                              case "end":
                                return t.stop();
                            }
                        }, n, this);
                    })), function() {
                        return P.apply(this, arguments);
                    }),
                    gotoMine: function() {
                        var t = this;
                        e.navigateTo({
                            url: "/pages/mine/info?source=fromIndex",
                            success: function() {
                                t.isShow_flag14 = !1;
                            }
                        });
                    },
                    nextAgain: function() {
                        this.isShow_flag14 = !1, this.getPopupList(this.popupListObj);
                    },
                    queryInfo: function(t) {
                        var n = this;
                        1 == t.is14YearsOld ? this.isShow_flag14 = !1 : 0 == t.is14YearsOld && (this.isShow_flag14 = !0), 
                        c.default.queryBannerByType(w({
                            unionid: e.getStorageSync("unionId"),
                            backQqueryType: this.backQqueryType
                        }, t)).then(function(e) {
                            if (0 == e.code) {
                                if (e.data.bannerList.length > 0) {
                                    var t = e.data.bannerList.map(function(e) {
                                        return w(w({}, e), {}, {
                                            newpicUrl: u.default.assetsRoot + e.picUrl
                                        });
                                    });
                                    n.swiper.imgUrls = t;
                                }
                                e.data.popupList.length > 0 && (n.pictype || (n.popupListObj = e.data.popupList, 
                                n.isShow_flag14 || n.getPopupList(e.data.popupList)));
                            }
                        });
                    },
                    showIconFun: function() {
                        var e = new Date(), t = h.default.dateFormat("YYYY-mm-dd", e);
                        h.default.timeDiffAll(t, "2022-08-15", "2022-09-10") ? this.showIcon_btn = !0 : this.showIcon_btn = !1;
                    },
                    typeParamList: function() {
                        var t = this;
                        c.default.typeParamList({
                            unionid: e.getStorageSync("unionId"),
                            frontQueryType: "2,7,8,11"
                        }).then(function(e) {
                            console.log(e), 0 == e.code ? (t.tzQueryType = e.data.tzQueryType, t.backQqueryType = e.data.backQqueryType, 
                            1 == e.data.isBuyCount && (t.isBuyCount = 1, t.backStartDate = e.data.backStartDate, 
                            t.backEndDate = e.data.backEndDate), t.getuserinfoState()) : t.getuserinfoState();
                        }).catch(function() {
                            t.getuserinfoState();
                        });
                    },
                    queryBanner: function(e) {
                        var t = this;
                        console.log(this.typeVal);
                        var n = {};
                        if (this.typeVal.length > 0) console.log(e), n = {
                            queryType: this.typeVal.join()
                        }, this.typeVal.forEach(function(t) {
                            n[t] = e[t] ? e[t] : "";
                        }), console.log(n); else {
                            var o = e.tierName, i = e.updateScoreValue;
                            n = {
                                queryType: "tierName,updateScoreValue",
                                tierName: o,
                                updateScoreValue: i
                            };
                        }
                        c.default.queryBanner(n).then(function(e) {
                            console.log(e), 0 == e.code && (e.data.bannerList.length > 0 && (t.swiper.imgUrls = e.data.bannerList.map(function(e) {
                                return w(w({}, e), {}, {
                                    newpicUrl: u.default.assetsRoot + e.picUrl
                                });
                            })), e.data.popupList.length > 0 && (t.pictype || t.getPopupList(e.data.popupList)));
                        });
                    },
                    getuserinfoState: function() {
                        var t = this, n = {
                            idType: "2",
                            id: e.getStorageSync("unionId"),
                            type: "2,3,7,8,11"
                        };
                        1 == this.isBuyCount && (n.startDate = this.backStartDate, n.endDate = this.backEndDate), 
                        c.default.getmemberForProgress(n).then(function(e) {
                            if (0 == e.resultCode) {
                                var n = e.data, o = n.tierName, i = n.updateScoreValue, a = n.is14YearsOld;
                                e.data.tzCode = 0, console.log(e.data), t.queryInfo(e.data), t.$store.commit("updateUserInfo", o), 
                                t.$store.commit("updateScoreValue", i || 0), t.updateScoreValue2 = i ? parseInt(i) : 0, 
                                t.$store.commit("is14YearsOldFun", a), t.$store.commit("forProgress", e.data);
                            } else t.queryInfo({
                                tzCode: -1
                            });
                        }).catch(function() {
                            t.queryInfo({
                                tzCode: -1
                            });
                        });
                    },
                    getHome_delivery: function() {
                        var e = this;
                        c.default.home_delivery().then(function(t) {
                            if (console.log(t), 0 == t.code && t.data.length > 0) {
                                e.my_voucher = "", e.points_mall = "", e.check_in = "", e.home_delivery = "";
                                for (var n = 0; n < t.data.length; n++) "home_delivery" == t.data[n].type ? e.home_delivery = t.data[n].name : "my_voucher" == t.data[n].type ? e.my_voucher = t.data[n].name : "points_mall" == t.data[n].type ? e.points_mall = t.data[n].name : "check_in" == t.data[n].type && (e.check_in = t.data[n].name);
                            }
                        });
                    },
                    navigateToNo: function(t) {
                        e.navigateTo({
                            url: t
                        });
                    },
                    gotoMiniProgram: function() {
                        h.default.recordPv("pages/index/index?appid=wxf83dc13b5390d17b"), getApp().hxt.sendAction("homedelivery_clk"), 
                        e.navigateToMiniProgram({
                            appId: "wxf83dc13b5390d17b",
                            path: "pages/index/index",
                            success: function(e) {
                                getApp().hxt.sendAction("hd_allow");
                            },
                            fail: function() {
                                getApp().hxt.sendAction("hd_cancel");
                            }
                        });
                    },
                    gotoLink: function() {
                        this.imgActiveLink.indexOf("/mine/mine") > 0 ? e.switchTab({
                            url: this.imgActiveLink
                        }) : this.pictype ? Object.keys(e.getStorageSync("logininfo")).length > 0 && (this.showActivity = !1, 
                        this.getRecord("HD-618")) : this.imgActiveLink.indexOf("moonActive/rule/index") > 0 && "success" == e.getStorageSync("isGetMoonRule") ? e.navigateTo({
                            url: "/pages/shop/shop"
                        }) : e.navigateTo({
                            url: this.imgActiveLink
                        });
                    },
                    closeActivity: function() {
                        this.pictype && Object.keys(e.getStorageSync("logininfo")).length > 0 && this.getRecord("HD-618"), 
                        this.showActivity = !1;
                    },
                    getPopupList: (_ = n(t.default.mark(function n(o) {
                        var i, a, r, s;
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                if (!e.getStorageSync("unionId") || "/evaluation/repurchase/index" != o[0].linkUrl) {
                                    t.next = 6;
                                    break;
                                }
                                return t.next = 3, this.existsGive();

                              case 3:
                                if (i = t.sent, console.log(i), 602 != i.code && 604 != i.code && 601 != i.code) {
                                    t.next = 6;
                                    break;
                                }
                                return t.abrupt("return", (this.showActivity = !1, !1));

                              case 6:
                                o.length > 0 && (o && "/evaluation/repurchase/index" == o[0].linkUrl ? this.showIndexRule = !0 : this.showIndexRule = !1, 
                                "1" == o[0].frequency ? (e.removeStorageSync("isFirstPopupList"), this.imgActivityUrl = u.default.assetsRoot + o[0].picUrl, 
                                this.imgActiveLink = o[0].linkUrl, this.showActivity = !0) : "3" == o[0].frequency ? new Date().getHours() > 12 ? (1 == e.getStorageSync("unionid_back") && e.removeStorageSync("unionid_back"), 
                                e.getStorageSync("unionid_back") || (this.imgActivityUrl = u.default.assetsRoot + o[0].picUrl, 
                                this.imgActiveLink = o[0].linkUrl, this.showActivity = !0, e.setStorageSync("unionid_back", 2))) : (2 == e.getStorageSync("unionid_back") && e.removeStorageSync("unionid_back"), 
                                e.getStorageSync("unionid_back") || (this.imgActivityUrl = u.default.assetsRoot + o[0].picUrl, 
                                this.imgActiveLink = o[0].linkUrl, this.showActivity = !0, e.setStorageSync("unionid_back", 1))) : (a = new Date(new Date(new Date().toLocaleDateString()).getTime() + 864e5 - 1), 
                                r = new Date().getTime(), s = new Date(a).getTime(), console.log(s, "........"), 
                                s - r <= 0 && e.removeStorageSync("isFirstPopupList"), e.getStorageSync("isFirstPopupList") || (this.imgActivityUrl = u.default.assetsRoot + o[0].picUrl, 
                                this.imgActiveLink = o[0].linkUrl, this.showActivity = !0, e.setStorageSync("isFirstPopupList", !0))));

                              case 7:
                              case "end":
                                return t.stop();
                            }
                        }, n, this);
                    })), function(e) {
                        return _.apply(this, arguments);
                    }),
                    getPopupList2: function() {
                        var o = this;
                        c.default.getPopupList().then(function() {
                            var i = n(t.default.mark(function n(i) {
                                var a, r, s, c, l;
                                return t.default.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        if (console.log(i), !e.getStorageSync("unionId") || !i.data || "/evaluation/repurchase/index" != i.data[0].linkUrl) {
                                            t.next = 6;
                                            break;
                                        }
                                        return t.next = 3, o.existsGive();

                                      case 3:
                                        if (a = t.sent, console.log(a), 602 != a.code && 604 != a.code && 601 != a.code) {
                                            t.next = 6;
                                            break;
                                        }
                                        return t.abrupt("return", (o.showActivity = !1, !1));

                                      case 6:
                                        0 == i.code && i.data.length > 0 && (i.data && "/evaluation/repurchase/index" == i.data[0].linkUrl ? o.showIndexRule = !0 : o.showIndexRule = !1, 
                                        "1" == i.data[0].frequency ? (e.removeStorageSync("isFirstPopupList"), o.imgActivityUrl = u.default.assetsRoot + i.data[0].picUrl, 
                                        o.imgActiveLink = i.data[0].linkUrl, o.showActivity = !0) : "3" == i.data[0].frequency ? (r = new Date(), 
                                        r.getHours() > 12 ? (1 == e.getStorageSync("unionid_back") && e.removeStorageSync("unionid_back"), 
                                        e.getStorageSync("unionid_back") || (o.imgActivityUrl = u.default.assetsRoot + i.data[0].picUrl, 
                                        o.imgActiveLink = i.data[0].linkUrl, o.showActivity = !0, e.setStorageSync("unionid_back", 2))) : (2 == e.getStorageSync("unionid_back") && e.removeStorageSync("unionid_back"), 
                                        e.getStorageSync("unionid_back") || (o.imgActivityUrl = u.default.assetsRoot + i.data[0].picUrl, 
                                        o.imgActiveLink = i.data[0].linkUrl, o.showActivity = !0, e.setStorageSync("unionid_back", 1)))) : (s = new Date(new Date(new Date().toLocaleDateString()).getTime() + 864e5 - 1), 
                                        c = new Date().getTime(), l = new Date(s).getTime(), console.log(l, "........"), 
                                        l - c <= 0 && e.removeStorageSync("isFirstPopupList"), e.getStorageSync("isFirstPopupList") || (o.imgActivityUrl = u.default.assetsRoot + i.data[0].picUrl, 
                                        o.imgActiveLink = i.data[0].linkUrl, o.showActivity = !0, e.setStorageSync("isFirstPopupList", !0))));

                                      case 7:
                                      case "end":
                                        return t.stop();
                                    }
                                }, n);
                            }));
                            return function(e) {
                                return i.apply(this, arguments);
                            };
                        }());
                    },
                    existsGive: function() {
                        return c.default.existsGive(e.getStorageSync("unionId"));
                    },
                    getByType: function() {
                        var e = this;
                        c.default.getByType(this.pictype).then(function(t) {
                            console.log(t), 0 == t.code && (e.imgActivityUrl = u.default.assetsRoot + t.data.picUrl, 
                            e.imgActiveLink = t.data.linkUrl, e.showActivity = !0);
                        });
                    },
                    gotoWebView: function() {
                        e.navigateTo({
                            url: "../webView/index"
                        });
                    },
                    newInfoA: (I = n(t.default.mark(function n() {
                        var o;
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, this.getNewUserInfo();

                              case 2:
                                o = t.sent, console.log(o), e.setStorageSync("wxuserinfoAvatar", o.userInfo.avatarUrl), 
                                this.avatarUrl = o.userInfo.avatarUrl, this.hasWxtX = !1;

                              case 4:
                              case "end":
                                return t.stop();
                            }
                        }, n, this);
                    })), function() {
                        return I.apply(this, arguments);
                    }),
                    newInfo: (x = n(t.default.mark(function n() {
                        var o, i;
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, this.getNewUserInfo();

                              case 2:
                                return o = t.sent, console.log(o), e.setStorageSync("wxinfo", o.userInfo), t.next = 6, 
                                this.getUnionid(o);

                              case 6:
                                i = t.sent, e.setStorageSync("unionId", i.data.unionId), this.getMemberinfo();

                              case 8:
                              case "end":
                                return t.stop();
                            }
                        }, n, this);
                    })), function() {
                        return x.apply(this, arguments);
                    }),
                    getNewUserInfo: function() {
                        return new Promise(function(t, n) {
                            e.getUserProfile({
                                desc: "会员信息",
                                success: function(e) {
                                    console.log(e), t(e);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    gotoAct: function() {
                        e.redirectTo({
                            url: "../../evaluation/list/index"
                        });
                    },
                    getRecord: function(t) {
                        d.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: t || e.getStorageSync("smsSource")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getList: function() {
                        var e = this;
                        g.default.getList().then(function(t) {
                            0 == t.code && (e.swiper.imgUrls = t.data.map(function(e) {
                                return w(w({}, e), {}, {
                                    newpicUrl: u.default.assetsRoot + e.picUrl
                                });
                            }));
                        });
                    },
                    prevImg: function() {
                        this.swiper.current = this.swiper.current > 0 ? this.swiper.current - 1 : this.swiper.imgUrls.length - 1;
                    },
                    nextImg: function() {
                        this.swiper.current = this.swiper.current < this.swiper.imgUrls.length - 1 ? this.swiper.current + 1 : 0;
                    },
                    onGetUserInfo: (b = n(t.default.mark(function n() {
                        var o, i;
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, this.getUserinfo(this.loginRes);

                              case 2:
                                return o = t.sent, e.setStorageSync("wxinfo", o.userInfo), t.next = 6, this.getUnionid(o);

                              case 6:
                                i = t.sent, e.setStorageSync("unionId", i.data.unionId), this.getMemberinfo();

                              case 8:
                              case "end":
                                return t.stop();
                            }
                        }, n, this);
                    })), function() {
                        return b.apply(this, arguments);
                    }),
                    onGetPhoneNumber: function(t) {
                        var n = this;
                        "getPhoneNumber:fail user deny" == t.detail.errMsg ? console.log("取消授权") : c.default.decrypt({
                            encryptedData: t.detail.encryptedData,
                            openId: e.getStorageSync("openId"),
                            iv: t.detail.iv
                        }).then(function(t) {
                            n.phone = t.data.phoneNumber, e.setStorageSync("userinfoPhone", t.data.phoneNumber), 
                            n.bindQuery();
                        });
                    },
                    doLogin: function() {
                        return new Promise(function(t, n) {
                            e.login({
                                success: function(e) {
                                    console.log(e), t(e);
                                },
                                fail: function(e) {
                                    console.log(e), n(e);
                                }
                            });
                        });
                    },
                    getUserinfo: function(t) {
                        return console.log(t), new Promise(function(n, o) {
                            t.code ? e.getUserInfo({
                                success: function(e) {
                                    console.log(e), n(e);
                                }
                            }) : (o("登录失败！" + t.errMsg), console.log("登录失败！" + t.errMsg));
                        });
                    },
                    getOpenid: function(e) {},
                    getUnionid: function(t) {
                        return c.default.decrypt({
                            encryptedData: t.encryptedData,
                            openId: e.getStorageSync("openId"),
                            iv: t.iv
                        });
                    },
                    bindQuery: function() {
                        var t = this, n = e.getStorageSync("unionId"), o = e.getStorageSync("openId");
                        c.default.bindquery({
                            thirdPartyId: n,
                            openid: o,
                            source: 2,
                            mobilePhone: this.phone
                        }).then(function(i) {
                            console.log("会员绑定查询入参" + JSON.stringify({
                                thirdPartyId: n,
                                openid: o,
                                source: 2,
                                mobilePhone: t.phone
                            })), console.log("会员绑定查询返回" + JSON.stringify(i)), 0 == i.resultCode ? "E000101" == i.resultDesc ? e.navigateTo({
                                url: "/pages/register/register?fromUrl=index"
                            }) : "E000102" == i.resultDesc ? c.default.bind({
                                thirdPartyId: e.getStorageSync("unionId"),
                                thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                openid: e.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: t.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: e.getStorageSync("unionId"),
                                    thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                    openid: e.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: t.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (t.iserror = !1, 
                                e.setStorageSync("socialhubId", n.data.socialhubId), t.getMemberinfo()) : (e.showToast({
                                    title: "访问异常，小哈正在努力恢复，请稍后重试",
                                    icon: "none"
                                }), that.iserror = !0);
                            }) : "E000103" == i.resultDesc ? (e.setStorageSync("socialhubId", i.data.socialhubId), 
                            t.getMemberinfo()) : t.showFlag = !0 : 1 == i.resultCode ? "E000107" == i.resultDesc ? (t.iserror = !1, 
                            c.default.bind({
                                thirdPartyId: e.getStorageSync("unionId"),
                                thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                openid: e.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: t.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: e.getStorageSync("unionId"),
                                    thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                    openid: e.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: t.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (t.iserror = !1, 
                                e.setStorageSync("socialhubId", n.data.socialhubId), t.getMemberinfo()) : (e.showToast({
                                    title: "访问异常，小哈正在努力恢复，请稍后重试",
                                    icon: "none"
                                }), that.iserror = !0);
                            })) : (e.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), that.iserror = !0) : e.showToast({
                                title: "请求异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    getMemberinfo: function() {
                        var o = this;
                        c.default.getmember({
                            idType: "2",
                            id: e.getStorageSync("unionId")
                        }).then(function() {
                            var i = n(t.default.mark(function n(i) {
                                return t.default.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        if (console.log(i), 0 != i.resultCode) {
                                            t.next = 7;
                                            break;
                                        }
                                        return e.setStorageSync("logininfo", i.data), e.setStorageSync("socialhubId", i.data.socialhubId), 
                                        o.$store.commit("userinfo", i.data), T.hxt.identify({
                                            openid: e.getStorageSync("openId"),
                                            unionid: e.getStorageSync("unionId")
                                        }), T.hxt.setUserInfo({
                                            cust_id: e.getStorageSync("socialhubId"),
                                            phone: e.getStorageSync("logininfo").mobilePhone
                                        }), T.hxt.sendAction("menu_home_clk"), o.typeParamList(), o.indexSiteMessage(), 
                                        o.getPoint(), t.next = 4, o.getCardnum();

                                      case 4:
                                        o.getRecord(), o.isLogin = !0, o.pictype && (o.isHasUserInfo = !0, o.getByType()), 
                                        e.showTabBar(), o.cangoNext = !0, t.next = 8;
                                        break;

                                      case 7:
                                        o.isLogin = !1, o.iserror = !1, o.isLogin ? (o.isLogin = !1, e.hideTabBar(), e.showToast({
                                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                                            icon: "none"
                                        }), that.iserror = !0) : o.wxgetPhone = !0, o.pictype || o.getPopupList2(), o.pictype && (o.isHasUserInfo = !1, 
                                        o.getByType());

                                      case 8:
                                      case "end":
                                        return t.stop();
                                    }
                                }, n);
                            }));
                            return function(e) {
                                return i.apply(this, arguments);
                            };
                        }()).catch(function(t) {
                            console.log("接口出错了"), o.isLogin = !1, e.hideTabBar(), e.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), that.iserror = !0;
                        });
                    },
                    plusPoints: function() {
                        c.default.plusPoints(e.getStorageSync("unionId")).then(function(e) {
                            console.log(e);
                        });
                    },
                    getCardnum: function() {
                        var t = this;
                        return new Promise(function(n, o) {
                            l.default.indexCouponList({
                                idType: 1,
                                id: e.getStorageSync("socialhubId"),
                                state: 1e8,
                                pageSize: 100,
                                unionId: e.getStorageSync("unionId")
                            }).then(function(e) {
                                0 == e.resultCode ? (t.cardNum = e.data >= 100 ? "99+" : e.data, n(e)) : (t.cardNum = 0, 
                                o(e));
                            }).catch(function() {
                                t.cardNum = 0;
                            });
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        l.default.getRuledesc({
                            type: 1
                        }).then(function(t) {
                            e.ruleDesc = t.data[0].content, e.showindex = !0;
                        });
                    },
                    tabbarClick: function() {
                        this.wxgetPhone ? e.showToast({
                            title: "请点击登录验证",
                            icon: "none"
                        }) : this.showLogin = !0;
                    },
                    gotoMoon: function(t) {
                        var n = "";
                        if (t.includes("/moonActive/middle/index")) {
                            var o = new Date(), i = h.default.dateFormat("YYYY-mm-dd", o);
                            h.default.timeDiff(i, "2022-09-09") ? (T.hxt.sendAction("sn_sj_mooncake-pickUp-home"), 
                            T.hxt.sendAction("utm_from", {
                                refer_url: "/pages/index/index",
                                refer_content: "预约提领_首页主入口",
                                refer_channel: "MKT"
                            }), n = t) : (T.hxt.sendAction("sn_sj_mooncake-pickUp"), T.hxt.sendAction("utm_from", {
                                refer_url: "/appointment/pickUp/index",
                                refer_content: "预约提领",
                                refer_channel: "MKT"
                            }), n = "/appointment/pickUp/index?source=F23MC_pickUp&channelLabel=F23MC_pickUp");
                        } else t.includes("distribution/index") ? (T.hxt.sendAction("sn_sj_mooncake-delivery"), 
                        T.hxt.sendAction("utm_from", {
                            refer_url: "/appointment/distribution/index",
                            refer_content: "预约配送",
                            refer_channel: "MKT"
                        }), n = t) : n = t;
                        e.navigateTo({
                            url: n
                        });
                    },
                    gotoCDP: function(t, n) {
                        if (this.iserror) e.showToast({
                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                            icon: "none"
                        }); else {
                            if (!this.isLogin) return this.wxgetPhone ? void e.showToast({
                                title: "请点击登录验证",
                                icon: "none"
                            }) : void (this.showLogin = !0);
                            if (this.cangoNext) if (t.includes("/shop/shop") || t.includes("/attendance/attendance")) {
                                t.includes("/shop/shop") && (t = t + "?tabFrom=" + (!this.newPoints || this.newPoints <= 199 ? "pointA" : this.newPoints > 199 && this.newPoints <= 499 ? "pointB" : this.newPoints > 499 ? "pointC" : "pointA")), 
                                e.navigateTo({
                                    url: t,
                                    complete: function() {
                                        getApp().hxt.sendAction(n);
                                    }
                                });
                            } else h.default.recordPv(t), e.navigateTo({
                                url: t,
                                complete: function() {
                                    getApp().hxt.sendAction(n);
                                }
                            });
                        }
                    },
                    navigateTo: function(t) {
                        if (this.iserror) e.showToast({
                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                            icon: "none"
                        }); else {
                            if (!this.isLogin) return this.wxgetPhone ? void e.showToast({
                                title: "请点击登录验证",
                                icon: "none"
                            }) : void (this.showLogin = !0);
                            if (this.cangoNext) if (t.url) if (t.url.includes("/shop/shop") || t.url.includes("/pages/attendance/attendance") || h.default.recordPv(t.url), 
                            t.outAppid && "" != t.outAppid) e.navigateToMiniProgram({
                                appId: t.outAppid,
                                path: t.url,
                                success: function(e) {
                                    getApp().hxt.sendAction("hd_allow");
                                },
                                fail: function() {
                                    getApp().hxt.sendAction("hd_cancel");
                                }
                            }); else if (t.url.includes("/shop/shop")) {
                                var n, o = t.url;
                                n = !this.newPoints || this.newPoints <= 199 ? "pointA" : this.newPoints > 199 && this.newPoints <= 499 ? "pointB" : this.newPoints > 499 ? "pointC" : "pointA", 
                                o = o.includes("?") ? o + "&tabFrom=" + n : o + "?tabFrom=" + n, e.navigateTo({
                                    url: o
                                });
                            } else e.navigateTo({
                                url: t.url
                            }); else if (t.includes("/shop/shop") || t.includes("/attendance/attendance") || h.default.recordPv(t), 
                            t.includes("/mine/mine") || t.includes("/code/code")) e.switchTab({
                                url: t
                            }); else if (t.includes("/shop/shop")) {
                                var i;
                                i = !this.newPoints || this.newPoints <= 199 ? "pointA" : this.newPoints > 199 && this.newPoints <= 499 ? "pointB" : this.newPoints > 499 ? "pointC" : "pointA", 
                                t = t.includes("?") ? t + "&tabFrom=" + i : t + "?tabFrom=" + i, e.navigateTo({
                                    url: t
                                });
                            } else t.indexOf("moonActive/rule/index") > 0 ? "success" == e.getStorageSync("isGetMoonRule") ? e.navigateTo({
                                url: "/pages/shop/shop"
                            }) : e.navigateTo({
                                url: t
                            }) : t.indexOf("pages/webView/home_index") > -1 ? e.requestSubscribeMessage({
                                tmplIds: [ "vs2kCdD9yEQ28bUvk2lklAVX8jiO7u5-VoTZjfWzsNk", "_2Xdxp95FeXVwryFbxN6VsVKMFbLwe0HD-FCn9KSyi4" ],
                                complete: function(n) {
                                    e.navigateTo({
                                        url: t
                                    });
                                }
                            }) : "/indexShow" == t ? this.showBannerAct = !0 : e.navigateTo({
                                url: t
                            });
                        }
                    },
                    switchTab: function(t) {
                        if (console.log("switchTab"), !this.isLogin) return this.wxgetPhone ? void e.showToast({
                            title: "请点击登录验证",
                            icon: "none"
                        }) : void (this.showLogin = !0);
                        e.switchTab({
                            url: t
                        });
                    },
                    gopupop: function() {
                        this.getRuleDesc();
                    }
                })
            };
            o.default = U;
        }).call(this, i("543d").default);
    },
    ad9f: function(e, t, n) {
        var o = n("22e0");
        n.n(o).a;
    },
    d25a: function(e, t, n) {
        (function(e) {
            var t = n("4ea4");
            n("a1ea"), t(n("66fd"));
            var o = t(n("e145"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(o.default);
        }).call(this, n("543d").createPage);
    },
    e145: function(e, t, n) {
        n.r(t);
        var o = n("43ae"), i = n("f913");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("ad9f");
        var r = n("f0c5"), s = Object(r.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = s.exports;
    },
    f913: function(e, t, n) {
        n.r(t);
        var o = n("a6eb"), i = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    }
}, [ [ "d25a", "common/runtime", "common/vendor" ] ] ]);