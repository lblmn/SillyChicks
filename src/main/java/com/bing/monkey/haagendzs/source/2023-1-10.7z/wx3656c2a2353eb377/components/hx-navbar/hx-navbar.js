(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/hx-navbar/hx-navbar" ], {
    "0143": function(t, o, n) {
        (function(t) {
            var r = n("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a = r(n("7037")), i = {
                name: "hxNavbar",
                components: {},
                data: function() {
                    return {
                        title: "",
                        backgroundColorRgba: "",
                        backgroundColorRgb: "rgb(222,222,222)",
                        backgroundImage: null,
                        backgroundImageEnd: null,
                        txtColor: "#333333",
                        bgArr: [],
                        colorArr: [],
                        statusBarBackground: "",
                        bgTransparent: 1,
                        bgImgTransparent: [ 1, 1 ],
                        jnWidth: 0,
                        bgIsLine: !1,
                        slotSwitchOpacity: 1,
                        conf: {
                            title: "",
                            height: 44,
                            fixed: !0,
                            statusBar: !0,
                            statusBarFontColor: "#000000",
                            statusBarBackground: null,
                            font: "hxicon",
                            fontSize: "18px",
                            color: "#fff",
                            backgroundColor: [ 1, "#ffffff" ],
                            backgroundImg: null,
                            backgroundColorLinearDeg: "to right",
                            slideHeight: 100,
                            slideBackgroundColor: null,
                            back: !0,
                            backTxt: null,
                            backTabPage: null,
                            backPage: null,
                            leftButton: null,
                            rightButton: null,
                            search: null,
                            shadow: !1,
                            border: !1,
                            barPlaceholder: !0,
                            slotSwitch: 0,
                            rightSlot: !1,
                            rightSlotSwitch: !1
                        }
                    };
                },
                props: {
                    config: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    }
                },
                computed: {
                    statusBarHeight: function() {
                        return t.getSystemInfoSync().statusBarHeight;
                    },
                    navbarHeight: function() {
                        return t.getSystemInfoSync().statusBarHeight + this.conf.height + "px";
                    },
                    screenWidth: function() {
                        return t.getSystemInfoSync().screenWidth;
                    }
                },
                created: function() {
                    var o = t.getMenuButtonBoundingClientRect();
                    console.log(o), this.jnWidth = o.width, this.init();
                },
                mounted: function() {},
                watch: {
                    "config.backgroundImg": {
                        handler: function(t, o) {
                            console.log(t), console.log(o), this.backgroundImage = t, console.info(this.conf);
                        },
                        deep: !0
                    }
                },
                methods: {
                    iconHandle: function(t) {
                        return t = t.replace(/(&#x|;)/g, ""), unescape("%u" + t);
                    },
                    init: function() {
                        if (this.conf = Object.assign(this.conf, this.config), "" != this.conf.title && t.setNavigationBarTitle({
                            title: this.conf.title
                        }), this.conf.title && ("object" == (0, a.default)(this.conf.title) && 2 == this.conf.title.length ? this.title = this.conf.title[0] : this.title = this.conf.title), 
                        this.conf.statusBarBackground && ("object" == (0, a.default)(this.conf.statusBarBackground) && 2 == this.conf.statusBarBackground.length ? this.statusBarBackground = this.conf.statusBarBackground[0] : this.statusBarBackground = this.conf.statusBarBackground), 
                        this.conf.statusBarFontColor && t.setNavigationBarColor({
                            frontColor: "object" == (0, a.default)(this.conf.statusBarFontColor) ? this.conf.statusBarFontColor[0] : this.conf.statusBarFontColor,
                            backgroundColor: "#000000"
                        }), "" != this.conf.color && ("object" == (0, a.default)(this.conf.color) && 2 == this.conf.color.length ? (this.txtColor = this.conf.color[0], 
                        this.colorArr = this.gradientColor(this.conf.color[0], this.conf.color[1], this.conf.slideHeight)) : this.txtColor = this.conf.color), 
                        this.conf.backgroundImg) {
                            var o = "";
                            "object" == (0, a.default)(this.conf.backgroundImg) ? (o = this.conf.backgroundImg[0], 
                            this.conf.backgroundImg.length > 2 && (this.bgTransparent = this.conf.backgroundImg[2])) : (o = this.conf.backgroundImg, 
                            this.bgTransparent = 1), this.backgroundImage = this.bgImgStringHandle(o);
                        }
                        if (this.conf.backgroundColor) {
                            var n = this.conf.backgroundColor[0], r = this.conf.backgroundColor[1];
                            if ("object" == (0, a.default)(r) && r.length > 1 && (this.bgIsLine = !0), this.conf.slideBackgroundColor) {
                                var i = this.conf.slideBackgroundColor[1];
                                if (this.bgArr = [], r && "object" == (0, a.default)(r) && r.length > 0) for (var e in r) this.bgArr.push(this.gradientColor(r[e], i[e], this.conf.slideHeight)); else this.bgArr.push(this.gradientColor(r, i, this.conf.slideHeight));
                            }
                            this.bgTransparent = n, this.setBgColor(r, n);
                        }
                        this.conf.rightButton && this.conf.rightButton.length;
                    },
                    onBack: function() {
                        this.conf.backTabPage ? t.switchTab({
                            url: this.conf.backTabPage
                        }) : this.conf.backPage ? t.redirectTo({
                            url: this.conf.backPage
                        }) : getCurrentPages().length > 1 ? t.navigateBack() : 1 == getCurrentPages().length && t.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    onClickBtn: function(t) {
                        this.$emit("clickBtn", t);
                    },
                    pageScroll: function(o) {
                        var n = parseFloat(o.scrollTop.toFixed(2)), r = this.conf.slideHeight, i = Math.round(n);
                        if (i > 0 ? i -= 1 : i = 0, this.conf.title && "object" == (0, a.default)(this.conf.title) && 2 == this.conf.title.length && (this.title = n <= r ? this.conf.title[0] : this.conf.title[1]), 
                        this.conf.color && "object" == (0, a.default)(this.conf.color) && 2 == this.conf.color.length) {
                            var e = this.colorArr, c = i <= e.length - 1 ? e[i] : e[e.length - 1];
                            this.txtColor = c;
                        }
                        this.slotSwitchOpacity = this.transHandle(n, r, 1, 0), this.conf.statusBarFontColor && "object" == (0, 
                        a.default)(this.conf.statusBarFontColor) && 2 == this.conf.statusBarFontColor.length && (n <= r ? t.setNavigationBarColor({
                            frontColor: this.conf.statusBarFontColor[0],
                            backgroundColor: "#ffffff"
                        }) : t.setNavigationBarColor({
                            frontColor: this.conf.statusBarFontColor[1],
                            backgroundColor: "#ffffff"
                        })), this.conf.statusBarBackground && "object" == (0, a.default)(this.conf.statusBarBackground) && 2 == this.conf.statusBarBackground.length && (this.statusBarBackground = n <= r ? this.conf.statusBarBackground[0] : this.conf.statusBarBackground[1]);
                        var s = this.conf.backgroundImg;
                        if (this.conf.backgroundImg && "object" == (0, a.default)(this.conf.backgroundImg) && s.length > 1) {
                            var l = s.length;
                            this.bgTransparent = l <= 3 ? 1 : this.transHandle(n, r, s[2], s[3]), this.bgImgTransparent[0] = l <= 3 ? 1 : this.transHandle(n, r, s[2], 0), 
                            this.bgImgTransparent[1] = s[3], n <= r ? s[0] : s[1], this.backgroundImage = this.bgImgStringHandle(s[0]), 
                            this.backgroundImageEnd = this.bgImgStringHandle(s[1]);
                        }
                        if (this.conf.slideBackgroundColor) {
                            var f = this.bgArr, g = [];
                            for (var h in this.bgArr) {
                                var u = i <= f[h].length - 1 ? f[h][i] : f[h][f[h].length - 1];
                                g.push(u.replace(/(?:\(|\)|rgb|RGB)*/g, "").split(","));
                            }
                            var d = this.conf.backgroundColor[0], b = this.conf.slideBackgroundColor[0], p = b;
                            if (n <= r) {
                                var B = Math.abs(b - d), k = parseFloat(B / r).toFixed(4), v = parseFloat(k * n).toFixed(2);
                                p = d > b ? d - v : d + v, p = parseFloat(p).toFixed(2);
                            }
                            var C = this.conf.slideBackgroundColor[1], m = "";
                            if ("object" == (0, a.default)(C) && C.length > 1) {
                                m = "linear-gradient(" + this.conf.backgroundColorLinearDeg + ",";
                                var x = g.length;
                                for (var h in g) {
                                    var I = g[h];
                                    m += "rgba(" + I[0] + "," + I[1] + "," + I[2] + "," + p + ")", x != 1 * h + 1 && (m += ",");
                                }
                                m += ")";
                            } else m = "rgba(" + g[0][0] + "," + g[0][1] + "," + g[0][2] + "," + p + ")";
                            this.bgTransparent = p, this.backgroundColorRgba = m;
                        }
                    },
                    transHandle: function(t, o, n, r) {
                        var a = r;
                        if (t <= o) {
                            var i = Math.abs(r - n), e = parseFloat(i / o).toFixed(4), c = parseFloat(e * t).toFixed(2);
                            a = n > r ? n - c : n + c, a = parseFloat(a).toFixed(2);
                        }
                        return a;
                    },
                    gradientColor: function(t, o, n) {
                        for (var r = this.colorRgb(t), a = r[0], i = r[1], e = r[2], c = this.colorRgb(o), s = (c[0] - a) / n, l = (c[1] - i) / n, f = (c[2] - e) / n, g = [], h = 0; h < n; h++) {
                            var u = "rgb(" + parseInt(s * h + a) + "," + parseInt(l * h + i) + "," + parseInt(f * h + e) + ")", d = this.colorHex(u);
                            g.push(d);
                        }
                        return g;
                    },
                    colorRgb: function(t) {
                        if ((t = t.toLowerCase()) && /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/.test(t)) {
                            if (4 === t.length) {
                                for (var o = "#", n = 1; n < 4; n += 1) o += t.slice(n, n + 1).concat(t.slice(n, n + 1));
                                t = o;
                            }
                            var r = [];
                            for (n = 1; n < 7; n += 2) r.push(parseInt("0x" + t.slice(n, n + 2)));
                            return r;
                        }
                        return t;
                    },
                    colorHex: function(t) {
                        var o = t;
                        if (/^(rgb|RGB)/.test(o)) {
                            for (var n = o.replace(/(?:(|)|rgb|RGB)*/g, "").split(","), r = "#", a = 0; a < n.length; a++) {
                                var i = Number(n[a]).toString(16);
                                "0" === (i = i < 10 ? "0" + i : i) && (i += i), r += i;
                            }
                            return 7 !== r.length && (r = o), r;
                        }
                        if (!/^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/.test(o)) return o;
                        var e = o.replace(/#/, "").split("");
                        if (6 === e.length) return o;
                        if (3 === e.length) {
                            var c = "#";
                            for (a = 0; a < e.length; a += 1) c += e[a] + e[a];
                            return c;
                        }
                    },
                    setBgColor: function(t, o) {
                        if ("object" == (0, a.default)(t) && t.length > 0) {
                            var n = "linear-gradient(" + this.conf.backgroundColorLinearDeg + ",", r = null;
                            for (var i in t) {
                                r = t[i];
                                var e = this.colorRgb(r);
                                n += "rgba(".concat(e[0], ", ").concat(e[1], ", ").concat(e[2], ", ").concat(o, ")"), 
                                t.length != 1 * i + 1 && (n += ",");
                            }
                            n += ")", this.backgroundColorRgba = n;
                        } else {
                            var c = t, s = this.colorRgb(c);
                            this.backgroundColorRgba = "rgba(".concat(s[0], ", ").concat(s[1], ", ").concat(s[2], ", ").concat(o, ")");
                        }
                    },
                    bgImgStringHandle: function(t) {
                        return t;
                    },
                    searchConfirm: function(t) {
                        this.$emit("searchConfirm", t.detail);
                    },
                    searchClick: function(t) {
                        this.$emit("searchClick", !0);
                    }
                }
            };
            o.default = i;
        }).call(this, n("543d").default);
    },
    "07ee": function(t, o, n) {
        n.r(o);
        var r = n("0143"), a = n.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(o, t, function() {
                return r[t];
            });
        }(i);
        o.default = a.a;
    },
    "1faa": function(t, o, n) {},
    "614f": function(t, o, n) {
        n.r(o);
        var r = n("b61c"), a = n("07ee");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(o, t, function() {
                return a[t];
            });
        }(i);
        n("f983");
        var e = n("f0c5"), c = Object(e.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        o.default = c.exports;
    },
    b61c: function(t, o, n) {
        n.d(o, "b", function() {
            return r;
        }), n.d(o, "c", function() {
            return a;
        }), n.d(o, "a", function() {});
        var r = function() {
            var t = this, o = (t.$createElement, t._self._c, t.conf.leftButton ? t.__map(t.conf.leftButton, function(o, n) {
                return {
                    $orig: t.__get_orig(o),
                    m0: o.position && "left" == o.position ? t.iconHandle(o.icon) : null,
                    m1: o.position && "left" == o.position ? null : t.iconHandle(o.icon)
                };
            }) : null), n = t.conf.rightButton ? t.__map(t.conf.rightButton, function(o, n) {
                return {
                    $orig: t.__get_orig(o),
                    m2: o.position && "left" == o.position ? t.iconHandle(o.icon) : null,
                    m3: o.position && "left" == o.position ? null : t.iconHandle(o.icon)
                };
            }) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: o,
                    l1: n
                }
            });
        }, a = [];
    },
    f983: function(t, o, n) {
        var r = n("1faa");
        n.n(r).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/hx-navbar/hx-navbar-create-component", {
    "components/hx-navbar/hx-navbar-create-component": function(t, o, n) {
        n("543d").createComponent(n("614f"));
    }
}, [ [ "components/hx-navbar/hx-navbar-create-component" ] ] ]);