(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/hans-tabbar/hans-tabbar" ], {
    5456: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, getApp();
        var c = {
            props: {
                list: {
                    type: Array,
                    default: function() {
                        return [ {
                            iconPath: "../../static/shouye/home_unselected.png",
                            selectedIconPath: "../../static/shouye/home_selected.png",
                            text: "首页"
                        }, {
                            iconPath: "../../static/shouye/clock_in_unselected.png",
                            selectedIconPath: "../../static/shouye/clock_in_selected.png",
                            text: "积心打卡"
                        }, {
                            iconPath: "../../static/shouye/member_code.png"
                        }, {
                            iconPath: "../../static/shouye/order_unselected.png",
                            selectedIconPath: "../../static/shouye/order_selected.png",
                            text: "我的订单"
                        }, {
                            iconPath: "../../static/shouye/center_unselected.png",
                            selectedIconPath: "../../static/shouye/center_selected.png",
                            text: "个人中心"
                        } ];
                    }
                },
                current: {
                    type: Number || String,
                    default: 0
                }
            },
            mounted: function() {},
            data: function() {
                return {
                    currentIndex: this.current
                };
            },
            watch: {
                current: function(t) {
                    console.log(t), this.currentIndex = t;
                }
            },
            methods: {
                tabChange: function(t) {
                    t !== this.currentIndex && this.$emit("tabChange", t);
                }
            }
        };
        e.default = c;
    },
    "8f35": function(t, e, n) {
        n.r(e);
        var c = n("e672"), a = n("da33");
        for (var o in a) "default" !== o && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("f377");
        var r = n("f0c5"), s = Object(r.a)(a.default, c.b, c.c, !1, null, "7c472829", null, !1, c.a, void 0);
        e.default = s.exports;
    },
    da33: function(t, e, n) {
        n.r(e);
        var c = n("5456"), a = n.n(c);
        for (var o in c) "default" !== o && function(t) {
            n.d(e, t, function() {
                return c[t];
            });
        }(o);
        e.default = a.a;
    },
    e672: function(t, e, n) {
        n.d(e, "b", function() {
            return c;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var c = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    f377: function(t, e, n) {
        var c = n("fb5f");
        n.n(c).a;
    },
    fb5f: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/hans-tabbar/hans-tabbar-create-component", {
    "components/hans-tabbar/hans-tabbar-create-component": function(t, e, n) {
        n("543d").createComponent(n("8f35"));
    }
}, [ [ "components/hans-tabbar/hans-tabbar-create-component" ] ] ]);