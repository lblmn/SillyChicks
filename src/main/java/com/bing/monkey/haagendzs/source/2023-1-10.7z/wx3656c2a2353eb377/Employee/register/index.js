// Employee/register/index.js
Page({data: {}})