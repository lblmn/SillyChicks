// thanksgiving/share/turnGet.js
Page({data: {}})