// activity/awards_info/awards_info.js
Page({data: {}})