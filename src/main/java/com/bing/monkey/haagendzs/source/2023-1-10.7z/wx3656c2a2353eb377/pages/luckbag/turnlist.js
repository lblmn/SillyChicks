(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/luckbag/turnlist" ], {
    "02f5": function(n, t, e) {},
    "2a85": function(n, t, e) {
        (function(n) {
            var t = e("4ea4");
            e("a1ea"), t(e("66fd"));
            var o = t(e("492b"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(o.default);
        }).call(this, e("543d").createPage);
    },
    "492b": function(n, t, e) {
        e.r(t);
        var o = e("87de"), i = e("f395");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(a);
        e("ca34");
        var c = e("f0c5"), u = Object(c.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    "87de": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    "916f": function(n, t, e) {
        (function(n) {
            var o = e("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(e("3724")), a = {
                name: "jixin",
                components: {
                    Zzhuanzeng: function() {
                        e.e("components/Zzhuanzeng").then(function() {
                            return resolve(e("3b88"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    uniIcons: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(e("6093"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        cardList: [],
                        nextId: "",
                        pageSize: 100,
                        noMore: !1
                    };
                },
                onShow: function() {},
                onLoad: function() {
                    var n = getApp().globalData.PointAccount.filter(function(n) {
                        return n.pointAccountName.indexOf("积心") > -1;
                    })[0];
                    this.pointAccountId = n.pointAccountId, this.getList();
                },
                methods: {
                    cancelBtn: function(t) {
                        console.log(t);
                        var e = this;
                        i.default.transfer({
                            openid: n.getStorageSync("openId"),
                            nickName: n.getStorageSync("logininfo").fullName,
                            unionId: n.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: t.vinfo.couponCode,
                            actionType: "2",
                            remark: ""
                        }, !1).then(function(t) {
                            console.log(t), "0" == t.code ? n.showToast({
                                icon: "none",
                                title: "取消成功",
                                success: function() {
                                    setTimeout(function() {
                                        e.cardList = [], e.nextId = "", e.getList();
                                    }, 1e3);
                                }
                            }) : n.showToast({
                                icon: "none",
                                title: "取消失败，请稍后重试"
                            });
                        });
                    },
                    goShop: function() {
                        n.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    getList: function() {
                        var t = this, e = {
                            idType: 1,
                            id: n.getStorageSync("socialhubId"),
                            flag: 0,
                            nextId: this.nextId,
                            pageSize: this.pageSize,
                            state: 0
                        };
                        "" == this.nextId && delete e.nextId, i.default.coupontransferlist(e).then(function(e) {
                            n.hideLoading(), console.log(e), 0 == e.resultCode && (e.data.nextId && (t.nextId = e.data.nextId), 
                            e.data.list && e.data.list.length > 0 && (t.cardList = t.cardList.concat(e.data.list)), 
                            e.data.nextId || (t.noMore = !0));
                        });
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (n.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), this.getList());
                    }
                }
            };
            t.default = a;
        }).call(this, e("543d").default);
    },
    ca34: function(n, t, e) {
        var o = e("02f5");
        e.n(o).a;
    },
    f395: function(n, t, e) {
        e.r(t);
        var o = e("916f"), i = e.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        t.default = i.a;
    }
}, [ [ "2a85", "common/runtime", "common/vendor" ] ] ]);