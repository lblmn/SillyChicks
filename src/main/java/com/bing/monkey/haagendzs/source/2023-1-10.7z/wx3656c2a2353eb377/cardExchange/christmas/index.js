// cardExchange/christmas/index.js
Page({data: {}})