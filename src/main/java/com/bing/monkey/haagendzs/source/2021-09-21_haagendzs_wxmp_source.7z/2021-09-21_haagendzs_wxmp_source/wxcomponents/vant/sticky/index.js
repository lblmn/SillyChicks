var t = function() {
    function t(t, e) {
        var r = [], n = !0, o = !1, i = void 0;
        try {
            for (var a, f = t[Symbol.iterator](); !(n = (a = f.next()).done) && (r.push(a.value), 
            !e || r.length !== e); n = !0) ;
        } catch (t) {
            o = !0, i = t;
        } finally {
            try {
                !n && f.return && f.return();
            } finally {
                if (o) throw i;
            }
        }
        return r;
    }
    return function(e, r) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, r);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), e = require("../common/component"), r = require("../mixins/page-scroll");

(0, e.VantComponent)({
    props: {
        zIndex: {
            type: Number,
            value: 99
        },
        offsetTop: {
            type: Number,
            value: 0,
            observer: "onScroll"
        },
        disabled: {
            type: Boolean,
            observer: "onScroll"
        },
        container: {
            type: null,
            observer: "onScroll"
        },
        scrollTop: {
            type: null,
            observer: function(t) {
                this.onScroll({
                    scrollTop: t
                });
            }
        }
    },
    mixins: [ (0, r.pageScrollMixin)(function(t) {
        null == this.data.scrollTop && this.onScroll(t);
    }) ],
    data: {
        height: 0,
        fixed: !1,
        transform: 0
    },
    mounted: function() {
        this.onScroll();
    },
    methods: {
        onScroll: function() {
            var e = this, r = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).scrollTop, n = this.data, o = n.container, i = n.offsetTop;
            n.disabled ? this.setDataAfterDiff({
                fixed: !1,
                transform: 0
            }) : (this.scrollTop = r || this.scrollTop, "function" != typeof o ? this.getRect(".van-sticky").then(function(t) {
                i >= t.top ? (e.setDataAfterDiff({
                    fixed: !0,
                    height: t.height
                }), e.transform = 0) : e.setDataAfterDiff({
                    fixed: !1
                });
            }) : Promise.all([ this.getRect(".van-sticky"), this.getContainerRect() ]).then(function(r) {
                var n = t(r, 2), o = n[0], a = n[1];
                i + o.height > a.height + a.top ? e.setDataAfterDiff({
                    fixed: !1,
                    transform: a.height - o.height
                }) : i >= o.top ? e.setDataAfterDiff({
                    fixed: !0,
                    height: o.height,
                    transform: 0
                }) : e.setDataAfterDiff({
                    fixed: !1,
                    transform: 0
                });
            }));
        },
        setDataAfterDiff: function(t) {
            var e = this;
            wx.nextTick(function() {
                var r = Object.keys(t).reduce(function(r, n) {
                    return t[n] !== e.data[n] && (r[n] = t[n]), r;
                }, {});
                e.setData(r), e.$emit("scroll", {
                    scrollTop: e.scrollTop,
                    isFixed: t.fixed || e.data.fixed
                });
            });
        },
        getContainerRect: function() {
            var t = this.data.container();
            return new Promise(function(e) {
                return t.boundingClientRect(e).exec();
            });
        }
    }
});