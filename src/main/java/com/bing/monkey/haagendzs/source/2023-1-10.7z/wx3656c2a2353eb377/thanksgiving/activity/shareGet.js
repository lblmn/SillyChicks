// thanksgiving/activity/shareGet.js
Page({data: {}})