// pureFeeling/cameraHome/shareHelp.js
Page({data: {}})