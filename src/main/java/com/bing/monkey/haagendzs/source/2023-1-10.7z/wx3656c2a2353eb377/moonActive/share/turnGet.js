// moonActive/share/turnGet.js
Page({data: {}})