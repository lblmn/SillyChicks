// activity/helpperson/helpperson.js
Page({data: {}})