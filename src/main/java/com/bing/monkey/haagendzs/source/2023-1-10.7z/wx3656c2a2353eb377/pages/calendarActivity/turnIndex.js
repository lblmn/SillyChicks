(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calendarActivity/turnIndex" ], {
    "091c": function(e, o, t) {
        (function(e) {
            var n = t("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a = n(t("3724")), i = n(t("f3d4")), r = n(t("9296")), c = (getApp(), {
                data: function() {
                    return {
                        placeholderInfo: "在此输入您的新年祝福",
                        textareaValue: "",
                        userName: "",
                        imgUrl: i.default.assetsRoot,
                        isshare: !0,
                        isShowSharePopup: !1,
                        isShowSharePopup2: !1,
                        isShowSharePopup3: !1,
                        helpinfo: "",
                        helpinfo2: ""
                    };
                },
                onLoad: function(o) {
                    this.couponCode = o.couponCode, this.userName = e.getStorageSync("logininfo").fullName, 
                    this.detailInfo = JSON.parse(decodeURIComponent(o.detailinfo));
                },
                onShow: function() {
                    e.getStorageSync("shareback") && (this.isshare = !1, this.isShowSharePopup = !1, 
                    this.isShowSharePopup2 = !1, this.helpinfo = "", this.helpinfo2 = "", this.isShowSharePopup3 = !0, 
                    e.removeStorageSync("shareback"));
                },
                destroyed: function() {},
                methods: {
                    textareaValueFun: function(e) {
                        console.log(e), this.textareaValue = e.detail.value;
                    },
                    cancelFun: function() {
                        var o = this, t = e.getStorageSync("logininfo").socialhubId;
                        a.default.ebuyCancelTransfer({
                            openid: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId"),
                            socialHubid: t,
                            couponKey: this.textid
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (o.isshare = !0, o.isShowSharePopup = !1, o.isShowSharePopup2 = !0, 
                            o.helpinfo2 = "取消转赠成功\n该券已可以使用\n请去【我的券包】") : (o.isShowSharePopup2 = !0, o.helpinfo2 = "取消转赠失败");
                        });
                    },
                    sendCard: function() {
                        var o = this;
                        console.log(this.textareaValue);
                        var t = e.getStorageSync("logininfo").socialhubId;
                        a.default.ebuyDeliverTransfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            couponCode: this.couponCode,
                            socialHubid: t,
                            remark: "" == this.textareaValue ? "邀请您来哈根达斯体验哦~" : this.textareaValue
                        }).then(function(e) {
                            console.log(e.code), 0 == e.code ? (o.textid = e.data, o.isshare = !1, o.isShowSharePopup = !0, 
                            o.helpinfo = "提交成功\n请点分享将券转赠给指定好友") : (o.isShowSharePopup2 = !0, o.helpinfo2 = "提交失败\n请稍后重试");
                        });
                    }
                },
                onShareAppMessage: function(o) {
                    e.setStorageSync("shareback", !0);
                    var t = "叮，您有一份来自好友的新年祝福好礼", n = "".concat(i.default.assetsRoot, "/oss/wxapp/1130/shareCalendar.jpg");
                    if (this.detailInfo.forwardTitle && (t = this.detailInfo.forwardTitle), this.detailInfo.forwardPictureUrl && (n = "".concat(i.default.assetsRoot) + this.detailInfo.forwardPictureUrl), 
                    r.default.shareRecord({
                        aid: "",
                        unionId: e.getStorageSync("unionId"),
                        openid: e.getStorageSync("openId"),
                        path: "pages/calendarActivity/turnIndex",
                        button: "",
                        invitedOpenid: "",
                        type: "1"
                    }).then(function(e) {
                        console.log(e);
                    }).catch(function(e) {
                        console.log(e);
                    }), console.log("pages/calendarActivity/turnGet?textid=".concat(this.textid)), "button" === o.from) return {
                        title: t,
                        path: "pages/calendarActivity/turnGet?textid=".concat(this.textid),
                        imageUrl: n
                    };
                }
            });
            o.default = c;
        }).call(this, t("543d").default);
    },
    "10c0": function(e, o, t) {},
    "22f1": function(e, o, t) {
        var n = t("10c0");
        t.n(n).a;
    },
    2609: function(e, o, t) {
        t.r(o);
        var n = t("9e0b"), a = t("b82e");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(o, e, function() {
                return a[e];
            });
        }(i);
        t("22f1");
        var r = t("f0c5"), c = Object(r.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        o.default = c.exports;
    },
    "4fc4": function(e, o, t) {
        (function(e) {
            var o = t("4ea4");
            t("a1ea"), o(t("66fd"));
            var n = o(t("2609"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("543d").createPage);
    },
    "9e0b": function(e, o, t) {
        t.d(o, "b", function() {
            return n;
        }), t.d(o, "c", function() {
            return a;
        }), t.d(o, "a", function() {});
        var n = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(o) {
                e.isShowSharePopup2 = !1;
            }, e.e1 = function(o) {
                e.isShowSharePopup3 = !1;
            });
        }, a = [];
    },
    b82e: function(e, o, t) {
        t.r(o);
        var n = t("091c"), a = t.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(o, e, function() {
                return n[e];
            });
        }(i);
        o.default = a.a;
    }
}, [ [ "4fc4", "common/runtime", "common/vendor" ] ] ]);