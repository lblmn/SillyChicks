(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/noHot" ], {
    "0a26": function(n, e, t) {
        t.r(e);
        var o = t("ba0e"), a = t("7f29");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        t("be90");
        var u = t("f0c5"), f = Object(u.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = f.exports;
    },
    "376c": function(n, e, t) {},
    "7f29": function(n, e, t) {
        t.r(e);
        var o = t("85a5"), a = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = a.a;
    },
    "85a5": function(n, e, t) {
        (function(n) {
            var o = t("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = o(t("f3d4")), c = o(t("7d43")), u = o(t("5db4")), f = {
                data: function() {
                    return {
                        imgoss: a.default.ossurl + "unifyExchange/noHot/",
                        config: {
                            statusBarFontColor: "#ffffff",
                            barPlaceholder: !1,
                            backgroundColor: [ 0, "#fff" ]
                        },
                        isHeightScreen: !1
                    };
                },
                onLoad: function(n) {
                    var e = this;
                    c.default.isHeightPhone().then(function(n) {
                        e.isHeightScreen = n;
                    }).catch(function(n) {
                        e.isHeightScreen = n;
                    }), c.default.setSource(n);
                },
                onShow: function() {
                    this.getRecord();
                },
                components: {
                    hxNavbar: function() {
                        t.e("components/hx-navbar/hx-navbar").then(function() {
                            return resolve(t("614f"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                methods: {
                    getRecord: function(e) {
                        u.default.saveLoginRecord({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId"),
                            source: e || n.getStorageSync("smsSource")
                        }, !1);
                    },
                    goIndex: function() {
                        1 == getCurrentPages().length ? n.switchTab({
                            url: "/pages/index/index"
                        }) : n.navigateBack({
                            delta: -1
                        });
                    }
                }
            };
            e.default = f;
        }).call(this, t("543d").default);
    },
    "9f25": function(n, e, t) {
        (function(n) {
            var e = t("4ea4");
            t("a1ea"), e(t("66fd"));
            var o = e(t("0a26"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t("543d").createPage);
    },
    ba0e: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    be90: function(n, e, t) {
        var o = t("376c");
        t.n(o).a;
    }
}, [ [ "9f25", "common/runtime", "common/vendor" ] ] ]);