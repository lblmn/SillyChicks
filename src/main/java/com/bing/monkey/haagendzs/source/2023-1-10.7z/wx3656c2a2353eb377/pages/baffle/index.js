(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/baffle/index" ], {
    "170a": function(e, t, n) {
        n.r(t);
        var r = n("e1c8"), o = n.n(r);
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        t.default = o.a;
    },
    "22de": function(e, t, n) {
        var r = n("7536");
        n.n(r).a;
    },
    "2f7d": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    7536: function(e, t, n) {},
    "840e": function(e, t, n) {
        n.r(t);
        var r = n("2f7d"), o = n("170a");
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        n("22de");
        var a = n("f0c5"), f = Object(a.a)(o.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = f.exports;
    },
    e1c8: function(e, t, n) {
        (function(e) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = r(n("9523")), c = r(n("f3d4")), a = r(n("5db4"));
            function f(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            var u = {
                data: function() {
                    return {
                        imgoss: c.default.ossurl + "baffle/",
                        config: {
                            statusBarFontColor: "#ffffff",
                            barPlaceholder: !1,
                            backgroundColor: [ 0, "#fff" ]
                        }
                    };
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? f(Object(n), !0).forEach(function(t) {
                            (0, o.default)(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, n("26cb").mapState)([ "isHeightScreen", "navbarHeight_a" ])),
                onLoad: function(e) {},
                onShow: function() {
                    this.getRecord();
                },
                methods: {
                    getRecord: function(t) {
                        a.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: t || e.getStorageSync("smsSource")
                        }, !1);
                    }
                }
            };
            t.default = u;
        }).call(this, n("543d").default);
    },
    f558: function(e, t, n) {
        (function(e) {
            var t = n("4ea4");
            n("a1ea"), t(n("66fd"));
            var r = t(n("840e"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(r.default);
        }).call(this, n("543d").createPage);
    }
}, [ [ "f558", "common/runtime", "common/vendor" ] ] ]);