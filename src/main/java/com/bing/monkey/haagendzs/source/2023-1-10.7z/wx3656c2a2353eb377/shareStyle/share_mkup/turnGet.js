// shareStyle/share_mkup/turnGet.js
Page({data: {}})