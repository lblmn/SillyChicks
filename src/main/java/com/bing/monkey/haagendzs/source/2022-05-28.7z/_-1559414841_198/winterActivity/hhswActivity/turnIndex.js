// winterActivity/hhswActivity/turnIndex.js
Page({data: {}})