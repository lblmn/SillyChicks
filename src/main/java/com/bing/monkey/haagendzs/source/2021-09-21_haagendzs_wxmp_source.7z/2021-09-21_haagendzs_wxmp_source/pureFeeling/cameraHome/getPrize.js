// pureFeeling/cameraHome/getPrize.js
Page({data: {}})