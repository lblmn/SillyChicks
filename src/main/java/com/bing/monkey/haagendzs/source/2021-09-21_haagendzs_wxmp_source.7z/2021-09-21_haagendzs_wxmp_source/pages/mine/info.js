(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/info" ], {
    "1ed5": function(e, t, n) {
        var o = n("b537");
        n.n(o).a;
    },
    "2b44": function(e, t, n) {
        n.r(t);
        var o = n("f056"), i = n("4687");
        for (var a in i) "default" !== a && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("1ed5");
        var r = n("f0c5"), l = Object(r.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = l.exports;
    },
    4687: function(e, t, n) {
        n.r(t);
        var o = n("a27c"), i = n.n(o);
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = i.a;
    },
    "84db": function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("f4aa"), t(n("66fd")), e(t(n("2b44")).default);
        }).call(this, n("543d").createPage);
    },
    a27c: function(e, t, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = o(n("d7df")), a = o(n("54de")), r = o(n("e0da")), l = {
                components: {},
                data: function() {
                    return {
                        showphone: !1,
                        form: {
                            fullName: e.getStorageSync("logininfo").fullName,
                            genderCode: "" + e.getStorageSync("logininfo").genderCode,
                            birthDate: e.getStorageSync("logininfo").birthDate,
                            phone: e.getStorageSync("logininfo").mobilePhone,
                            detailAddress: e.getStorageSync("logininfo").detailAddress,
                            email: e.getStorageSync("logininfo").email,
                            tierName: e.getStorageSync("logininfo").tier.tierName,
                            area: ""
                        },
                        cityvalue: [ e.getStorageSync("logininfo").provinceName, e.getStorageSync("logininfo").cityName ]
                    };
                },
                mounted: function() {
                    var t = e.getStorageSync("logininfo").provinceCode, n = e.getStorageSync("logininfo").cityCode, o = e.getStorageSync("logininfo").provinceName;
                    e.getStorageSync("logininfo").cityName, this.form.area = "" == t || "0" == t || "" == n || "0" == n || null == o || "null" == o ? "" : [ t, n ];
                },
                methods: {
                    nameChange: function(e) {
                        var t = e.detail;
                        this.form.fullName = t;
                    },
                    addressChange: function(e) {
                        var t = e.detail;
                        this.form.detailAddress = t;
                    },
                    onSexChange: function(e) {
                        var t = e.detail;
                        this.form.genderCode = t;
                    },
                    emailChange: function(e) {
                        var t = e.detail;
                        this.form.email = t;
                    },
                    getLocation: function() {
                        var t = this;
                        e.getLocation({
                            type: "gcj02",
                            success: function(n) {
                                var o, i;
                                e.showLoading({
                                    title: "正在获取位置"
                                }), o = n.latitude.toString(), i = n.longitude.toString(), e.request({
                                    header: {
                                        "Content-Type": "application/text"
                                    },
                                    url: "https://apis.map.qq.com/ws/geocoder/v1/?location=" + o + "," + i + "&key=FRHBZ-P4Q6P-LPIDI-LZR73-ZHJKS-K5FAN",
                                    success: function(e) {
                                        200 === e.statusCode ? (console.log("获取中文街道地理位置成功"), t.cityvalue = [ e.data.result.ad_info.province, e.data.result.ad_info.city ], 
                                        t.form.area = [], t.cityvalue.map(function(e, n) {
                                            return 0 == n ? t.form.area.push(a.default.province.filter(function(t) {
                                                return t[1] == e;
                                            })[0][0]) : 1 == n ? t.form.area.push(a.default.city.filter(function(t) {
                                                return t[1] == e;
                                            })[0][0]) : void 0;
                                        })) : console.log("获取信息失败，请重试！");
                                    },
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            },
                            fail: function() {
                                e.showToast({
                                    title: "您拒绝了授权，请在右上角设置中打开地理位置授权",
                                    icon: "none"
                                }), console.log("你拒绝了授权，无法获得周边信息");
                            }
                        });
                    },
                    gophone: function() {
                        e.showToast({
                            title: "如需修改，请致电客服热线400-820-7917更改",
                            icon: "none",
                            duration: 3e3
                        });
                    },
                    goclose: function() {
                        this.showphone = !1;
                    },
                    doSave: function() {
                        if (this.form.fullName) {
                            var t = /\@/g;
                            if (!this.form.email || t.test(this.form.email)) {
                                var n = this.form, o = n.fullName, a = n.genderCode, l = n.birthDate, c = n.detailAddress, f = n.email;
                                r.default.info({
                                    idType: 1,
                                    id: e.getStorageSync("socialhubId"),
                                    fullName: o,
                                    genderCode: Number(a),
                                    birthDate: l,
                                    provinceCode: this.form.area[0],
                                    provinceName: this.cityvalue[0],
                                    cityCode: this.form.area[1],
                                    cityName: this.cityvalue[1],
                                    detailAddress: c,
                                    email: f
                                }).then(function(t) {
                                    0 == t.resultCode ? i.default.getmember({
                                        idType: "1",
                                        id: e.getStorageSync("socialhubId")
                                    }).then(function(t) {
                                        e.setStorageSync("logininfo", t.data), e.showToast({
                                            title: "更新成功"
                                        }), setTimeout(function() {
                                            e.switchTab({
                                                url: "/pages/mine/mine"
                                            });
                                        }, 800);
                                    }) : e.showToast({
                                        title: "请求异常请稍后重试",
                                        icon: "none"
                                    });
                                });
                            } else e.showToast({
                                title: "邮箱格式不正确",
                                icon: "none"
                            });
                        } else e.showToast({
                            title: "姓名不能为空",
                            icon: "none"
                        });
                    }
                }
            };
            t.default = l;
        }).call(this, n("543d").default);
    },
    b537: function(e, t, n) {},
    f056: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, i = [];
    }
}, [ [ "84db", "common/runtime", "common/vendor" ] ] ]);