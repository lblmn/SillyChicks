var e = require("../@babel/runtime/helpers/interopRequireDefault")(require("../@babel/runtime/regenerator")), n = require("../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/loginDialog_new" ], {
    "1a14": function(e, n, t) {
        t.r(n);
        var o = t("2d9f"), r = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        n.default = r.a;
    },
    "2d9f": function(t, o, r) {
        (function(t) {
            var i = r("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a, s, c, u = i(r("9296")), l = {
                name: "loginDialog",
                data: function() {
                    return {
                        showLogin: !1,
                        showMobile: !1,
                        loginRes: {},
                        phone: "",
                        showLoading: !1,
                        canIUseGetUserProfile: !1
                    };
                },
                props: {
                    showloginDialog: {
                        type: Boolean
                    }
                },
                mounted: (c = n(e.default.mark(function n() {
                    var o;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (console.log("jiazaizujian"), 0 != Object.keys(t.getStorageSync("logininfo")).length) {
                                e.next = 12;
                                break;
                            }
                            if (console.log("logindialog,微信登录"), !t.getStorageSync("openId") || !t.getStorageSync("unionId")) {
                                e.next = 5;
                                break;
                            }
                            this.getMemberinfo(), e.next = 12;
                            break;

                          case 5:
                            return e.next = 7, this.doLogin();

                          case 7:
                            return this.loginRes = e.sent, e.next = 10, this.getOpenid(this.loginRes);

                          case 10:
                            o = e.sent, t.setStorageSync("openId", o.data.openid), t.setStorageSync("sessionKey", o.data.sessionKey), 
                            console.log("code换的值", o), o.data.unionId ? (t.setStorageSync("unionId", o.data.unionId), 
                            getApp().hxt.identify({
                                openid: o.data.openid,
                                unionid: o.data.unionId
                            }), this.getMemberinfo()) : (t.getUserProfile && (this.canIUseGetUserProfile = !0), 
                            this.showLogin = !0, t.hideLoading());

                          case 12:
                          case "end":
                            return e.stop();
                        }
                    }, n, this);
                })), function() {
                    return c.apply(this, arguments);
                }),
                updated: function() {
                    console.log("更新");
                },
                methods: {
                    cancelFun: function() {
                        t.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    getNewUserInfo: function() {
                        return new Promise(function(e, n) {
                            t.getUserProfile({
                                desc: "会员信息",
                                success: function(n) {
                                    console.log(n), e(n);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    newInfo: (s = n(e.default.mark(function n() {
                        var o, r;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.getNewUserInfo();

                              case 2:
                                return o = e.sent, t.setStorageSync("wxinfo", o.userInfo), e.next = 6, this.getUnionid(o);

                              case 6:
                                r = e.sent, t.setStorageSync("unionId", r.data.unionId);

                              case 8:
                              case "end":
                                return e.stop();
                            }
                        }, n, this);
                    })), function() {
                        return s.apply(this, arguments);
                    }),
                    onGetUserInfo: (a = n(e.default.mark(function n() {
                        var o, r;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.getUserinfo(this.loginRes);

                              case 2:
                                return o = e.sent, t.setStorageSync("wxinfo", o.userInfo), e.next = 6, this.getUnionid(o);

                              case 6:
                                r = e.sent, t.setStorageSync("unionId", r.data.unionId), this.getMemberinfo();

                              case 8:
                              case "end":
                                return e.stop();
                            }
                        }, n, this);
                    })), function() {
                        return a.apply(this, arguments);
                    }),
                    doLogin: function() {
                        return new Promise(function(e, n) {
                            t.login({
                                success: function(n) {
                                    e(n);
                                }
                            });
                        });
                    },
                    getOpenid: function(e) {
                        return u.default.login({
                            code: e.code,
                            appId: this.$env.appId
                        }, !1);
                    },
                    getUserinfo: function(e) {
                        var n = this;
                        return new Promise(function(o, r) {
                            e.code ? t.getUserInfo({
                                success: function(e) {
                                    o(e);
                                },
                                fail: function(e) {
                                    n.showLogin = !0, console.log("拒绝了用户信息授权");
                                }
                            }) : (r("登录失败！" + e.errMsg), console.log("登录失败！" + e.errMsg));
                        });
                    },
                    getUnionid: function(e) {
                        return u.default.decrypt({
                            encryptedData: e.encryptedData,
                            openId: t.getStorageSync("openId"),
                            iv: e.iv
                        }, !1);
                    },
                    getMemberinfo: function() {
                        var e = this;
                        return new Promise(function(n, o) {
                            u.default.getmember({
                                idType: "2",
                                id: t.getStorageSync("unionId")
                            }, !1).then(function(r) {
                                console.log("getmemberinfo", r), 0 == r.resultCode ? (t.setStorageSync("logininfo", r.data), 
                                t.setStorageSync("socialhubId", r.data.socialhubId), console.log(e.returnUrl), console.log("即将刷新", e.returnUrl()[2]), 
                                e.$emit("getmemberSuccess", "all"), n(r)) : (0 == Object.keys(t.getStorageSync("logininfo")).length ? (e.showMobile = !0, 
                                e.$emit("getmemberSuccess", "error"), t.hideLoading()) : t.showToast({
                                    title: "请求会员信息异常请稍后重试",
                                    icon: "none"
                                }), o(r));
                            });
                        });
                    },
                    onGetPhoneNumber: function(e) {
                        this.showMobile = !1;
                        var n = this;
                        console.log(e), "getPhoneNumber:fail user deny" == e.detail.errMsg || "getPhoneNumber:fail:user deny" == e.detail.errMsg ? (console.log("取消授权"), 
                        n.$nextTick(function() {
                            n.showMobile = !0;
                        })) : u.default.decrypt({
                            encryptedData: e.detail.encryptedData,
                            openId: t.getStorageSync("openId"),
                            iv: e.detail.iv
                        }).then(function(e) {
                            n.phone = e.data.phoneNumber, t.setStorageSync("userinfoPhone", n.phone), n.bindQuery();
                        });
                    },
                    bindQuery: function() {
                        var e = this, n = t.getStorageSync("unionId"), o = t.getStorageSync("openId");
                        u.default.bindquery({
                            thirdPartyId: n,
                            openid: o,
                            source: 2,
                            mobilePhone: this.phone
                        }).then(function(r) {
                            console.log("会员绑定查询入参" + JSON.stringify({
                                thirdPartyId: n,
                                openid: o,
                                source: 2,
                                mobilePhone: e.phone
                            })), console.log("校验登录返回" + JSON.stringify(r)), 0 == r.resultCode ? "E000101" == r.resultDesc ? (console.log(e.returnUrl()), 
                            t.redirectTo({
                                url: "/pages/register/register?url=" + e.returnUrl()[0] + "&param=" + JSON.stringify(e.returnUrl()[1])
                            })) : "E000102" == r.resultDesc ? u.default.bind({
                                thirdPartyId: t.getStorageSync("unionId"),
                                thirdPartyName: t.getStorageSync("wxinfo").nickName,
                                openid: t.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: e.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: t.getStorageSync("unionId"),
                                    thirdPartyName: t.getStorageSync("wxinfo").nickName,
                                    openid: t.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: e.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (t.setStorageSync("socialhubId", n.data.socialhubId), 
                                e.$emit("getmemberSuccess", "all")) : (e.$emit("getmemberSuccess", "error"), t.showToast({
                                    title: "请求异常请稍后重试",
                                    icon: "none"
                                }));
                            }) : "E000103" == r.resultDesc ? (t.setStorageSync("socialhubId", r.data.socialhubId), 
                            e.$emit("getmemberSuccess", "all")) : (e.$emit("getmemberSuccess", "error"), t.showToast({
                                title: "会员已被他人绑定",
                                icon: "none"
                            })) : 1 == r.resultCode && "E000107" == r.resultDesc ? u.default.bind({
                                thirdPartyId: t.getStorageSync("unionId"),
                                thirdPartyName: t.getStorageSync("wxinfo").nickName,
                                openid: t.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: e.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: t.getStorageSync("unionId"),
                                    thirdPartyName: t.getStorageSync("wxinfo").nickName,
                                    openid: t.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: e.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (t.setStorageSync("socialhubId", n.data.socialhubId), 
                                t.reLaunch({
                                    url: "/pages/index/index"
                                })) : (e.$emit("getmemberSuccess", "error"), t.showToast({
                                    title: "请求异常请稍后重试",
                                    icon: "none"
                                }));
                            }) : (e.$emit("getmemberSuccess", "error"), t.showToast({
                                title: "请求异常请稍后重试",
                                icon: "none"
                            }));
                        });
                    },
                    returnUrl: function() {
                        var e = getCurrentPages(), n = e[e.length - 1].route, t = e[e.length - 1].options, o = "";
                        if ("" == Object.keys(t)) o = "/" + n; else if (Object.keys(t).length > 0) {
                            var r = "";
                            for (var i in t) r += ("" == r ? "" : "&") + i + "=" + t[i];
                            o = "/" + n + "?" + r;
                        } else o = "/" + n;
                        return [ n, t, o ];
                    }
                }
            };
            o.default = l;
        }).call(this, r("543d").default);
    },
    5972: function(e, n, t) {
        t.r(n);
        var o = t("d5e2"), r = t("1a14");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        t("baef");
        var a = t("f0c5"), s = Object(a.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = s.exports;
    },
    baef: function(e, n, t) {
        var o = t("f8ae");
        t.n(o).a;
    },
    d5e2: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    f8ae: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/loginDialog_new-create-component", {
    "components/loginDialog_new-create-component": function(e, n, t) {
        t("543d").createComponent(t("5972"));
    }
}, [ [ "components/loginDialog_new-create-component" ] ] ]);