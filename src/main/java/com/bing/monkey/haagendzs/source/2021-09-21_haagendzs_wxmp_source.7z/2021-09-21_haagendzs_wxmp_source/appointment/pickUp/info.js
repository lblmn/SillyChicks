// appointment/pickUp/info.js
Page({data: {}})