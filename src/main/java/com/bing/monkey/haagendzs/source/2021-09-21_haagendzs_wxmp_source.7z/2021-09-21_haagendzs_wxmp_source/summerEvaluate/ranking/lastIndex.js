// summerEvaluate/ranking/lastIndex.js
Page({data: {}})