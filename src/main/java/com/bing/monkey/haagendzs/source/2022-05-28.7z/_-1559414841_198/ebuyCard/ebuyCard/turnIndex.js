// ebuyCard/ebuyCard/turnIndex.js
Page({data: {}})