(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/uni-icons/uni-icons" ], {
    2271: function(n, t, e) {},
    "349f": function(n, t, e) {
        e.r(t);
        var o = e("e51f"), c = e("43c9");
        for (var u in c) "default" !== u && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(u);
        e("c6bb");
        var i = e("f0c5"), a = Object(i.a)(c.default, o.b, o.c, !1, null, "76658282", null, !1, o.a, void 0);
        t.default = a.exports;
    },
    "43c9": function(n, t, e) {
        e.r(t);
        var o = e("6c59"), c = e.n(o);
        for (var u in o) "default" !== u && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(u);
        t.default = c.a;
    },
    "6c59": function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = function(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }(e("916a")), c = {
            name: "UniIcons",
            props: {
                type: {
                    type: String,
                    default: ""
                },
                color: {
                    type: String,
                    default: "#333333"
                },
                size: {
                    type: [ Number, String ],
                    default: 16
                }
            },
            data: function() {
                return {
                    icons: o.default
                };
            },
            methods: {
                _onClick: function() {
                    this.$emit("click");
                }
            }
        };
        t.default = c;
    },
    c6bb: function(n, t, e) {
        var o = e("2271");
        e.n(o).a;
    },
    e51f: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, c = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/uni-icons/uni-icons-create-component", {
    "components/uni-icons/uni-icons-create-component": function(n, t, e) {
        e("543d").createComponent(e("349f"));
    }
}, [ [ "components/uni-icons/uni-icons-create-component" ] ] ]);