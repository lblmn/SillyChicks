// newStore/winterLotteryBlack/index.js
Page({data: {}})