// appointment/distribution/orderSuccess.js
Page({data: {}})