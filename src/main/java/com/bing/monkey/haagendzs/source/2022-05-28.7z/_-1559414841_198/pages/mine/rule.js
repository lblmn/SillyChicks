(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/rule" ], {
    "0e78": function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("c0e2"), t(n("66fd")), e(t(n("853a")).default);
        }).call(this, n("543d").createPage);
    },
    "4c0a": function(e, t, n) {
        n.r(t);
        var o = n("5d1b"), c = n.n(o);
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = c.a;
    },
    "5d1b": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = u(n("c1f6")), c = u(n("500b")), a = u(n("234f")), i = u(n("6bd2"));
            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var r = getApp(), l = {
                data: function() {
                    return {
                        ruleDesc: "",
                        showloginDialog: !1,
                        showRead: !1,
                        type: "",
                        title: "会员规则",
                        frompath: ""
                    };
                },
                onLoad: function(e) {
                    a.default.setSource(e), a.default.recordPv(), this.type = e.type ? e.type : "4", 
                    this.frompath = e.frompath, this.getRuleDesc();
                },
                onShow: function() {
                    "all" == e.getStorageSync("successInfo") && (this.showRead = !0);
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("3761"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                destroyed: function() {},
                onHide: function() {
                    e.removeStorageSync("successInfo");
                },
                methods: {
                    getRecord: function() {
                        i.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: e.getStorageSync("smsSource")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        o.default.getRuledesc({
                            type: this.type
                        }).then(function(t) {
                            console.log(t), t.data.length <= 0 ? e.ruleDesc = "暂无会员规则信息" : (e.ruleDesc = t.data[0].content, 
                            e.title = t.data[0].title);
                        });
                    },
                    backtoMine: function() {
                        "index" == this.frompath ? (e.setStorageSync("isFirstGoIndex", !0), e.navigateBack({
                            delta: -1
                        })) : 0 == Object.keys(e.getStorageSync("logininfo")).length ? this.showloginDialog = !0 : (r.hxt.sendAction("memberrule_read"), 
                        this.shareRecord(), this.getRecord());
                    },
                    readrule: function() {
                        this.showRead = !1, e.removeStorageSync("successInfo"), this.shareRecord(), this.getRecord();
                    },
                    shareRecord: function() {
                        c.default.shareRecord({
                            aid: "",
                            unionId: e.getStorageSync("unionId"),
                            openid: e.getStorageSync("openId"),
                            path: "" != this.type ? "pages/mine/rule?type=".concat(this.type) : "pages/mine/rule",
                            button: "" != this.type ? "pages/mine/rule?type=".concat(this.type) : "pages/mine/rule",
                            invitedOpenid: "",
                            type: "2"
                        }).then(function(e) {
                            console.log(e);
                        }).catch(function(e) {
                            console.log(e);
                        });
                        var t = getCurrentPages();
                        console.log(t), t.length - 1 <= 0 ? e.switchTab({
                            url: "./mine"
                        }) : e.navigateBack({});
                    }
                }
            };
            t.default = l;
        }).call(this, n("543d").default);
    },
    "6a89": function(e, t, n) {
        var o = n("9080");
        n.n(o).a;
    },
    "853a": function(e, t, n) {
        n.r(t);
        var o = n("c78e"), c = n("4c0a");
        for (var a in c) "default" !== a && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(a);
        n("6a89");
        var i = n("f0c5"), u = Object(i.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    9080: function(e, t, n) {},
    c78e: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return c;
        }), n.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    }
}, [ [ "0e78", "common/runtime", "common/vendor" ] ] ]);