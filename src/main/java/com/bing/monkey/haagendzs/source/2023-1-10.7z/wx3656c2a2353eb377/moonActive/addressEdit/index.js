// moonActive/addressEdit/index.js
Page({data: {}})