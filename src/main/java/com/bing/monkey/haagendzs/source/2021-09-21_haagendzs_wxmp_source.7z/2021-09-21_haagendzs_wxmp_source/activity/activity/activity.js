// activity/activity/activity.js
Page({data: {}})