// newStore/winterRecords/index.js
Page({data: {}})