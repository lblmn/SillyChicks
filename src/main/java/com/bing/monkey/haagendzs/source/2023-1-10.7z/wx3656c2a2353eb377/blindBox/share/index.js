// blindBox/share/index.js
Page({data: {}})