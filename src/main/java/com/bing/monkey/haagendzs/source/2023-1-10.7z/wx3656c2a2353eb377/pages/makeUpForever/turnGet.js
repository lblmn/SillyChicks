(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/makeUpForever/turnGet" ], {
    "02a9": function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return a;
        }), n.d(o, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "040b": function(e, o, n) {
        var t = n("2203");
        n.n(t).a;
    },
    "1c8b": function(e, o, n) {
        n.r(o);
        var t = n("a971"), a = n.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(i);
        o.default = a.a;
    },
    2203: function(e, o, n) {},
    a971: function(e, o, n) {
        (function(e) {
            var t = n("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a = t(n("f3d4")), i = t(n("3724")), c = {
                data: function() {
                    return {
                        textareaValue: "",
                        imgUrl: a.default.assetsRoot,
                        showloginDialog: !1,
                        showRead: !1,
                        isShowSharePopup: !1,
                        helpinfo: "",
                        nickName: "",
                        checkCodeState: !1,
                        imgBase: a.default.assetsRoot + "/oss/evaluation/"
                    };
                },
                onLoad: function(e) {
                    this.textid = e.textid, this.getTextInfo();
                },
                onShow: function() {},
                components: {
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("d6e5"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                destroyed: function() {
                    console.log("销毁了");
                },
                onHide: function() {
                    console.log("关闭了"), e.removeStorageSync("successInfo");
                },
                methods: {
                    closepopup: function() {
                        this.checkCodeState ? (this.isShowSharePopup = !1, e.redirectTo({
                            url: "/pages/mine/mycard"
                        })) : this.isShowSharePopup = !1;
                    },
                    getTextInfo: function() {
                        var e = this;
                        i.default.ebuyTransferDetail(this.textid).then(function(o) {
                            console.log(o), e.textareaValue = o.data.remark, e.couponCode = o.data.couponCode, 
                            e.openid = o.data.openid, e.nickName = o.data.nickName;
                        });
                    },
                    readrule: function() {
                        this.showRead = !1, e.removeStorageSync("successInfo"), this.getCard();
                    },
                    sendCard: function() {
                        0 == Object.keys(e.getStorageSync("logininfo")).length ? this.showloginDialog = !0 : this.getCard();
                    },
                    getCard: function() {
                        var o = this;
                        if (this.openid == e.getStorageSync("openId")) return this.isShowSharePopup = !0, 
                        this.helpinfo = "请勿领取自己的券", !1;
                        i.default.ebuyReceiveTransfer({
                            toOpenid: e.getStorageSync("openId"),
                            toUnionid: e.getStorageSync("unionId"),
                            toSocialHubid: e.getStorageSync("socialhubId"),
                            mobile: e.getStorageSync("logininfo").mobilePhone,
                            couponKey: this.textid
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (o.isShowSharePopup = !0, o.helpinfo = '成功领取好友赠送的\n哈根达斯产品兑换券一张\n快去小程序哈根达斯会员中心\n"个人中心-我的券包"看看吧', 
                            o.checkCodeState = !0) : "502" == e.code ? (o.isShowSharePopup = !0, o.helpinfo = '您已成功领取\n快去小程序哈根达斯会员中心\n"个人中心-我的券包"看看吧', 
                            o.checkCodeState = !0) : "702" == e.code ? (o.isShowSharePopup = !0, o.helpinfo = "请勿重复领取", 
                            o.checkCodeState = !0) : "703" == e.code ? (o.isShowSharePopup = !0, o.helpinfo = "您的礼物已被领取或被好友撤回", 
                            o.checkCodeState = !1) : (o.isShowSharePopup = !0, o.helpinfo = "您的礼物已被好友取回\n快去联系TA吧");
                        });
                    }
                }
            };
            o.default = c;
        }).call(this, n("543d").default);
    },
    b26e: function(e, o, n) {
        n.r(o);
        var t = n("02a9"), a = n("1c8b");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(o, e, function() {
                return a[e];
            });
        }(i);
        n("040b");
        var c = n("f0c5"), u = Object(c.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = u.exports;
    },
    cfc6: function(e, o, n) {
        (function(e) {
            var o = n("4ea4");
            n("a1ea"), o(n("66fd"));
            var t = o(n("b26e"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    }
}, [ [ "cfc6", "common/runtime", "common/vendor" ] ] ]);