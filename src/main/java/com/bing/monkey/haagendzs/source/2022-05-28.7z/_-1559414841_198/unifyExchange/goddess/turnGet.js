// unifyExchange/goddess/turnGet.js
Page({data: {}})