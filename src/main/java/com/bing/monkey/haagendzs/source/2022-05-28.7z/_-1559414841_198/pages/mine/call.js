(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/call" ], {
    3053: function(n, e, o) {
        o.r(e);
        var t = o("8700"), u = o.n(t);
        for (var c in t) "default" !== c && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(c);
        e.default = u.a;
    },
    "681f": function(n, e, o) {
        var t = o("bfd7");
        o.n(t).a;
    },
    8612: function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return u;
        }), o.d(e, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    8700: function(n, e, o) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(o("234f"));
            var u = {
                components: {
                    uniIcons: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(o("fafe"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Zswiper: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/Zswiper") ]).then(function() {
                            return resolve(o("5d9b"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        showBtn: !0
                    };
                },
                onLoad: function() {
                    t.default.recordPv();
                },
                methods: {
                    callPhone: function() {
                        n.makePhoneCall({
                            phoneNumber: "400 820 7917"
                        });
                    }
                }
            };
            e.default = u;
        }).call(this, o("543d").default);
    },
    bfd7: function(n, e, o) {},
    f6583: function(n, e, o) {
        o.r(e);
        var t = o("8612"), u = o("3053");
        for (var c in u) "default" !== c && function(n) {
            o.d(e, n, function() {
                return u[n];
            });
        }(c);
        o("681f");
        var f = o("f0c5"), a = Object(f.a)(u.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = a.exports;
    },
    f98a: function(n, e, o) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("c0e2"), e(o("66fd")), n(e(o("f6583")).default);
        }).call(this, o("543d").createPage);
    }
}, [ [ "f98a", "common/runtime", "common/vendor" ] ] ]);