// pureFeeling/cameraHome/game.js
Page({data: {}})