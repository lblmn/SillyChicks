// ebuyCard/ebuyCard/index.js
Page({data: {}})