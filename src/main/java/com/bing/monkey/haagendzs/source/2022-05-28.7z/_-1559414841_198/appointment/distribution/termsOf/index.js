// appointment/distribution/termsOf/index.js
Page({data: {}})