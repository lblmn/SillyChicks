// blindBox/index/index.js
Page({data: {}})