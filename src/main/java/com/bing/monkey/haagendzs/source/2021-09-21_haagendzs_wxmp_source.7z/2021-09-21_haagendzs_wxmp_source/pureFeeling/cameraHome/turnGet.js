// pureFeeling/cameraHome/turnGet.js
Page({data: {}})