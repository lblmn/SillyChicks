// appointment/distribution/expressInfo.js
Page({data: {}})