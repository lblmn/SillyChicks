// oldActivity/punchclock/shareIndex/index.js
Page({data: {}})