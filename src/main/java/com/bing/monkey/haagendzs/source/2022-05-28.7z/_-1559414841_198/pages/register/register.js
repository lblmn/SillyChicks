(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/register/register" ], {
    "006d": function(e, n, t) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = f(t("a34a")), i = f(t("30c4")), a = f(t("500b")), r = f(t("1a85")), s = f(t("1246")), c = f(t("c1f6")), l = f(t("f0fd")), u = f(t("234f"));
            function f(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function d(e, n, t, o, i, a, r) {
                try {
                    var s = e[a](r), c = s.value;
                } catch (e) {
                    return void t(e);
                }
                s.done ? n(c) : Promise.resolve(c).then(o, i);
            }
            function g(e) {
                return function() {
                    var n = this, t = arguments;
                    return new Promise(function(o, i) {
                        var a = e.apply(n, t);
                        function r(e) {
                            d(a, o, i, r, s, "next", e);
                        }
                        function s(e) {
                            d(a, o, i, r, s, "throw", e);
                        }
                        r(void 0);
                    });
                };
            }
            var h = {
                components: {
                    Zswiper: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/Zswiper") ]).then(function() {
                            return resolve(t("5d9b"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        ossurl: l.default.ossurl + "images/home/",
                        cityvalue: [],
                        showArea: !1,
                        form: {
                            username: e.getStorageSync("wxinfo").nickName ? e.getStorageSync("wxinfo").nickName : "",
                            sex: e.getStorageSync("wxinfo").gender + "" ? e.getStorageSync("wxinfo").gender + "" : "0",
                            birthday: "",
                            area: "",
                            phone: e.getStorageSync("logininfo").mobilePhone ? e.getStorageSync("logininfo").mobilePhone : e.getStorageSync("userinfoPhone"),
                            address: "",
                            email: ""
                        },
                        disabled: !1,
                        btnTitle: "发送验证码",
                        areaList: i.default,
                        checked: !1,
                        dateShow: !1,
                        showMore: !0,
                        showFlag: !1,
                        ruleDesc: "",
                        callbackUrl: "",
                        showLogin: !1,
                        showisYZ: !1,
                        showLoading: !1,
                        canIUseGetUserProfile: !1,
                        fromtype: "",
                        confirmVisible: !1,
                        isCityGet: !0,
                        maxDate: new Date(new Date().setFullYear(new Date().getFullYear() - 14)).getTime(),
                        minDate: new Date(new Date().setFullYear(new Date().getFullYear() - 80)).getTime(),
                        showFlag_first: !1
                    };
                },
                onLoad: function(n) {
                    if (console.log(n), e.getUserProfile && (this.canIUseGetUserProfile = !0), this.getRuleDesc(), 
                    n.url) if (console.log(n), "winterActivity/enterprise/index" == n.url) this.callbackUrl = "/moonActive/lifecycle/index?scence=NEW_D1&urltype=enterprise"; else if ("mycard" == n.fromType) this.callbackUrl = "/pages/mine/mycard", 
                    this.fromtype = n.fromType; else if (n.param) {
                        var t = "";
                        for (var o in JSON.parse(n.param)) t += ("" == t ? "" : "&") + o + "=" + JSON.parse(n.param)[o];
                        var i = "/" + n.url + "?" + t;
                        this.callbackUrl = i;
                    } else this.callbackUrl = "/" + n.url; else "index" == n.fromUrl ? (this.fromUrl = "index", 
                    this.callbackUrl = "/moonActive/lifecycle/index?scence=NEW_D1") : this.callbackUrl = "/pages/index/index";
                },
                onShow: function() {
                    console.log(i.default), console.log(1037 == getApp().globalData.scene, "外部小程序进入"), 
                    e.getStorageSync("wxinfo") || (this.showLogin = !0), this.getSetting();
                },
                methods: {
                    cancelFun: function() {
                        e.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    getSetting: function() {
                        var n = this;
                        e.getSetting({
                            success: function(e) {
                                //!res.authSetting['scope.userLocation']
                                console.log(e), 0 == e.authSetting["scope.userLocation"] ? (console.log("11"), n.isCityGet = !1) : (console.log("22"), 
                                n.isCityGet = !0);
                            }
                        });
                    },
                    newInfo: function() {
                        var n = this;
                        return g(o.default.mark(function t() {
                            var i, a, r, s;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, n.getNewUserInfo();

                                  case 2:
                                    if (i = t.sent, e.setStorageSync("wxinfo", i.userInfo), e.getStorageSync("openId")) {
                                        t.next = 16;
                                        break;
                                    }
                                    return t.next = 7, n.doLogin();

                                  case 7:
                                    return a = t.sent, t.next = 10, n.getOpenid(a);

                                  case 10:
                                    return r = t.sent, e.setStorageSync("openId", r.data.openid), t.next = 14, n.getUnionid(getNewUserInfo);

                                  case 14:
                                    s = t.sent, e.setStorageSync("unionId", s.data.unionId);

                                  case 16:
                                    n.form.username = e.getStorageSync("wxinfo").nickName, n.form.sex = e.getStorageSync("wxinfo").gender + "";

                                  case 18:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getNewUserInfo: function() {
                        return new Promise(function(n, t) {
                            e.getUserProfile({
                                desc: "会员信息",
                                success: function(e) {
                                    console.log(e), n(e);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    onGetUserInfo: function() {
                        var n = this;
                        return g(o.default.mark(function t() {
                            var i, a, r, s;
                            return o.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, n.doLogin();

                                  case 2:
                                    return i = t.sent, t.next = 5, n.getUserinfo(i);

                                  case 5:
                                    if (a = t.sent, e.setStorageSync("wxinfo", a.userInfo), console.log(i, a), e.getStorageSync("openId")) {
                                        t.next = 17;
                                        break;
                                    }
                                    return t.next = 11, n.getOpenid(i);

                                  case 11:
                                    return r = t.sent, e.setStorageSync("openId", r.data.openid), t.next = 15, n.getUnionid(a);

                                  case 15:
                                    s = t.sent, e.setStorageSync("unionId", s.data.unionId);

                                  case 17:
                                    n.form.username = e.getStorageSync("wxinfo").nickName, n.form.sex = e.getStorageSync("wxinfo").gender + "";

                                  case 19:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    doLogin: function() {
                        return new Promise(function(n, t) {
                            e.login({
                                success: function(e) {
                                    n(e);
                                }
                            });
                        });
                    },
                    getUserinfo: function(n) {
                        var t = this;
                        return console.log("进来了"), console.log(n), new Promise(function(o, i) {
                            n.code ? e.getUserInfo({
                                success: function(e) {
                                    o(e);
                                },
                                fail: function(e) {
                                    t.showLogin = !0, console.log("拒绝了用户信息授权");
                                }
                            }) : (i("登录失败！" + n.errMsg), console.log("登录失败！" + n.errMsg));
                        });
                    },
                    getOpenid: function(e) {
                        return a.default.login({
                            code: e.code,
                            appId: this.$env.appId
                        });
                    },
                    getUnionid: function(n) {
                        return a.default.decrypt({
                            encryptedData: n.encryptedData,
                            openId: e.getStorageSync("openId"),
                            iv: n.iv
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        c.default.getRuledesc({
                            type: 1
                        }).then(function(n) {
                            e.ruleDesc = n.data[0].content;
                        });
                    },
                    nameChange: function(e) {
                        var n = e.detail;
                        this.form.username = n;
                    },
                    onSexChange: function(e) {
                        var n = e.detail;
                        console.log(n), this.form.sex = n;
                    },
                    phoneChange: function(e) {
                        var n = e.detail;
                        this.form.phone = n;
                    },
                    addressChange: function(e) {
                        var n = e.detail;
                        this.form.address = n;
                    },
                    emailChange: function(e) {
                        var n = e.detail;
                        this.form.email = n;
                    },
                    onRuleChange: function(e) {
                        var n = e.detail;
                        this.checked = n;
                    },
                    ondateConfirm: function(e) {
                        var n = e.detail, t = new Date(n);
                        this.form.birthday = this.$util.dateFormat("YYYY-mm-dd", t), this.dateShow = !1;
                    },
                    onGetPhoneNumber: function(n) {
                        var t = this;
                        "getPhoneNumber:fail user deny" == n.detail.errMsg ? console.log("取消授权") : (console.log("允许授权"), 
                        a.default.decrypt({
                            encryptedData: n.detail.encryptedData,
                            openId: e.getStorageSync("openId"),
                            iv: n.detail.iv
                        }).then(function(e) {
                            console.log(e.data);
                            var n = e.data.phoneNumber;
                            t.form.phone = n;
                        }));
                    },
                    getLocation: function() {
                        var n = this;
                        e.getLocation({
                            type: "gcj02",
                            success: function(t) {
                                var o, i;
                                e.showLoading({
                                    title: "正在获取位置"
                                }), console.log(t), o = t.latitude.toString(), i = t.longitude.toString(), e.request({
                                    header: {
                                        "Content-Type": "application/text"
                                    },
                                    url: "https://apis.map.qq.com/ws/geocoder/v1/?location=" + o + "," + i + "&key=WR5BZ-7XBCI-JJBGM-5WIGM-6E4V6-XRF6I",
                                    success: function(e) {
                                        n.isCityGet = !0, 200 === e.statusCode ? (console.log("获取中文街道地理位置成功"), n.cityvalue = [ e.data.result.ad_info.province, e.data.result.ad_info.city ], 
                                        n.form.area = [], n.cityvalue.map(function(e, t) {
                                            return 0 == t ? n.form.area.push(s.default.province.filter(function(n) {
                                                return n[1] == e;
                                            })[0][0]) : 1 == t ? n.form.area.push(s.default.city.filter(function(n) {
                                                return n[1] == e;
                                            })[0][0]) : void 0;
                                        })) : console.log("获取信息失败，请重试！");
                                    },
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            },
                            fail: function() {
                                e.showToast({
                                    title: "您拒绝了授权，请在右上角设置中打开地理位置授权",
                                    icon: "none"
                                }), n.isCityGet = !1, console.log("你拒绝了授权，无法获得周边信息");
                            }
                        });
                    },
                    oncityConfirm: function(e) {
                        var n = this;
                        console.log(e), this.cityvalue = [ e.detail.values[0].name, e.detail.values[1].name ], 
                        this.form.area = [], this.cityvalue.map(function(e, t) {
                            return 0 == t ? n.form.area.push(s.default.province.filter(function(n) {
                                return n[1] == e;
                            })[0][0]) : 1 == t ? n.form.area.push(s.default.city.filter(function(n) {
                                return n[1] == e;
                            })[0][0]) : void 0;
                        }), this.showArea = !1;
                    },
                    doRegister: function() {
                        var n = this;
                        if (n.form.username) if (n.form.sex && 0 != n.form.sex && "undefined" != n.form.sex) if (n.form.birthday) if (n.form.area) if (n.form.phone) if (/^1\d{10}$/.test(n.form.phone)) {
                            !n.form.email || /\@/g.test(n.form.email) ? n.checked ? e.requestSubscribeMessage({
                                tmplIds: [ "x7jigI-jwliSYQsZw6kTWQ6WPkUHQGJDgHfoCHppjTI", "9ORgdz-ifNpXB3_K6fMWW0psnNtiOjP3bSQq6XofME0" ],
                                complete: function() {
                                    n.registerOver();
                                }
                            }) : e.showToast({
                                title: "请阅读会员规则",
                                icon: "none"
                            }) : e.showToast({
                                title: "邮箱格式不正确",
                                icon: "none"
                            });
                        } else e.showToast({
                            title: "手机号格式不正确",
                            icon: "none"
                        }); else e.showToast({
                            title: "手机号不能为空",
                            icon: "none"
                        }); else e.showToast({
                            title: "城市不能为空",
                            icon: "none"
                        }); else e.showToast({
                            title: "生日不能为空",
                            icon: "none"
                        }); else e.showToast({
                            title: "性别不能为空",
                            icon: "none"
                        }); else e.showToast({
                            title: "姓名不能为空",
                            icon: "none"
                        });
                    },
                    handleExchange: function() {
                        e.setStorageSync("isGetMoonRule", "success"), e.reLaunch({
                            url: "/pages/shop/shop"
                        });
                    },
                    registerOver: function() {
                        var n = this;
                        this.showLoading = !0;
                        var t = this.form, o = t.phone, i = t.username, s = t.sex, c = t.birthday, l = t.address, f = t.email;
                        getApp().hxt.sendAction("register_botton", {
                            name: i,
                            gender: 1 == s ? "男" : "女",
                            phone: o,
                            city: this.cityvalue[0] + "" + this.cityvalue[1],
                            address: l,
                            email: f
                        });
                        var d = new Date().getTime();
                        r.default.register({
                            mobilePhone: o,
                            source: 2,
                            fullName: i,
                            genderCode: 1 == s ? 100000001 : 100000002,
                            birthDate: c,
                            provinceCode: this.form.area[0],
                            provinceName: this.cityvalue[0],
                            cityCode: this.form.area[1],
                            cityName: this.cityvalue[1],
                            detailAddress: l,
                            email: f,
                            thirdPartyId: e.getStorageSync("unionId"),
                            thirdPartyName: e.getStorageSync("wxinfo").nickName ? e.getStorageSync("wxinfo").nickName : this.form.username,
                            openid: e.getStorageSync("openId"),
                            shopCode: e.getStorageSync("shopCode"),
                            channelLabel: e.getStorageSync("channelLabel"),
                            sign: u.default.mdString(d, {
                                mobilePhone: o,
                                thirdPartyId: e.getStorageSync("unionId")
                            }),
                            timestamp: d
                        }).then(function(t) {
                            console.log("注册返回对象", t), 0 == t.resultCode ? (e.setStorageSync("socialhubId", t.data.socialhubId), 
                            a.default.getmember({
                                idType: "1",
                                id: e.getStorageSync("socialhubId")
                            }).then(function(t) {
                                if (0 == t.resultCode) {
                                    var o = n;
                                    e.setStorageSync("logininfo", t.data), o.$store.commit("userinfo", t.data), console.log("外部小程序进入注册会员成功后弹出回有赞弹窗"), 
                                    n.showLoading = !1, o.callbackUrl.indexOf("/machine/index") > 0 ? e.setStorageSync("registerF", "success") : o.callbackUrl.indexOf("thanksgiving/getShareCard/index") > 0 ? e.setStorageSync("successInfo", "all") : o.callbackUrl.indexOf("winterActivity/home/index") > 0 ? e.setStorageSync("cnysuccess", "all") : o.callbackUrl.indexOf("unifyExchange/index/index") > 0 && e.setStorageSync("unifyExchange", "all"), 
                                    "mycard" == n.fromtype ? o.confirmVisible = !0 : e.showToast({
                                        title: "注册成功",
                                        mask: !0,
                                        complete: function() {
                                            setTimeout(function() {
                                                e.reLaunch({
                                                    url: o.callbackUrl
                                                });
                                            }, 1e3);
                                        }
                                    });
                                } else 401 == t.resultCode ? (n.showLoading = !1, e.showToast({
                                    title: t.msg,
                                    icon: "none"
                                })) : (n.showLoading = !1, e.showToast({
                                    title: "获取会员信息异常",
                                    icon: "none"
                                }));
                            })) : (n.showLoading = !1, e.showToast({
                                title: "网络不佳,请稍后重试",
                                icon: "none"
                            }));
                        }).catch(function() {
                            n.showLoading = !1, e.showToast({
                                title: "网络不佳,请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    goBack: function() {
                        getApp().hxt.sendAction("tem_not_register"), "index" == this.fromUrl ? e.navigateBack({
                            delta: -1
                        }) : e.reLaunch({
                            url: "/pages/index/index"
                        });
                    },
                    goIndex: function() {
                        e.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    backYZ: function() {
                        e.navigateBackMiniProgram();
                    }
                }
            };
            n.default = h;
        }).call(this, t("543d").default);
    },
    "4b3f": function(e, n, t) {},
    "7f3f": function(e, n, t) {
        t.r(n);
        var o = t("db05"), i = t("a6d3");
        for (var a in i) "default" !== a && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(a);
        t("c650");
        var r = t("f0c5"), s = Object(r.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = s.exports;
    },
    a6d3: function(e, n, t) {
        t.r(n);
        var o = t("006d"), i = t.n(o);
        for (var a in o) "default" !== a && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = i.a;
    },
    c650: function(e, n, t) {
        var o = t("4b3f");
        t.n(o).a;
    },
    db05: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this, n = (e.$createElement, e._self._c, new Date(1990, 0, 1).getTime());
            e._isMounted || (e.e0 = function(n) {
                e.dateShow = !0;
            }, e.e1 = function(n) {
                e.dateShow = !1;
            }, e.e2 = function(n) {
                e.dateShow = !1;
            }, e.e3 = function(n) {
                e.showArea = !0;
            }, e.e4 = function(n) {
                e.showArea = !1;
            }, e.e5 = function(n) {
                e.showMore = !e.showMore;
            }, e.e6 = function(n) {
                e.showFlag = !0;
            }, e.e7 = function(n) {
                e.showFlag = !1;
            }, e.e8 = function(n) {
                e.showFlag = !1;
            }, e.e9 = function(n) {
                e.showFlag_first = !1;
            }, e.e10 = function(n) {
                e.showFlag_first = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: n
                }
            });
        }, i = [];
    },
    e681: function(e, n, t) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            t("c0e2"), n(t("66fd")), e(n(t("7f3f")).default);
        }).call(this, t("543d").createPage);
    }
}, [ [ "e681", "common/runtime", "common/vendor" ] ] ]);