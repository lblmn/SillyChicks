// summerEvaluate/ranking/index.js
Page({data: {}})