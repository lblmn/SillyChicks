var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/register/register" ], {
    "020d": function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return i;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this, n = (e.$createElement, e._self._c, new Date(1990, 0, 1).getTime());
            e._isMounted || (e.e0 = function(n) {
                e.dateShow = !0;
            }, e.e1 = function(n) {
                e.dateShow = !1;
            }, e.e2 = function(n) {
                e.dateShow = !1;
            }, e.e3 = function(n) {
                e.showArea = !0;
            }, e.e4 = function(n) {
                e.showArea = !1;
            }, e.e5 = function(n) {
                e.showMore = !e.showMore;
            }, e.e6 = function(n) {
                e.showFlag = !0;
            }, e.e7 = function(n) {
                e.showFlag = !1;
            }, e.e8 = function(n) {
                e.showFlag = !1;
            }, e.e9 = function(n) {
                e.showFlag_first = !1;
            }, e.e10 = function(n) {
                e.showFlag_first = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: n
                }
            });
        }, i = [];
    },
    "080e": function(e, n, t) {
        t.r(n);
        var o = t("020d"), i = t("c07c");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(a);
        t("7bc0");
        var r = t("f0c5"), s = Object(r.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = s.exports;
    },
    "7bc0": function(e, n, t) {
        var o = t("e072");
        t.n(o).a;
    },
    b98e: function(t, o, i) {
        (function(t) {
            var a = i("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var r, s, c = a(i("bc67")), l = a(i("9296")), u = a(i("bac0")), d = a(i("bcfc")), f = a(i("0098")), g = a(i("f3d4")), h = a(i("7d43")), m = {
                components: {
                    Zswiper: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/Zswiper") ]).then(function() {
                            return resolve(i("4483"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                data: function() {
                    return {
                        ossurl: g.default.ossurl + "images/home/",
                        cityvalue: [],
                        showArea: !1,
                        form: {
                            username: t.getStorageSync("wxinfo").nickName ? t.getStorageSync("wxinfo").nickName : "",
                            sex: t.getStorageSync("wxinfo").gender + "" ? t.getStorageSync("wxinfo").gender + "" : "0",
                            birthday: "",
                            area: "",
                            phone: t.getStorageSync("logininfo").mobilePhone ? t.getStorageSync("logininfo").mobilePhone : t.getStorageSync("userinfoPhone"),
                            address: "",
                            email: ""
                        },
                        disabled: !1,
                        btnTitle: "发送验证码",
                        areaList: c.default,
                        checked: !1,
                        dateShow: !1,
                        showMore: !0,
                        showFlag: !1,
                        ruleDesc: "",
                        callbackUrl: "",
                        showLogin: !1,
                        showisYZ: !1,
                        showLoading: !1,
                        canIUseGetUserProfile: !1,
                        fromtype: "",
                        confirmVisible: !1,
                        isCityGet: !0,
                        maxDate: new Date(new Date().setFullYear(new Date().getFullYear() - 14)).getTime(),
                        minDate: new Date(new Date().setFullYear(new Date().getFullYear() - 80)).getTime(),
                        showFlag_first: !1
                    };
                },
                onLoad: function(e) {
                    if (console.log(e), t.getUserProfile && (this.canIUseGetUserProfile = !0), this.getRuleDesc(), 
                    e.url) if (console.log(e), "winterActivity/enterprise/index" == e.url || "ebuyCard/enterprise/index" == e.url) this.callbackUrl = "/moonActive/lifecycle/index?scence=NEW_D1&urltype=enterprise"; else if (e.url.includes("blindBox/cardGet/index")) this.callbackUrl = "/moonActive/lifecycle/index?scence=NEW_D1&urltype=cardGet"; else if ("mycard" == e.fromType) this.callbackUrl = "/pages/mine/mycard", 
                    this.fromtype = e.fromType; else if (e.param) {
                        var n = "";
                        if ("yes" == JSON.parse(e.param).needLifecycle) this.callbackUrl = "/moonActive/lifecycle/index?scence=NEW_D1&needLifecycle=yes&urltype=cardGet&backurl=" + e.url; else {
                            for (var o in JSON.parse(e.param)) n += ("" == n ? "" : "&") + o + "=" + JSON.parse(e.param)[o];
                            var i = "/" + e.url + "?" + n;
                            this.callbackUrl = i;
                        }
                    } else this.callbackUrl = "/" + e.url; else "index" == e.fromUrl ? (this.fromUrl = "index", 
                    this.callbackUrl = "/moonActive/lifecycle/index?scence=NEW_D1") : this.callbackUrl = "/pages/index/index";
                },
                onShow: function() {
                    console.log(c.default), console.log(1037 == getApp().globalData.scene, "外部小程序进入"), 
                    this.getSetting();
                },
                methods: {
                    cancelFun: function() {
                        t.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    getSetting: function() {
                        var e = this;
                        t.getSetting({
                            success: function(n) {
                                console.log(n), 0 == n.authSetting["scope.userLocation"] ? (console.log("11"), e.isCityGet = !1) : (console.log("22"), 
                                e.isCityGet = !0);
                            }
                        });
                    },
                    newInfo: (s = n(e.default.mark(function n() {
                        var o, i, a, r;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.getNewUserInfo();

                              case 2:
                                if (o = e.sent, t.setStorageSync("wxinfo", o.userInfo), t.getStorageSync("openId")) {
                                    e.next = 15;
                                    break;
                                }
                                return e.next = 6, this.doLogin();

                              case 6:
                                return i = e.sent, e.next = 9, this.getOpenid(i);

                              case 9:
                                return a = e.sent, t.setStorageSync("openId", a.data.openid), e.next = 13, this.getUnionid(getNewUserInfo);

                              case 13:
                                r = e.sent, t.setStorageSync("unionId", r.data.unionId);

                              case 15:
                                this.form.username = t.getStorageSync("wxinfo").nickName, this.form.sex = t.getStorageSync("wxinfo").gender + "";

                              case 16:
                              case "end":
                                return e.stop();
                            }
                        }, n, this);
                    })), function() {
                        return s.apply(this, arguments);
                    }),
                    getNewUserInfo: function() {
                        return new Promise(function(e, n) {
                            t.getUserProfile({
                                desc: "会员信息",
                                success: function(n) {
                                    console.log(n), getApp().hxt.sendAction("allow_alias"), e(n);
                                },
                                fail: function(e) {
                                    console.log(e), getApp().hxt.sendAction("deny_alias"), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    onGetUserInfo: (r = n(e.default.mark(function n() {
                        var o, i, a, r;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.doLogin();

                              case 2:
                                return o = e.sent, e.next = 5, this.getUserinfo(o);

                              case 5:
                                if (i = e.sent, t.setStorageSync("wxinfo", i.userInfo), console.log(o, i), t.getStorageSync("openId")) {
                                    e.next = 15;
                                    break;
                                }
                                return e.next = 9, this.getOpenid(o);

                              case 9:
                                return a = e.sent, t.setStorageSync("openId", a.data.openid), e.next = 13, this.getUnionid(i);

                              case 13:
                                r = e.sent, t.setStorageSync("unionId", r.data.unionId);

                              case 15:
                                this.form.username = t.getStorageSync("wxinfo").nickName, this.form.sex = t.getStorageSync("wxinfo").gender + "";

                              case 16:
                              case "end":
                                return e.stop();
                            }
                        }, n, this);
                    })), function() {
                        return r.apply(this, arguments);
                    }),
                    doLogin: function() {
                        return new Promise(function(e, n) {
                            t.login({
                                success: function(n) {
                                    e(n);
                                }
                            });
                        });
                    },
                    getUserinfo: function(e) {
                        var n = this;
                        return console.log("进来了"), console.log(e), new Promise(function(o, i) {
                            e.code ? t.getUserInfo({
                                success: function(e) {
                                    o(e);
                                },
                                fail: function(e) {
                                    n.showLogin = !0, console.log("拒绝了用户信息授权");
                                }
                            }) : (i("登录失败！" + e.errMsg), console.log("登录失败！" + e.errMsg));
                        });
                    },
                    getOpenid: function(e) {
                        return l.default.login({
                            code: e.code,
                            appId: this.$env.appId
                        });
                    },
                    getUnionid: function(e) {
                        return l.default.decrypt({
                            encryptedData: e.encryptedData,
                            openId: t.getStorageSync("openId"),
                            iv: e.iv
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        f.default.getRuledesc({
                            type: 1
                        }).then(function(n) {
                            e.ruleDesc = n.data[0].content;
                        });
                    },
                    nameChange: function(e) {
                        var n = e.detail;
                        console.log(n), this.form.username = n;
                    },
                    onSexChange: function(e) {
                        var n = e.detail;
                        console.log(n), this.form.sex = n;
                    },
                    phoneChange: function(e) {
                        var n = e.detail;
                        this.form.phone = n;
                    },
                    addressChange: function(e) {
                        var n = e.detail;
                        this.form.address = n;
                    },
                    emailChange: function(e) {
                        var n = e.detail;
                        this.form.email = n;
                    },
                    onRuleChange: function(e) {
                        var n = e.detail;
                        this.checked = n;
                    },
                    ondateConfirm: function(e) {
                        var n = e.detail, t = new Date(n);
                        this.form.birthday = this.$util.dateFormat("YYYY-mm-dd", t), this.dateShow = !1;
                    },
                    onGetPhoneNumber: function(e) {
                        var n = this;
                        "getPhoneNumber:fail user deny" == e.detail.errMsg ? console.log("取消授权") : (console.log("允许授权"), 
                        l.default.decrypt({
                            encryptedData: e.detail.encryptedData,
                            openId: t.getStorageSync("openId"),
                            iv: e.detail.iv
                        }).then(function(e) {
                            console.log(e.data);
                            var t = e.data.phoneNumber;
                            n.form.phone = t;
                        }));
                    },
                    getLocation: function() {
                        var e = this;
                        t.getLocation({
                            type: "gcj02",
                            success: function(n) {
                                var o, i;
                                t.showLoading({
                                    title: "正在获取位置"
                                }), console.log(n), o = n.latitude.toString(), i = n.longitude.toString(), t.request({
                                    header: {
                                        "Content-Type": "application/text"
                                    },
                                    url: "https://apis.map.qq.com/ws/geocoder/v1/?location=" + o + "," + i + "&key=WR5BZ-7XBCI-JJBGM-5WIGM-6E4V6-XRF6I",
                                    success: function(n) {
                                        e.isCityGet = !0, 200 === n.statusCode ? (console.log("获取中文街道地理位置成功"), e.cityvalue = [ n.data.result.ad_info.province, n.data.result.ad_info.city ], 
                                        e.form.area = [], e.cityvalue.map(function(n, t) {
                                            return 0 == t ? e.form.area.push(d.default.province.filter(function(e) {
                                                return e[1] == n;
                                            })[0][0]) : 1 == t ? e.form.area.push(d.default.city.filter(function(e) {
                                                return e[1] == n;
                                            })[0][0]) : void 0;
                                        })) : console.log("获取信息失败，请重试！");
                                    },
                                    complete: function() {
                                        t.hideLoading();
                                    }
                                });
                            },
                            fail: function() {
                                t.showToast({
                                    title: "您拒绝了授权，请在右上角设置中打开地理位置授权",
                                    icon: "none"
                                }), e.isCityGet = !1, console.log("你拒绝了授权，无法获得周边信息");
                            }
                        });
                    },
                    oncityConfirm: function(e) {
                        var n = this;
                        console.log(e), this.cityvalue = [ e.detail.values[0].name, e.detail.values[1].name ], 
                        this.form.area = [], this.cityvalue.map(function(e, t) {
                            return 0 == t ? n.form.area.push(d.default.province.filter(function(n) {
                                return n[1] == e;
                            })[0][0]) : 1 == t ? n.form.area.push(d.default.city.filter(function(n) {
                                return n[1] == e;
                            })[0][0]) : void 0;
                        }), this.showArea = !1;
                    },
                    doRegister: function() {
                        var e = this;
                        e.form.username ? e.form.sex && 0 != e.form.sex && "undefined" != e.form.sex ? e.form.birthday ? e.form.area ? e.form.phone ? /^1\d{10}$/.test(e.form.phone) ? !e.form.email || /\@/g.test(e.form.email) ? e.checked ? t.requestSubscribeMessage({
                            tmplIds: [ "x7jigI-jwliSYQsZw6kTWQ6WPkUHQGJDgHfoCHppjTI", "9ORgdz-ifNpXB3_K6fMWW0psnNtiOjP3bSQq6XofME0" ],
                            complete: function() {
                                e.registerOver();
                            }
                        }) : t.showToast({
                            title: "请阅读会员规则",
                            icon: "none"
                        }) : t.showToast({
                            title: "邮箱格式不正确",
                            icon: "none"
                        }) : t.showToast({
                            title: "手机号格式不正确",
                            icon: "none"
                        }) : t.showToast({
                            title: "手机号不能为空",
                            icon: "none"
                        }) : t.showToast({
                            title: "城市不能为空",
                            icon: "none"
                        }) : t.showToast({
                            title: "生日不能为空",
                            icon: "none"
                        }) : t.showToast({
                            title: "性别不能为空",
                            icon: "none"
                        }) : t.showToast({
                            title: "姓名不能为空",
                            icon: "none"
                        });
                    },
                    handleExchange: function() {
                        t.setStorageSync("isGetMoonRule", "success"), t.reLaunch({
                            url: "/pages/shop/shop"
                        });
                    },
                    registerOver: function() {
                        var e = this;
                        this.showLoading = !0;
                        var n = this.form, o = n.phone, i = n.username, a = n.sex, r = n.birthday, s = n.address, c = n.email;
                        getApp().hxt.sendAction("register_botton", {
                            name: i,
                            gender: 1 == a ? "男" : "女",
                            phone: o,
                            city: this.cityvalue[0] + "" + this.cityvalue[1],
                            address: s,
                            email: c,
                            birthday: r
                        });
                        var d = new Date().getTime();
                        u.default.register({
                            mobilePhone: o,
                            source: 2,
                            fullName: i,
                            genderCode: 1 == a ? 100000001 : 100000002,
                            birthDate: r,
                            provinceCode: this.form.area[0],
                            provinceName: this.cityvalue[0],
                            cityCode: this.form.area[1],
                            cityName: this.cityvalue[1],
                            detailAddress: s,
                            email: c,
                            thirdPartyId: t.getStorageSync("unionId"),
                            thirdPartyName: t.getStorageSync("wxinfo").nickName ? t.getStorageSync("wxinfo").nickName : this.form.username,
                            openid: t.getStorageSync("openId"),
                            shopCode: t.getStorageSync("shopCode"),
                            channelLabel: t.getStorageSync("channelLabel"),
                            sessionKey: t.getStorageSync("sessionKey"),
                            sign: h.default.mdString(d, {
                                mobilePhone: o,
                                thirdPartyId: t.getStorageSync("unionId")
                            }),
                            timestamp: d
                        }).then(function(n) {
                            console.log("注册返回对象", n), 0 == n.resultCode ? (t.setStorageSync("socialhubId", n.data.socialhubId), 
                            t.removeStorageSync("sessionKey"), l.default.getmember({
                                idType: "1",
                                id: t.getStorageSync("socialhubId")
                            }).then(function(n) {
                                if (0 == n.resultCode) {
                                    var o = e;
                                    t.setStorageSync("logininfo", n.data), o.$store.commit("userinfo", n.data), console.log("外部小程序进入注册会员成功后弹出回有赞弹窗"), 
                                    e.showLoading = !1, o.callbackUrl.indexOf("/machine/index") > 0 ? t.setStorageSync("registerF", "success") : o.callbackUrl.indexOf("thanksgiving/getShareCard/index") > 0 ? t.setStorageSync("successInfo", "all") : o.callbackUrl.indexOf("winterActivity/home/index") > 0 ? t.setStorageSync("cnysuccess", "all") : o.callbackUrl.indexOf("unifyExchange/index/index") > 0 ? t.setStorageSync("unifyExchange", "all") : o.callbackUrl.indexOf("blindBox/makeup/index") > 0 && t.setStorageSync("blindBoxMake", "all"), 
                                    "mycard" == e.fromtype ? o.confirmVisible = !0 : t.showToast({
                                        title: "注册成功",
                                        mask: !0,
                                        complete: function() {
                                            setTimeout(function() {
                                                t.reLaunch({
                                                    url: o.callbackUrl
                                                });
                                            }, 1e3);
                                        }
                                    });
                                } else 401 == n.resultCode ? (e.showLoading = !1, t.showToast({
                                    title: n.msg,
                                    icon: "none"
                                })) : (e.showLoading = !1, t.showToast({
                                    title: "获取会员信息异常",
                                    icon: "none"
                                }));
                            })) : (e.showLoading = !1, t.showToast({
                                title: "网络不佳,请稍后重试",
                                icon: "none"
                            }));
                        }).catch(function() {
                            e.showLoading = !1, t.showToast({
                                title: "网络不佳,请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    goBack: function() {
                        getApp().hxt.sendAction("tem_not_register"), "index" == this.fromUrl ? t.navigateBack({
                            delta: -1
                        }) : t.reLaunch({
                            url: "/pages/index/index"
                        });
                    },
                    goIndex: function() {
                        t.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    backYZ: function() {
                        t.navigateBackMiniProgram();
                    }
                }
            };
            o.default = m;
        }).call(this, i("543d").default);
    },
    c07c: function(e, n, t) {
        t.r(n);
        var o = t("b98e"), i = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = i.a;
    },
    e072: function(e, n, t) {},
    f372: function(e, n, t) {
        (function(e) {
            var n = t("4ea4");
            t("a1ea"), n(t("66fd"));
            var o = n(t("080e"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(o.default);
        }).call(this, t("543d").createPage);
    }
}, [ [ "f372", "common/runtime", "common/vendor" ] ] ]);