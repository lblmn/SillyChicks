// newStore/winterZhweel/index.js
Page({data: {}})