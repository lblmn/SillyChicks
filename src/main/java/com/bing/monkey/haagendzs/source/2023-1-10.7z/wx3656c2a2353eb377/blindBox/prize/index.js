// blindBox/prize/index.js
Page({data: {}})