// winterActivity/hhswActivity/turnGet.js
Page({data: {}})