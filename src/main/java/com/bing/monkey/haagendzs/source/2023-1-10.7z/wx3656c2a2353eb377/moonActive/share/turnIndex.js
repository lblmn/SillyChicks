// moonActive/share/turnIndex.js
Page({data: {}})