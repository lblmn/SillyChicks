// shareStyle/share_mkup/turnIndex.js
Page({data: {}})