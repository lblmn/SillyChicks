// appointment/distribution/index.js
Page({data: {}})