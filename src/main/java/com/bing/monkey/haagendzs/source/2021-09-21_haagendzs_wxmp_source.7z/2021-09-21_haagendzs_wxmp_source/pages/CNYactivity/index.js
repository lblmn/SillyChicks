(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/CNYactivity/index" ], {
    2395: function(e, o, n) {
        var i = n("379c");
        n.n(i).a;
    },
    "379c": function(e, o, n) {},
    "9fc2": function(e, o, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("f4aa"), o(n("66fd")), e(o(n("abb0")).default);
        }).call(this, n("543d").createPage);
    },
    abb0: function(e, o, n) {
        n.r(o);
        var i = n("f7c7"), t = n("f682");
        for (var c in t) "default" !== c && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(c);
        n("2395");
        var a = n("f0c5"), l = Object(a.a)(t.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        o.default = l.exports;
    },
    edde: function(e, o, n) {
        (function(e) {
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var t = i(n("9607")), c = i(n("11e1")), a = i(n("1328")), l = {
                data: function() {
                    return {
                        loading: !1,
                        showloginDialog: !1,
                        isShowSharePopup: !1,
                        helpinfo: "",
                        code: "",
                        imgUrl: a.default.assetsRoot,
                        checkCodeState: !1,
                        itemvalue: "selected",
                        checked: !0,
                        showrule: !1,
                        rulesinfo: "",
                        activityType: "",
                        isLovePink: !1,
                        isLoveGold: !1,
                        imgurl: a.default.assetsRoot + "/oss/wxapp/20210127/static"
                    };
                },
                onLoad: function(o) {
                    this.aid = o.aid ? o.aid : "13", this.activityType = o.activityType;
                    var n = "#48080f";
                    "lovePink" == this.activityType ? (n = "#e5848d", this.isLovePink = !0) : "loveGolden" == this.activityType && (n = "#caa684", 
                    this.isLoveGold = !0), e.setNavigationBarColor({
                        frontColor: "#ffffff",
                        backgroundColor: n,
                        animation: {
                            duration: 400,
                            timingFunc: "easeIn"
                        }
                    }), e.showLoading({
                        title: "数据加载中...",
                        mask: !0
                    });
                },
                onShow: function() {
                    this.showloginDialog = !0;
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("a81e"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                methods: {
                    closerule: function() {
                        this.checked = !0, this.showrule = !1;
                    },
                    checkboxChange: function(e) {
                        console.log(e), e.detail.value.length > 0 ? this.checked = !0 : this.checked = !1;
                    },
                    lineshowrule: function() {
                        var o = this;
                        console.log("显示规则"), t.default.activityGet(this.aid, {
                            unionId: e.getStorageSync("unionId")
                        }).then(function(n) {
                            console.log(n), 0 == n.code ? (o.rulesinfo = n.data.activity.ruleDesc.replace(/\n/g, "<br/>"), 
                            o.showrule = !0) : e.showToast({
                                title: "活动信息获取失败",
                                icon: "none"
                            });
                        });
                    },
                    loadOver: function() {
                        console.log("图片加载完成"), e.hideLoading();
                    },
                    inputValue: function(e) {
                        console.log(e);
                        var o = e.detail.value.replace(/[^\w\\]/gi, "");
                        return this.code = o.trim(), o;
                    },
                    goIndex: function() {
                        e.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    closepopup: function() {
                        this.checkCodeState ? (this.isShowSharePopup = !1, e.redirectTo({
                            url: "/pages/mine/mycard"
                        })) : this.isShowSharePopup = !1;
                    },
                    checkCode: function() {
                        var o = this;
                        return "" == this.code ? (this.isShowSharePopup = !0, this.helpinfo = "请输入兑换密码验证", 
                        !1) : this.checked ? void c.default.checkCode(this.aid, {
                            code: this.code,
                            openid: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            "401" == e.code ? o.helpinfo = "页面走丢，请联系客服\n400-2904-400" : "401002" == e.code ? o.helpinfo = "已被兑换哦\n请查看您的券包~" : "401001" == e.code ? o.helpinfo = "密码不正确，请重新输入" : 0 == e.code ? (o.checkCodeState = !0, 
                            o.helpinfo = '密码验证通过，电子产品兑换券已发送至"我的券包"') : 1 == e.code ? "E030003" == e.msg ? o.helpinfo = "兑换失败，\n请联系客服400-820-7917" : "E010005" == e.msg ? o.helpinfo = "好礼请求超时，请稍后重试\n或联系客服400-820-7917" : "SINOBASE0029" == e.msg ? o.helpinfo = '密码已被兑换，\n请前往"我的券包"查看\n如有问题联系客服：400-820-7917' : ("SINOBASE0037" == e.msg || "SINOBASE0030" == e.msg || "SINOBASE0039" == e.msg || e.msg, 
                            o.helpinfo = "兑换失败，\n请联系客服400-820-7917") : o.helpinfo = "兑换失败，\n请联系客服400-820-7917", 
                            o.isShowSharePopup = !0;
                        }).catch(function(e) {
                            console.log(e);
                        }) : (this.isShowSharePopup = !0, this.helpinfo = "请阅读勾选兑换须知", !1);
                    }
                }
            };
            o.default = l;
        }).call(this, n("543d").default);
    },
    f682: function(e, o, n) {
        n.r(o);
        var i = n("edde"), t = n.n(i);
        for (var c in i) "default" !== c && function(e) {
            n.d(o, e, function() {
                return i[e];
            });
        }(c);
        o.default = t.a;
    },
    f7c7: function(e, o, n) {
        n.d(o, "b", function() {
            return i;
        }), n.d(o, "c", function() {
            return t;
        }), n.d(o, "a", function() {});
        var i = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, t = [];
    }
}, [ [ "9fc2", "common/runtime", "common/vendor" ] ] ]);