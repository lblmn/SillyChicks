// summerEvaluate/rule/index.js
Page({data: {}})