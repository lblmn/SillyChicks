// newStore/winterLottery/index.js
Page({data: {}})