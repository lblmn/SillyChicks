// moonActive/home/index.js
Page({data: {}})