(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/luckbag/turnlist" ], {
    "2adc": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(e("2fa1"));
            var i = {
                name: "jixin",
                components: {
                    Zzhuanzeng: function() {
                        e.e("components/Zzhuanzeng").then(function() {
                            return resolve(e("7df3"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    uniIcons: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(e("fafe"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        cardList: [],
                        nextId: "",
                        pageSize: 100,
                        noMore: !1
                    };
                },
                onShow: function() {},
                onLoad: function() {
                    var n = getApp().globalData.PointAccount.filter(function(n) {
                        return n.pointAccountName.indexOf("积心") > -1;
                    })[0];
                    this.pointAccountId = n.pointAccountId, this.getList();
                },
                methods: {
                    cancelBtn: function(t) {
                        console.log(t);
                        var e = this;
                        o.default.transfer({
                            openid: n.getStorageSync("openId"),
                            nickName: n.getStorageSync("logininfo").fullName,
                            unionId: n.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: t.vinfo.couponCode,
                            actionType: "2",
                            remark: ""
                        }, !1).then(function(t) {
                            console.log(t), "0" == t.code ? n.showToast({
                                icon: "none",
                                title: "取消成功",
                                success: function() {
                                    setTimeout(function() {
                                        e.cardList = [], e.nextId = "", e.getList();
                                    }, 1e3);
                                }
                            }) : n.showToast({
                                icon: "none",
                                title: "取消失败，请稍后重试"
                            });
                        });
                    },
                    goShop: function() {
                        n.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    getList: function() {
                        var t = this, e = {
                            idType: 1,
                            id: n.getStorageSync("socialhubId"),
                            flag: 0,
                            nextId: this.nextId,
                            pageSize: this.pageSize,
                            state: 0
                        };
                        "" == this.nextId && delete e.nextId, o.default.coupontransferlist(e).then(function(e) {
                            n.hideLoading(), console.log(e), 0 == e.resultCode && (e.data.nextId && (t.nextId = e.data.nextId), 
                            e.data.list && e.data.list.length > 0 && (t.cardList = t.cardList.concat(e.data.list)), 
                            e.data.nextId || (t.noMore = !0));
                        });
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (n.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), this.getList());
                    }
                }
            };
            t.default = i;
        }).call(this, e("543d").default);
    },
    "2ea3": function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("c0e2"), t(e("66fd")), n(t(e("ae0a")).default);
        }).call(this, e("543d").createPage);
    },
    "41d4": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    6024: function(n, t, e) {
        e.r(t);
        var o = e("2adc"), i = e.n(o);
        for (var a in o) "default" !== a && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(a);
        t.default = i.a;
    },
    6571: function(n, t, e) {
        var o = e("9e94");
        e.n(o).a;
    },
    "9e94": function(n, t, e) {},
    ae0a: function(n, t, e) {
        e.r(t);
        var o = e("41d4"), i = e("6024");
        for (var a in i) "default" !== a && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(a);
        e("6571");
        var c = e("f0c5"), u = Object(c.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    }
}, [ [ "2ea3", "common/runtime", "common/vendor" ] ] ]);