(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/Zswiper" ], {
    "339b": function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, function(n) {
            n && n.__esModule;
        }(t("9b6d"));
        var o = getApp();
        console.log(o);
        var c = {
            name: "Zswiper",
            data: function() {
                return {};
            },
            props: {
                swiper: {
                    type: Object,
                    default: function() {
                        return {
                            imgUrls: [],
                            indicatorDots: !0,
                            autoplay: !0,
                            interval: 3e3,
                            duration: 500,
                            current: 0
                        };
                    }
                }
            },
            methods: {
                goWheel: function(n) {
                    console.log(n), n && this.$emit("navigateTo", n);
                }
            }
        };
        e.default = c;
    },
    "535c": function(n, e, t) {},
    b780: function(n, e, t) {
        t.r(e);
        var o = t("339b"), c = t.n(o);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = c.a;
    },
    d9b0: function(n, e, t) {
        var o = t("535c");
        t.n(o).a;
    },
    e541: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, c = [];
    },
    f95d: function(n, e, t) {
        t.r(e);
        var o = t("e541"), c = t("b780");
        for (var a in c) "default" !== a && function(n) {
            t.d(e, n, function() {
                return c[n];
            });
        }(a);
        t("d9b0");
        var r = t("f0c5"), u = Object(r.a)(c.default, o.b, o.c, !1, null, "5c6585fa", null, !1, o.a, void 0);
        e.default = u.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/Zswiper-create-component", {
    "components/Zswiper-create-component": function(n, e, t) {
        t("543d").createComponent(t("f95d"));
    }
}, [ [ "components/Zswiper-create-component" ] ] ]);