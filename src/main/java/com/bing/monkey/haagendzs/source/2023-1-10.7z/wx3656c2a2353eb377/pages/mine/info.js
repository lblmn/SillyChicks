(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/info" ], {
    1567: function(e, t, o) {
        (function(e) {
            var t = o("4ea4");
            o("a1ea"), t(o("66fd"));
            var n = t(o("f11c"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = o, e(n.default);
        }).call(this, o("543d").createPage);
    },
    2456: function(e, t, o) {
        (function(e) {
            var n = o("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = n(o("9296")), a = n(o("bcfc")), r = n(o("8415")), s = n(o("7d43")), l = n(o("f3d4")), c = (getApp(), 
            {
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog_new") ]).then(function() {
                            return resolve(o("5972"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Loading: function() {
                        o.e("components/loading").then(function() {
                            return resolve(o("64ff"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        showloginDialog: !1,
                        isdisabled: !1,
                        showphone: !1,
                        from: "",
                        form: {
                            fullName: "",
                            genderCode: "",
                            birthDate: "",
                            phone: "",
                            detailAddress: "",
                            email: "",
                            tierName: "",
                            area: ""
                        },
                        cityvalue: [],
                        dateShow: !1,
                        maxDate: new Date(new Date().setFullYear(new Date().getFullYear() - 14)).getTime(),
                        minDate: new Date(new Date().setFullYear(new Date().getFullYear() - 80)).getTime(),
                        userYear14: !1,
                        imgurl: l.default.ossurl + "/images",
                        showModel: !1,
                        doSaveModel: !1
                    };
                },
                onLoad: function(e) {
                    this.$refs.Loading.showLoading(), s.default.setSource(e), this.from = e.from;
                },
                onShow: function() {
                    Object.keys(e.getStorageSync("logininfo")).length > 0 ? (s.default.recordPv(), s.default.getRecord(), 
                    this.isYear14(), this.setInfo(), this.$refs.Loading.hideLoading()) : (this.$refs.Loading.showLoading(), 
                    this.showloginDialog = !0);
                },
                methods: {
                    isshowModel: function() {
                        e.getStorageSync("showUserInfoYearModel") ? this.showModel = !1 : (this.showModel = !0, 
                        e.setStorageSync("showUserInfoYearModel", !0));
                    },
                    birthDate: function() {
                        this.dateShow = !0;
                    },
                    isYear14: function() {
                        var t = this;
                        this.from ? i.default.getmemberForProgress({
                            idType: "2",
                            id: e.getStorageSync("unionId"),
                            type: "11"
                        }).then(function(e) {
                            0 == e.resultCode ? (t.$store.commit("is14YearsOldFun", e.data.is14YearsOld), 1 == e.data.is14YearsOld ? t.userYear14 = !0 : (t.userYear14 = !1, 
                            t.isshowModel())) : t.userYear14 = !0;
                        }).catch(function() {
                            t.userYear14 = !0;
                        }) : this.isshowModel();
                    },
                    ondateConfirm: function(e) {
                        var t = e.detail, o = new Date(t);
                        this.form.birthDate = this.$util.dateFormat("YYYY-mm-dd", o), this.dateShow = !1;
                    },
                    setInfo: function() {
                        var t = {
                            fullName: e.getStorageSync("logininfo").fullName,
                            genderCode: "" + e.getStorageSync("logininfo").genderCode,
                            birthDate: e.getStorageSync("logininfo").birthDate,
                            phone: e.getStorageSync("logininfo").mobilePhone,
                            detailAddress: e.getStorageSync("logininfo").detailAddress,
                            email: e.getStorageSync("logininfo").email,
                            tierName: e.getStorageSync("logininfo").tier.tierName,
                            area: ""
                        }, o = [ e.getStorageSync("logininfo").provinceName, e.getStorageSync("logininfo").cityName ], n = e.getStorageSync("logininfo").provinceCode, i = e.getStorageSync("logininfo").cityCode, a = e.getStorageSync("logininfo").provinceName;
                        e.getStorageSync("logininfo").cityName, t.area = "" == n || "0" == n || "" == i || "0" == i || null == a || "null" == a ? "" : [ n, i ], 
                        "100000001" == e.getStorageSync("logininfo").genderCode || "100000002" == e.getStorageSync("logininfo").genderCode ? this.isdisabled = !0 : this.isdisabled = !1, 
                        this.cityvalue = o, this.form = t;
                    },
                    getmemberSuccess: function(e) {
                        "all" == e ? (s.default.recordPv(), s.default.getRecord(), this.isYear14(), this.setInfo(), 
                        this.showloginDialog = !1, this.$refs.Loading.hideLoading()) : "error" == e && this.$refs.Loading.hideLoading();
                    },
                    nameChange: function(e) {
                        var t = e.detail;
                        this.form.fullName = t;
                    },
                    addressChange: function(e) {
                        var t = e.detail;
                        this.form.detailAddress = t;
                    },
                    onSexChange: function(e) {
                        var t = e.detail;
                        this.form.genderCode = t;
                    },
                    emailChange: function(e) {
                        var t = e.detail;
                        this.form.email = t;
                    },
                    getLocation1: function() {
                        var t = this;
                        return e.showLoading({
                            title: "定位中...",
                            mask: !0
                        }), new Promise(function(o, n) {
                            var i = t, a = function t(o) {
                                console.log("location change", o), i.getList(o), e.hideLoading(), e.offLocationChange(t);
                            };
                            e.startLocationUpdate({
                                success: function(t) {
                                    console.log(t), e.onLocationChange(a), o();
                                },
                                fail: function(t) {
                                    console.log("获取当前位置失败", t), e.hideLoading(), n();
                                }
                            });
                        });
                    },
                    getList: function(t) {
                        var o, n, i = this;
                        o = t.latitude.toString(), n = t.longitude.toString(), e.request({
                            header: {
                                "Content-Type": "application/text"
                            },
                            url: "https://apis.map.qq.com/ws/geocoder/v1/?location=" + o + "," + n + "&key=WR5BZ-7XBCI-JJBGM-5WIGM-6E4V6-XRF6I",
                            success: function(e) {
                                200 === e.statusCode ? (console.log("获取中文街道地理位置成功"), i.cityvalue = [ e.data.result.ad_info.province, e.data.result.ad_info.city ], 
                                i.form.area = [], i.cityvalue.map(function(e, t) {
                                    return 0 == t ? i.form.area.push(a.default.province.filter(function(t) {
                                        return t[1] == e;
                                    })[0][0]) : 1 == t ? i.form.area.push(a.default.city.filter(function(t) {
                                        return t[1] == e;
                                    })[0][0]) : void 0;
                                })) : console.log("获取信息失败，请重试！");
                            },
                            fail: function() {
                                e.showToast({
                                    title: "您拒绝了授权，请在右上角设置中打开地理位置授权",
                                    icon: "none"
                                }), console.log("你拒绝了授权，无法获得周边信息");
                            }
                        });
                    },
                    getLocation: function() {
                        var t = this;
                        e.getLocation({
                            type: "gcj02",
                            success: function(o) {
                                var n, i;
                                e.showLoading({
                                    title: "正在获取位置"
                                }), console.log(o), n = o.latitude.toString(), i = o.longitude.toString(), e.request({
                                    header: {
                                        "Content-Type": "application/text"
                                    },
                                    url: "https://apis.map.qq.com/ws/geocoder/v1/?location=" + n + "," + i + "&key=WR5BZ-7XBCI-JJBGM-5WIGM-6E4V6-XRF6I",
                                    success: function(e) {
                                        200 === e.statusCode ? (console.log("获取中文街道地理位置成功"), t.cityvalue = [ e.data.result.ad_info.province, e.data.result.ad_info.city ], 
                                        t.form.area = [], t.cityvalue.map(function(e, o) {
                                            return 0 == o ? t.form.area.push(a.default.province.filter(function(t) {
                                                return t[1] == e;
                                            })[0][0]) : 1 == o ? t.form.area.push(a.default.city.filter(function(t) {
                                                return t[1] == e;
                                            })[0][0]) : void 0;
                                        })) : console.log("获取信息失败，请重试！");
                                    },
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            },
                            fail: function() {
                                e.showToast({
                                    title: "您拒绝了授权，请在右上角设置中打开地理位置授权",
                                    icon: "none"
                                }), console.log("你拒绝了授权，无法获得周边信息");
                            }
                        });
                    },
                    gophone: function(t) {
                        if ("other" == t) {
                            if (!this.isdisabled || 1 != this.isdisabled) return !1;
                            e.showToast({
                                title: "如需修改，请致电客服热线400-820-7917更改",
                                icon: "none",
                                duration: 3e3
                            });
                        } else e.showToast({
                            title: "如需修改，请致电客服热线400-820-7917更改",
                            icon: "none",
                            duration: 3e3
                        });
                    },
                    goclose: function() {
                        this.showphone = !1;
                    },
                    doSaveLast: function() {
                        var t = this, o = this.form, n = o.fullName, a = o.genderCode, s = o.birthDate, l = o.detailAddress, c = o.email, d = this;
                        r.default.info({
                            idType: 1,
                            id: e.getStorageSync("socialhubId"),
                            unionId: e.getStorageSync("unionId"),
                            fullName: n,
                            genderCode: Number(a),
                            birthDate: s,
                            provinceCode: this.form.area[0],
                            provinceName: this.cityvalue[0],
                            cityCode: this.form.area[1],
                            cityName: this.cityvalue[1],
                            ageType: 1 == this.userYear14 ? 0 : 1,
                            detailAddress: l,
                            email: c
                        }).then(function(o) {
                            0 == o.resultCode ? (getApp().hxt.sendAction("correct_profilesave", {
                                name: n,
                                city: t.cityvalue[0] + "" + t.cityvalue[1],
                                address: l,
                                email: c
                            }), i.default.getmember({
                                idType: "1",
                                id: e.getStorageSync("socialhubId")
                            }).then(function(t) {
                                e.setStorageSync("logininfo", t.data), d.$store.commit("userinfo", t.data), d.doSaveModel = !1, 
                                d.userYear14 = !0, setTimeout(function() {
                                    e.showToast({
                                        title: "更新成功"
                                    });
                                }, 800);
                            })) : (t.doSaveModel = !1, e.showToast({
                                title: "更新失败，请稍后重试",
                                icon: "none"
                            }));
                        });
                    },
                    doSave: function() {
                        this.form.fullName ? !this.form.email || /\@/g.test(this.form.email) ? this.userYear14 ? this.doSaveLast() : this.doSaveModel = !0 : e.showToast({
                            title: "邮箱格式不正确",
                            icon: "none"
                        }) : e.showToast({
                            title: "姓名不能为空",
                            icon: "none"
                        });
                    }
                }
            });
            t.default = c;
        }).call(this, o("543d").default);
    },
    3157: function(e, t, o) {
        o.r(t);
        var n = o("2456"), i = o.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(a);
        t.default = i.a;
    },
    "8bda": function(e, t, o) {
        var n = o("af25");
        o.n(n).a;
    },
    af25: function(e, t, o) {},
    c823: function(e, t, o) {
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {});
        var n = function() {
            var e = this, t = (e.$createElement, e._self._c, new Date(1990, 0, 1).getTime());
            e._isMounted || (e.e0 = function(t) {
                e.userYear14 ? e.gophone() : e.birthDate();
            }, e.e1 = function(t) {
                e.dateShow = !1;
            }, e.e2 = function(t) {
                e.dateShow = !1;
            }, e.e3 = function(t) {
                e.showModel = !1;
            }, e.e4 = function(t) {
                e.doSaveModel = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: t
                }
            });
        }, i = [];
    },
    f11c: function(e, t, o) {
        o.r(t);
        var n = o("c823"), i = o("3157");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            o.d(t, e, function() {
                return i[e];
            });
        }(a);
        o("8bda");
        var r = o("f0c5"), s = Object(r.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = s.exports;
    }
}, [ [ "1567", "common/runtime", "common/vendor" ] ] ]);