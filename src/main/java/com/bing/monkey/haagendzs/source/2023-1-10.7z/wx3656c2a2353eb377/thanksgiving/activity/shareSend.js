// thanksgiving/activity/shareSend.js
Page({data: {}})