// winterActivity/cnyshare/turnGet.js
Page({data: {}})