// summerEvaluate/exchangeActivity/turnGet.js
Page({data: {}})