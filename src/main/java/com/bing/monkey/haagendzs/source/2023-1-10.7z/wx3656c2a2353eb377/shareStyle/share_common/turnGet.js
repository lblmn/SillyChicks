// shareStyle/share_common/turnGet.js
Page({data: {}})