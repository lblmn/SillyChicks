(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/luckbag/turnIndex" ], {
    "02ae": function(e, o, n) {
        (function(e) {
            var o = n("4ea4");
            n("a1ea"), o(n("66fd"));
            var t = o(n("8313"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    "0deb": function(e, o, n) {
        n.r(o);
        var t = n("d561"), a = n.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(i);
        o.default = a.a;
    },
    "1b9c": function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return a;
        }), n.d(o, "a", function() {});
        var t = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(o) {
                e.isShowSharePopup2 = !1;
            }, e.e1 = function(o) {
                e.isShowSharePopup3 = !1;
            });
        }, a = [];
    },
    8313: function(e, o, n) {
        n.r(o);
        var t = n("1b9c"), a = n("0deb");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(o, e, function() {
                return a[e];
            });
        }(i);
        n("b53e");
        var u = n("f0c5"), r = Object(u.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = r.exports;
    },
    b53e: function(e, o, n) {
        var t = n("e784");
        n.n(t).a;
    },
    d561: function(e, o, n) {
        (function(e) {
            var t = n("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a = t(n("3724")), i = t(n("f3d4")), u = t(n("9296")), r = (getApp(), {
                data: function() {
                    return {
                        placeholderInfo: "在此输入您的圣诞祝福",
                        textareaValue: "",
                        userName: "",
                        imgUrl: i.default.assetsRoot,
                        isshare: !0,
                        isShowSharePopup: !1,
                        isShowSharePopup2: !1,
                        isShowSharePopup3: !1,
                        helpinfo: "",
                        helpinfo2: "",
                        imgBase: i.default.assetsRoot + "/oss/evaluation/"
                    };
                },
                onLoad: function(o) {
                    this.couponCode = o.couponCode, console.log(this.couponCode), this.userName = e.getStorageSync("logininfo").fullName, 
                    console.log(this.userName), console.log(o.detailinfo), this.detailInfo = o.detailinfo ? JSON.parse(decodeURIComponent(o.detailinfo)) : "", 
                    console.log(this.detailInfo);
                },
                onShow: function() {
                    e.getStorageSync("shareback") && (this.isshare = !1, this.isShowSharePopup = !1, 
                    this.isShowSharePopup2 = !1, this.helpinfo = "", this.helpinfo2 = "", this.isShowSharePopup3 = !0, 
                    e.removeStorageSync("shareback"));
                },
                destroyed: function() {},
                methods: {
                    textareaValueFun: function(e) {
                        console.log(e), this.textareaValue = e.detail.value;
                    },
                    cancelFun: function() {
                        var o = this, n = e.getStorageSync("logininfo").socialhubId;
                        a.default.ebuyCancelTransfer({
                            openid: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId"),
                            socialHubid: n,
                            couponKey: this.textid
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (o.isshare = !0, o.isShowSharePopup = !1, o.isShowSharePopup2 = !0, 
                            o.helpinfo2 = "取消转赠成功\n该券已可以使用\n请去【我的券包】") : (o.isShowSharePopup2 = !0, o.helpinfo2 = "取消转赠失败");
                        });
                    },
                    sendCard: function() {
                        var o = this;
                        console.log(this.textareaValue);
                        var n = e.getStorageSync("logininfo").socialhubId;
                        a.default.ebuyDeliverTransfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            couponCode: this.couponCode,
                            socialHubid: n,
                            remark: "" == this.textareaValue ? "邀请您来哈根达斯体验哦~" : this.textareaValue
                        }).then(function(e) {
                            console.log(e.code), 0 == e.code ? (o.textid = e.data, o.isshare = !1, o.isShowSharePopup = !0, 
                            o.helpinfo = "提交成功\n请点分享将券转赠给指定好友") : (o.isShowSharePopup2 = !0, o.helpinfo2 = "提交失败\n请稍后重试");
                        });
                    }
                },
                onShareAppMessage: function(o) {
                    e.setStorageSync("shareback", !0);
                    var n = "叮，您有一份来自好友的圣诞缤纷好礼", t = "".concat(i.default.assetsRoot, "/oss/wxapp/112/luckShare.png");
                    if (this.detailInfo.forwardTitle && (n = this.detailInfo.forwardTitle), this.detailInfo.forwardPictureUrl && (t = "".concat(i.default.assetsRoot) + this.detailInfo.forwardPictureUrl), 
                    u.default.shareRecord({
                        aid: "",
                        unionId: e.getStorageSync("unionId"),
                        openid: e.getStorageSync("openId"),
                        path: "pages/luckbag/turnIndex",
                        button: "",
                        invitedOpenid: "",
                        type: "1"
                    }).then(function(e) {
                        console.log(e);
                    }).catch(function(e) {
                        console.log(e);
                    }), console.log("pages/luckbag/turnGet?textid=".concat(this.textid)), "button" === o.from) return {
                        title: n,
                        path: "pages/luckbag/turnGet?textid=".concat(this.textid),
                        imageUrl: t
                    };
                }
            });
            o.default = r;
        }).call(this, n("543d").default);
    },
    e784: function(e, o, n) {}
}, [ [ "02ae", "common/runtime", "common/vendor" ] ] ]);