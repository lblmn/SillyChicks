// pureFeeling/machine/index.js
Page({data: {}})