// pureFeeling/hdShare/turnIndex.js
Page({data: {}})