// moonActive/middle/index.js
Page({data: {}})