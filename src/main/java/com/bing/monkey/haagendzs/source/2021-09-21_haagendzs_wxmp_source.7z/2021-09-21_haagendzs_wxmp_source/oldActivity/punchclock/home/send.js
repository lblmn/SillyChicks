// oldActivity/punchclock/home/send.js
Page({data: {}})