// ebuyCard/qwShopCode/index.js
Page({data: {}})