(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/CNYactivity/turnIndex" ], {
    "03a1": function(e, t, o) {
        o.r(t);
        var n = o("b200"), a = o.n(n);
        for (var i in n) "default" !== i && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(i);
        t.default = a.a;
    },
    "1ae4": function(e, t, o) {
        o.r(t);
        var n = o("3b4a"), a = o("03a1");
        for (var i in a) "default" !== i && function(e) {
            o.d(t, e, function() {
                return a[e];
            });
        }(i);
        o("d171");
        var r = o("f0c5"), s = Object(r.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = s.exports;
    },
    "3b4a": function(e, t, o) {
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return a;
        }), o.d(t, "a", function() {});
        var n = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.isShowSharePopup2 = !1;
            }, e.e1 = function(t) {
                e.isShowSharePopup3 = !1;
            });
        }, a = [];
    },
    "610a": function(e, t, o) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            o("c0e2"), t(o("66fd")), e(t(o("1ae4")).default);
        }).call(this, o("543d").createPage);
    },
    b200: function(e, t, o) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = r(o("2fa1")), a = r(o("f0fd")), i = r(o("500b"));
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            getApp();
            var s = {
                data: function() {
                    return {
                        placeholderInfo: "在此输入您的新年祝福",
                        textareaValue: "",
                        userName: "",
                        imgUrl: a.default.assetsRoot,
                        isshare: !0,
                        isShowSharePopup: !1,
                        isShowSharePopup2: !1,
                        isShowSharePopup3: !1,
                        helpinfo: "",
                        helpinfo2: "",
                        activityType: "",
                        isLovePink: !1,
                        isLoveGold: !1,
                        imgurl: a.default.assetsRoot + "/oss/wxapp/20210127/static"
                    };
                },
                onLoad: function(t) {
                    this.couponCode = t.couponCode, this.activityType = t.activityType, this.detailInfo = JSON.parse(decodeURIComponent(t.detailinfo));
                    var o = "#48080f";
                    "newYearType" == this.activityType ? this.placeholderInfo = "在此输入您的新年利是封" : "lovePink" == this.activityType ? (o = "#e5848d", 
                    this.placeholderInfo = "在此输入您的情人节祝福", this.isLovePink = !0) : "loveGolden" == this.activityType && (this.placeholderInfo = "在此输入您的情人节祝福", 
                    o = "#caa684", this.isLoveGold = !0), e.setNavigationBarColor({
                        frontColor: "#ffffff",
                        backgroundColor: o,
                        animation: {
                            duration: 400,
                            timingFunc: "easeIn"
                        }
                    }), this.userName = e.getStorageSync("logininfo").fullName;
                },
                onShow: function() {
                    e.getStorageSync("shareback") && (this.isshare = !1, this.isShowSharePopup = !1, 
                    this.isShowSharePopup2 = !1, this.helpinfo = "", this.helpinfo2 = "", this.isShowSharePopup3 = !0, 
                    e.removeStorageSync("shareback"));
                },
                destroyed: function() {},
                methods: {
                    textareaValueFun: function(e) {
                        console.log(e), this.textareaValue = e.detail.value;
                    },
                    cancelFun: function() {
                        var t = this;
                        n.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "2",
                            remark: this.textareaValue
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (t.isshare = !0, t.isShowSharePopup = !1, t.isShowSharePopup2 = !0, 
                            t.helpinfo2 = "取消转赠成功\n该券已可以使用\n请去【我的券包】") : (t.isShowSharePopup2 = !0, t.helpinfo2 = "取消转赠失败");
                        });
                    },
                    sendCard: function() {
                        var t = this;
                        console.log(this.textareaValue), n.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "1",
                            remark: "" == this.textareaValue ? "邀请你来哈根达斯体验哦~" : this.textareaValue
                        }).then(function(e) {
                            console.log(e.code), 0 == e.code ? (t.textid = e.data, t.isshare = !1, t.isShowSharePopup = !0, 
                            t.helpinfo = "提交成功\n请点分享将券转赠给指定好友") : (t.isShowSharePopup2 = !0, t.helpinfo2 = "提交失败\n请稍后重试");
                        });
                    }
                },
                onShareAppMessage: function(t) {
                    e.setStorageSync("shareback", !0);
                    var o = "", n = "";
                    if ("newYearType" == this.activityType ? (o = "叮，您有一份来自好友的新年利是封好礼", n = "".concat(a.default.assetsRoot, "/oss/wxapp/201210/CNYshare.jpg")) : "lovePink" == this.activityType ? (o = "叮，您有一份来自好友的情人节好礼", 
                    n = this.imgurl + "/loveAct/lovePink.png") : "loveGolden" == this.activityType ? (o = "叮，您有一份来自好友的情人节好礼", 
                    n = this.imgurl + "/loveAct/loveGolden.png") : (o = "叮，您有一份来自好友的新年福袋好礼", n = "".concat(a.default.assetsRoot, "/oss/wxapp/201210/CNYshare.jpg")), 
                    this.detailInfo.forwardTitle && (o = this.detailInfo.forwardTitle), this.detailInfo.forwardPictureUrl && (n = "".concat(a.default.assetsRoot) + this.detailInfo.forwardPictureUrl), 
                    i.default.shareRecord({
                        aid: "",
                        unionId: e.getStorageSync("unionId"),
                        openid: e.getStorageSync("openId"),
                        path: "pages/CNYactivity/turnIndex",
                        button: "",
                        invitedOpenid: "",
                        type: "1"
                    }).then(function(e) {
                        console.log(e);
                    }).catch(function(e) {
                        console.log(e);
                    }), console.log("pages/CNYactivity/turnGet?textid=".concat(this.textid)), "button" === t.from) return {
                        title: o,
                        path: "pages/CNYactivity/turnGet?textid=".concat(this.textid, "&activityType=").concat(this.activityType),
                        imageUrl: n
                    };
                }
            };
            t.default = s;
        }).call(this, o("543d").default);
    },
    d171: function(e, t, o) {
        var n = o("ddb6");
        o.n(n).a;
    },
    ddb6: function(e, t, o) {}
}, [ [ "610a", "common/runtime", "common/vendor" ] ] ]);