(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/breakfast/breakfast" ], {
    "0730": function(n, o, e) {
        e.d(o, "b", function() {
            return t;
        }), e.d(o, "c", function() {
            return a;
        }), e.d(o, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(o) {
                n.showFlag = !1;
            }, n.e1 = function(o) {
                n.showFlag = !1;
            });
        }, a = [];
    },
    "1a83": function(n, o, e) {},
    a635: function(n, o, e) {
        e.r(o);
        var t = e("f632"), a = e.n(t);
        for (var i in t) "default" !== i && function(n) {
            e.d(o, n, function() {
                return t[n];
            });
        }(i);
        o.default = a.a;
    },
    bb07: function(n, o, e) {
        (function(n) {
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("f4aa"), o(e("66fd")), n(o(e("e8d1")).default);
        }).call(this, e("543d").createPage);
    },
    ca79: function(n, o, e) {
        var t = e("1a83");
        e.n(t).a;
    },
    e8d1: function(n, o, e) {
        e.r(o);
        var t = e("0730"), a = e("a635");
        for (var i in a) "default" !== i && function(n) {
            e.d(o, n, function() {
                return a[n];
            });
        }(i);
        e("ca79");
        var c = e("f0c5"), u = Object(c.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = u.exports;
    },
    f632: function(n, o, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var a = t(e("6d2b")), i = t(e("a5d3")), c = getApp().globalData.N_ENV.assetsRoot, u = {
                name: "breakfast",
                components: {
                    loginDialog: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/loginDialog") ]).then(function() {
                            return resolve(e("a81e"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        showFlag: !1,
                        errorMsg: "",
                        couponObj: {},
                        hasReceive: !1,
                        peituSrc: "",
                        showloginDialog: !1
                    };
                },
                onLoad: function(n) {
                    this.getList(), this.peituSrc = c + "/oss/wxapp/zaocan3.png";
                },
                onShow: function() {
                    console.log("breakfast omshow"), this.showloginDialog = !0;
                },
                onHide: function() {
                    this.showloginDialog = !1;
                },
                methods: {
                    getList: function() {
                        var o = this;
                        return new Promise(function(e, t) {
                            a.default.getList({
                                channel: 3,
                                offset: 0,
                                limit: 500
                            }).then(function(t) {
                                0 == t.code ? (o.couponObj = t.data[0], e(t.data[0])) : n.showToast({
                                    title: "获取券id请求异常请稍后重试",
                                    icon: "none"
                                });
                            });
                        });
                    },
                    receiveCoupon: function() {
                        var o = this;
                        this.hasReceive || i.default.exchange({
                            id: this.couponObj.id,
                            unionId: n.getStorageSync("unionId"),
                            channel: this.couponObj.channel,
                            openId: n.getStorageSync("openId")
                        }).then(function(n) {
                            o.errorMsg = n.msg.replace(/-/g, "<br>"), o.showFlag = !0, 0 == n.code && (o.hasReceive = !0);
                        });
                    }
                }
            };
            o.default = u;
        }).call(this, e("543d").default);
    }
}, [ [ "bb07", "common/runtime", "common/vendor" ] ] ]);