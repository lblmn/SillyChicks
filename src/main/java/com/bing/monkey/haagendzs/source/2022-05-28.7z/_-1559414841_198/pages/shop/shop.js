(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/shop/shop" ], {
    "0343": function(t, e, n) {
        (function(t) {
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            n("c0e2"), e(n("66fd")), t(e(n("40281")).default);
        }).call(this, n("543d").createPage);
    },
    "315f": function(t, e, n) {},
    3510: function(t, e, n) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0, u(n("c344"));
            var o = u(n("c1f6")), i = (u(n("500b")), u(n("6bd2"))), a = u(n("234f")), s = u(n("f0fd")), c = u(n("f3d6")), r = n("26cb");
            function u(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function l(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function h(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? l(Object(n), !0).forEach(function(e) {
                        d(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function d(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            var f = getApp(), p = f.globalData.N_ENV.assetsRoot, g = {
                name: "shop",
                components: {
                    Zcard: function() {
                        n.e("components/Zcard").then(function() {
                            return resolve(n("38b2"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("3761"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    Loading: function() {
                        n.e("components/loading").then(function() {
                            return resolve(n("b1b4"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    headerimg: function() {
                        n.e("components/headerimg").then(function() {
                            return resolve(n("a806"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    var t;
                    return d(t = {
                        imgoss: s.default.ossurl + "images/home",
                        imgshop: s.default.ossurl + "UX/shop",
                        isGongGao: !0,
                        isHeightScreen: !1,
                        showType: 0,
                        searchValue: "",
                        tabs: [],
                        tabActive: "",
                        mainTabs: [ {
                            title: "积心兑好礼",
                            name: 0
                        }, {
                            title: "集豆兑好礼",
                            name: 1
                        } ],
                        mainTabActive: 0,
                        cardList: [],
                        offset: 0,
                        limit: 10,
                        noMore: !1,
                        channel: 1,
                        ruleDesc: "",
                        showloginDialog: !1,
                        pointAccount: 0,
                        PointJidou: 0,
                        deadHeart: 0,
                        deadBean: 0,
                        remberActive: ""
                    }, "ruleDesc", "<p><b>积心规则</b></p><p>消费1元积1心，积心当天到账</p><p><br/></p><p><b>积心有效期</b></p><p>自该笔积心获得当日起1年内有效，每笔积心有效期单独计算。例:2020年6月1日获得的积心将在2021年5月31日到期。积心有效期不会因会籍的升降而受到影响。</p><p><br/></p><p><b>积心条件</b></p><p>在哈根达斯门店或线上点单小程序，出示会员身份后，使用现金、银行卡、支付宝、微信支付方式所进行的购买可实时获得积心；</p><p>通过官方合作的第三方平台（如哈根达斯天猫旗舰店、美团团购、大众点评等）以会员身份购买的电子券，到店使用时出示会员码后的1~3个工作日内积心到账；</p><p>在积心商城“积心+现金”兑购产品时，支付现金部分皆不可参与积心；</p><p>尊礼卡、代金券、月饼提领券（含电子兑换券/纸质兑换券）到门店或提领点核销使用均不能累积（获得）积心。（因尊礼卡、代金券购买时已获得积心、月饼提领券为特殊商品，购买时已享受对应优惠或获得积心，故核销时不能累计获得积心）。</p><p><br/></p><p><b>积心兑换规则</b></p><p>在积心商城选择兑换产品，选择兑换数量并提交，兑换成功后电子券将发放至 “我的券包”。</p><p>如选择的兑换产品需支付现金，兑换提交且支付成功后，兑换成功后电子券将发放至 “我的券包”。</p><p>在积心商城兑换的电子券一旦兑换成功，不予退换。</p><p>电子兑换券（除月饼冰淇淋电子券）适用于中国大陆地区哈根达斯冰淇淋专卖店（机场店，高铁店，景点店，联营店除外）。</p><p>所有电子券兑换码为唯一码且仅限使用一次，请在有效期内使用，过期视为自动放弃。</p><p><br/></p><p><b>当季月饼冰淇淋兑换注意事项</b></p><p>月饼冰淇淋兑换券一经选择电子券提领或纸质券提领，无法变更；</p><p>月饼冰淇淋兑换券一经兑换，不退不换；</p><p>部分地区不参与，请先参考兑换详情对应规则；</p><p>月饼冰淇淋兑换券可由用户在积心+现金兑购时自行选择电子兑换券或者纸质兑换券，若选择电子兑换券，将会于兑购成功后发放至“我的券包”；</p><p>如需兑购纸质兑换券，务必在填写收货信息时正确填写地址及联系方式，并自行支付寄送物流费（上海市内10元，其他省市地区20元，同一用户一天内下单同一收货地址将只收取一次运费）；品牌将于5-10个工作日内安排寄送纸质兑换券，届时请自行关注物流信息，无法加急；纸质券数量有限，先到先得；</p><p>若因联系方式或地址填写错误导致的丢件或寄送失败，品牌将不予安排补发；</p><p>纸质券提领城市默认上海，若需变更提领地点，请在兑换后前往哈根达斯公众号-月饼专区-异地换券进行变更提领城市处理；异地换券需在9/14前完成；</p><p>需凭相应电子或纸质兑换券在有效期内至指定城市指定提领点进行兑换（具体提领信息可参见“哈根达斯”微信公众号-“月饼专区”-“月饼|提领点查询”）；</p><p>在积心商城“积心+现金”兑购月饼冰淇淋兑换券时，每个系列上限20套；</p><p>购买月饼冰淇淋若需开票请联系客服-会员热线：400-820-7917；</p><p>具体兑换规则见券面详情。</p><p><br/></p>"), 
                    d(t, "noScroll", !1), d(t, "showbuild", !1), d(t, "tabFrom", ""), d(t, "ruleDesc_a", ""), 
                    d(t, "showbuild_a", !1), d(t, "showIcon", !0), d(t, "aid_a", ""), d(t, "showIcon_btn", !1), 
                    d(t, "isHasHeadimg", !1), d(t, "widthXP", 0), t;
                },
                onLoad: function(t) {
                    var e = this;
                    a.default.isHeightPhone().then(function(t) {
                        e.isHeightScreen = t;
                    }).catch(function(t) {
                        e.isHeightScreen = t;
                    }), a.default.setSource(t);
                    var n = t.tabFrom ? t.tabFrom : "pointA";
                    this.tabFrom = n, "pointA" == n ? (this.tabActive = 1, this.remberActive = 1) : "pointB" == n ? (this.tabActive = 2, 
                    this.remberActive = 2) : "pointC" == n && (this.tabActive = 3, this.remberActive = 3), 
                    this.getGiftCategory();
                },
                onShow: function() {
                    var e = this;
                    if (t.getBackgroundAudioManager().stop(), this.$refs.Loading.showLoading(), Object.keys(t.getStorageSync("logininfo")).length > 0) {
                        this.getPoint().then(function(t) {
                            e.$refs.Loading.hideLoading();
                        }).catch(function() {
                            e.$refs.Loading.hideLoading();
                        }), this.$store.dispatch("existsSignIn"), a.default.recordPv(), this.getRecord(), 
                        getApp().hxt.sendAction("pointmall_clk");
                        var n = new Date(), o = a.default.dateFormat("YYYY-mm-dd", n);
                        a.default.timeDiffAll(o, "2022-01-11", "2022-02-06") ? this.showIcon_btn = !0 : this.showIcon_btn = !1;
                    } else this.showloginDialog = !0;
                },
                computed: h(h({}, (0, r.mapState)([ "points", "nextMonthExpiredPoints", "userinfo", "wxuserinfoAvatar", "signInCount" ])), (0, 
                r.mapGetters)([ "userinfoBg", "userinfoType", "signInCountNum", "signAgain" ])),
                onHide: function() {
                    this.showFlag = !1, this.showObtain = !1;
                },
                methods: h(h({}, (0, r.mapActions)([ "getPoint" ])), {}, {
                    beginAct: function() {
                        var e = this;
                        t.getBackgroundAudioManager().stop(), this.$refs.Loading.showLoading(), Object.keys(t.getStorageSync("logininfo")).length > 0 ? (this.getPoint().then(function(t) {
                            console.log(t), e.$refs.Loading.hideLoading();
                        }).catch(function() {
                            e.$refs.Loading.hideLoading();
                        }), a.default.recordPv(), this.getRecord()) : this.showloginDialog = !0;
                    },
                    gongGao: function() {
                        var t = this;
                        c.default.switches().then(function(e) {
                            console.log(e), 0 == e.code ? t.isGongGao = !0 : 500 == e.code && (t.isGongGao = !1, 
                            t.beginAct());
                        });
                    },
                    showRule: function() {
                        this.showbuild = !0, this.noScroll = !0;
                    },
                    buildhide: function() {
                        this.showbuild = !1, this.noScroll = !1;
                    },
                    buildhide_a: function() {
                        this.showbuild_a = !1, this.noScroll = !1;
                    },
                    userInfoSuccess: function(e) {
                        "all" == e && (this.$store.dispatch("existsSignIn"), this.getRecord(), a.default.recordPv(), 
                        getApp().hxt.sendAction("pointmall_clk"), t.removeStorageSync("successInfo"), this.$refs.Loading.hideLoading());
                    },
                    gotoAtten: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 7;
                        t.navigateTo({
                            url: "../attendance/attendance?from=shop"
                        }), console.log(e);
                    },
                    getRecord: function() {
                        i.default.saveLoginRecord({
                            unionId: t.getStorageSync("unionId"),
                            openId: t.getStorageSync("openId"),
                            source: t.getStorageSync("smsSource")
                        }).then(function(t) {
                            console.log(t);
                        });
                    },
                    getGiftCategory: function() {
                        var e = this;
                        o.default.sortList().then(function(n) {
                            console.log(n), 0 == n.code ? (e.tabs = n.data, e.getList()) : t.showToast({
                                title: "类别获取失败",
                                icon: "none"
                            });
                        });
                    },
                    getList: function() {
                        var e, n = this;
                        e = 0 == this.showType ? {
                            channel: this.channel,
                            offset: this.offset,
                            limit: this.limit,
                            pointGearId: this.tabActive,
                            unionId: t.getStorageSync("unionId")
                        } : {
                            channel: this.channel,
                            offset: this.offset,
                            limit: this.limit
                        }, o.default.getList(e).then(function(e) {
                            t.hideLoading(), 0 == e.code ? (0 == e.data.length && (n.noMore = !0), e.data.forEach(function(t) {
                                n.cardList.push(h(h({}, t), {}, {
                                    name: t.giftName,
                                    imgUrl: p + t.couponPicUrl,
                                    descObj: {
                                        ruleCount: (null == t ? void 0 : t.ruleCount) > 1 ? t.ruleCount : "",
                                        dec: t.requiredPoints,
                                        type: 0 == n.showType ? "积心" : "集豆",
                                        price: t.requiredAmount > 0 ? "".concat(t.requiredAmount) : ""
                                    },
                                    subname: t.subName,
                                    time: "".concat(n.$util.dateFormat("YYYY年mm月dd日", new Date(t.startTime.replace(/-/g, "/"))), "- ").concat(n.$util.dateFormat("YYYY年mm月dd日", new Date(t.endTime.replace(/-/g, "/"))))
                                }));
                            }), n.$refs.Loading.hideLoading()) : (n.$refs.Loading.hideLoading(), t.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }));
                        }).catch(function() {
                            n.$refs.Loading.hideLoading(), t.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    docheck: function(e) {
                        console.log(e);
                        var n = e.couponRuleId;
                        f.hxt.sendAction("couponkv_clk", {
                            coupon_id: e.id,
                            coupon_account: e.requiredPoints + "积分" + (e.requiredAmount > 0 ? e.requiredAmount + "元" : ""),
                            coupon_name: e.giftName
                        }), t.navigateTo({
                            url: "/pages/newCoupondetail/index?couponRuleId=" + n
                        });
                    },
                    getRuleDesc: function() {
                        var t = this;
                        o.default.getRuledesc({
                            type: 2
                        }).then(function(e) {
                            t.ruleDesc = e.data[0].content;
                        });
                    },
                    getRuleDesc_a: function() {
                        t.reLaunch({
                            url: "/winterActivity/home/index?fromSourceType=shop"
                        });
                    },
                    onChangeMain: function(t) {
                        this.$refs.Loading.showLoading(), console.log("主页切换"), this.mainTabActive = t.detail.name, 
                        this.showType = t.detail.index, this.channel = 0 == t.detail.index ? 1 : 2, console.log("channel", this.channel), 
                        this.cardList = [], this.offset = 0, this.noMore = !1, 0 == this.showType && (this.tabActive = this.remberActive), 
                        this.getList();
                    },
                    onChange: function(t) {
                        console.log("内页切换"), this.$refs.Loading.showLoading(), this.searchValue = "", this.cardList = [], 
                        this.offset = 0, this.noMore = !1, this.tabActive = t.detail.name, this.getList();
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (this.$refs.Loading.showLoading(), this.offset = this.offset + this.limit, 
                        this.getList());
                    },
                    gotoRecords: function() {
                        0 == this.showType ? t.navigateTo({
                            url: "/pages/mine/heart"
                        }) : 1 == this.showType && t.navigateTo({
                            url: "/pages/coffee/jidou"
                        });
                    },
                    gosign: function() {
                        this.showObtain = !1, t.navigateTo({
                            url: "/pages/attendance/attendance"
                        });
                    }
                }),
                onShareAppMessage: function(t) {
                    var e = new Date("2021/9/21 23:59:59").valueOf(), n = new Date().valueOf();
                    console.log(e, n);
                    var o = "月饼冰淇淋会员独享限时福利购~", i = "pages/shop/shop?channelLabel=Points-mall&source=Points-mall&tabFrom=" + this.tabFrom, a = "".concat(s.default.ossurl, "/images/home/shop.jpg");
                    return n > e && (o = "哈根达斯会员中心小程序", a = "".concat(s.default.assetsRoot, "/oss/wxapp/miniprogram.jpg")), 
                    console.log(i), {
                        title: o,
                        path: i,
                        imageUrl: a
                    };
                }
            };
            e.default = g;
        }).call(this, n("543d").default);
    },
    40281: function(t, e, n) {
        n.r(e);
        var o = n("8abc"), i = n("d096");
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        n("ac09");
        var s = n("f0c5"), c = Object(s.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = c.exports;
    },
    "8abc": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    ac09: function(t, e, n) {
        var o = n("315f");
        n.n(o).a;
    },
    d096: function(t, e, n) {
        n.r(e);
        var o = n("3510"), i = n.n(o);
        for (var a in o) "default" !== a && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        e.default = i.a;
    }
}, [ [ "0343", "common/runtime", "common/vendor" ] ] ]);