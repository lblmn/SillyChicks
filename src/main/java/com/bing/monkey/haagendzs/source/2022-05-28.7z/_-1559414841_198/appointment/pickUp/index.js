// appointment/pickUp/index.js
Page({data: {}})