// moonActive/lifecycle/index.js
Page({data: {}})