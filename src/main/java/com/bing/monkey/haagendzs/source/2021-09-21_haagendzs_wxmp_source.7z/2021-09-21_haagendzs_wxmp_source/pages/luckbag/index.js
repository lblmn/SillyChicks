(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/luckbag/index" ], {
    "027d": function(e, o, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("f4aa"), o(n("66fd")), e(o(n("67ca")).default);
        }).call(this, n("543d").createPage);
    },
    "02f8": function(e, o, n) {
        n.r(o);
        var t = n("9719"), i = n.n(t);
        for (var c in t) "default" !== c && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(c);
        o.default = i.a;
    },
    "41ec": function(e, o, n) {},
    "67ca": function(e, o, n) {
        n.r(o);
        var t = n("b7b5"), i = n("02f8");
        for (var c in i) "default" !== c && function(e) {
            n.d(o, e, function() {
                return i[e];
            });
        }(c);
        n("b39c");
        var a = n("f0c5"), u = Object(a.a)(i.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = u.exports;
    },
    9719: function(e, o, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var i = t(n("9607")), c = t(n("11e1")), a = t(n("1328")), u = {
                data: function() {
                    return {
                        loading: !1,
                        showloginDialog: !1,
                        isShowSharePopup: !1,
                        helpinfo: "",
                        code: "",
                        imgUrl: a.default.assetsRoot,
                        checkCodeState: !1,
                        itemvalue: "selected",
                        checked: !0,
                        showrule: !1,
                        rulesinfo: ""
                    };
                },
                onLoad: function(o) {
                    this.aid = o.aid ? o.aid : "7", e.showLoading({
                        title: "数据加载中...",
                        mask: !0
                    });
                },
                onShow: function() {
                    this.showloginDialog = !0;
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("a81e"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                methods: {
                    closerule: function() {
                        this.checked = !0, this.showrule = !1;
                    },
                    checkboxChange: function(e) {
                        console.log(e), e.detail.value.length > 0 ? this.checked = !0 : this.checked = !1;
                    },
                    lineshowrule: function() {
                        var o = this;
                        console.log("显示规则"), i.default.activityGet(this.aid, {
                            unionId: e.getStorageSync("unionId")
                        }).then(function(n) {
                            console.log(n), 0 == n.code ? (o.rulesinfo = n.data.activity.ruleDesc.replace(/\n/g, "<br/>"), 
                            o.showrule = !0) : e.showToast({
                                title: "活动信息获取失败",
                                icon: "none"
                            });
                        });
                    },
                    loadOver: function() {
                        console.log("图片加载完成"), e.hideLoading();
                    },
                    inputValue: function(e) {
                        console.log(e);
                        var o = e.detail.value.replace(/[\u4e00-\u9fa5]/gi, "");
                        return this.code = o.trim(), o;
                    },
                    goIndex: function() {
                        e.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    closepopup: function() {
                        this.checkCodeState ? (this.isShowSharePopup = !1, e.redirectTo({
                            url: "/pages/mine/mycard"
                        })) : this.isShowSharePopup = !1;
                    },
                    checkCode: function() {
                        var o = this;
                        return "" == this.code ? (this.isShowSharePopup = !0, this.helpinfo = "请输入兑换券密码", 
                        !1) : this.checked ? void c.default.checkCode(this.aid, {
                            code: this.code,
                            openid: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            "401" == e.code ? (o.isShowSharePopup = !0, o.helpinfo = "活动暂未开启，敬请期待哦~") : "401002" == e.code ? (o.isShowSharePopup = !0, 
                            o.helpinfo = "该码已被使用\n请勿重复领取") : "401001" == e.code ? (o.isShowSharePopup = !0, 
                            o.helpinfo = "密码不正确\n请重新输入") : 0 == e.code ? (o.checkCodeState = !0, o.isShowSharePopup = !0, 
                            o.helpinfo = '密码验证通过，电子产品兑换券已发送至"我的券包"，请点击查看') : (o.isShowSharePopup = !0, o.helpinfo = "密码不正确\n请重新输入");
                        }) : (this.isShowSharePopup = !0, this.helpinfo = "请阅读勾选兑换须知", !1);
                    }
                }
            };
            o.default = u;
        }).call(this, n("543d").default);
    },
    b39c: function(e, o, n) {
        var t = n("41ec");
        n.n(t).a;
    },
    b7b5: function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return i;
        }), n.d(o, "a", function() {});
        var t = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, i = [];
    }
}, [ [ "027d", "common/runtime", "common/vendor" ] ] ]);