// news/list/index.js
Page({data: {}})