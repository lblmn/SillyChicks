require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/mycard" ], {
    "0728": function(e, o, n) {
        var t = n("eeda");
        n.n(t).a;
    },
    "16b4": function(e, o, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("c0e2"), o(n("66fd")), e(o(n("be40")).default);
        }).call(this, n("543d").createPage);
    },
    "5a2a": function(e, o, n) {
        n.r(o);
        var t = n("e3b3"), i = n.n(t);
        for (var a in t) "default" !== a && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(a);
        o.default = i.a;
    },
    "640b": function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return i;
        }), n.d(o, "a", function() {});
        var t = function() {
            var e = this, o = (e.$createElement, e._self._c, 0 != e.indexs ? e.__map(e.tabs2, function(o, n) {
                return {
                    $orig: e.__get_orig(o),
                    l0: e.cardList.length > 0 || e.voucherList.length > 0 ? e.__map(e.cardList, function(o, n) {
                        return {
                            $orig: e.__get_orig(o),
                            m0: o.validStartTime ? e.formTime(o.validStartTime) : null,
                            m1: o.validStartTime ? e.formTime(o.validEndTime) : null
                        };
                    }) : null,
                    l1: e.cardList.length > 0 || e.voucherList.length > 0 ? e.__map(e.voucherList, function(o, n) {
                        return {
                            $orig: e.__get_orig(o),
                            m2: o.validStartTime ? e.formTime(o.validStartTime) : null,
                            m3: o.validStartTime ? e.formTime(o.validEndTime) : null
                        };
                    }) : null
                };
            }) : null);
            e.$mp.data = Object.assign({}, {
                $root: {
                    l2: o
                }
            });
        }, i = [];
    },
    be40: function(e, o, n) {
        n.r(o);
        var t = n("640b"), i = n("5a2a");
        for (var a in i) "default" !== a && function(e) {
            n.d(o, e, function() {
                return i[e];
            });
        }(a);
        n("0728");
        var c = n("f0c5"), d = Object(c.a)(i.default, t.b, t.c, !1, null, "45c82c02", null, !1, t.a, void 0);
        o.default = d.exports;
    },
    e3b3: function(e, o, n) {
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0, l(n("30c4"));
            var t = l(n("500b")), i = l(n("c1f6")), a = l(n("6bd2")), c = (l(n("727b")), l(n("2fa1"))), d = l(n("7d86")), r = l(n("f0fd")), s = l(n("234f")), u = l(n("f3d6"));
            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function g(e, o) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    o && (t = t.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), n.push.apply(n, t);
                }
                return n;
            }
            function f(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var n = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? g(Object(n), !0).forEach(function(o) {
                        p(e, o, n[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : g(Object(n)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(n, o));
                    });
                }
                return e;
            }
            function p(e, o, n) {
                return o in e ? Object.defineProperty(e, o, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[o] = n, e;
            }
            var h = getApp(), m = h.globalData.N_ENV.assetsRoot, v = {
                components: {
                    uniIcons: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(n("fafe"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("3761"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    Loading: function() {
                        n.e("components/loading").then(function() {
                            return resolve(n("b1b4"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        indexs: 0,
                        tabActive: 1e8,
                        tabs: [ {
                            name: 1e8,
                            title: "可使用"
                        }, {
                            name: 100000001,
                            title: "已使用"
                        }, {
                            name: 100000002,
                            title: "已过期/失效"
                        }, {
                            name: 100000007,
                            title: "券转赠"
                        } ],
                        tabActive2: 1e8,
                        tabs2: [ {
                            name: 1e8,
                            title: "可使用"
                        }, {
                            name: 100000001,
                            title: "已失效"
                        } ],
                        resultList: [],
                        nextId: "",
                        pageSize: 10,
                        noMore: !1,
                        isFirstNoChange: !0,
                        showloginDialog: !1,
                        cardList: [],
                        voucherList: [],
                        imgoss: r.default.ossurl + "images/home/",
                        isGongGao: !0,
                        isHeightScreen: !1
                    };
                },
                onLoad: function(o) {
                    var n = this;
                    console.log(o), s.default.isHeightPhone().then(function(e) {
                        n.isHeightScreen = e;
                    }).catch(function(e) {
                        n.isHeightScreen = e;
                    }), this.source = o.soure ? o.soure : o.source, e.setStorageSync("source", this.source), 
                    s.default.setSource(o), this.tabActive = o.tabActive ? +o.tabActive : 1e8, 1e8 != this.tabActive && (this.isFirstNoChange = !1), 
                    console.log("执行onLoad1");
                },
                onShow: function() {
                    this.nextId = "", this.resultList = [], "all" == e.getStorageSync("successInfo") && e.removeStorageSync("successInfo"), 
                    console.log("执行onshow1"), e.getStorageSync("logininfo") ? (s.default.recordPv(), 
                    getApp().hxt.sendAction("myvoucher_clk"), console.log("执行onshow2"), "Traffic-CD" == e.getStorageSync("smsSource") && "Traffic-CD" == e.getStorageSync("channelLabel") ? (console.log("进来了"), 
                    this.getFromCard()) : this.getCardList()) : (console.log("执行onshow3"), this.showloginDialog = !0);
                },
                methods: {
                    beginList: function() {
                        this.nextId = "", this.resultList = [], "all" == e.getStorageSync("successInfo") && e.removeStorageSync("successInfo"), 
                        console.log("执行onshow1"), e.getStorageSync("logininfo") ? (console.log("执行onshow2"), 
                        "Traffic-CD" == e.getStorageSync("smsSource") && "Traffic-CD" == e.getStorageSync("channelLabel") ? (console.log("进来了"), 
                        this.getFromCard()) : this.getCardList()) : (console.log("执行onshow3"), this.showloginDialog = !0);
                    },
                    gongGao: function() {
                        var e = this;
                        u.default.switches().then(function(o) {
                            console.log(o), 0 == o.code ? e.isGongGao = !0 : 500 == o.code && (e.isGongGao = !1, 
                            e.beginList());
                        });
                    },
                    gotoTl: function(o) {
                        var n = ("release" == r.default.envVersion ? "https://hd.rydeen.com.cn/coupon-booking/booking" : "https://hd-uat.rydeen.com.cn/coupon-booking/booking") + "?couponNo=" + o.couponCode;
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + encodeURIComponent(n)
                        });
                    },
                    getFromCard: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var n = new Date().getTime();
                        c.default.pyqCoupon({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            appId: "wx3656c2a2353eb377",
                            sign: s.default.mdString(n, {
                                unionId: e.getStorageSync("unionId"),
                                openId: e.getStorageSync("openId")
                            }),
                            timestamp: n
                        }).then(function(e) {
                            0 == e.code ? setTimeout(function() {
                                o.getCardList();
                            }, 1500) : o.getCardList();
                        }).catch(function() {
                            o.getCardList();
                        });
                    },
                    getCardList: function() {
                        100000007 == this.tabActive ? (console.log("这是转赠记录"), this.getList_records()) : this.getList(), 
                        e.getStorageSync("source") && this.getRecord();
                    },
                    gotoType: function(o) {
                        if (console.log(o), 1e8 != this.tabActive2) return !1;
                        if (o.canGogoMiniProgram) this.gotoMiniprogram(o); else if ("esc" == o.voucherSource) {
                            var n = o.templateUrl, t = encodeURIComponent(n);
                            if (!t) return !1;
                            e.navigateTo({
                                url: "/pages/webView/indexN?url=" + t
                            });
                        } else {
                            var i = o.templateUrl, a = encodeURIComponent(i);
                            if (!a) return !1;
                            e.navigateTo({
                                url: "/pages/webView/indexN?url=" + a
                            });
                        }
                    },
                    gotoMiniprogramBoth: function() {
                        e.navigateToMiniProgram({
                            appId: "wxf83dc13b5390d17b",
                            path: "pages/index/index",
                            success: function(e) {}
                        });
                    },
                    gotoMiniprogram: function(o) {
                        var n, t;
                        console.log(o);
                        var i = null === (n = o.voucherExtend.jumpInfo) || void 0 === n ? void 0 : n.jumpAppId, a = null === (t = o.voucherExtend.jumpInfo) || void 0 === t ? void 0 : t.jumpButtonParam;
                        e.navigateToMiniProgram({
                            appId: i,
                            path: a,
                            success: function(e) {}
                        });
                    },
                    gotoUrl: function(o) {
                        console.log(o);
                        var n = o.templateUrl, t = encodeURIComponent(n);
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + t
                        });
                    },
                    formTime: function(e) {
                        return e.substring(0, 8).replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");
                    },
                    onChange2: function(e) {
                        this.$refs.Loading.showLoading(), this.tabActive2 = e.detail.name, this.cardList = [], 
                        this.voucherList = [], this.getList_cards();
                    },
                    getList_cards: function() {
                        var o = this, n = {
                            socialhubId: e.getStorageSync("socialhubId"),
                            cardType: ""
                        };
                        100000001 == this.tabActive2 && (n = {
                            socialhubId: e.getStorageSync("socialhubId"),
                            cardType: "1"
                        }), d.default.getList(n).then(function(e) {
                            console.log("列表", e.resultCode), 0 == e.code && (0 == e.data.cardList.length && 0 == e.data.voucherList.length && (o.noMore = !0), 
                            o.cardList = e.data.cardList.map(function(e) {
                                var o = JSON.parse(e.voucherExtend).jumpInfo;
                                return console.log(JSON.parse(e.voucherExtend)), e.voucherExtend = JSON.parse(e.voucherExtend), 
                                (null == o ? void 0 : o.jumpAppId) && (null == o ? void 0 : o.jumpButtonType) ? e.canGogoMiniProgram = !0 : e.canGogoMiniProgram = !1, 
                                e;
                            }), o.voucherList = e.data.voucherList.map(function(e) {
                                var o = JSON.parse(e.voucherExtend).jumpInfo;
                                return console.log(JSON.parse(e.voucherExtend)), e.voucherExtend = JSON.parse(e.voucherExtend), 
                                (null == o ? void 0 : o.jumpAppId) && (null == o ? void 0 : o.jumpButtonType) ? e.canGogoMiniProgram = !0 : e.canGogoMiniProgram = !1, 
                                e;
                            }));
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    changeIndex: function(e) {
                        this.$refs.Loading.showLoading(), 0 == e ? (this.resultList = [], this.indexs = 0, 
                        this.tabActive = 1e8, this.nextId = "", this.getList()) : (this.indexs = 1, this.tabActive2 = 1e8, 
                        this.nextId = "", this.getList_cards());
                    },
                    getRecord: function() {
                        a.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: e.getStorageSync("source")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getList_records: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var n = {
                            idType: 1,
                            id: e.getStorageSync("socialhubId"),
                            flag: 0,
                            nextId: this.nextId,
                            pageSize: this.pageSize,
                            state: 0
                        };
                        "" == this.nextId && delete n.nextId, c.default.coupontransferlist(n).then(function(e) {
                            o.$refs.Loading.hideLoading(), console.log(e), 0 == e.resultCode && (e.data.nextId && (o.nextId = e.data.nextId), 
                            e.data.list && e.data.list.length > 0 && e.data.list.forEach(function(e) {
                                o.resultList.push(f(f({}, e), {}, {
                                    imgUrlAll: e.imgUrl ? m + e.imgUrl : m + "/oss/wxapp/small.jpg"
                                }));
                            }), e.data.nextId || (o.noMore = !0));
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    getList: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var n = {
                            idType: 1,
                            id: e.getStorageSync("logininfo").socialhubId,
                            state: this.tabActive,
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        };
                        "" == this.nextId && delete n.nextId, i.default.couponList(n).then(function(n) {
                            if (console.log("列表", n.resultCode), 0 == n.resultCode) {
                                if (n.data.nextId && (o.nextId = n.data.nextId), 0 == n.data.list.length) return void (o.noMore = !0);
                                n.data.list.forEach(function(e) {
                                    o.resultList.push(f(f({}, e), {}, {
                                        imgUrlAll: e.imgUrl ? m + e.imgUrl : m + "/oss/wxapp/small.jpg",
                                        validTime: e.validTime ? e.validTime.slice(0, 11) : e.validTime,
                                        invalidTime: "jfsc004" == e.couponRuleCode ? "2021-09-21" : e.invalidTime ? e.invalidTime.slice(0, 11) : e.invalidTime,
                                        showTl: "16nNBFBe00004f00" == e.couponRuleCode || "16YoGt8H00020200" == e.couponRuleCode || "16YoGrrk0001ff00" == e.couponRuleCode || "16YoyYkc00003f00" == e.couponRuleCode || "16YoyYqQ00005503" == e.couponRuleCode || "16nLwZJZ00005e03" == e.couponRuleCode || "16nLwZNe00004f00" == e.couponRuleCode ? "yes" : "no"
                                    }));
                                });
                            } else 1 == n.resultCode && (e.removeStorageSync("logininfo"), o.showloginDialog = !0);
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    goexchange: function(o) {
                        if (1e8 == this.tabActive) {
                            var n = f(f({}, o), {}, {
                                giftName: o.name,
                                endTime: o.invalidTime,
                                giftPicUrl: m + o.giftPicUrl
                            });
                            "1" == o.isAddedWechat ? e.navigateTo({
                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(n)) + "&couponCode=" + o.couponCode + "&couponRuleId=" + o.couponRuleCode + "&showbtn=true"
                            }) : (console.log("点击详情"), console.log(n), e.navigateTo({
                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(n)) + "&couponCode=" + o.couponCode + "&couponRuleId=" + o.couponRuleCode
                            }));
                        }
                    },
                    cancalCard: function(o) {
                        console.log(o);
                        var n = this;
                        c.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: o.couponCode,
                            actionType: "2",
                            remark: ""
                        }, !1).then(function(o) {
                            console.log(o), "0" == o.code ? e.showToast({
                                icon: "none",
                                title: "取消成功",
                                success: function() {
                                    setTimeout(function() {
                                        n.resultList = [], n.nextId = "", n.getList_records();
                                    }, 1e3);
                                }
                            }) : e.showToast({
                                icon: "none",
                                title: "取消失败，请稍后重试"
                            });
                        });
                    },
                    onChange: function(e) {
                        if (!this.isFirstNoChange) return this.isFirstNoChange = !0, !1;
                        this.tabActive = e.detail.name, this.resultList = [], this.nextId = "", this.noMore = !1, 
                        "100000007" == e.detail.name ? (console.log("这是转赠记录"), this.getList_records()) : this.getList();
                    },
                    scrolltolowerFn: function() {
                        console.log("到底了"), this.noMore || (this.$refs.Loading.showLoading(), 100000007 === this.tabActive ? this.getList_records() : this.getList());
                    },
                    transfer: function(o) {
                        if (this.$refs.Loading.showLoading(), 100000002 != this.tabActive) if (100000001 != this.tabActive) {
                            console.log(o);
                            var n = [ "16XHhMdG00009200", "16XHhMjT0000ad00", "16XHsckE0000b800", "16XHscoa0000d400", "16XHscs70000d700", "16XHseM60000da00", "16XHseQV0000dd00", "16XQfj9c0000dc00", "16XQfjBL0000df00", "16XQfjCv0000e200", "16XQgbRg0000e500", "16XQgbV40000e800", "16XQgbkL00010400", "16XQgbqV0000d500", "16XQs74E00000a00", "16XRZbF700002900", "16XRZbki00002f00", "16XQs7tW00011000" ], t = o.couponCode, a = o.couponRuleCode, c = this;
                            console.log(a), console.log(n), console.log(n.indexOf(a)), "16HYjDy800006e00" == o.couponBagCode ? e.navigateTo({
                                url: "/pages/calendarActivity/turnIndex?couponCode=" + t,
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : "16XQs7SQ00001600" == o.couponBagCode || "16XRa7Qr00003800" == o.couponBagCode || "16XQs8Ei00011c00" == o.couponBagCode ? e.navigateTo({
                                url: "/pureFeeling/hdShare/turnIndex?couponCode=" + t + "&couponRuleCode=" + a,
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : [ "16HaQ1eW0000ad00", "16HaQ1eu0000ae00", "16HaQ1fu0000af00", "16Hb25MK00008400", "16Hb25Mg00008500", "16Hb25My00008600" ].indexOf(o.couponBagCode) >= 0 ? e.navigateTo({
                                url: "/pages/makeUpForever/turnIndex?couponCode=" + t,
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : "16XG7Fw20000a000" == o.couponBagCode || "16XG7Fub00009e00" == o.couponBagCode || "16XG23EA00004000" == o.couponBagCode || "16XG23EQ00004100" == o.couponBagCode || "16XG23Ch00003e00" == o.couponBagCode || "16HZcEPN00009d00" == o.couponBagCode || "16HZsSWt00007800" == o.couponBagCode || "16X9Dn7D00009c00" == o.couponBagCode || "16HYYpXw00007b00" == o.couponBagCode ? "16X9Dn7D00009c00" == o.couponBagCode || "16HYYpXw00007b00" == o.couponBagCode || "16XG23Ch00003e00" == o.couponBagCode ? e.navigateTo({
                                url: "/pages/CNYactivity/turnIndex?couponCode=" + t + "&activityType=newYearType",
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : "16XG7Fub00009e00" == o.couponBagCode || "16XG23EA00004000" == o.couponBagCode || "16XG7Fub00009e00" == o.couponBagCode ? e.navigateTo({
                                url: "/pages/CNYactivity/turnIndex?couponCode=" + t + "&activityType=loveGolden",
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : "16XG7Fw20000a000" == o.couponBagCode || "16XG23EQ00004100" == o.couponBagCode || "16XG7Fw20000a000" == o.couponBagCode ? e.navigateTo({
                                url: "/pages/CNYactivity/turnIndex?couponCode=" + t + "&activityType=lovePink",
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : e.navigateTo({
                                url: "/pages/CNYactivity/turnIndex?couponCode=" + t,
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : n.indexOf(a) >= 0 ? e.navigateTo({
                                url: "/pureFeeling/hdShare/turnIndex?couponCode=" + t + "&couponRuleCode=" + a,
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : [ "16HZcE2q00008e00", "16HZcE4H00009100", "16HZcE5h00009400", "16HZcE6R00009700", "16HZcE7x00009a00", "16HaE49q00007900", "16HaE4Pe00007500", "16HaE4Uw00007f00", "16HaE4Uw00007f00", "16HaE4md00007800", "16HaE51V00007b00", "16Hb2EZz00008800", "16Hb2Eey00008700", "16HQ4edg00001d00", "16HQ4ebn00001a00", "16HaE1Vu0000a100", "16Hb2EWZ00008500" ].indexOf(a) >= 0 ? e.navigateTo({
                                url: "/pureFeeling/cameraHome/turnIndex?couponCode=" + t + "&couponRuleCode=" + a,
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : "16X9DnM500002500" == o.couponBagCode || "16XG7cAN0000a200" == o.couponBagCode ? e.navigateTo({
                                url: "/pureFeeling/cameraHome/turnIndex?type=winterGet&couponCode=" + t + "&couponRuleCode=" + a,
                                complete: function() {
                                    c.$refs.Loading.hideLoading();
                                }
                            }) : i.default.findGet({
                                couponRuleId: a,
                                ops: {
                                    couponRuleId: "equal"
                                }
                            }).then(function(o) {
                                if (console.log(o), 0 == o.code) {
                                    var n = o.data.forwardViewUrl;
                                    n.includes("?") ? n += "&couponCode=" + t + "&couponRuleCode=" + a + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)) : n += "?couponCode=" + t + "&couponRuleCode=" + a + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)), 
                                    e.navigateTo({
                                        url: n,
                                        complete: function() {
                                            c.$refs.Loading.hideLoading();
                                        }
                                    });
                                } else e.navigateTo({
                                    url: "/unifyExchange/home/turnIndex?couponCode=" + t,
                                    complete: function() {
                                        c.$refs.Loading.hideLoading();
                                    }
                                });
                            }).catch(function() {
                                e.navigateTo({
                                    url: "/unifyExchange/home/turnIndex?couponCode=" + t,
                                    complete: function() {
                                        c.$refs.Loading.hideLoading();
                                    }
                                });
                            });
                        } else e.showToast({
                            title: "券已使用无法转赠",
                            icon: "none"
                        }); else e.showToast({
                            title: "券已过期无法转赠",
                            icon: "none"
                        });
                    },
                    openWeixinCard: function(o) {
                        1e8 == this.tabActive && (console.log(o), e.openCard({
                            cardList: [ {
                                cardId: o.wxCardId,
                                code: o.couponCode
                            } ],
                            success: function(e) {}
                        }));
                    },
                    addToWeixinCard: function(o) {
                        1e8 == this.tabActive && t.default.convertWxCardId({
                            couponRuleId: o.couponRuleCode
                        }).then(function(n) {
                            t.default.getJsCardSignature({
                                code: o.couponCode,
                                cardId: n.data.wxCardId,
                                openId: e.getStorageSync("openId")
                            }).then(function(o) {
                                var n = o.data, t = n.cardId, i = n.cardSign, a = n.openId, c = n.nonceStr, d = n.timestamp, r = {
                                    code: n.code,
                                    cardId: t,
                                    signature: i,
                                    openid: a,
                                    nonce_str: c,
                                    timestamp: d,
                                    outer_str: "miniProgram"
                                };
                                console.log(JSON.stringify(r)), e.addCard({
                                    cardList: [ {
                                        cardId: t,
                                        cardExt: JSON.stringify(r)
                                    } ],
                                    success: function(e) {
                                        console.log(e), h.globalData.isbackfromSaveWXCard = !0, console.log(h.globalData.isbackfromSaveWXCard);
                                    },
                                    fail: function(e) {
                                        console.log(e), h.globalData.isbackfromSaveWXCard = !1, console.log(h.globalData.isbackfromSaveWXCard);
                                    }
                                });
                            });
                        });
                    }
                }
            };
            o.default = v;
        }).call(this, n("543d").default);
    },
    eeda: function(e, o, n) {}
}, [ [ "16b4", "common/runtime", "common/vendor" ] ] ]);