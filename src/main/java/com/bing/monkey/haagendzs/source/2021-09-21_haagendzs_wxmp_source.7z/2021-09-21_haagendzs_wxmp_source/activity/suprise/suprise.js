// activity/suprise/suprise.js
Page({data: {}})