var t = require("../mixins/link"), i = require("../common/component"), e = require("../common/utils");

(0, i.VantComponent)({
    relation: {
        name: "grid",
        type: "ancestor",
        current: "grid-item"
    },
    classes: [ "content-class", "icon-class", "text-class" ],
    mixins: [ t.link ],
    props: {
        icon: String,
        dot: Boolean,
        info: null,
        badge: null,
        text: String,
        useSlot: Boolean
    },
    data: {
        viewStyle: ""
    },
    mounted: function() {
        this.updateStyle();
    },
    methods: {
        updateStyle: function() {
            if (this.parent) {
                var t = this.parent, i = t.data, n = t.children, o = i.columnNum, r = i.border, a = i.square, c = i.gutter, s = i.clickable, l = i.center, u = i.direction, d = i.iconSize, h = 100 / o + "%", m = [];
                if (m.push("width: " + h), a && m.push("padding-top: " + h), c) {
                    var p = (0, e.addUnit)(c);
                    m.push("padding-right: " + p), n.indexOf(this) >= o && !a && m.push("margin-top: " + p);
                }
                var g = "";
                if (a && c) {
                    var S = (0, e.addUnit)(c);
                    g = "\n          right: " + S + ";\n          bottom: " + S + ";\n          height: auto;\n        ";
                }
                this.setData({
                    viewStyle: m.join("; "),
                    contentStyle: g,
                    center: l,
                    border: r,
                    square: a,
                    gutter: c,
                    clickable: s,
                    direction: u,
                    iconSize: d
                });
            }
        },
        onClick: function() {
            this.$emit("click"), this.jumpLink();
        }
    }
});