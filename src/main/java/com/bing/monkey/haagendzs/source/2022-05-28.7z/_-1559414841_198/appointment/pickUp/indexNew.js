// appointment/pickUp/indexNew.js
Page({data: {}})