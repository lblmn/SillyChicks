// summerEvaluate/luckDraw/index.js
Page({data: {}})