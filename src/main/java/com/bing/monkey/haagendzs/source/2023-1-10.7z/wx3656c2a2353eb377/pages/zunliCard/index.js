(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/zunliCard/index" ], {
    "4ec7": function(n, e, t) {},
    "67b0": function(n, e, t) {
        var o = t("4ec7");
        t.n(o).a;
    },
    "8b53": function(n, e, t) {
        t.r(e);
        var o = t("f6a5"), a = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(i);
        e.default = a.a;
    },
    9213: function(n, e, t) {
        (function(n) {
            var e = t("4ea4");
            t("a1ea"), e(t("66fd"));
            var o = e(t("9500"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t("543d").createPage);
    },
    9500: function(n, e, t) {
        t.r(e);
        var o = t("e817"), a = t("8b53");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(i);
        t("67b0");
        var u = t("f0c5"), c = Object(u.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = c.exports;
    },
    e817: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    f6a5: function(n, e, t) {
        (function(n) {
            var o = t("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0, o(t("ac3e"));
            var a = o(t("f3d4")), i = o(t("7d43")), u = {
                data: function() {
                    return {
                        showRead: !1,
                        listArr: [],
                        imgUrl: a.default.assetsRoot,
                        imgBase: a.default.ossurl + "images/zunli/new",
                        isHeightScreen: !1,
                        config: {
                            statusBarFontColor: "#ffffff",
                            barPlaceholder: !1,
                            backgroundColor: [ 0, "#fff" ]
                        }
                    };
                },
                onLoad: function(n) {
                    var e = this;
                    i.default.isHeightPhone().then(function(n) {
                        e.isHeightScreen = n;
                    }).catch(function(n) {
                        e.isHeightScreen = n;
                    }), i.default.setSource(n);
                },
                onShow: function() {
                    i.default.recordPv();
                },
                components: {
                    hxNavbar: function() {
                        t.e("components/hx-navbar/hx-navbar").then(function() {
                            return resolve(t("614f"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                destroyed: function() {},
                onHide: function() {},
                methods: {
                    callPhone: function() {
                        n.makePhoneCall({
                            phoneNumber: "13917828855"
                        });
                    },
                    shareRecord: function() {
                        userinfoApi.shareRecord({
                            aid: "",
                            unionId: n.getStorageSync("unionId"),
                            openid: n.getStorageSync("openId"),
                            path: "pages/zunliCard/index",
                            button: "pages/zunliCard/index",
                            invitedOpenid: "",
                            type: "2"
                        }).then(function(n) {
                            console.log(n);
                        }).catch(function(n) {
                            console.log(n);
                        });
                    }
                }
            };
            e.default = u;
        }).call(this, t("543d").default);
    }
}, [ [ "9213", "common/runtime", "common/vendor" ] ] ]);