// winterActivity/enterprise/index.js
Page({data: {}})