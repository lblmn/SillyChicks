(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/attendance/attendance" ], {
    2882: function(t, n, e) {
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(n) {
                t.showFlag = !1;
            }, t.e1 = function(n) {
                t.showFlag = !1;
            }, t.e2 = function(n) {
                t.showactive = !1;
            }, t.e3 = function(n) {
                t.showactive = !1;
            });
        }, i = [];
    },
    "4b6f": function(t, n, e) {
        (function(t) {
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function i(t, n) {
                var e = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    n && (o = o.filter(function(n) {
                        return Object.getOwnPropertyDescriptor(t, n).enumerable;
                    })), e.push.apply(e, o);
                }
                return e;
            }
            function a(t) {
                for (var n = 1; n < arguments.length; n++) {
                    var e = null != arguments[n] ? arguments[n] : {};
                    n % 2 ? i(Object(e), !0).forEach(function(n) {
                        c(t, n, e[n]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : i(Object(e)).forEach(function(n) {
                        Object.defineProperty(t, n, Object.getOwnPropertyDescriptor(e, n));
                    });
                }
                return t;
            }
            function c(t, n, e) {
                return n in t ? Object.defineProperty(t, n, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[n] = e, t;
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = o(e("6008")), u = o(e("1d54")), s = o(e("1328")), l = o(e("811a")), f = getApp(), d = {
                components: {
                    uniIcons: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(e("349f"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    uniCalendar: function() {
                        Promise.all([ e.e("common/vendor"), e.e("pages/attendance/uni-calendar/uni-calendar") ]).then(function() {
                            return resolve(e("eebb"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        showFlag: !1,
                        showactive: !1,
                        attendanceList: [],
                        startDate: "",
                        endDate: "",
                        dayLength: 0,
                        canSign: Boolean,
                        points: 0,
                        isfirst: !1,
                        from: "",
                        imgoss: s.default.ossurl + "/images/attendance/",
                        fromzwheel: !1
                    };
                },
                onLoad: function(t) {
                    this.from = t.from, "zwheel" == this.from && (this.fromzwheel = !0), this.signInSearch();
                },
                onShow: function() {
                    0 == getApp().globalData.PointAccountResult.length ? this.getPoint() : this.points = getApp().globalData.PointAccountResult.filter(function(t) {
                        return t.pointAccountName.indexOf("积心") > -1;
                    })[0].availablePoint, console.log(this.points);
                },
                methods: {
                    getPoint: function() {
                        var n = this;
                        u.default.point({
                            idType: "1",
                            id: t.getStorageSync("socialhubId")
                        }).then(function(e) {
                            if (0 == e.resultCode) {
                                f.globalData.PointAccountResult = e.data;
                                var o = e.data.filter(function(t) {
                                    return t.pointAccountName.indexOf("积心") > -1;
                                })[0];
                                n.points = o.availablePoint, f.globalData.PointAccount = o.availablePoint, f.globalData.deadHeart = o.availablePoint;
                            } else t.showToast({
                                title: "请求积分异常请稍后重试",
                                icon: "none"
                            });
                        }).catch(function() {});
                    },
                    signInSearch: function() {
                        var n = this;
                        r.default.signInSearch({
                            unionId: t.getStorageSync("unionId"),
                            startTime: "",
                            endTime: ""
                        }).then(function(e) {
                            if (0 == e.code) {
                                var o = [];
                                e.data.signInList.forEach(function(t) {
                                    o.push(a(a({}, t), {}, {
                                        date: t.signInDate
                                    }));
                                }), n.attendanceList = o, n.dayLength = e.data.continuingSignInCount, n.canSign = !e.data.currentSignIn;
                            } else t.showToast({
                                title: e.msg ? e.msg : "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    doSign: function() {
                        var n = this;
                        if (this.canSign) {
                            if (this.isfirst) return !1;
                            this.isfirst = !0;
                            var e = new Date().getTime();
                            r.default.signIn({
                                unionId: t.getStorageSync("unionId"),
                                sign: l.default.mdString(e, [ "unionId" ]),
                                timestamp: e
                            }).then(function(e) {
                                0 == e.code ? n.getPoints() : (t.showToast({
                                    title: e.msg ? e.msg : "访问异常，小哈正在努力恢复，请稍后重试",
                                    icon: "none"
                                }), n.isfirst = !1);
                            });
                        } else this.showFlag = !0;
                    },
                    gotoShop: function() {
                        "shop" == this.from || "zwheel" == this.from ? t.navigateBack({
                            delta: -1
                        }) : t.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    getPoints: function() {
                        var n = this;
                        u.default.point({
                            idType: "1",
                            id: t.getStorageSync("socialhubId")
                        }).then(function(t) {
                            0 == t.resultCode ? (getApp().globalData.PointAccountResult = t.data, n.points = t.data.filter(function(t) {
                                return t.pointAccountName.indexOf("积心") > -1;
                            })[0].availablePoint, n.showFlag = !0, n.isfirst = !1) : n.isfirst = !1;
                        }).catch(function() {
                            n.isfirst = !1;
                        });
                    },
                    activeRule: function() {
                        this.showactive = !0;
                    },
                    goheart: function() {
                        t.navigateTo({
                            url: "/pages/mine/heart"
                        });
                    },
                    goshop: function() {
                        "shop" == this.from ? t.navigateBack({
                            delta: -1
                        }) : t.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    leaveAlert: function() {
                        this.canSign && (this.canSign = !1);
                    }
                }
            };
            n.default = d;
        }).call(this, e("543d").default);
    },
    "8ba0": function(t, n, e) {
        e.r(n);
        var o = e("4b6f"), i = e.n(o);
        for (var a in o) "default" !== a && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        n.default = i.a;
    },
    a5b2: function(t, n, e) {
        var o = e("e1d2");
        e.n(o).a;
    },
    b7fe: function(t, n, e) {
        e.r(n);
        var o = e("2882"), i = e("8ba0");
        for (var a in i) "default" !== a && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(a);
        e("a5b2");
        var c = e("f0c5"), r = Object(c.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = r.exports;
    },
    bb95: function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("f4aa"), n(e("66fd")), t(n(e("b7fe")).default);
        }).call(this, e("543d").createPage);
    },
    e1d2: function(t, n, e) {}
}, [ [ "bb95", "common/runtime", "common/vendor" ] ] ]);