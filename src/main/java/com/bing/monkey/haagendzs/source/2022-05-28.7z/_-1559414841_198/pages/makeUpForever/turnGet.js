(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/makeUpForever/turnGet" ], {
    "3c25": function(e, n, o) {},
    "3e8e": function(e, n, o) {
        o.r(n);
        var t = o("c527"), a = o("4b10");
        for (var i in a) "default" !== i && function(e) {
            o.d(n, e, function() {
                return a[e];
            });
        }(i);
        o("c3c9");
        var c = o("f0c5"), u = Object(c.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        n.default = u.exports;
    },
    "4b10": function(e, n, o) {
        o.r(n);
        var t = o("b0a6"), a = o.n(t);
        for (var i in t) "default" !== i && function(e) {
            o.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = a.a;
    },
    b0a6: function(e, n, o) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = i(o("f0fd")), a = i(o("2fa1"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var c = {
                data: function() {
                    return {
                        textareaValue: "",
                        imgUrl: t.default.assetsRoot,
                        showloginDialog: !1,
                        showRead: !1,
                        isShowSharePopup: !1,
                        helpinfo: "",
                        nickName: "",
                        checkCodeState: !1
                    };
                },
                onLoad: function(e) {
                    this.textid = e.textid, this.getTextInfo();
                },
                onShow: function() {},
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("3761"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                destroyed: function() {
                    console.log("销毁了");
                },
                onHide: function() {
                    console.log("关闭了"), e.removeStorageSync("successInfo");
                },
                methods: {
                    closepopup: function() {
                        this.checkCodeState ? (this.isShowSharePopup = !1, e.redirectTo({
                            url: "/pages/mine/mycard"
                        })) : this.isShowSharePopup = !1;
                    },
                    getTextInfo: function() {
                        var e = this;
                        a.default.transferGet(this.textid).then(function(n) {
                            console.log(n), e.textareaValue = n.data.remark, e.couponCode = n.data.couponCode, 
                            e.openid = n.data.openid, e.nickName = n.data.nickName;
                        });
                    },
                    readrule: function() {
                        this.showRead = !1, e.removeStorageSync("successInfo"), this.getCard();
                    },
                    sendCard: function() {
                        0 == Object.keys(e.getStorageSync("logininfo")).length ? this.showloginDialog = !0 : this.getCard();
                    },
                    getCard: function() {
                        var n = this;
                        if (this.openid == e.getStorageSync("openId")) return this.isShowSharePopup = !0, 
                        this.helpinfo = "请勿领取自己的券", !1;
                        a.default.transfer({
                            openid: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "3",
                            remark: this.textareaValue
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (n.isShowSharePopup = !0, n.helpinfo = '成功领取好友赠送的\n哈根达斯产品兑换券一张\n快去小程序哈根达斯会员中心\n"个人中心-我的券包"看看吧', 
                            n.checkCodeState = !0) : "502" == e.code ? (n.isShowSharePopup = !0, n.helpinfo = '您已成功领取\n快去小程序哈根达斯会员中心\n"个人中心-我的券包"看看吧', 
                            n.checkCodeState = !0) : (n.isShowSharePopup = !0, n.helpinfo = "您的礼物已被好友取回\n快去联系TA吧");
                        });
                    }
                }
            };
            n.default = c;
        }).call(this, o("543d").default);
    },
    c3c9: function(e, n, o) {
        var t = o("3c25");
        o.n(t).a;
    },
    c527: function(e, n, o) {
        o.d(n, "b", function() {
            return t;
        }), o.d(n, "c", function() {
            return a;
        }), o.d(n, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    c55e: function(e, n, o) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            o("c0e2"), n(o("66fd")), e(n(o("3e8e")).default);
        }).call(this, o("543d").createPage);
    }
}, [ [ "c55e", "common/runtime", "common/vendor" ] ] ]);