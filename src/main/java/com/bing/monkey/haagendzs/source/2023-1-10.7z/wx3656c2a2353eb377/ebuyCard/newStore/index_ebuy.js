// ebuyCard/newStore/index_ebuy.js
Page({data: {}})