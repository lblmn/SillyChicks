var e = require("../common/component"), t = require("./utils"), a = require("./shared");

(0, e.VantComponent)({
    props: Object.assign(Object.assign({
        disabled: Boolean,
        multiple: Boolean,
        uploadText: String,
        useBeforeRead: Boolean,
        afterRead: null,
        beforeRead: null,
        previewSize: {
            type: null,
            value: 90
        },
        name: {
            type: [ Number, String ],
            value: ""
        },
        accept: {
            type: String,
            value: "image"
        },
        fileList: {
            type: Array,
            value: [],
            observer: "formatFileList"
        },
        maxSize: {
            type: Number,
            value: Number.MAX_VALUE
        },
        maxCount: {
            type: Number,
            value: 100
        },
        deletable: {
            type: Boolean,
            value: !0
        },
        showUpload: {
            type: Boolean,
            value: !0
        },
        previewImage: {
            type: Boolean,
            value: !0
        },
        previewFullImage: {
            type: Boolean,
            value: !0
        },
        imageFit: {
            type: String,
            value: "scaleToFill"
        },
        uploadIcon: {
            type: String,
            value: "photograph"
        }
    }, a.chooseImageProps), a.chooseVideoProps),
    data: {
        lists: [],
        isInCount: !0
    },
    methods: {
        formatFileList: function() {
            var e = this.data, a = e.fileList, i = void 0 === a ? [] : a, n = e.maxCount, s = i.map(function(e) {
                return Object.assign(Object.assign({}, e), {
                    isImage: void 0 === e.isImage ? (0, t.isImageFile)(e) : e.isImage,
                    deletable: void 0 === e.deletable || e.deletable
                });
            });
            this.setData({
                lists: s,
                isInCount: s.length < n
            });
        },
        getDetail: function(e) {
            return {
                name: this.data.name,
                index: null == e ? this.data.fileList.length : e
            };
        },
        startUpload: function() {
            var e = this, a = this.data, i = a.maxCount, n = a.multiple, s = a.accept, l = a.lists;
            a.disabled || (0, t.chooseFile)(Object.assign(Object.assign({}, this.data), {
                maxCount: i - l.length
            })).then(function(a) {
                var i = null;
                i = (0, t.isVideo)(a, s) ? Object.assign({
                    path: a.tempFilePath
                }, a) : n ? a.tempFiles : a.tempFiles[0], e.onBeforeRead(i);
            }).catch(function(t) {
                e.$emit("error", t);
            });
        },
        onBeforeRead: function(e) {
            var a = this, i = this.data, n = i.beforeRead, s = i.useBeforeRead, l = !0;
            "function" == typeof n && (l = n(e, this.getDetail())), s && (l = new Promise(function(t, i) {
                a.$emit("before-read", Object.assign(Object.assign({
                    file: e
                }, a.getDetail()), {
                    callback: function(e) {
                        e ? t() : i();
                    }
                }));
            })), l && ((0, t.isPromise)(l) ? l.then(function(t) {
                return a.onAfterRead(t || e);
            }) : this.onAfterRead(e));
        },
        onAfterRead: function(e) {
            var t = this.data.maxSize;
            (Array.isArray(e) ? e.some(function(e) {
                return e.size > t;
            }) : e.size > t) ? this.$emit("oversize", Object.assign({
                file: e
            }, this.getDetail())) : ("function" == typeof this.data.afterRead && this.data.afterRead(e, this.getDetail()), 
            this.$emit("after-read", Object.assign({
                file: e
            }, this.getDetail())));
        },
        deleteItem: function(e) {
            var t = e.currentTarget.dataset.index;
            this.$emit("delete", Object.assign(Object.assign({}, this.getDetail(t)), {
                file: this.data.fileList[t]
            }));
        },
        onPreviewImage: function(e) {
            if (this.data.previewFullImage) {
                var t = e.currentTarget.dataset.index, a = this.data.lists, i = a[t];
                wx.previewImage({
                    urls: a.filter(function(e) {
                        return e.isImage;
                    }).map(function(e) {
                        return e.url || e.path;
                    }),
                    current: i.url || i.path,
                    fail: function() {
                        wx.showToast({
                            title: "预览图片失败",
                            icon: "none"
                        });
                    }
                });
            }
        },
        onClickPreview: function(e) {
            var t = e.currentTarget.dataset.index, a = this.data.lists[t];
            this.$emit("click-preview", Object.assign(Object.assign({}, a), this.getDetail(t)));
        }
    }
});