(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/winterMenu/index" ], {
    2394: function(n, t, e) {},
    "5ea5": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this, t = (n.$createElement, n._self._c, n.__map(n.listArr, function(t, e) {
                return {
                    $orig: n.__get_orig(t),
                    l0: n.__map(t.gifts, function(t, e) {
                        return {
                            $orig: n.__get_orig(t),
                            m0: n.changeContent(t),
                            g0: t.ruleDesc.replace(/\n/g, "<br/>")
                        };
                    })
                };
            }));
            n._isMounted || (n.e0 = function(t) {
                t.stopPropagation(), n.isFirstMenu = !1;
            }, n.e1 = function(t) {
                n.isShowSharePopup = !1;
            }), n.$mp.data = Object.assign({}, {
                $root: {
                    l1: t
                }
            });
        }, i = [];
    },
    "697d": function(n, t, e) {
        e.r(t);
        var o = e("993d"), i = e.n(o);
        for (var r in o) "default" !== r && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        t.default = i.a;
    },
    "709a": function(n, t, e) {
        e.r(t);
        var o = e("5ea5"), i = e("697d");
        for (var r in i) "default" !== r && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(r);
        e("8b5e");
        var a = e("f0c5"), s = Object(a.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = s.exports;
    },
    "8b5e": function(n, t, e) {
        var o = e("2394");
        e.n(o).a;
    },
    "993d": function(n, t, e) {
        (function(n) {
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function i(n) {
                return c(n) || s(n) || a(n) || r();
            }
            function r() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function a(n, t) {
                if (n) {
                    if ("string" == typeof n) return u(n, t);
                    var e = Object.prototype.toString.call(n).slice(8, -1);
                    return "Object" === e && n.constructor && (e = n.constructor.name), "Map" === e || "Set" === e ? Array.from(n) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? u(n, t) : void 0;
                }
            }
            function s(n) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(n)) return Array.from(n);
            }
            function c(n) {
                if (Array.isArray(n)) return u(n);
            }
            function u(n, t) {
                (null == t || t > n.length) && (t = n.length);
                for (var e = 0, o = new Array(t); e < t; e++) o[e] = n[e];
                return o;
            }
            function d(n, t, e, o, i, r, a) {
                try {
                    var s = n[r](a), c = s.value;
                } catch (n) {
                    return void e(n);
                }
                s.done ? t(c) : Promise.resolve(c).then(o, i);
            }
            function l(n) {
                return function() {
                    var t = this, e = arguments;
                    return new Promise(function(o, i) {
                        function r(n) {
                            d(s, o, i, r, a, "next", n);
                        }
                        function a(n) {
                            d(s, o, i, r, a, "throw", n);
                        }
                        var s = n.apply(t, e);
                        r(void 0);
                    });
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var h = o(e("a34a")), f = o(e("2e0b")), g = o(e("1328")), p = o(e("d1fd")), S = o(e("d7df")), m = {
                data: function() {
                    return {
                        showRead: !1,
                        listArr: [],
                        imgUrl: g.default.assetsRoot,
                        imgUrl2: g.default.assetsRoot + "/oss/wxapp/20210127/static/",
                        isFirstMenu: !1,
                        isShowBtn: !1,
                        showloginDialog: !1,
                        openid: "",
                        unionId: "",
                        aid: "",
                        showbtn: "",
                        isShowSharePopup: !1,
                        helpinfo: "Hi,还是你自己哦\n分享好友获得限量好礼哦~",
                        isShareBtn: !0,
                        isShowShareBack: !1,
                        helpinfoBack: "",
                        gobackText: ""
                    };
                },
                onLoad: function(t) {
                    console.log(t), n.removeStorageSync("fromHome"), this.type = t.type, this.fromHome = t.fromHome, 
                    "fromTask" != this.type ? n.hideShareMenu() : ("all" != t.showbtn && ("all" == n.getStorageSync("isFirstMenu") ? this.isFirstMenu = !1 : (n.setStorageSync("isFirstMenu", "all"), 
                    this.isFirstMenu = !0)), this.openid = t.openid, this.unionId = t.unionId, this.showbtn = t.showbtn, 
                    "all" == t.showbtn && (this.isShowBtn = !0), this.aid = t.aid), this.getBycategory();
                },
                onShow: function() {
                    "all" == n.getStorageSync("successInfo") && (this.showRead = !0), this.isShowSharePopup = !1, 
                    "home" == n.getStorageSync("fromHome") ? (this.isShowShareBack = !0, this.helpinfoBack = "分享成功\n快去成为测评官吧，\n完成不同任务享不同好礼~", 
                    this.gobackText = "成为测评官") : "task" == n.getStorageSync("fromHome") && (this.isShowShareBack = !0, 
                    this.helpinfoBack = "分享成功\n快去完成其他任务\n享更多任务好礼~", this.gobackText = "前往任务中心");
                },
                mounted: function() {
                    var t = this;
                    return l(h.default.mark(function e() {
                        var o;
                        return h.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (0 != Object.keys(n.getStorageSync("logininfo")).length) {
                                    e.next = 10;
                                    break;
                                }
                                return console.log("微信登录"), e.next = 4, t.doLogin();

                              case 4:
                                return t.loginRes = e.sent, e.next = 7, t.getOpenid(t.loginRes);

                              case 7:
                                (o = e.sent).data.unionId && n.setStorageSync("unionId", o.data.unionId), n.setStorageSync("openId", o.data.openid);

                              case 10:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/loginDialog") ]).then(function() {
                            return resolve(e("a81e"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                destroyed: function() {},
                onHide: function() {},
                methods: {
                    gotoBack: function() {
                        n.navigateBack({
                            delta: -1
                        });
                    },
                    readrule: function() {
                        this.showRead = !1, n.removeStorageSync("successInfo"), this.gotoHomeIndex();
                    },
                    gotoAct: function() {
                        n.redirectTo({
                            url: "../../evaluation/home/index?aid=" + this.aid
                        });
                    },
                    gotoHomeIndex: function() {
                        this.openid == n.getStorageSync("openId") ? this.isShowSharePopup = !0 : n.getStorageSync("unionId") ? (n.showLoading({
                            mask: !0,
                            title: "加载中..."
                        }), "all" == this.showbtn && (this.shareFun(), this.isShareBtn = !1, this.isShowSharePopup = !0, 
                        this.helpinfo = "赞！\n会员奢宠礼包你也可以有~", n.hideLoading())) : this.showloginDialog = !0;
                    },
                    shareFun: function() {
                        console.log(this.openid), console.log(this.unionId), console.log(n.getStorageSync("openId")), 
                        console.log(n.getStorageSync("unionId")), p.default.shareFun({
                            openId: this.openid,
                            unionId: this.unionId,
                            clickOpenId: n.getStorageSync("openId"),
                            clickUnionId: n.getStorageSync("unionId")
                        });
                    },
                    doLogin: function() {
                        return new Promise(function(t, e) {
                            n.login({
                                success: function(n) {
                                    t(n);
                                }
                            });
                        });
                    },
                    getOpenid: function(n) {
                        return S.default.login({
                            code: n.code,
                            appId: this.$env.appId
                        });
                    },
                    triggerItem: function(n) {
                        console.log(n);
                        var t = i(this.listArr), e = n.currentTarget.dataset.index;
                        console.log(e), 0 == this.listArr[e].height ? (t[e].height = "auto", t[e].openicon = "0", 
                        this.listArr = t) : (t[e].height = 0, t[e].openicon = "1", this.listArr = t);
                    },
                    changeContent: function(n) {
                        return n.content ? n.content : "";
                    },
                    getBycategory: function() {
                        var n = this;
                        f.default.bycategory("11").then(function(t) {
                            console.log(t), t.data.length <= 0 ? n.ruleDesc = "暂无冬季菜单信息" : (n.listArr = t.data, 
                            n.listArr.map(function(n) {
                                return n.height = "auto", n.openicon = "0", n;
                            }));
                        });
                    },
                    shareRecord: function() {
                        S.default.shareRecord({
                            aid: "",
                            unionId: n.getStorageSync("unionId"),
                            openid: n.getStorageSync("openId"),
                            path: "pages/mine/rule",
                            button: "pages/mine/rule",
                            invitedOpenid: "",
                            type: "2"
                        }).then(function(n) {
                            console.log(n);
                        }).catch(function(n) {
                            console.log(n);
                        });
                    }
                },
                onShareAppMessage: function() {
                    var t = "".concat(g.default.assetsRoot, "/oss/wxapp/20210127/static/hdShare/share.png"), e = n.getStorageSync("openId"), o = n.getStorageSync("unionId");
                    return "home" == this.fromHome ? n.setStorageSync("fromHome", "home") : "task" == this.fromHome && n.setStorageSync("fromHome", "task"), 
                    console.log("pages/winterMenu/index?type=fromTask&openid=".concat(e, "&unionId=").concat(o, "&aid=").concat(this.aid)), 
                    {
                        title: "春季测评官任务进行中，为好友赢取免费赏味券和积心~",
                        path: "pages/winterMenu/index?type=fromTask&openid=".concat(e, "&unionId=").concat(o, "&aid=").concat(this.aid, "&showbtn=all"),
                        imageUrl: t
                    };
                }
            };
            t.default = m;
        }).call(this, e("543d").default);
    },
    ec10: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("f4aa"), t(e("66fd")), n(t(e("709a")).default);
        }).call(this, e("543d").createPage);
    }
}, [ [ "ec10", "common/runtime", "common/vendor" ] ] ]);