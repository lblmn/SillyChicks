(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webView/indexN" ], {
    "11c8": function(n, e, o) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(o("1328")), i = {
                data: function() {
                    return {
                        webviewStyles: {
                            progress: {
                                color: "#FF3333"
                            }
                        },
                        url: "",
                        urlLink: "",
                        showloginDialog: !1
                    };
                },
                onLoad: function(n) {
                    console.log(n), this.url = decodeURIComponent(n.url);
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("a81e"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                onShow: function() {
                    Object.keys(n.getStorageSync("logininfo")).length > 0 ? this.url.indexOf("reserveHome?scene=1") > 0 ? this.urlLink = this.url + "&openid=" + n.getStorageSync("openId") + "&unionid=" + n.getStorageSync("unionId") + "&nickname=" + n.getStorageSync("logininfo").fullName : (n.hideShareMenu(), 
                    this.urlLink = this.url) : this.showloginDialog = !0;
                },
                onShareAppMessage: function(n) {
                    var e = "pages/webView/indexN?url=" + encodeURIComponent(this.url);
                    return "button" === n.from && console.log(n.target), {
                        title: "相聚乐享空间，一起空间自由",
                        path: e,
                        imageUrl: "".concat(t.default.ossurl, "/images/home/share.png")
                    };
                }
            };
            e.default = i;
        }).call(this, o("543d").default);
    },
    "798e": function(n, e, o) {
        o.r(e);
        var t = o("9600"), i = o("96c4");
        for (var u in i) "default" !== u && function(n) {
            o.d(e, n, function() {
                return i[n];
            });
        }(u);
        var l = o("f0c5"), r = Object(l.a)(i.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = r.exports;
    },
    9263: function(n, e, o) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("f4aa"), e(o("66fd")), n(e(o("798e")).default);
        }).call(this, o("543d").createPage);
    },
    9600: function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return i;
        }), o.d(e, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, i = [];
    },
    "96c4": function(n, e, o) {
        o.r(e);
        var t = o("11c8"), i = o.n(t);
        for (var u in t) "default" !== u && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(u);
        e.default = i.a;
    }
}, [ [ "9263", "common/runtime", "common/vendor" ] ] ]);