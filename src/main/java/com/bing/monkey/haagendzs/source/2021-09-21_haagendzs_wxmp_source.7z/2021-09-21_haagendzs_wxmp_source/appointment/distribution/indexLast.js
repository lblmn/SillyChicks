// appointment/distribution/indexLast.js
Page({data: {}})