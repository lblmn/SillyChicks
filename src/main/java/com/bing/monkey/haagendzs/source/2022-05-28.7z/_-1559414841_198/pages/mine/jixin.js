(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/jixin" ], {
    b296: function(n, t, e) {
        e.r(t);
        var o = e("fc7b"), c = e("d2fe");
        for (var i in c) "default" !== i && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(i);
        e("e7cc");
        var r = e("f0c5"), u = Object(r.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    c074: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(e("f0a9"));
            function c(n, t) {
                var e = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(n);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable;
                    })), e.push.apply(e, o);
                }
                return e;
            }
            function i(n) {
                for (var t = 1; t < arguments.length; t++) {
                    var e = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? c(Object(e), !0).forEach(function(t) {
                        r(n, t, e[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : c(Object(e)).forEach(function(t) {
                        Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t));
                    });
                }
                return n;
            }
            function r(n, t, e) {
                return t in n ? Object.defineProperty(n, t, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[t] = e, n;
            }
            var u = {
                name: "jixin",
                components: {
                    Zduihuan: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/Zduihuan") ]).then(function() {
                            return resolve(e("6251"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    uniIcons: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(e("fafe"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        cardList: [],
                        nextId: "",
                        pageSize: 10,
                        noMore: !1
                    };
                },
                onShow: function() {},
                onLoad: function() {
                    var n = getApp().globalData.PointAccount.filter(function(n) {
                        return n.pointAccountName.indexOf("积心") > -1;
                    })[0];
                    this.pointAccountId = n.pointAccountId, this.getList();
                },
                methods: {
                    goShop: function() {
                        n.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    getList: function() {
                        var t = this, e = {
                            idType: 1,
                            id: n.getStorageSync("socialhubId"),
                            pointAccountId: this.pointAccountId,
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        };
                        "" == this.nextId && delete e.nextId, o.default.pointexchangeList(e).then(function(e) {
                            n.hideLoading(), 0 == e.resultCode && (e.data.nextId && (t.nextId = e.data.nextId), 
                            e.data.list.forEach(function(n) {
                                t.cardList.push(i(i({}, n), {}, {
                                    value: n.score + " 积心",
                                    num: n.qty
                                }));
                            }), e.data.nextId || (t.noMore = !0));
                        });
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (n.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), this.getList());
                    }
                }
            };
            t.default = u;
        }).call(this, e("543d").default);
    },
    d2fe: function(n, t, e) {
        e.r(t);
        var o = e("c074"), c = e.n(o);
        for (var i in o) "default" !== i && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t.default = c.a;
    },
    e4c2: function(n, t, e) {},
    e7cc: function(n, t, e) {
        var o = e("e4c2");
        e.n(o).a;
    },
    f84d: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("c0e2"), t(e("66fd")), n(t(e("b296")).default);
        }).call(this, e("543d").createPage);
    },
    fc7b: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    }
}, [ [ "f84d", "common/runtime", "common/vendor" ] ] ]);