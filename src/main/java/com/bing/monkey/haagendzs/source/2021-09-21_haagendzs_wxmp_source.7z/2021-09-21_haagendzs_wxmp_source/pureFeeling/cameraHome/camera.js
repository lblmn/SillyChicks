// pureFeeling/cameraHome/camera.js
Page({data: {}})