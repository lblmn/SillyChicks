// summerEvaluate/comment/index.js
Page({data: {}})