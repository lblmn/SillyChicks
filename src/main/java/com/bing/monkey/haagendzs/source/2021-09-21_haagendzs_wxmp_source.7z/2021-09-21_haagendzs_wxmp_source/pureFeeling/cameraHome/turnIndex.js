// pureFeeling/cameraHome/turnIndex.js
Page({data: {}})