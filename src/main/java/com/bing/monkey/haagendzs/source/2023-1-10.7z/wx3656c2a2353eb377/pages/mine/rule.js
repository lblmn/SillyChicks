(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/rule" ], {
    "25b0": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "41ac": function(e, t, n) {
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(n("0098")), c = o(n("9296")), i = o(n("7d43")), r = o(n("5db4")), u = getApp(), s = {
                data: function() {
                    return {
                        ruleDesc: "",
                        showloginDialog: !1,
                        showRead: !1,
                        type: "",
                        title: "会员规则",
                        frompath: ""
                    };
                },
                onLoad: function(e) {
                    i.default.setSource(e), i.default.recordPv(), this.type = e.type ? e.type : "4", 
                    this.frompath = e.frompath, this.getRuleDesc();
                },
                onShow: function() {
                    "all" == e.getStorageSync("successInfo") && (this.showRead = !0);
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("d6e5"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                destroyed: function() {},
                onHide: function() {
                    e.removeStorageSync("successInfo");
                },
                methods: {
                    getRecord: function() {
                        r.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: e.getStorageSync("smsSource")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        a.default.getRuledesc({
                            type: this.type
                        }).then(function(t) {
                            console.log(t), t.data.length <= 0 ? e.ruleDesc = "暂无会员规则信息" : (e.ruleDesc = t.data[0].content, 
                            e.title = t.data[0].title);
                        });
                    },
                    backtoMine: function() {
                        "index" == this.frompath ? (e.setStorageSync("isFirstGoIndex", !0), e.navigateBack({
                            delta: -1
                        })) : 0 == Object.keys(e.getStorageSync("logininfo")).length ? this.showloginDialog = !0 : (u.hxt.sendAction("memberrule_read"), 
                        this.shareRecord(), this.getRecord());
                    },
                    readrule: function() {
                        this.showRead = !1, e.removeStorageSync("successInfo"), this.shareRecord(), this.getRecord();
                    },
                    shareRecord: function() {
                        c.default.shareRecord({
                            aid: "",
                            unionId: e.getStorageSync("unionId"),
                            openid: e.getStorageSync("openId"),
                            path: "" != this.type ? "pages/mine/rule?type=".concat(this.type) : "pages/mine/rule",
                            button: "" != this.type ? "pages/mine/rule?type=".concat(this.type) : "pages/mine/rule",
                            invitedOpenid: "",
                            type: "2"
                        }).then(function(e) {
                            console.log(e);
                        }).catch(function(e) {
                            console.log(e);
                        });
                        var t = getCurrentPages();
                        console.log(t), t.length - 1 <= 0 ? 10 == this.type ? e.reLaunch({
                            url: "/pages/shop/shop?tabFrom=pointC"
                        }) : e.getStorageSync("isFirstGoIndex") ? e.switchTab({
                            url: "./mine"
                        }) : e.switchTab({
                            url: "/pages/index/index"
                        }) : 10 == this.type ? e.reLaunch({
                            url: "/pages/shop/shop?tabFrom=pointC"
                        }) : e.navigateBack({});
                    }
                }
            };
            t.default = s;
        }).call(this, n("543d").default);
    },
    "569b": function(e, t, n) {},
    "8de2": function(e, t, n) {
        var o = n("569b");
        n.n(o).a;
    },
    "9eb4": function(e, t, n) {
        n.r(t);
        var o = n("41ac"), a = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        t.default = a.a;
    },
    a204: function(e, t, n) {
        n.r(t);
        var o = n("25b0"), a = n("9eb4");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(c);
        n("8de2");
        var i = n("f0c5"), r = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = r.exports;
    },
    c9cb: function(e, t, n) {
        (function(e) {
            var t = n("4ea4");
            n("a1ea"), t(n("66fd"));
            var o = t(n("a204"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(o.default);
        }).call(this, n("543d").createPage);
    }
}, [ [ "c9cb", "common/runtime", "common/vendor" ] ] ]);