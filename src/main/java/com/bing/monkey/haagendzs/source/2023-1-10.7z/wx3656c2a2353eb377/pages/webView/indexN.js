(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webView/indexN" ], {
    "218b": function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return i;
        }), o.d(e, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    "277b": function(n, e, o) {
        o.r(e);
        var t = o("218b"), i = o("8e77");
        for (var l in i) [ "default" ].indexOf(l) < 0 && function(n) {
            o.d(e, n, function() {
                return i[n];
            });
        }(l);
        var c = o("f0c5"), r = Object(c.a)(i.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = r.exports;
    },
    "8e77": function(n, e, o) {
        o.r(e);
        var t = o("a24b"), i = o.n(t);
        for (var l in t) [ "default" ].indexOf(l) < 0 && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(l);
        e.default = i.a;
    },
    a24b: function(n, e, o) {
        (function(n) {
            var t = o("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = t(o("f3d4")), l = t(o("7d43")), c = {
                data: function() {
                    return {
                        webviewStyles: {
                            progress: {
                                color: "#FF3333"
                            }
                        },
                        url: "",
                        urlLink: "",
                        code: "",
                        fromIndex: "",
                        showloginDialog: !1
                    };
                },
                onLoad: function(n) {
                    console.log(n), l.default.setSource(n), this.url = decodeURIComponent(null == n ? void 0 : n.url), 
                    this.code = null == n ? void 0 : n.code, this.fromIndex = null == n ? void 0 : n.fromIndex;
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("d6e5"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                onShow: function() {
                    Object.keys(n.getStorageSync("logininfo")).length > 0 ? (l.default.recordPv(), l.default.getRecord(), 
                    this.url.indexOf("reserveHome?scene=1") > 0 ? this.urlLink = this.url + "&openid=" + n.getStorageSync("openId") + "&unionid=" + n.getStorageSync("unionId") + "&nickname=" + n.getStorageSync("logininfo").fullName : (n.hideShareMenu(), 
                    this.code || "yes" == this.fromIndex ? (n.setNavigationBarTitle({
                        title: "哈根达斯“钱兔”似锦礼盒预约提领"
                    }), "release" == i.default.envVersion ? this.code ? this.urlLink = "https://hd-sp.rydeen.com.cn/coupon-booking/booking?bizType=seasons_gift&channel=SNMIN&couponNo=" + this.code : "yes" == this.fromIndex && (this.urlLink = "https://hd-sp.rydeen.com.cn/coupon-booking/booking?bizType=seasons_gift&channel=SNMIN") : this.code ? this.urlLink = "https://hd-uat.rydeen.com.cn/coupon-booking/booking?bizType=seasons_gift&channel=SNMIN&couponNo=" + this.code : "yes" == this.fromIndex && (this.urlLink = "https://hd-uat.rydeen.com.cn/coupon-booking/booking?bizType=seasons_gift&channel=SNMIN")) : this.urlLink = this.url, 
                    console.log(this.urlLink))) : this.showloginDialog = !0;
                }
            };
            e.default = c;
        }).call(this, o("543d").default);
    },
    f388: function(n, e, o) {
        (function(n) {
            var e = o("4ea4");
            o("a1ea"), e(o("66fd"));
            var t = e(o("277b"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = o, n(t.default);
        }).call(this, o("543d").createPage);
    }
}, [ [ "f388", "common/runtime", "common/vendor" ] ] ]);