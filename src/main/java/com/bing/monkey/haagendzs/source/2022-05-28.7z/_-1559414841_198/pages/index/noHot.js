(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/noHot" ], {
    "0a81": function(n, e, t) {
        t.r(e);
        var o = t("a222"), a = t.n(o);
        for (var u in o) "default" !== u && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(u);
        e.default = a.a;
    },
    "197c": function(n, e, t) {},
    "5f87": function(n, e, t) {
        var o = t("197c");
        t.n(o).a;
    },
    "70b1": function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t("c0e2"), e(t("66fd")), n(e(t("85d6")).default);
        }).call(this, t("543d").createPage);
    },
    "85d6": function(n, e, t) {
        t.r(e);
        var o = t("d8d3"), a = t("0a81");
        for (var u in a) "default" !== u && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(u);
        t("5f87");
        var c = t("f0c5"), f = Object(c.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = f.exports;
    },
    a222: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = c(t("f0fd")), a = c(t("234f")), u = c(t("6bd2"));
            function c(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            var f = {
                data: function() {
                    return {
                        imgoss: o.default.ossurl + "unifyExchange/noHot/",
                        config: {
                            statusBarFontColor: "#ffffff",
                            barPlaceholder: !1,
                            backgroundColor: [ 0, "#fff" ]
                        },
                        isHeightScreen: !1
                    };
                },
                onLoad: function(n) {
                    var e = this;
                    a.default.isHeightPhone().then(function(n) {
                        e.isHeightScreen = n;
                    }).catch(function(n) {
                        e.isHeightScreen = n;
                    }), a.default.setSource(n);
                },
                onShow: function() {
                    this.getRecord();
                },
                components: {
                    hxNavbar: function() {
                        t.e("components/hx-navbar/hx-navbar").then(function() {
                            return resolve(t("a006"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                methods: {
                    getRecord: function(e) {
                        u.default.saveLoginRecord({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId"),
                            source: e || n.getStorageSync("smsSource")
                        }, !1);
                    },
                    goIndex: function() {
                        1 == getCurrentPages().length ? n.switchTab({
                            url: "/pages/index/index"
                        }) : n.navigateBack({
                            delta: -1
                        });
                    }
                }
            };
            e.default = f;
        }).call(this, t("543d").default);
    },
    d8d3: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    }
}, [ [ "70b1", "common/runtime", "common/vendor" ] ] ]);