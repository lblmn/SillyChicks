(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/winterMenu/index" ], {
    "27e6": function(n, t, e) {
        e.r(t);
        var o = e("b691"), i = e.n(o);
        for (var r in o) "default" !== r && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        t.default = i.a;
    },
    4705: function(n, t, e) {
        var o = e("c5d4");
        e.n(o).a;
    },
    6279: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this, t = (n.$createElement, n._self._c, n.__map(n.listArr, function(t, e) {
                return {
                    $orig: n.__get_orig(t),
                    l0: n.__map(t.gifts, function(t, e) {
                        return {
                            $orig: n.__get_orig(t),
                            m0: n.changeContent(t),
                            g0: t.ruleDesc.replace(/\n/g, "<br/>")
                        };
                    })
                };
            }));
            n._isMounted || (n.e0 = function(t) {
                t.stopPropagation(), n.isFirstMenu = !1;
            }, n.e1 = function(t) {
                n.isShowSharePopup = !1;
            }), n.$mp.data = Object.assign({}, {
                $root: {
                    l1: t
                }
            });
        }, i = [];
    },
    8374: function(n, t, e) {
        e.r(t);
        var o = e("6279"), i = e("27e6");
        for (var r in i) "default" !== r && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(r);
        e("4705");
        var a = e("f0c5"), s = Object(a.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = s.exports;
    },
    b691: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = h(e("a34a")), i = h(e("33d4")), r = h(e("f0fd")), a = h(e("18425")), s = h(e("500b")), c = h(e("234f")), u = h(e("f3d6"));
            function h(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function l(n) {
                return function(n) {
                    if (Array.isArray(n)) return d(n);
                }(n) || function(n) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(n)) return Array.from(n);
                }(n) || function(n, t) {
                    if (n) {
                        if ("string" == typeof n) return d(n, t);
                        var e = Object.prototype.toString.call(n).slice(8, -1);
                        return "Object" === e && n.constructor && (e = n.constructor.name), "Map" === e || "Set" === e ? Array.from(n) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? d(n, t) : void 0;
                    }
                }(n) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function d(n, t) {
                (null == t || t > n.length) && (t = n.length);
                for (var e = 0, o = new Array(t); e < t; e++) o[e] = n[e];
                return o;
            }
            function g(n, t, e, o, i, r, a) {
                try {
                    var s = n[r](a), c = s.value;
                } catch (n) {
                    return void e(n);
                }
                s.done ? t(c) : Promise.resolve(c).then(o, i);
            }
            var f = {
                data: function() {
                    return {
                        imgoss: r.default.ossurl + "images/home",
                        isGongGao: !0,
                        isHeightScreen: !1,
                        showRead: !1,
                        listArr: [],
                        imgUrl: r.default.assetsRoot,
                        imgUrl2: r.default.assetsRoot + "/oss/wxapp/20210127/static/",
                        isFirstMenu: !1,
                        isShowBtn: !1,
                        showloginDialog: !1,
                        openid: "",
                        unionId: "",
                        aid: "",
                        showbtn: "",
                        isShowSharePopup: !1,
                        helpinfo: "Hi,还是你自己哦\n分享好友获得限量好礼哦~",
                        isShareBtn: !0,
                        isShowShareBack: !1,
                        helpinfoBack: "",
                        gobackText: ""
                    };
                },
                onLoad: function(t) {
                    var e = this;
                    c.default.isHeightPhone().then(function(n) {
                        e.isHeightScreen = n;
                    }).catch(function(n) {
                        e.isHeightScreen = n;
                    }), console.log(t), n.removeStorageSync("fromHome"), this.type = t.type, this.fromHome = t.fromHome, 
                    "fromTask" != this.type ? n.hideShareMenu() : ("all" != t.showbtn && ("all" == n.getStorageSync("isFirstMenu") ? this.isFirstMenu = !1 : (n.setStorageSync("isFirstMenu", "all"), 
                    this.isFirstMenu = !0)), this.openid = t.openid, this.unionId = t.unionId, this.showbtn = t.showbtn, 
                    "all" == t.showbtn && (this.isShowBtn = !0), this.aid = t.aid), this.getBycategory();
                },
                onShow: function() {
                    "all" == n.getStorageSync("successInfo") && (this.showRead = !0), this.isShowSharePopup = !1, 
                    "home" == n.getStorageSync("fromHome") ? (this.isShowShareBack = !0, this.helpinfoBack = "分享成功\n快去成为测评官吧，\n完成不同任务享不同好礼~", 
                    this.gobackText = "成为测评官") : "task" == n.getStorageSync("fromHome") && (this.isShowShareBack = !0, 
                    this.helpinfoBack = "分享成功\n快去完成其他任务\n享更多任务好礼~", this.gobackText = "前往任务中心");
                },
                mounted: function() {
                    var t = this;
                    return function(n) {
                        return function() {
                            var t = this, e = arguments;
                            return new Promise(function(o, i) {
                                var r = n.apply(t, e);
                                function a(n) {
                                    g(r, o, i, a, s, "next", n);
                                }
                                function s(n) {
                                    g(r, o, i, a, s, "throw", n);
                                }
                                a(void 0);
                            });
                        };
                    }(o.default.mark(function e() {
                        var i;
                        return o.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (0 != Object.keys(n.getStorageSync("logininfo")).length) {
                                    e.next = 10;
                                    break;
                                }
                                return console.log("微信登录"), e.next = 4, t.doLogin();

                              case 4:
                                return t.loginRes = e.sent, e.next = 7, t.getOpenid(t.loginRes);

                              case 7:
                                (i = e.sent).data.unionId && n.setStorageSync("unionId", i.data.unionId), n.setStorageSync("openId", i.data.openid);

                              case 10:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/loginDialog") ]).then(function() {
                            return resolve(e("3761"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                destroyed: function() {},
                onHide: function() {},
                methods: {
                    beginAct: function() {
                        "all" == n.getStorageSync("successInfo") && (this.showRead = !0), this.isShowSharePopup = !1, 
                        "home" == n.getStorageSync("fromHome") ? (this.isShowShareBack = !0, this.helpinfoBack = "分享成功\n快去成为测评官吧，\n完成不同任务享不同好礼~", 
                        this.gobackText = "成为测评官") : "task" == n.getStorageSync("fromHome") && (this.isShowShareBack = !0, 
                        this.helpinfoBack = "分享成功\n快去完成其他任务\n享更多任务好礼~", this.gobackText = "前往任务中心");
                    },
                    gongGao: function() {
                        var n = this;
                        u.default.switches().then(function(t) {
                            console.log(t), 0 == t.code ? n.isGongGao = !0 : 500 == t.code && (n.isGongGao = !1, 
                            n.beginAct());
                        });
                    },
                    gotoBack: function() {
                        n.navigateBack({
                            delta: -1
                        });
                    },
                    readrule: function() {
                        this.showRead = !1, n.removeStorageSync("successInfo"), this.gotoHomeIndex();
                    },
                    gotoAct: function() {
                        n.redirectTo({
                            url: "../../evaluation/home/index?aid=" + this.aid
                        });
                    },
                    gotoHomeIndex: function() {
                        this.openid == n.getStorageSync("openId") ? this.isShowSharePopup = !0 : n.getStorageSync("unionId") ? (n.showLoading({
                            mask: !0,
                            title: "加载中..."
                        }), "all" == this.showbtn && (this.shareFun(), this.isShareBtn = !1, this.isShowSharePopup = !0, 
                        this.helpinfo = "赞！\n会员奢宠礼包你也可以有~", n.hideLoading())) : this.showloginDialog = !0;
                    },
                    shareFun: function() {
                        console.log(this.openid), console.log(this.unionId), console.log(n.getStorageSync("openId")), 
                        console.log(n.getStorageSync("unionId")), a.default.shareFun({
                            openId: this.openid,
                            unionId: this.unionId,
                            clickOpenId: n.getStorageSync("openId"),
                            clickUnionId: n.getStorageSync("unionId")
                        });
                    },
                    doLogin: function() {
                        return new Promise(function(t, e) {
                            n.login({
                                success: function(n) {
                                    t(n);
                                }
                            });
                        });
                    },
                    getOpenid: function(n) {
                        return s.default.login({
                            code: n.code,
                            appId: this.$env.appId
                        });
                    },
                    triggerItem: function(n) {
                        console.log(n);
                        var t = l(this.listArr), e = n.currentTarget.dataset.index;
                        console.log(e), 0 == this.listArr[e].height ? (t[e].height = "auto", t[e].openicon = "0", 
                        this.listArr = t) : (t[e].height = 0, t[e].openicon = "1", this.listArr = t);
                    },
                    changeContent: function(n) {
                        return n.content ? n.content : "";
                    },
                    getBycategory: function() {
                        var n = this;
                        i.default.bycategory("11").then(function(t) {
                            console.log(t), t.data.length <= 0 ? n.ruleDesc = "暂无冬季菜单信息" : (n.listArr = t.data, 
                            n.listArr.map(function(n) {
                                return n.height = "0", n.openicon = "1", n;
                            }));
                        });
                    },
                    shareRecord: function() {
                        s.default.shareRecord({
                            aid: "",
                            unionId: n.getStorageSync("unionId"),
                            openid: n.getStorageSync("openId"),
                            path: "pages/mine/rule",
                            button: "pages/mine/rule",
                            invitedOpenid: "",
                            type: "2"
                        }).then(function(n) {
                            console.log(n);
                        }).catch(function(n) {
                            console.log(n);
                        });
                    }
                },
                onShareAppMessage: function() {
                    var t = "".concat(r.default.assetsRoot, "/oss/wxapp/20210127/static/hdShare/share.png"), e = n.getStorageSync("openId"), o = n.getStorageSync("unionId");
                    return "home" == this.fromHome ? n.setStorageSync("fromHome", "home") : "task" == this.fromHome && n.setStorageSync("fromHome", "task"), 
                    console.log("pages/winterMenu/index?type=fromTask&openid=".concat(e, "&unionId=").concat(o, "&aid=").concat(this.aid)), 
                    {
                        title: "春季测评官任务进行中，为好友赢取免费赏味券和积心~",
                        path: "pages/winterMenu/index?type=fromTask&openid=".concat(e, "&unionId=").concat(o, "&aid=").concat(this.aid, "&showbtn=all"),
                        imageUrl: t
                    };
                }
            };
            t.default = f;
        }).call(this, e("543d").default);
    },
    c5d4: function(n, t, e) {},
    e110: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("c0e2"), t(e("66fd")), n(t(e("8374")).default);
        }).call(this, e("543d").createPage);
    }
}, [ [ "e110", "common/runtime", "common/vendor" ] ] ]);