// thanksgiving/activity/index.js
Page({data: {}})