(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/uni-icons/uni-icons" ], {
    1190: function(n, e, t) {
        var o = t("4ea4");
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var c = o(t("9461")), i = {
            name: "UniIcons",
            props: {
                type: {
                    type: String,
                    default: ""
                },
                color: {
                    type: String,
                    default: "#333333"
                },
                size: {
                    type: [ Number, String ],
                    default: 16
                }
            },
            data: function() {
                return {
                    icons: c.default
                };
            },
            methods: {
                _onClick: function() {
                    this.$emit("click");
                }
            }
        };
        e.default = i;
    },
    "198a": function(n, e, t) {
        t.r(e);
        var o = t("1190"), c = t.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(i);
        e.default = c.a;
    },
    4389: function(n, e, t) {},
    5240: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    6093: function(n, e, t) {
        t.r(e);
        var o = t("5240"), c = t("198a");
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(n) {
            t.d(e, n, function() {
                return c[n];
            });
        }(i);
        t("bca4");
        var u = t("f0c5"), a = Object(u.a)(c.default, o.b, o.c, !1, null, "beec3ea8", null, !1, o.a, void 0);
        e.default = a.exports;
    },
    bca4: function(n, e, t) {
        var o = t("4389");
        t.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/uni-icons/uni-icons-create-component", {
    "components/uni-icons/uni-icons-create-component": function(n, e, t) {
        t("543d").createComponent(t("6093"));
    }
}, [ [ "components/uni-icons/uni-icons-create-component" ] ] ]);