(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webView/indexSJ" ], {
    3458: function(e, n, o) {
        (function(e) {
            var t = o("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var c = t(o("f3d4")), i = t(o("7d43")), a = {
                data: function() {
                    return {
                        webviewStyles: {
                            progress: {
                                color: "#FF3333"
                            }
                        },
                        url: "",
                        urlLink: "",
                        code: "",
                        showloginDialog: !1
                    };
                },
                onLoad: function(n) {
                    console.log(n);
                    var o = "undefined" == decodeURIComponent(n.scene) ? "" : decodeURIComponent(n.scene);
                    console.log("进入1", o), o && (this.code = o), e.setStorageSync("smsSource", "SJLH_ZZ"), 
                    e.setStorageSync("channelLabel", "SJLH_ZZ");
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("d6e5"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                onShow: function() {
                    Object.keys(e.getStorageSync("logininfo")).length > 0 ? (i.default.recordPv(), i.default.getRecord(), 
                    e.hideShareMenu(), e.setNavigationBarTitle({
                        title: "哈根达斯“钱兔”似锦礼盒预约提领"
                    }), "release" == c.default.envVersion ? this.urlLink = "https://hd-sp.rydeen.com.cn/coupon-booking/booking?bizType=seasons_gift&channel=SNMIN&couponNo=" + this.code : this.urlLink = "https://hd-uat.rydeen.com.cn/coupon-booking/booking?bizType=seasons_gift&channel=SNMIN&couponNo=" + this.code) : this.showloginDialog = !0;
                }
            };
            n.default = a;
        }).call(this, o("543d").default);
    },
    "3ef2": function(e, n, o) {
        (function(e) {
            var n = o("4ea4");
            o("a1ea"), n(o("66fd"));
            var t = n(o("b336"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = o, e(t.default);
        }).call(this, o("543d").createPage);
    },
    "4eb1": function(e, n, o) {
        o.r(n);
        var t = o("3458"), c = o.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = c.a;
    },
    b336: function(e, n, o) {
        o.r(n);
        var t = o("cf2c"), c = o("4eb1");
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(n, e, function() {
                return c[e];
            });
        }(i);
        var a = o("f0c5"), l = Object(a.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        n.default = l.exports;
    },
    cf2c: function(e, n, o) {
        o.d(n, "b", function() {
            return t;
        }), o.d(n, "c", function() {
            return c;
        }), o.d(n, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    }
}, [ [ "3ef2", "common/runtime", "common/vendor" ] ] ]);