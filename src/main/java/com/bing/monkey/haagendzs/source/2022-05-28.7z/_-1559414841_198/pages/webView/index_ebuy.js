(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webView/index_ebuy" ], {
    "9d50": function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0, function(n) {
            n && n.__esModule;
        }(t("f0fd"));
        var u = {
            data: function() {
                return {
                    webviewStyles: {
                        progress: {
                            color: "#FF3333"
                        }
                    },
                    url: "",
                    urlLink: ""
                };
            },
            onLoad: function(n) {
                this.url = decodeURIComponent(n.url);
            },
            onShow: function() {}
        };
        e.default = u;
    },
    a624: function(n, e, t) {
        t.r(e);
        var u = t("9d50"), o = t.n(u);
        for (var c in u) "default" !== c && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(c);
        e.default = o.a;
    },
    be8a: function(n, e, t) {
        t.r(e);
        var u = t("bfb5"), o = t("a624");
        for (var c in o) "default" !== c && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        var f = t("f0c5"), r = Object(f.a)(o.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        e.default = r.exports;
    },
    bfb5: function(n, e, t) {
        t.d(e, "b", function() {
            return u;
        }), t.d(e, "c", function() {
            return o;
        }), t.d(e, "a", function() {});
        var u = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    c119: function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t("c0e2"), e(t("66fd")), n(e(t("be8a")).default);
        }).call(this, t("543d").createPage);
    }
}, [ [ "c119", "common/runtime", "common/vendor" ] ] ]);