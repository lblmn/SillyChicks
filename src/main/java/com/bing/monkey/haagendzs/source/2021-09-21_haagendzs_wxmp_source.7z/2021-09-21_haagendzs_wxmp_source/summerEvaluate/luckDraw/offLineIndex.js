// summerEvaluate/luckDraw/offLineIndex.js
Page({data: {}})