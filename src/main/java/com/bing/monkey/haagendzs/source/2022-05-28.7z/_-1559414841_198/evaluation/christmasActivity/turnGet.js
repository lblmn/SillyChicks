// evaluation/christmasActivity/turnGet.js
Page({data: {}})