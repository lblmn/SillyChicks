(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/exchange" ], {
    "16c1": function(e, o, n) {
        n.r(o);
        var t = n("59db"), c = n("3017");
        for (var i in c) "default" !== i && function(e) {
            n.d(o, e, function() {
                return c[e];
            });
        }(i);
        n("3343");
        var a = n("f0c5"), d = Object(a.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = d.exports;
    },
    3017: function(e, o, n) {
        n.r(o);
        var t = n("5afe"), c = n.n(t);
        for (var i in t) "default" !== i && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(i);
        o.default = c.a;
    },
    3343: function(e, o, n) {
        var t = n("f088");
        n.n(t).a;
    },
    "59db": function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return c;
        }), n.d(o, "a", function() {});
        var t = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, c = [];
    },
    "5afe": function(e, o, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function c(e, o) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    o && (t = t.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), n.push.apply(n, t);
                }
                return n;
            }
            function i(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var n = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? c(Object(n), !0).forEach(function(o) {
                        a(e, o, n[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(n, o));
                    });
                }
                return e;
            }
            function a(e, o, n) {
                return o in e ? Object.defineProperty(e, o, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[o] = n, e;
            }
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var d = t(n("bdeb")), u = t(n("d7df")), r = t(n("1d54")), s = t(n("e81b")), l = getApp(), f = {
                components: {
                    uniIcons: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(n("349f"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        qrcode: "",
                        obj: {},
                        couponRuleId: "",
                        effectEnd: "",
                        getcity: "",
                        isCanvasImg: "",
                        showbtn: !1,
                        typeFrom: !1
                    };
                },
                onLoad: function(e) {
                    console.log(e);
                    var o = JSON.parse(decodeURIComponent(e.obj));
                    console.log(o), this.obj = i(i({}, o), {}, {
                        ruleDesc: o.ruleDesc.replace(/\n/g, "<br>")
                    }), this.qrcode = e.couponCode, this.couponRuleId = e.couponRuleId, this.couponCode = e.couponCode, 
                    this.showbtn = e.showbtn, this.typeFrom = e.typeFrom, this.make(), e.effectEnd && (this.effectEnd = this.$util.dateFormat("YYYY年mm月dd日", new Date(e.effectEnd.replace(/-/g, "/")))), 
                    this.getcity = s.default.filter(function(e) {
                        return e.code == o.cityCode;
                    }).length > 0 ? s.default.filter(function(e) {
                        return e.code == o.cityCode;
                    })[0].text : "";
                },
                onShow: function() {
                    this.isCanvasImg || this.make(), this.getPoints();
                },
                onHide: function() {
                    l.globalData.istransfer = !1;
                },
                methods: {
                    make: function() {
                        var o = this;
                        d.default.make({
                            canvasId: "qrcode",
                            componentInstance: this,
                            text: this.qrcode,
                            size: e.upx2px(292),
                            margin: 10,
                            backgroundColor: "#ffffff",
                            foregroundColor: "#000000",
                            fileType: "jpg",
                            correctLevel: d.default.defaults.correctLevel,
                            success: function(e) {
                                o.isCanvasImg = e;
                            }
                        });
                    },
                    transfer: function() {
                        e.showLoading({
                            mask: !0,
                            title: "加载中..."
                        });
                        var o = [ "16HZcE2q00008e00", "16HZcE4H00009100", "16HZcE5h00009400", "16HZcE6R00009700", "16HZcE7x00009a00", "16HaE49q00007900", "16HaE4Pe00007500", "16HaE4Uw00007f00", "16HaE4Uw00007f00", "16HaE4md00007800", "16HaE51V00007b00", "16Hb2EZz00008800", "16Hb2Eey00008700", "16HQ4edg00001d00", "16HQ4ebn00001a00", "16HaE1Vu0000a100", "16Hb2EWZ00008500" ], n = [ "16HaQ1eW0000ad00", "16HaQ1eu0000ae00", "16HaQ1fu0000af00", "16Hb25MK00008400", "16Hb25Mg00008500", "16Hb25My00008600" ], t = [ "16XHhMdG00009200", "16XHhMjT0000ad00", "16XHsckE0000b800", "16XHscoa0000d400", "16XHscs70000d700", "16XHseM60000da00", "16XHseQV0000dd00", "16XQfj9c0000dc00", "16XQfjBL0000df00", "16XQfjCv0000e200", "16XQgbRg0000e500", "16XQgbV40000e800", "16XQgbkL00010400", "16XQgbqV0000d500", "16XQs74E00000a00", "16XRZbF700002900", "16XRZbki00002f00", "16XQs7tW00011000" ], c = [ "16XG7Fw20000a000", "16XG7Fub00009e00", "16XG23EQ00004100", "16XG23EA00004000", "16XG7Fw20000a000", "16XG7Fub00009e00", "16HZcEPN00009d00", "16HZsSWt00007800", "16X9Dn7D00009c00", "16HYYpXw00007b00", "16XG23Ch00003e00" ], i = this.obj.couponCode, a = this.obj.couponRuleCode;
                        "mooncard" == this.typeFrom && (i = this.couponCode, a = this.couponRuleId), "16HYjDy800006e00" == this.obj.couponBagCode ? e.redirectTo({
                            url: "/pages/calendarActivity/turnIndex?couponCode=" + this.couponCode,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XQs8Ei00011c00" == this.obj.couponBagCode || "16XQs7SQ00001600" == this.obj.couponBagCode || "16XRa7Qr00003800" == this.obj.couponBagCode ? e.redirectTo({
                            url: "/pureFeeling/hdShare/turnIndex?couponCode=" + i,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : n.indexOf(this.obj.couponBagCode) >= 0 ? e.redirectTo({
                            url: "/pages/makeUpForever/turnIndex?couponCode=" + this.couponCode,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : c.indexOf(this.obj.couponBagCode) >= 0 ? "16X9Dn7D00009c00" == this.obj.couponBagCode || "16HYYpXw00007b00" == this.obj.couponBagCode || "16XG23Ch00003e00" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + i + "&activityType=newYearType",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XG7Fub00009e00" == this.obj.couponBagCode || "16XG23EA00004000" == this.obj.couponBagCode || "16XG7Fub00009e00" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + i + "&activityType=loveGolden",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XG7Fw20000a000" == this.obj.couponBagCode || "16XG23EQ00004100" == this.obj.couponBagCode || "16XG7Fw20000a000" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + i + "&activityType=lovePink",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + i,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : t.indexOf(a) >= 0 ? e.navigateTo({
                            url: "/pureFeeling/hdShare/turnIndex?couponCode=" + i,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : o.indexOf(a) >= 0 ? e.navigateTo({
                            url: "/pureFeeling/cameraHome/turnIndex?couponCode=" + i,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16X9DnM500002500" == this.obj.couponBagCode || "16XG7cAN0000a200" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pureFeeling/cameraHome/turnIndex?type=winterGet&couponCode=" + i + "&couponRuleCode=" + a,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : (a = a.indexOf("_") > 0 ? a.split("_")[0] : a, r.default.findGet({
                            couponRuleId: a,
                            ops: {
                                couponRuleId: "equal"
                            }
                        }).then(function(o) {
                            if (console.log(o), 0 == o.code) {
                                var n = o.data.forwardViewUrl;
                                n.includes("?") ? n += "&couponRuleCode=" + a + "&couponCode=" + i + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)) : n += "?couponRuleCode=" + a + "&couponCode=" + i + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)), 
                                e.navigateTo({
                                    url: n,
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            } else e.navigateTo({
                                url: "/pages/luckbag/turnIndex?couponCode=" + i,
                                complete: function() {
                                    e.hideLoading();
                                }
                            });
                        }).catch(function() {
                            e.navigateTo({
                                url: "/pages/luckbag/turnIndex?couponCode=" + i,
                                complete: function() {
                                    e.hideLoading();
                                }
                            });
                        }));
                    },
                    findWeixinCard: function() {
                        e.openCard({
                            cardList: [ {
                                cardId: this.obj.wxCardId,
                                code: this.couponCode
                            } ],
                            success: function(e) {}
                        });
                    },
                    getPoints: function() {
                        r.default.point({
                            idType: "1",
                            id: e.getStorageSync("socialhubId")
                        }).then(function(e) {
                            0 == e.resultCode && (getApp().globalData.PointAccount = e.data);
                        });
                    },
                    changeCard: function() {
                        var o = encodeURIComponent("https://www.gmec.top/hgdz_dwz/ticketExchange.html");
                        e.navigateTo({
                            url: "../webView/indexN?url=" + o
                        });
                    },
                    addToWeixinCard: function() {
                        var o = this;
                        u.default.convertWxCardId({
                            couponRuleId: this.couponRuleId
                        }).then(function(n) {
                            u.default.getJsCardSignature({
                                code: o.qrcode,
                                cardId: n.data.wxCardId,
                                openId: e.getStorageSync("openId")
                            }).then(function(e) {
                                console.log("调getjscard签名", e);
                                var o = e.data, n = o.cardId, t = o.cardSign, c = o.openId, i = o.nonceStr, a = o.timestamp, d = {
                                    code: o.code,
                                    cardId: n,
                                    signature: t,
                                    openid: c,
                                    nonce_str: i,
                                    timestamp: a,
                                    outer_str: "miniProgram"
                                };
                                console.log(JSON.stringify(d)), wx.addCard({
                                    cardList: [ {
                                        cardId: n,
                                        cardExt: JSON.stringify(d)
                                    } ],
                                    success: function(e) {
                                        console.log(e);
                                    },
                                    fail: function(e) {
                                        console.log(e);
                                    }
                                });
                            });
                        });
                    }
                }
            };
            o.default = f;
        }).call(this, n("543d").default);
    },
    "73ea": function(e, o, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("f4aa"), o(n("66fd")), e(o(n("16c1")).default);
        }).call(this, n("543d").createPage);
    },
    f088: function(e, o, n) {}
}, [ [ "73ea", "common/runtime", "common/vendor" ] ] ]);