(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/call" ], {
    "060a": function(n, e, o) {
        o.r(e);
        var t = o("e442"), a = o.n(t);
        for (var u in t) [ "default" ].indexOf(u) < 0 && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(u);
        e.default = a.a;
    },
    "321f": function(n, e, o) {
        o.r(e);
        var t = o("e9d9"), a = o("060a");
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(n) {
            o.d(e, n, function() {
                return a[n];
            });
        }(u);
        o("5655");
        var c = o("f0c5"), i = Object(c.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = i.exports;
    },
    "45f6": function(n, e, o) {
        (function(n) {
            var e = o("4ea4");
            o("a1ea"), e(o("66fd"));
            var t = e(o("321f"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = o, n(t.default);
        }).call(this, o("543d").createPage);
    },
    5655: function(n, e, o) {
        var t = o("8abb");
        o.n(t).a;
    },
    "8abb": function(n, e, o) {},
    e442: function(n, e, o) {
        (function(n) {
            var t = o("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = t(o("7d43")), u = {
                components: {
                    uniIcons: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(o("6093"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Zswiper: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/Zswiper") ]).then(function() {
                            return resolve(o("4483"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        showBtn: !0
                    };
                },
                onLoad: function() {
                    a.default.recordPv();
                },
                methods: {
                    callPhone: function() {
                        n.makePhoneCall({
                            phoneNumber: "400 820 7917"
                        });
                    }
                }
            };
            e.default = u;
        }).call(this, o("543d").default);
    },
    e9d9: function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return a;
        }), o.d(e, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    }
}, [ [ "45f6", "common/runtime", "common/vendor" ] ] ]);