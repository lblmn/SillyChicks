(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/Zdetail" ], {
    "13ec": function(n, e, t) {
        var c = t("f482");
        t.n(c).a;
    },
    "1fcc": function(n, e, t) {
        t.d(e, "b", function() {
            return c;
        }), t.d(e, "c", function() {
            return o;
        }), t.d(e, "a", function() {});
        var c = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, o = [];
    },
    "25c3": function(n, e, t) {
        t.r(e);
        var c = t("1fcc"), o = t("7c7c");
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        t("13ec");
        var u = t("f0c5"), f = Object(u.a)(o.default, c.b, c.c, !1, null, null, null, !1, c.a, void 0);
        e.default = f.exports;
    },
    "7c7c": function(n, e, t) {
        t.r(e);
        var c = t("ac3e"), o = t.n(c);
        for (var a in c) "default" !== a && function(n) {
            t.d(e, n, function() {
                return c[n];
            });
        }(a);
        e.default = o.a;
    },
    ac3e: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var c = {
            name: "Zdetail",
            props: {
                name: "",
                num: "",
                time: ""
            },
            methods: {}
        };
        e.default = c;
    },
    f482: function(n, e, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/Zdetail-create-component", {
    "components/Zdetail-create-component": function(n, e, t) {
        t("543d").createComponent(t("25c3"));
    }
}, [ [ "components/Zdetail-create-component" ] ] ]);