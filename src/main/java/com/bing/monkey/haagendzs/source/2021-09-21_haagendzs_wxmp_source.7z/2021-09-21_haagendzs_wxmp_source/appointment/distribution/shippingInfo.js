// appointment/distribution/shippingInfo.js
Page({data: {}})