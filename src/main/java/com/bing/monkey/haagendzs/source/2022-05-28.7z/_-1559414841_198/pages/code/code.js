(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/code/code" ], {
    2255: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = l(n("a34a")), a = l(n("727b")), i = l(n("c1f6")), c = l(n("500b")), r = l(n("234f")), s = l(n("f0fd")), u = n("26cb");
            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function f(e, t, n, o, a, i, c) {
                try {
                    var r = e[i](c), s = r.value;
                } catch (e) {
                    return void n(e);
                }
                r.done ? t(s) : Promise.resolve(s).then(o, a);
            }
            function d(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function m(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? d(Object(n), !0).forEach(function(t) {
                        g(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : d(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function g(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            var v = getApp(), h = {
                components: {
                    uniIcons: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(n("fafe"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    headerimg: function() {
                        n.e("components/headerimg").then(function() {
                            return resolve(n("a806"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        qrcode: e.getStorageSync("logininfo").cardNumber,
                        imgUX: s.default.ossurl + "UX",
                        showFlag: !1,
                        ruleDesc: "",
                        showCanvas: !0,
                        canvasImg: "",
                        timeObj: "",
                        dynamicCode: "",
                        showLoad: !1,
                        codetime: 30,
                        sevtime: "",
                        desname: "",
                        expiryTimeEnd: "",
                        startTime: "",
                        endTime: "",
                        dtime: "",
                        timeTZ: "",
                        hasWxtX: !0,
                        avatarUrl: ""
                    };
                },
                onLoad: function() {
                    this.getRuleDesc();
                },
                onShow: function() {
                    v.hxt.sendAction("member_clk"), r.default.recordPv(), this.make(), e.getStorageSync("wxuserinfoAvatar") ? (this.hasWxtX = !1, 
                    this.avatarUrl = e.getStorageSync("wxuserinfoAvatar")) : this.hasWxtX = !0;
                },
                computed: m(m({}, (0, u.mapState)([ "points", "navbarHeight_a" ])), (0, u.mapGetters)([ "userinfoBg" ])),
                onHide: function() {
                    console.log("关闭");
                },
                onUnload: function() {},
                methods: {
                    newInfoA: function() {
                        var t = this;
                        return function(e) {
                            return function() {
                                var t = this, n = arguments;
                                return new Promise(function(o, a) {
                                    var i = e.apply(t, n);
                                    function c(e) {
                                        f(i, o, a, c, r, "next", e);
                                    }
                                    function r(e) {
                                        f(i, o, a, c, r, "throw", e);
                                    }
                                    c(void 0);
                                });
                            };
                        }(o.default.mark(function n() {
                            var a;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.getNewUserInfo();

                                  case 2:
                                    a = n.sent, console.log(a), e.setStorageSync("wxuserinfoAvatar", a.userInfo.avatarUrl), 
                                    t.avatarUrl = a.userInfo.avatarUrl, t.hasWxtX = !1;

                                  case 7:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getNewUserInfo: function() {
                        return new Promise(function(t, n) {
                            e.getUserProfile({
                                desc: "会员信息",
                                success: function(e) {
                                    console.log(e), t(e);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    refreash: function() {
                        this.clearGetCode(), this.showLoad = !0, this.getdynamiccode();
                    },
                    clearGetCode: function() {
                        console.log("清除"), clearTimeout(this.timeObj), clearInterval(this.sevtime), console.log(this.sevtime), 
                        this.timeObj = "", this.sevtime = "", this.codetime = 30;
                    },
                    getdynamiccode: function() {
                        var t = this;
                        c.default.getdynamiccode({
                            idType: "2",
                            id: e.getStorageSync("unionId"),
                            flag: 1
                        }).then(function(e) {
                            console.log(e), 0 == e.resultCode && (t.dynamicCode = e.data.dynamicCode, t.showCanvas = !0, 
                            t.canvasImg = "", t.desname = e.data.dynamicCode, t.expiryTimeEnd = r.default.getMyDate(e.data.expiryTimeEnd), 
                            t.timeTZ = r.default.getMyDate(e.data.time), t.make(), t.getCode(e.data.expiryTimeEnd, e.data.time), 
                            t.codeTimeFun(), t.showLoad = !1);
                        });
                    },
                    getCode: function(e, t) {
                        var n = this;
                        clearTimeout(n.timeObj), n.timeObj = "";
                        var o = new Date().getTime();
                        console.log(e - o);
                        var a = e - t;
                        console.log(a), this.startTime = r.default.getMyDate(o), console.log("开始时间:", o), 
                        this.dtime = a, n.timeObj = setTimeout(function() {
                            var e = new Date().getTime();
                            console.log("结束时间:", e);
                            var t = e - o;
                            console.log("时间差", t), clearInterval(n.sevtime), n.codetime = 30, clearTimeout(n.timeObj), 
                            n.getdynamiccode(), n.showLoad = !0;
                        }, a);
                    },
                    codeTimeFun: function() {
                        var e = this;
                        clearInterval(this.sevtime), this.sevtime = "", this.sevtime = setInterval(function() {
                            e.codetime = e.codetime - 1, console.log(e.codetime);
                        }, 1e3);
                    },
                    make: function() {
                        var t = this;
                        a.default.make({
                            canvasId: "qrcode",
                            componentInstance: this,
                            text: this.qrcode,
                            size: e.upx2px(336),
                            margin: 10,
                            backgroundColor: "#ffffff",
                            foregroundColor: "#000000",
                            fileType: "jpg",
                            correctLevel: a.default.defaults.correctLevel,
                            success: function(e) {
                                console.log(e), t.canvasImg = e, t.showCanvas = !1;
                            }
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        i.default.getRuledesc({
                            type: 1
                        }).then(function(t) {
                            e.ruleDesc = t.data[0].content;
                        });
                    },
                    gocode: function() {
                        this.showFlag = !0, this.showCanvas = !1;
                    },
                    navigateTo: function(t) {
                        v.hxt.sendAction("point_go"), e.navigateTo({
                            url: t
                        });
                    },
                    switchTab: function(t) {
                        e.switchTab({
                            url: t
                        });
                    }
                }
            };
            t.default = h;
        }).call(this, n("543d").default);
    },
    2791: function(e, t, n) {
        n.r(t);
        var o = n("2255"), a = n.n(o);
        for (var i in o) "default" !== i && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        t.default = a.a;
    },
    "33e1": function(e, t, n) {
        n.r(t);
        var o = n("7af3"), a = n("2791");
        for (var i in a) "default" !== i && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        n("4ec9");
        var c = n("f0c5"), r = Object(c.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = r.exports;
    },
    "4ec9": function(e, t, n) {
        var o = n("a496");
        n.n(o).a;
    },
    "7af3": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.showFlag = !1;
            }, e.e1 = function(t) {
                e.showFlag = !1;
            });
        }, a = [];
    },
    "7c00": function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("c0e2"), t(n("66fd")), e(t(n("33e1")).default);
        }).call(this, n("543d").createPage);
    },
    a496: function(e, t, n) {}
}, [ [ "7c00", "common/runtime", "common/vendor" ] ] ]);