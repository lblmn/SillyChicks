var e = require("../../@babel/runtime/helpers/interopRequireDefault");

require("../../@babel/runtime/helpers/Arrayincludes");

var o = e(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/mycard" ], {
    "342e": function(e, o, t) {
        (function(e) {
            var o = t("4ea4");
            t("a1ea"), o(t("66fd"));
            var n = o(t("ffa8"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("543d").createPage);
    },
    7680: function(e, o, t) {
        t.r(o);
        var n = t("d4b7"), i = t.n(n);
        for (var a in n) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(o, e, function() {
                return n[e];
            });
        }(a);
        o.default = i.a;
    },
    c525: function(e, o, t) {},
    cd54: function(e, o, t) {
        t.d(o, "b", function() {
            return n;
        }), t.d(o, "c", function() {
            return i;
        }), t.d(o, "a", function() {});
        var n = function() {
            var e = this, o = (e.$createElement, e._self._c, 0 == e.indexs ? Object.keys(e.resultListTotal) : null), t = 0 != e.indexs && 2 != e.indexs ? e.__map(e.tabs2, function(o, t) {
                return {
                    $orig: e.__get_orig(o),
                    l0: e.cardList.length > 0 || e.voucherList.length > 0 ? e.__map(e.cardList, function(o, t) {
                        return {
                            $orig: e.__get_orig(o),
                            m0: o.validStartTime ? e.formTime(o.validStartTime) : null,
                            m1: o.validStartTime ? e.formTime(o.validEndTime) : null
                        };
                    }) : null,
                    l1: e.cardList.length > 0 || e.voucherList.length > 0 ? e.__map(e.voucherList, function(o, t) {
                        return {
                            $orig: e.__get_orig(o),
                            m2: o.validStartTime ? e.formTime(o.validStartTime) : null,
                            m3: o.validStartTime ? e.formTime(o.validEndTime) : null
                        };
                    }) : null
                };
            }) : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    g0: o,
                    l2: t
                }
            });
        }, i = [];
    },
    d4b7: function(e, n, i) {
        (function(e) {
            var a = i("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var s = a(i("9523")), r = (a(i("bc67")), a(i("9296"))), c = a(i("0098")), l = a(i("5db4")), d = (a(i("fa26")), 
            a(i("3724"))), u = a(i("9619")), g = a(i("f3d4")), h = a(i("7d43"));
            function f(e, o) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    o && (n = n.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), t.push.apply(t, n);
                }
                return t;
            }
            function p(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var t = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? f(Object(t), !0).forEach(function(o) {
                        (0, s.default)(e, o, t[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : f(Object(t)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(t, o));
                    });
                }
                return e;
            }
            a(i("8865"));
            var m, v, S = getApp().globalData.N_ENV.assetsRoot, b = {
                components: {
                    uniIcons: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(i("6093"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/loginDialog_new") ]).then(function() {
                            return resolve(i("5972"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    Loading: function() {
                        i.e("components/loading").then(function() {
                            return resolve(i("64ff"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    mycardList: function() {
                        i.e("components/mycard-list/main").then(function() {
                            return resolve(i("d78b"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                data: function() {
                    return {
                        indexs: 0,
                        tabActive: 1e8,
                        tabs: [ {
                            name: 1e8,
                            title: "可使用"
                        }, {
                            name: 100000001,
                            title: "已使用"
                        }, {
                            name: 100000002,
                            title: "已过期/失效"
                        }, {
                            name: 100000007,
                            title: "券转赠"
                        } ],
                        tabActive1: 1e8,
                        tabs1: [ {
                            name: 1e8,
                            title: "可使用"
                        }, {
                            name: 100000001,
                            title: "已使用"
                        }, {
                            name: 100000002,
                            title: "已过期/失效"
                        }, {
                            name: 100000007,
                            title: "券转赠"
                        } ],
                        tabActive2: 1e8,
                        tabs2: [ {
                            name: 1e8,
                            title: "可使用"
                        }, {
                            name: 100000001,
                            title: "已失效"
                        } ],
                        resultList: [],
                        nextId: "",
                        pageSize: 10,
                        noMore: !1,
                        isFirstNoChange: !0,
                        showloginDialog: !1,
                        cardList: [],
                        voucherList: [],
                        imgoss: g.default.ossurl + "images/home/",
                        isGongGao: !0,
                        isHeightScreen: !1,
                        pageNumber: 1,
                        pageTotal: 0,
                        pageListTotal: 0,
                        resultListTotal: {},
                        is14YearsOld: -1,
                        isShow_flag14: !1
                    };
                },
                onLoad: function(o) {
                    var t = this;
                    console.log(o), h.default.isHeightPhone().then(function(e) {
                        t.isHeightScreen = e;
                    }).catch(function(e) {
                        t.isHeightScreen = e;
                    }), this.source = o.soure ? o.soure : o.source, e.setStorageSync("source", this.source), 
                    h.default.setSource(o), this.indexs = o.indexs ? +o.indexs : 0, o.indexs && 0 != o.indexs ? 2 == o.indexs && (this.tabActive1 = o.tabActive1 ? +o.tabActive1 : 1e8) : this.tabActive = o.tabActive ? +o.tabActive : 1e8, 
                    1e8 != this.tabActive && (this.isFirstNoChange = !1), console.log("执行onLoad1");
                },
                onShow: (v = t(o.default.mark(function t() {
                    return o.default.wrap(function(o) {
                        for (;;) switch (o.prev = o.next) {
                          case 0:
                            this.nextId = "", this.resultList = [], this.pageNumber = 1, this.pageListTotal = 0, 
                            this.noMore = !1, "all" == e.getStorageSync("successInfo") && e.removeStorageSync("successInfo"), 
                            console.log("执行onshow1"), e.getStorageSync("logininfo") ? (h.default.recordPv(), 
                            h.default.getRecord(), console.log("执行onshow2"), "Traffic-CD" == e.getStorageSync("smsSource") && "Traffic-CD" == e.getStorageSync("channelLabel") ? (console.log("进来了"), 
                            this.getFromCard()) : this.getCardList()) : (console.log("执行onshow3"), this.showloginDialog = !0);

                          case 1:
                          case "end":
                            return o.stop();
                        }
                    }, t, this);
                })), function() {
                    return v.apply(this, arguments);
                }),
                methods: {
                    gotoDetailList: function(o) {
                        console.log(o), getApp().hxt.sendAction("coupon_all_clk", {
                            coupon_type: o
                        }), e.navigateTo({
                            url: "/pages/mine/mycardDetailList?vouchersource=" + o
                        });
                    },
                    getmemberForProgress_year: function() {
                        var o = this;
                        r.default.getmemberForProgress({
                            idType: "2",
                            id: e.getStorageSync("unionId"),
                            type: "11"
                        }).then(function(e) {
                            0 == e.resultCode ? (o.$store.commit("is14YearsOldFun", e.data.is14YearsOld), o.is14YearsOld = e.data.is14YearsOld, 
                            1 == o.is14YearsOld ? o.isShow_flag14 = !1 : 0 == o.is14YearsOld && (o.isShow_flag14 = !0)) : (o.$store.commit("is14YearsOldFun", -1), 
                            o.is14YearsOld = -1, o.isShow_flag14 = !1);
                        }).catch(function() {
                            o.$store.commit("is14YearsOldFun", -1), o.is14YearsOld = -1, o.isShow_flag14 = !1;
                        });
                    },
                    gotoMine: function() {
                        var o = this;
                        e.navigateTo({
                            url: "/pages/mine/info?source=fromIndex",
                            success: function() {
                                o.isShow_flag14 = !1;
                            }
                        });
                    },
                    getmemberSuccess: (m = t(o.default.mark(function t(n) {
                        return o.default.wrap(function(o) {
                            for (;;) switch (o.prev = o.next) {
                              case 0:
                                console.log(n), "all" == n ? (this.showloginDialog = !1, h.default.recordPv(), h.default.getRecord(), 
                                console.log("执行onshow2"), "Traffic-CD" == e.getStorageSync("smsSource") && "Traffic-CD" == e.getStorageSync("channelLabel") ? (console.log("进来了"), 
                                this.getFromCard()) : this.getCardList(), this.$refs.Loading.hideLoading()) : "error" == n && this.$refs.Loading.hideLoading();

                              case 1:
                              case "end":
                                return o.stop();
                            }
                        }, t, this);
                    })), function(e) {
                        return m.apply(this, arguments);
                    }),
                    gotoTl: function(o) {
                        var t = ("release" == g.default.envVersion ? "https://hd.rydeen.com.cn/coupon-booking/booking" : "https://hd-uat.rydeen.com.cn/coupon-booking/booking") + "?couponNo=" + o.couponCode;
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + encodeURIComponent(t)
                        });
                    },
                    getFromCard: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var t = new Date().getTime();
                        d.default.pyqCoupon({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            appId: "wx3656c2a2353eb377",
                            sign: h.default.mdString(t, {
                                unionId: e.getStorageSync("unionId"),
                                openId: e.getStorageSync("openId")
                            }),
                            timestamp: t
                        }).then(function(e) {
                            0 == e.code ? setTimeout(function() {
                                o.getCardList();
                            }, 1500) : o.getCardList();
                        }).catch(function() {
                            o.getCardList();
                        });
                    },
                    getCardList: function() {
                        0 == this.indexs ? (this.getListTotal(), e.getStorageSync("source") && this.getRecord()) : 2 == this.indexs && (100000007 == this.tabActive1 ? (console.log("这是转赠记录"), 
                        this.getList_records_moon()) : this.getList_moon(), e.getStorageSync("source") && this.getRecord());
                    },
                    gotoType: function(o) {
                        if (console.log(o), 1e8 != this.tabActive2) return !1;
                        if (o.canGogoMiniProgram) this.gotoMiniprogram(o); else if ("esc" == o.voucherSource) {
                            var t = o.templateUrl, n = encodeURIComponent(t);
                            if (!n) return !1;
                            e.navigateTo({
                                url: "/pages/webView/indexN?url=" + n
                            });
                        } else {
                            var i = o.templateUrl, a = encodeURIComponent(i);
                            if (!a) return !1;
                            e.navigateTo({
                                url: "/pages/webView/indexN?url=" + a
                            });
                        }
                    },
                    gotoMiniprogramBoth: function() {
                        getApp().hxt.sendAction("gift_card_available_use_now", {
                            gift_card_name: "额外小程序",
                            gift_card_id: "wxf83dc13b5390d17b"
                        }), e.navigateToMiniProgram({
                            appId: "wxf83dc13b5390d17b",
                            path: "pages/index/index",
                            success: function(e) {}
                        });
                    },
                    gotoMiniprogram: function(o) {
                        var t, n;
                        console.log(o), getApp().hxt.sendAction("gift_card_available_use_now", {
                            gift_card_name: null == o ? void 0 : o.voucherName,
                            gift_card_id: null == o ? void 0 : o.ebuyMemberId
                        });
                        var i = null === (t = o.voucherExtend.jumpInfo) || void 0 === t ? void 0 : t.jumpAppId, a = null === (n = o.voucherExtend.jumpInfo) || void 0 === n ? void 0 : n.jumpButtonParam;
                        e.navigateToMiniProgram({
                            appId: i,
                            path: a,
                            success: function(e) {}
                        });
                    },
                    gotoUrl: function(o) {
                        console.log(o), getApp().hxt.sendAction("gift_card_available_to_order", {
                            gift_card_name: o.voucherName,
                            gift_card_id: o.ebuyMemberId
                        });
                        var t = o.templateUrl, n = encodeURIComponent(t);
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + n
                        });
                    },
                    formTime: function(e) {
                        return e.substring(0, 8).replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");
                    },
                    onChange2: function(e) {
                        this.$refs.Loading.showLoading(), this.tabActive2 = e.detail.name, 1e8 == this.tabActive2 ? getApp().hxt.sendAction("gift_card_available_clk") : getApp().hxt.sendAction("gift_card_expired_clk"), 
                        this.cardList = [], this.voucherList = [], this.getList_cards();
                    },
                    getList_cards: function() {
                        var o = this, t = {
                            socialhubId: e.getStorageSync("socialhubId"),
                            cardType: ""
                        };
                        100000001 == this.tabActive2 && (t = {
                            socialhubId: e.getStorageSync("socialhubId"),
                            cardType: "1"
                        }), u.default.getList(t).then(function(e) {
                            if (console.log("列表", e.resultCode), 0 == e.code) {
                                0 == e.data.cardList.length && 0 == e.data.voucherList.length && (o.noMore = !0);
                                var t = e.data.cardList.map(function(e) {
                                    if (null != e && e.voucherExtend) {
                                        var o = JSON.parse(e.voucherExtend).jumpInfo;
                                        console.log(JSON.parse(e.voucherExtend)), e.voucherExtend = JSON.parse(e.voucherExtend), 
                                        null != o && o.jumpAppId && null != o && o.jumpButtonType ? e.canGogoMiniProgram = !0 : e.canGogoMiniProgram = !1;
                                    }
                                    return e;
                                });
                                o.cardList = t.filter(function(e) {
                                    return "esc" != e.voucherSource;
                                });
                                var n = e.data.voucherList.map(function(e) {
                                    if (null != e && e.voucherExtend) {
                                        var o = JSON.parse(e.voucherExtend).jumpInfo;
                                        console.log(JSON.parse(e.voucherExtend)), e.voucherExtend = JSON.parse(e.voucherExtend), 
                                        null != o && o.jumpAppId && null != o && o.jumpButtonType ? e.canGogoMiniProgram = !0 : e.canGogoMiniProgram = !1;
                                    }
                                    return e;
                                });
                                o.voucherList = n.filter(function(e) {
                                    return "esc" != e.voucherSource;
                                });
                            }
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    changeIndex: function(e) {
                        this.$refs.Loading.showLoading(), 0 == e ? (this.resultList = [], this.indexs = 0, 
                        this.tabActive = 1e8, this.pageNumber = 1, this.nextId = "", this.pageListTotal = 0, 
                        this.noMore = !1, getApp().hxt.sendAction("electronic_coupon_clk"), this.getListTotal()) : 2 == e ? (this.resultList = [], 
                        this.indexs = 2, this.tabActive1 = 1e8, this.pageNumber = 1, this.nextId = "", this.pageListTotal = 0, 
                        this.noMore = !1, getApp().hxt.sendAction("maf_coupon_clk"), this.getList_moon()) : (this.indexs = 1, 
                        this.tabActive2 = 1e8, this.nextId = "", getApp().hxt.sendAction("gift_card_clk"), 
                        getApp().hxt.sendAction("gift_card_available_clk"), this.getList_cards());
                    },
                    getRecord: function() {
                        l.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: e.getStorageSync("source") ? e.getStorageSync("source") : e.getStorageSync("smsSource")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getList_records: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var t = new Date().getTime(), n = {
                            thirdOpenId: e.getStorageSync("socialhubId"),
                            pageSize: this.pageSize,
                            pageNumber: this.pageNumber,
                            packageStatus: "DELIVERING,CANCELED,SUCCESS",
                            timestamp: t,
                            sign: h.default.mdString(t, {
                                openid: e.getStorageSync("openId"),
                                unionId: e.getStorageSync("unionId")
                            })
                        };
                        d.default.ebuyGetTransferRecord(n).then(function(e) {
                            if (o.$refs.Loading.hideLoading(), console.log(e), o.pageTotal = e.totalCount, 0 == e.dataList.length) return o.noMore = !0, 
                            !1;
                            e.dataList && e.dataList.length > 0 && e.dataList.forEach(function(e) {
                                o.resultList.push(p(p({}, e), {}, {
                                    imgUrlAll: e.imgUrl ? S + e.imgUrl : S + "/oss/wxapp/small.jpg"
                                }));
                            });
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    getList_records_moon: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var t = {
                            id: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            socialHubid: e.getStorageSync("socialhubId"),
                            flag: 0,
                            nextId: this.nextId,
                            pageSize: this.pageSize,
                            state: 0,
                            idType: 2
                        };
                        "" == this.nextId && delete t.nextId, d.default.tzGetTransferRecord(t).then(function(e) {
                            o.$refs.Loading.hideLoading(), console.log(e), 0 == e.resultCode && (e.data.nextId && (o.nextId = e.data.nextId), 
                            e.data.list && e.data.list.length > 0 && e.data.list.forEach(function(e) {
                                o.resultList.push(p(p({}, e), {}, {
                                    imgUrlAll: e.imgUrl ? S + e.imgUrl : S + "/oss/wxapp/small.jpg"
                                }));
                            }), e.data.nextId || (o.noMore = !0));
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    getList_moon: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var t = {
                            idType: 2,
                            id: e.getStorageSync("unionId"),
                            state: this.tabActive1,
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        };
                        this.nextId || delete t.nextId, c.default.couponList(t).then(function(t) {
                            if (console.log(t.data.list), 0 == t.resultCode) {
                                if (t.data.nextId && (o.nextId = t.data.nextId), 0 == t.data.list.length) return void (o.noMore = !0);
                                o.noMore = !1, t.data.list.forEach(function(e) {
                                    o.resultList.push(p(p({}, e), {}, {
                                        imgUrlAll: e.imgUrl ? S + e.imgUrl : S + "/oss/wxapp/small.jpg",
                                        validTime: e.validTime ? e.validTime.slice(0, 11) : e.validTime,
                                        invalidTime: "jfsc004" == e.couponRuleCode ? "2021-09-21" : e.invalidTime ? e.invalidTime.slice(0, 11) : e.invalidTime,
                                        showTl: "16nNBFBe00004f00" == e.couponRuleCode || "16YoGt8H00020200" == e.couponRuleCode || "16YoGrrk0001ff00" == e.couponRuleCode || "16YoyYkc00003f00" == e.couponRuleCode || "16YoyYqQ00005503" == e.couponRuleCode || "16nLwZJZ00005e03" == e.couponRuleCode || "16nLwZNe00004f00" == e.couponRuleCode ? "yes" : "no"
                                    }));
                                });
                            } else 1 == t.resultCode && (e.removeStorageSync("logininfo"), o.showloginDialog = !0);
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    getListTotal: function() {
                        var o = this;
                        this.$refs.Loading.showLoading(), this.resultListTotal = {};
                        var t = {
                            socialhubId: e.getStorageSync("socialhubId")
                        };
                        console.log("getList执行了"), c.default.ebuyCouponIndex(t).then(function(e) {
                            0 == e.code && (o.resultListTotal = e.data);
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    getList: function() {
                        var o = this;
                        this.$refs.Loading.showLoading(), console.log(this.tabActive);
                        var t = {
                            status: "100000000" == this.tabActive ? "enabled" : "100000001" == this.tabActive ? "used" : "100000002" == this.tabActive ? "expire" : "",
                            socialhubId: e.getStorageSync("socialhubId"),
                            pageNumber: this.pageNumber,
                            pageSize: 10
                        };
                        console.log("getList执行了"), c.default.couponList_ebuy(t).then(function(t) {
                            if (0 == t.code) {
                                var n;
                                if (null === (n = t.data) || void 0 === n || !n.couponList) return void (o.noMore = !0);
                                if (t.data.couponList.forEach(function(e) {
                                    o.resultList.push(p(p({}, e), {}, {
                                        imgUrlAll: e.imgUrl ? S + e.imgUrl : S + "/oss/wxapp/small.jpg",
                                        validTime: e.validTime ? e.validTime.slice(0, 11) : e.validTime,
                                        invalidTime: "jfsc004" == e.couponRuleCode ? "2021-09-21" : e.invalidTime ? e.invalidTime.slice(0, 11) : e.invalidTime,
                                        showTl: "16nNBFBe00004f00" == e.couponRuleCode || "16YoGt8H00020200" == e.couponRuleCode || "16YoGrrk0001ff00" == e.couponRuleCode || "16YoyYkc00003f00" == e.couponRuleCode || "16YoyYqQ00005503" == e.couponRuleCode || "16nLwZJZ00005e03" == e.couponRuleCode || "16nLwZNe00004f00" == e.couponRuleCode ? "yes" : "no"
                                    }));
                                }), console.log("数据总数", t.data.totalCount), o.pageListTotal = t.data.totalCount, 
                                t.data.couponList.length < 10) return void (o.noMore = !0);
                            } else 1 == t.resultCode && (e.removeStorageSync("logininfo"), o.showloginDialog = !0);
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    gotoRuleNew: function(e) {
                        e.voucherSource && e.voucherSource.indexOf("HD") > -1 && this.goexchangeNew(e);
                    },
                    goexchange: function(o) {
                        if (console.log(o), 0 == this.indexs) {
                            if (1e8 != this.tabActive) return;
                            var t;
                            t = o.voucherSource && o.voucherSource.indexOf("HD") < 0 ? "会员权益券" : 1 == o.voucherSource ? "外卖券" : 2 == o.voucherSource ? "自取券" : 8 == o.voucherSource ? "堂食券" : "通用券", 
                            getApp().hxt.sendAction("coupon_use_clk", {
                                pack_coupon_name: o.name,
                                pack_coupon_id: o.couponCode,
                                coupon_type: t
                            });
                        } else if (2 == this.indexs && 1e8 != this.tabActive1) return;
                        if (o.voucherSource && o.voucherSource.indexOf("HD") > -1) {
                            var n;
                            if (n = "release" == g.default.envVersion ? "wxf83dc13b5390d17b" : "wx4840fa755ba3ce66", 
                            8 == o.voucherScope) return e.showToast({
                                title: "该优惠券可通过堂食扫码点餐使用",
                                icon: "none"
                            }), !1;
                            this.gotoMiniEc(n, o.voucherScope);
                        } else this.goexchangeNew(o);
                    },
                    gotoMiniEc: function(o, t) {
                        getApp().hxt.sendAction("gift_card_available_use_now", {
                            gift_card_name: "额外小程序",
                            gift_card_id: o
                        });
                        var n = 1 == t ? "pages/menu/index?channel=SNMIN&orderChannel=delivery" : 2 == t ? "pages/menu/index?channel=SNMIN&orderType=2" : "pages/index/index?channel=SNMIN";
                        e.navigateToMiniProgram({
                            appId: o,
                            path: n,
                            success: function(e) {}
                        });
                    },
                    goexchangeNew: function(o) {
                        var t = p(p({}, o), {}, {
                            giftName: o.name,
                            endTime: o.invalidTime
                        });
                        null != o && o.giftPicUrl && (t.giftPicUrl = S + o.giftPicUrl), o.templateUrl && "" != o.templateUrl ? e.navigateTo({
                            url: "/pages/mine/exchange?obj=" + encodeURIComponent(JSON.stringify(t)) + "&couponCode=" + o.couponCode + "&vouchersource=" + o.voucherSource + "&couponRuleId=" + o.couponRuleCode + "&cardType=active"
                        }) : "1" == o.isAddedWechat ? e.navigateTo({
                            url: "/pages/mine/exchange?obj=" + encodeURIComponent(JSON.stringify(t)) + "&couponCode=" + o.couponCode + "&vouchersource=" + o.voucherSource + "&couponRuleId=" + o.couponRuleCode + "&showbtn=true"
                        }) : (console.log("点击详情"), console.log(t), e.navigateTo({
                            url: "/pages/mine/exchange?obj=" + encodeURIComponent(JSON.stringify(t)) + "&couponCode=" + o.couponCode + "&vouchersource=" + o.voucherSource + "&couponRuleId=" + o.couponRuleCode
                        }));
                    },
                    cancalCard_moon: function(o) {
                        var t = this, n = e.getStorageSync("logininfo").socialhubId;
                        d.default.tzCancelTransfer({
                            openid: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId"),
                            socialHubid: n,
                            couponCode: o.couponCode,
                            nickName: e.getStorageSync("logininfo").fullName,
                            remark: ""
                        }).then(function(o) {
                            console.log(o), "0" == o.code ? e.showToast({
                                icon: "none",
                                title: "取消成功",
                                success: function() {
                                    setTimeout(function() {
                                        t.resultList = [], t.nextId = "", t.getList_records_moon();
                                    }, 1e3);
                                }
                            }) : e.showToast({
                                icon: "none",
                                title: "取消失败，请稍后重试"
                            });
                        });
                    },
                    cancalCard: function(o) {
                        var t = new Date().getTime();
                        console.log(o);
                        var n = this;
                        d.default.ebuyCancelTransfer({
                            openid: e.getStorageSync("openId"),
                            socialHubid: e.getStorageSync("socialhubId"),
                            unionId: e.getStorageSync("unionId"),
                            couponKey: o.packageId,
                            timestamp: t,
                            sign: h.default.mdString(t, {
                                openid: e.getStorageSync("openId"),
                                socialHubid: e.getStorageSync("socialhubId"),
                                unionId: e.getStorageSync("unionId"),
                                couponKey: o.packageId
                            })
                        }, !1).then(function(o) {
                            console.log(o), "0" == o.code ? e.showToast({
                                icon: "none",
                                title: "取消成功",
                                success: function() {
                                    setTimeout(function() {
                                        n.resultList = [], n.pageNumber = 1, n.getList_records();
                                    }, 1e3);
                                }
                            }) : e.showToast({
                                icon: "none",
                                title: "取消失败，请稍后重试"
                            });
                        });
                    },
                    onChange: function(e) {
                        if (!this.isFirstNoChange) return this.isFirstNoChange = !0, !1;
                        this.tabActive = e.detail.name, "100000000" == this.tabActive ? getApp().hxt.sendAction("electronic_coupon_available_clk") : "100000001" == this.tabActive ? getApp().hxt.sendAction("electronic_coupon_used_clk") : "100000002" == this.tabActive ? getApp().hxt.sendAction("electronic_coupon_expired_clk") : "100000007" == this.tabActive && getApp().hxt.sendAction("electronic_coupon_handsel_clk"), 
                        this.resultList = [], this.pageNumber = 1, this.nextId = "", this.noMore = !1, "100000007" == e.detail.name ? (console.log("这是转赠记录"), 
                        this.getList_records()) : this.getList();
                    },
                    onChange1: function(e) {
                        if (!this.isFirstNoChange) return this.isFirstNoChange = !0, !1;
                        this.tabActive1 = e.detail.name, this.resultList = [], this.pageNumber = 1, this.nextId = "", 
                        this.noMore = !1, "100000007" == e.detail.name ? (console.log("这是月饼转赠记录"), this.getList_records_moon()) : this.getList_moon();
                    },
                    scrolltolowerFn: function() {
                        console.log("到底了"), this.noMore || (this.$refs.Loading.showLoading(), 0 == this.indexs ? 100000007 === this.tabActive ? this.pageTotal > this.resultList.length ? (this.pageNumber += 1, 
                        this.getList_records()) : (this.noMore = !0, this.$refs.Loading.hideLoading()) : this.pageListTotal > this.resultList.length ? (this.pageNumber += 1, 
                        this.getList()) : (this.noMore = !0, this.$refs.Loading.hideLoading()) : 2 == this.indexs && (100000007 === this.tabActive1 ? this.getList_records_moon() : this.getList_moon()));
                    },
                    common_transfer: function(o) {
                        var t = null == o ? void 0 : o.couponCode, n = null == o ? void 0 : o.couponRuleCode, i = (null == o || o.name, 
                        null == o ? void 0 : o.moonState), a = this;
                        c.default.findGet_common({}).then(function(o) {
                            if (0 == o.code && Object.keys(o.data).length > 0) {
                                var s = o.data.forwardViewUrl;
                                s.includes("?") ? s += "&couponCode=" + t + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)) : s += "?couponCode=" + t + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)), 
                                1 == i && (s += "&moonState=1"), e.navigateTo({
                                    url: s,
                                    complete: function() {
                                        a.$refs.Loading.hideLoading();
                                    }
                                });
                            } else {
                                var r;
                                r = 1 == i ? "/shareStyle/share_common/turnIndex?couponCode=" + t + "&moonState=1" : "/shareStyle/share_common/turnIndex?couponCode=" + t, 
                                e.navigateTo({
                                    url: r,
                                    complete: function() {
                                        a.$refs.Loading.hideLoading();
                                    }
                                });
                            }
                        }).catch(function() {
                            var o;
                            o = 1 == i ? "/shareStyle/share_common/turnIndex?couponCode=" + t + "&moonState=1" : "/shareStyle/share_common/turnIndex?couponCode=" + t, 
                            e.navigateTo({
                                url: o,
                                complete: function() {
                                    a.$refs.Loading.hideLoading();
                                }
                            });
                        });
                    },
                    transfer: function(o) {
                        if (this.$refs.Loading.showLoading(), 0 != this.indexs || 100000002 != this.tabActive) if (0 != this.indexs || 100000001 != this.tabActive) if (2 != this.indexs || 100000001 != this.tabActive1) if (2 != this.indexs || 100000001 != this.tabActive1) {
                            var t = null == o ? void 0 : o.couponCode, n = null == o ? void 0 : o.couponRuleCode, i = null == o ? void 0 : o.name, a = null == o ? void 0 : o.moonState;
                            if (!t) return e.showToast({
                                title: "此券暂时无法转赠",
                                icon: "none"
                            }), !1;
                            0 == this.indexs && getApp().hxt.sendAction("electronic_coupon_available_give_ta", {
                                electronic_coupon_name: i,
                                electronic_coupon_id: t
                            });
                            var s = this;
                            c.default.findGet({
                                couponRuleId: n,
                                ops: {
                                    couponRuleId: "equal"
                                }
                            }).then(function(i) {
                                if (console.log(i), 0 == i.code && Object.keys(i.data).length > 0) {
                                    var r = i.data.forwardViewUrl;
                                    r.includes("?") ? r += "&couponCode=" + t + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(i.data)) : r += "?couponCode=" + t + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(i.data)), 
                                    1 == a && (r += "&moonState=1"), e.navigateTo({
                                        url: r,
                                        complete: function() {
                                            s.$refs.Loading.hideLoading();
                                        }
                                    });
                                } else s.common_transfer(o);
                            }).catch(function() {
                                s.common_transfer(o);
                            });
                        } else e.showToast({
                            title: "券已使用无法转赠",
                            icon: "none"
                        }); else e.showToast({
                            title: "券已过期无法转赠",
                            icon: "none"
                        }); else e.showToast({
                            title: "券已使用无法转赠",
                            icon: "none"
                        }); else e.showToast({
                            title: "券已过期无法转赠",
                            icon: "none"
                        });
                    }
                }
            };
            n.default = b;
        }).call(this, i("543d").default);
    },
    e734: function(e, o, t) {
        var n = t("c525");
        t.n(n).a;
    },
    ffa8: function(e, o, t) {
        t.r(o);
        var n = t("cd54"), i = t("7680");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(e) {
            t.d(o, e, function() {
                return i[e];
            });
        }(a);
        t("e734");
        var s = t("f0c5"), r = Object(s.a)(i.default, n.b, n.c, !1, null, "da914ef4", null, !1, n.a, void 0);
        o.default = r.exports;
    }
}, [ [ "342e", "common/runtime", "common/vendor" ] ] ]);