// evaluation/ranking/index.js
Page({data: {}})