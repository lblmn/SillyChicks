// newStore/winterShare/index.js
Page({data: {}})