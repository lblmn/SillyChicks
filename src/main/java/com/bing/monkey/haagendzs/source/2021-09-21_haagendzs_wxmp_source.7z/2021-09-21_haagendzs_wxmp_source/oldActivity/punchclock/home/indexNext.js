// oldActivity/punchclock/home/indexNext.js
Page({data: {}})