(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/my-turntable-draw/my-turntable-draw" ], {
    "125d": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = {
            props: {
                zwheelType: {
                    type: String,
                    default: "zwheel"
                },
                canvasWidth: {
                    type: Number,
                    default: 560
                },
                canvasHeight: {
                    type: Number,
                    default: 560
                },
                prizeList: {
                    type: Array,
                    validator: function(t) {
                        return t.length % 2 == 0;
                    },
                    required: !0
                },
                colors: {
                    type: Array,
                    default: function() {
                        return [ "#fff", "#fff" ];
                    },
                    validator: function(t) {
                        return 2 === t.length;
                    }
                },
                duration: {
                    type: Number,
                    default: 8
                },
                ringCount: {
                    type: Number,
                    default: 8
                },
                strKey: {
                    type: String,
                    default: String
                },
                targetIndex: {
                    type: Number,
                    default: 0
                },
                rotateArray: {
                    type: Number,
                    default: 0
                }
            },
            data: function() {
                return {
                    isClick: !0,
                    isShow: !0,
                    skew: 0,
                    degs: 0,
                    color1: "#FFF",
                    color2: "#FFF",
                    textWidth: "50%",
                    rotates: 0,
                    isRoteIndex: 0,
                    zwheelType2: "zwheel"
                };
            },
            created: function() {
                this.rotates = this.rotateArray;
            },
            mounted: function() {
                this.color1 = this.colors[0], this.color2 = this.colors[1], this.zwheelType2 = this.zwheelType, 
                this.setView();
            },
            methods: {
                setView: function() {
                    var t = this.prizeList.length;
                    this.textWidth = 180 / t + "%";
                    var e = 360 / t;
                    t < 4 || (this.degs = e, this.skew = e - 90);
                },
                handleAction: function() {
                    if (!this.isClick) return !1;
                    this.isClick = !1, this.$emit("befoterClick", {
                        type: "start",
                        callback: this.rotoreAction
                    });
                },
                rotoreAction: function(t) {
                    var e = this.rotates ? this.rotates : 0;
                    this.isShow ? (e = (this.prizeList.length - 1 - t) * this.degs + 360 * this.ringCount, 
                    this.isShow = !1, this.rotates += e + this.degs / 2) : (e = -(t - this.isRoteIndex) * this.degs + 360 * this.ringCount, 
                    this.rotates += e), this.isRoteIndex = t, this.setTimeOut();
                },
                setTimeOut: function() {
                    var t = this;
                    setTimeout(function() {
                        t.$emit("afterClick", {
                            type: "end",
                            callback: t.endAction
                        }), t.isClick = !0;
                    }, 1e3 * this.duration + 100);
                },
                endAction: function() {
                    console.log("本次选中的：" + this.prizeList[this.targetIndex].name);
                },
                doWheel: function() {
                    this.$emit("doWheel");
                }
            }
        };
        e.default = i;
    },
    "2da9": function(t, e, n) {
        var i = n("8bb6");
        n.n(i).a;
    },
    "47ed": function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var i = function() {
            var t = this, e = (t.$createElement, t._self._c, t.prizeList.length > 0 ? t.__map(t.prizeList, function(e, n) {
                var i = t.__get_orig(e), r = e.name.includes("+");
                return {
                    $orig: i,
                    g0: r,
                    g1: r ? e.name.split("-") : null,
                    g2: r ? e.name.split("+")[0].split("-") : null,
                    g3: r ? e.name.split("+") : null,
                    g4: r ? null : e.name.split("-")
                };
            }) : null);
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, r = [];
    },
    "8bb6": function(t, e, n) {},
    b02f: function(t, e, n) {
        n.r(e);
        var i = n("125d"), r = n.n(i);
        for (var o in i) "default" !== o && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = r.a;
    },
    b926: function(t, e, n) {
        n.r(e);
        var i = n("47ed"), r = n("b02f");
        for (var o in r) "default" !== o && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        n("2da9");
        var a = n("f0c5"), s = Object(a.a)(r.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        e.default = s.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/my-turntable-draw/my-turntable-draw-create-component", {
    "components/my-turntable-draw/my-turntable-draw-create-component": function(t, e, n) {
        n("543d").createComponent(n("b926"));
    }
}, [ [ "components/my-turntable-draw/my-turntable-draw-create-component" ] ] ]);