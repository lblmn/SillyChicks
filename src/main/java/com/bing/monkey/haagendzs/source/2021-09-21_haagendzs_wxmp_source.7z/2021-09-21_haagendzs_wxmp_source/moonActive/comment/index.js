// moonActive/comment/index.js
Page({data: {}})