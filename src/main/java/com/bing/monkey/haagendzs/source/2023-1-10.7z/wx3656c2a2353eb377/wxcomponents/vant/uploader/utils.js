Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.chooseFile = function(e) {
    var t = e.accept, r = e.multiple, i = e.capture, n = e.compressed, o = e.maxDuration, s = e.sizeType, u = e.camera, c = e.maxCount;
    switch (t) {
      case "image":
        return new Promise(function(e, t) {
            wx.chooseImage({
                count: r ? Math.min(c, 9) : 1,
                sourceType: i,
                sizeType: s,
                success: e,
                fail: t
            });
        });

      case "media":
        return new Promise(function(e, t) {
            wx.chooseMedia({
                count: r ? Math.min(c, 9) : 1,
                sourceType: i,
                maxDuration: o,
                sizeType: s,
                camera: u,
                success: e,
                fail: t
            });
        });

      case "video":
        return new Promise(function(e, t) {
            wx.chooseVideo({
                sourceType: i,
                compressed: n,
                maxDuration: o,
                camera: u,
                success: e,
                fail: t
            });
        });

      default:
        return new Promise(function(e, t) {
            wx.chooseMessageFile({
                count: r ? c : 1,
                type: "file",
                success: e,
                fail: t
            });
        });
    }
}, exports.isFunction = i, exports.isImageFile = function(e) {
    if (e.type) return 0 === e.type.indexOf("image");
    if (e.path) return r(e.path);
    if (e.url) return r(e.url);
    return !1;
}, exports.isObject = n, exports.isPromise = function(e) {
    return n(e) && i(e.then) && i(e.catch);
}, exports.isVideo = function(e, t) {
    return "video" === t;
};

var e = require("../../../@babel/runtime/helpers/typeof"), t = /\.(jpeg|jpg|gif|png|svg|webp|jfif|bmp|dpg)/i;

function r(e) {
    return t.test(e);
}

function i(e) {
    return "function" == typeof e;
}

function n(t) {
    return null !== t && "object" === e(t);
}