(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/baffle/index" ], {
    "0405": function(e, t, n) {
        n.r(t);
        var r = n("e046"), o = n("fb6a");
        for (var c in o) "default" !== c && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        n("a377");
        var f = n("f0c5"), u = Object(f.a)(o.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = u.exports;
    },
    "63b7": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = c(n("f0fd")), o = c(n("6bd2"));
            function c(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function f(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function u(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            var a = {
                data: function() {
                    return {
                        imgoss: r.default.ossurl + "baffle/",
                        config: {
                            statusBarFontColor: "#ffffff",
                            barPlaceholder: !1,
                            backgroundColor: [ 0, "#fff" ]
                        }
                    };
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? f(Object(n), !0).forEach(function(t) {
                            u(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, n("26cb").mapState)([ "isHeightScreen", "navbarHeight_a" ])),
                onLoad: function(e) {},
                onShow: function() {
                    this.getRecord();
                },
                methods: {
                    getRecord: function(t) {
                        o.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: t || e.getStorageSync("smsSource")
                        }, !1);
                    }
                }
            };
            t.default = a;
        }).call(this, n("543d").default);
    },
    7347: function(e, t, n) {},
    "858f": function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("c0e2"), t(n("66fd")), e(t(n("0405")).default);
        }).call(this, n("543d").createPage);
    },
    a377: function(e, t, n) {
        var r = n("7347");
        n.n(r).a;
    },
    e046: function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    fb6a: function(e, t, n) {
        n.r(t);
        var r = n("63b7"), o = n.n(r);
        for (var c in r) "default" !== c && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        t.default = o.a;
    }
}, [ [ "858f", "common/runtime", "common/vendor" ] ] ]);