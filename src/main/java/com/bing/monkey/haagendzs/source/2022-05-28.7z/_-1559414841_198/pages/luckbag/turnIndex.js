(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/luckbag/turnIndex" ], {
    "0910": function(e, o, t) {
        t.r(o);
        var n = t("cf65"), a = t("6a15");
        for (var i in a) "default" !== i && function(e) {
            t.d(o, e, function() {
                return a[e];
            });
        }(i);
        t("f4fb");
        var u = t("f0c5"), r = Object(u.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        o.default = r.exports;
    },
    "5d69": function(e, o, t) {
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var n = u(t("2fa1")), a = u(t("f0fd")), i = u(t("500b"));
            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            getApp();
            var r = {
                data: function() {
                    return {
                        placeholderInfo: "在此输入您的圣诞祝福",
                        textareaValue: "",
                        userName: "",
                        imgUrl: a.default.assetsRoot,
                        isshare: !0,
                        isShowSharePopup: !1,
                        isShowSharePopup2: !1,
                        isShowSharePopup3: !1,
                        helpinfo: "",
                        helpinfo2: ""
                    };
                },
                onLoad: function(o) {
                    this.couponCode = o.couponCode, console.log(this.couponCode), this.userName = e.getStorageSync("logininfo").fullName, 
                    console.log(this.userName), console.log(o.detailinfo), this.detailInfo = o.detailinfo ? JSON.parse(decodeURIComponent(o.detailinfo)) : "", 
                    console.log(this.detailInfo);
                },
                onShow: function() {
                    e.getStorageSync("shareback") && (this.isshare = !1, this.isShowSharePopup = !1, 
                    this.isShowSharePopup2 = !1, this.helpinfo = "", this.helpinfo2 = "", this.isShowSharePopup3 = !0, 
                    e.removeStorageSync("shareback"));
                },
                destroyed: function() {},
                methods: {
                    textareaValueFun: function(e) {
                        console.log(e), this.textareaValue = e.detail.value;
                    },
                    cancelFun: function() {
                        var o = this;
                        n.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "2",
                            remark: this.textareaValue
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (o.isshare = !0, o.isShowSharePopup = !1, o.isShowSharePopup2 = !0, 
                            o.helpinfo2 = "取消转赠成功\n该券已可以使用\n请去【我的券包】") : (o.isShowSharePopup2 = !0, o.helpinfo2 = "取消转赠失败");
                        });
                    },
                    sendCard: function() {
                        var o = this;
                        console.log(this.textareaValue), n.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "1",
                            remark: "" == this.textareaValue ? "邀请你来哈根达斯体验哦~" : this.textareaValue
                        }).then(function(e) {
                            console.log(e.code), 0 == e.code ? (o.textid = e.data, o.isshare = !1, o.isShowSharePopup = !0, 
                            o.helpinfo = "提交成功\n请点分享将券转赠给指定好友") : (o.isShowSharePopup2 = !0, o.helpinfo2 = "提交失败\n请稍后重试");
                        });
                    }
                },
                onShareAppMessage: function(o) {
                    e.setStorageSync("shareback", !0);
                    var t = "叮，您有一份来自好友的圣诞缤纷好礼", n = "".concat(a.default.assetsRoot, "/oss/wxapp/112/luckShare.png");
                    if (this.detailInfo.forwardTitle && (t = this.detailInfo.forwardTitle), this.detailInfo.forwardPictureUrl && (n = "".concat(a.default.assetsRoot) + this.detailInfo.forwardPictureUrl), 
                    i.default.shareRecord({
                        aid: "",
                        unionId: e.getStorageSync("unionId"),
                        openid: e.getStorageSync("openId"),
                        path: "pages/luckbag/turnIndex",
                        button: "",
                        invitedOpenid: "",
                        type: "1"
                    }).then(function(e) {
                        console.log(e);
                    }).catch(function(e) {
                        console.log(e);
                    }), console.log("pages/luckbag/turnGet?textid=".concat(this.textid)), "button" === o.from) return {
                        title: t,
                        path: "pages/luckbag/turnGet?textid=".concat(this.textid),
                        imageUrl: n
                    };
                }
            };
            o.default = r;
        }).call(this, t("543d").default);
    },
    "6a15": function(e, o, t) {
        t.r(o);
        var n = t("5d69"), a = t.n(n);
        for (var i in n) "default" !== i && function(e) {
            t.d(o, e, function() {
                return n[e];
            });
        }(i);
        o.default = a.a;
    },
    "6c7e": function(e, o, t) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            t("c0e2"), o(t("66fd")), e(o(t("0910")).default);
        }).call(this, t("543d").createPage);
    },
    cf65: function(e, o, t) {
        t.d(o, "b", function() {
            return n;
        }), t.d(o, "c", function() {
            return a;
        }), t.d(o, "a", function() {});
        var n = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(o) {
                e.isShowSharePopup2 = !1;
            }, e.e1 = function(o) {
                e.isShowSharePopup3 = !1;
            });
        }, a = [];
    },
    f4fb: function(e, o, t) {
        var n = t("f842");
        t.n(n).a;
    },
    f842: function(e, o, t) {}
}, [ [ "6c7e", "common/runtime", "common/vendor" ] ] ]);