(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/calendarActivity/turnIndex" ], {
    "086b": function(e, t, o) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(o("11e1")), i = n(o("1328")), r = n(o("d7df"));
            getApp();
            var u = {
                data: function() {
                    return {
                        placeholderInfo: "在此输入您的新年祝福",
                        textareaValue: "",
                        userName: "",
                        imgUrl: i.default.assetsRoot,
                        isshare: !0,
                        isShowSharePopup: !1,
                        isShowSharePopup2: !1,
                        isShowSharePopup3: !1,
                        helpinfo: "",
                        helpinfo2: ""
                    };
                },
                onLoad: function(t) {
                    this.couponCode = t.couponCode, this.userName = e.getStorageSync("logininfo").fullName, 
                    this.detailInfo = JSON.parse(decodeURIComponent(t.detailinfo));
                },
                onShow: function() {
                    e.getStorageSync("shareback") && (this.isshare = !1, this.isShowSharePopup = !1, 
                    this.isShowSharePopup2 = !1, this.helpinfo = "", this.helpinfo2 = "", this.isShowSharePopup3 = !0, 
                    e.removeStorageSync("shareback"));
                },
                destroyed: function() {},
                methods: {
                    textareaValueFun: function(e) {
                        console.log(e), this.textareaValue = e.detail.value;
                    },
                    cancelFun: function() {
                        var t = this;
                        a.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "2",
                            remark: this.textareaValue
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (t.isshare = !0, t.isShowSharePopup = !1, t.isShowSharePopup2 = !0, 
                            t.helpinfo2 = "取消转赠成功\n该券已可以使用\n请去【我的券包】") : (t.isShowSharePopup2 = !0, t.helpinfo2 = "取消转赠失败");
                        });
                    },
                    sendCard: function() {
                        var t = this;
                        console.log(this.textareaValue), a.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "1",
                            remark: "" == this.textareaValue ? "邀请你来哈根达斯体验哦~" : this.textareaValue
                        }).then(function(e) {
                            console.log(e.code), 0 == e.code ? (t.textid = e.data, t.isshare = !1, t.isShowSharePopup = !0, 
                            t.helpinfo = "提交成功\n请点分享将券转赠给指定好友") : (t.isShowSharePopup2 = !0, t.helpinfo2 = "提交失败\n请稍后重试");
                        });
                    }
                },
                onShareAppMessage: function(t) {
                    e.setStorageSync("shareback", !0);
                    var o = "叮，您有一份来自好友的新年祝福好礼", n = "".concat(i.default.assetsRoot, "/oss/wxapp/1130/shareCalendar.jpg");
                    if (this.detailInfo.forwardTitle && (o = this.detailInfo.forwardTitle), this.detailInfo.forwardPictureUrl && (n = "".concat(i.default.assetsRoot) + this.detailInfo.forwardPictureUrl), 
                    r.default.shareRecord({
                        aid: "",
                        unionId: e.getStorageSync("unionId"),
                        openid: e.getStorageSync("openId"),
                        path: "pages/calendarActivity/turnIndex",
                        button: "",
                        invitedOpenid: "",
                        type: "1"
                    }).then(function(e) {
                        console.log(e);
                    }).catch(function(e) {
                        console.log(e);
                    }), console.log("pages/calendarActivity/turnGet?textid=".concat(this.textid)), "button" === t.from) return {
                        title: o,
                        path: "pages/calendarActivity/turnGet?textid=".concat(this.textid),
                        imageUrl: n
                    };
                }
            };
            t.default = u;
        }).call(this, o("543d").default);
    },
    1112: function(e, t, o) {
        o.r(t);
        var n = o("086b"), a = o.n(n);
        for (var i in n) "default" !== i && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(i);
        t.default = a.a;
    },
    2818: function(e, t, o) {},
    "4f44": function(e, t, o) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            o("f4aa"), t(o("66fd")), e(t(o("fa40")).default);
        }).call(this, o("543d").createPage);
    },
    "73dd": function(e, t, o) {
        var n = o("2818");
        o.n(n).a;
    },
    ce5e: function(e, t, o) {
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return a;
        }), o.d(t, "a", function() {});
        var n = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.isShowSharePopup2 = !1;
            }, e.e1 = function(t) {
                e.isShowSharePopup3 = !1;
            });
        }, a = [];
    },
    fa40: function(e, t, o) {
        o.r(t);
        var n = o("ce5e"), a = o("1112");
        for (var i in a) "default" !== i && function(e) {
            o.d(t, e, function() {
                return a[e];
            });
        }(i);
        o("73dd");
        var r = o("f0c5"), u = Object(r.a)(a.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = u.exports;
    }
}, [ [ "4f44", "common/runtime", "common/vendor" ] ] ]);