// pureFeeling/cameraHome/index.js
Page({data: {}})