// newStore/winterShareBlack/index.js
Page({data: {}})