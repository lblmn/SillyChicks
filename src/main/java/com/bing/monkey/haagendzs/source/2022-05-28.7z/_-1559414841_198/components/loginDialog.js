(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/loginDialog" ], {
    3761: function(e, n, o) {
        o.r(n);
        var t = o("8873"), r = o("fccf");
        for (var i in r) "default" !== i && function(e) {
            o.d(n, e, function() {
                return r[e];
            });
        }(i);
        o("528b");
        var a = o("f0c5"), c = Object(a.a)(r.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        n.default = c.exports;
    },
    "528b": function(e, n, o) {
        var t = o("8e6d");
        o.n(t).a;
    },
    8873: function(e, n, o) {
        o.d(n, "b", function() {
            return t;
        }), o.d(n, "c", function() {
            return r;
        }), o.d(n, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    "8e6d": function(e, n, o) {},
    c16d: function(e, n, o) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = a(o("a34a")), r = a(o("500b")), i = a(o("33d4"));
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function c(e, n, o, t, r, i, a) {
                try {
                    var c = e[i](a), s = c.value;
                } catch (e) {
                    return void o(e);
                }
                c.done ? n(s) : Promise.resolve(s).then(t, r);
            }
            function s(e) {
                return function() {
                    var n = this, o = arguments;
                    return new Promise(function(t, r) {
                        var i = e.apply(n, o);
                        function a(e) {
                            c(i, t, r, a, s, "next", e);
                        }
                        function s(e) {
                            c(i, t, r, a, s, "throw", e);
                        }
                        a(void 0);
                    });
                };
            }
            var l = {
                name: "loginDialog",
                data: function() {
                    return {
                        showLogin: !1,
                        showMobile: !1,
                        loginRes: {},
                        phone: "",
                        showLoading: !1,
                        canIUseGetUserProfile: !1
                    };
                },
                props: {
                    isfromqw: {
                        type: Boolean,
                        default: !1
                    }
                },
                mounted: function() {
                    var n = this;
                    return s(t.default.mark(function o() {
                        var r;
                        return t.default.wrap(function(o) {
                            for (;;) switch (o.prev = o.next) {
                              case 0:
                                if (console.log("jiazaizujian"), 0 != Object.keys(e.getStorageSync("logininfo")).length) {
                                    o.next = 12;
                                    break;
                                }
                                return console.log("logindialog,微信登录"), o.next = 5, n.doLogin();

                              case 5:
                                return n.loginRes = o.sent, o.next = 8, n.getOpenid(n.loginRes);

                              case 8:
                                r = o.sent, e.setStorageSync("openId", r.data.openid), console.log("code换的值", r), 
                                r.data.unionId ? (e.setStorageSync("unionId", r.data.unionId), getApp().hxt.identify({
                                    openid: r.data.openid,
                                    unionid: r.data.unionId
                                }), console.log(n.isfromqw), n.isfromqw && n.customerinfo(), n.getMemberinfo()) : (e.getUserProfile && (n.canIUseGetUserProfile = !0), 
                                n.showLogin = !0, e.hideLoading());

                              case 12:
                              case "end":
                                return o.stop();
                            }
                        }, o);
                    }))();
                },
                methods: {
                    customerinfo: function() {
                        i.default.customerinfo(e.getStorageSync("unionId")).then(function(n) {
                            0 == n.code && (e.setStorageSync("shopCode", n.data.store_info[0].store_code), e.setStorageSync("channelLabel", "Work-WeChat"));
                        });
                    },
                    cancelFun: function() {
                        e.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    getNewUserInfo: function() {
                        return new Promise(function(n, o) {
                            e.getUserProfile({
                                desc: "会员信息",
                                success: function(e) {
                                    console.log(e), n(e);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    newInfo: function() {
                        var n = this;
                        return s(t.default.mark(function o() {
                            var r, i;
                            return t.default.wrap(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    return o.next = 2, n.getNewUserInfo();

                                  case 2:
                                    return r = o.sent, e.setStorageSync("wxinfo", r.userInfo), o.next = 6, n.getUnionid(r);

                                  case 6:
                                    i = o.sent, e.setStorageSync("unionId", i.data.unionId);

                                  case 8:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    onGetUserInfo: function() {
                        var n = this;
                        return s(t.default.mark(function o() {
                            var r, i;
                            return t.default.wrap(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    return o.next = 2, n.getUserinfo(n.loginRes);

                                  case 2:
                                    return r = o.sent, e.setStorageSync("wxinfo", r.userInfo), o.next = 6, n.getUnionid(r);

                                  case 6:
                                    i = o.sent, e.setStorageSync("unionId", i.data.unionId), n.getMemberinfo();

                                  case 9:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    doLogin: function() {
                        return new Promise(function(n, o) {
                            e.login({
                                success: function(e) {
                                    n(e);
                                }
                            });
                        });
                    },
                    getOpenid: function(e) {
                        return r.default.login({
                            code: e.code,
                            appId: this.$env.appId
                        }, !1);
                    },
                    getUserinfo: function(n) {
                        var o = this;
                        return new Promise(function(t, r) {
                            n.code ? e.getUserInfo({
                                success: function(e) {
                                    t(e);
                                },
                                fail: function(e) {
                                    o.showLogin = !0, console.log("拒绝了用户信息授权");
                                }
                            }) : (r("登录失败！" + n.errMsg), console.log("登录失败！" + n.errMsg));
                        });
                    },
                    getUnionid: function(n) {
                        return r.default.decrypt({
                            encryptedData: n.encryptedData,
                            openId: e.getStorageSync("openId"),
                            iv: n.iv
                        }, !1);
                    },
                    getMemberinfo: function() {
                        var n = this;
                        return new Promise(function(o, t) {
                            r.default.getmember({
                                idType: "2",
                                id: e.getStorageSync("unionId")
                            }, !1).then(function(r) {
                                console.log("getmemberinfo", r), 0 == r.resultCode ? (e.setStorageSync("logininfo", r.data), 
                                e.setStorageSync("socialhubId", r.data.socialhubId), console.log(n.returnUrl), console.log("即将刷新", n.returnUrl()[2]), 
                                console.log(n.$store.state), n.$store.commit("userinfo", r.data), n.$store.dispatch("getPoint"), 
                                e.setStorageSync("successInfo", "all"), "/pages/mine/mine" == n.returnUrl()[2] ? e.reLaunch({
                                    url: n.returnUrl()[2]
                                }) : (console.log("地址:", n.returnUrl()[2]), n.returnUrl()[2].includes("/pages/shop/shop") > 0 || n.returnUrl()[2].includes("/pages/attendance/attendance") > 0 || n.returnUrl()[2].includes("evaluation/repurchase/index") > 0 ? n.$emit("userInfoSuccess", "all") : e.redirectTo({
                                    url: n.returnUrl()[2]
                                })), o(r)) : (0 == Object.keys(e.getStorageSync("logininfo")).length ? (n.showMobile = !0, 
                                e.hideLoading()) : e.showToast({
                                    title: "请求会员信息异常请稍后重试",
                                    icon: "none"
                                }), t(r));
                            });
                        });
                    },
                    onGetPhoneNumber: function(n) {
                        this.showMobile = !1;
                        var o = this;
                        console.log(n), "getPhoneNumber:fail user deny" == n.detail.errMsg || "getPhoneNumber:fail:user deny" == n.detail.errMsg ? (console.log("取消授权"), 
                        o.$nextTick(function() {
                            o.showMobile = !0;
                        })) : r.default.decrypt({
                            encryptedData: n.detail.encryptedData,
                            openId: e.getStorageSync("openId"),
                            iv: n.detail.iv
                        }).then(function(n) {
                            o.phone = n.data.phoneNumber, e.setStorageSync("userinfoPhone", o.phone), o.bindQuery();
                        });
                    },
                    bindQuery: function() {
                        var n = this, o = e.getStorageSync("unionId"), t = e.getStorageSync("openId");
                        r.default.bindquery({
                            thirdPartyId: o,
                            openid: t,
                            source: 2,
                            mobilePhone: this.phone
                        }).then(function(i) {
                            console.log("会员绑定查询入参" + JSON.stringify({
                                thirdPartyId: o,
                                openid: t,
                                source: 2,
                                mobilePhone: n.phone
                            })), console.log("校验登录返回" + JSON.stringify(i)), 0 == i.resultCode ? "E000101" == i.resultDesc ? (console.log(n.returnUrl()), 
                            n.returnUrl()[2].includes("thanksgiving/getShareCard/index") ? (e.setStorageSync("channelLabel", "F22GEJ-Track"), 
                            e.redirectTo({
                                url: "/pages/register/register?url=" + n.returnUrl()[0] + "&param=" + JSON.stringify(n.returnUrl()[1])
                            })) : n.returnUrl()[2].includes("moonActive/rule/index") || n.returnUrl()[2].includes("source=CDPQ-MDNewActLAL2") || n.returnUrl()[2].includes("source=CDPS-MDNewActLAL2") || n.returnUrl()[2].includes("source=CDPQ-MDNewRet2") || n.returnUrl()[2].includes("source=CDPS-MDNewRet2") || n.returnUrl()[2].includes("source=CDPQ-MDNewLov2") || n.returnUrl()[2].includes("source=CDPS-MDNewLov2") ? e.navigateTo({
                                url: "/pages/register/register?fromType=mycard&url=" + n.returnUrl()[0] + "&param=" + JSON.stringify(n.returnUrl()[1])
                            }) : e.redirectTo({
                                url: "/pages/register/register?url=" + n.returnUrl()[0] + "&param=" + JSON.stringify(n.returnUrl()[1])
                            })) : "E000102" == i.resultDesc ? r.default.bind({
                                thirdPartyId: e.getStorageSync("unionId"),
                                thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                openid: e.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: n.phone
                            }).then(function(o) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: e.getStorageSync("unionId"),
                                    thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                    openid: e.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: n.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(o)), 0 == o.resultCode ? (e.setStorageSync("socialhubId", o.data.socialhubId), 
                                n.showLoading = !0, Promise.all([ n.getMemberinfo() ]).then(function(e) {
                                    console.log("Promise.all:", e);
                                }).catch(function(e) {
                                    console.log("promiseall-error", e);
                                }).finally(function(o) {
                                    console.log("promiseall-finally", o), n.showLoading = !1, e.reLaunch({
                                        url: n.returnUrl()[2]
                                    });
                                })) : e.showToast({
                                    title: "请求异常请稍后重试",
                                    icon: "none"
                                });
                            }) : "E000103" == i.resultDesc ? (e.setStorageSync("socialhubId", i.data.socialhubId), 
                            n.showLoading = !0, Promise.all([ n.getMemberinfo() ]).then(function(e) {
                                console.log("Promise.all:", e);
                            }).catch(function(e) {
                                console.log("promiseall-error", e);
                            }).finally(function(o) {
                                console.log("promiseall-finally", o), n.showLoading = !1, "/pages/coffee/coffee" == n.returnUrl()[2] ? e.reLaunch({
                                    url: n.returnUrl()[2]
                                }) : e.redirectTo({
                                    url: n.returnUrl()[2]
                                });
                            })) : e.showToast({
                                title: "会员已被他人绑定",
                                icon: "none"
                            }) : 1 == i.resultCode && "E000107" == i.resultDesc ? r.default.bind({
                                thirdPartyId: e.getStorageSync("unionId"),
                                thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                openid: e.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: n.phone
                            }).then(function(o) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: e.getStorageSync("unionId"),
                                    thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                    openid: e.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: n.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(o)), 0 == o.resultCode ? (e.setStorageSync("socialhubId", o.data.socialhubId), 
                                n.showLoading = !0, Promise.all([ n.getMemberinfo() ]).then(function(e) {
                                    console.log("Promise.all:", e);
                                }).catch(function(e) {
                                    console.log("promiseall-error", e);
                                }).finally(function(o) {
                                    console.log("promiseall-finally", o), n.showLoading = !1, e.reLaunch({
                                        url: "/pages/index/index"
                                    });
                                })) : e.showToast({
                                    title: "请求异常请稍后重试",
                                    icon: "none"
                                });
                            }) : e.showToast({
                                title: "请求异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    returnUrl: function() {
                        var e = getCurrentPages(), n = e[e.length - 1].route, o = e[e.length - 1].options, t = "";
                        if ("" == Object.keys(o)) t = "/" + n; else if (Object.keys(o).length > 0) {
                            var r = "";
                            for (var i in o) r += ("" == r ? "" : "&") + i + "=" + o[i];
                            t = "/" + n + "?" + r;
                        } else t = "/" + n;
                        return [ n, o, t ];
                    }
                }
            };
            n.default = l;
        }).call(this, o("543d").default);
    },
    fccf: function(e, n, o) {
        o.r(n);
        var t = o("c16d"), r = o.n(t);
        for (var i in t) "default" !== i && function(e) {
            o.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = r.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/loginDialog-create-component", {
    "components/loginDialog-create-component": function(e, n, o) {
        o("543d").createComponent(o("3761"));
    }
}, [ [ "components/loginDialog-create-component" ] ] ]);