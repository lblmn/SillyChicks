(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/attendance/attendance" ], {
    "2d53": function(n, t, e) {
        e.r(t);
        var i = e("b62d"), o = e.n(i);
        for (var s in i) "default" !== s && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(s);
        t.default = o.a;
    },
    "2e34": function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("c0e2"), t(e("66fd")), n(t(e("f018")).default);
        }).call(this, e("543d").createPage);
    },
    "56d7": function(n, t, e) {
        var i = e("fe32");
        e.n(i).a;
    },
    b62d: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = u(e("93f4")), o = u(e("c1f6")), s = u(e("f0fd")), a = u(e("234f")), r = u(e("6bd2")), c = e("26cb");
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function g(n, t) {
                var e = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(n);
                    t && (i = i.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable;
                    })), e.push.apply(e, i);
                }
                return e;
            }
            function h(n) {
                for (var t = 1; t < arguments.length; t++) {
                    var e = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? g(Object(e), !0).forEach(function(t) {
                        l(n, t, e[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : g(Object(e)).forEach(function(t) {
                        Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t));
                    });
                }
                return n;
            }
            function l(n, t, e) {
                return t in n ? Object.defineProperty(n, t, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[t] = e, n;
            }
            var d = [ 0, 3, 6, 9, 17, 19, 20, 25, 32, 33, 34, 35, 36, 36, 41, 48, 49, 50, 51, 52, 53, 58, 63, 64, 65, 66, 67, 68, 69, 71, 77, 81, 81, 82, 82, 82, 83, 83, 83, 83, 84, 84, 84, 84, 85, 85, 85, 85, 85, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 100 ], f = [ 5, 10, 15, "咖啡券×1", 20, 200 ], p = (getApp(), 
            {
                components: {
                    uniIcons: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(e("fafe"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    uniCalendar: function() {
                        Promise.all([ e.e("common/vendor"), e.e("pages/attendance/uni-calendar/uni-calendar") ]).then(function() {
                            return resolve(e("ce06"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/loginDialog") ]).then(function() {
                            return resolve(e("3761"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    Loading: function() {
                        e.e("components/loading").then(function() {
                            return resolve(e("b1b4"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    progress: function() {
                        e.e("components/progress").then(function() {
                            return resolve(e("dd29"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    headerimg: function() {
                        e.e("components/headerimg").then(function() {
                            return resolve(e("a806"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    hxNavbar: function() {
                        e.e("components/hx-navbar/hx-navbar").then(function() {
                            return resolve(e("a006"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        showFlag: !1,
                        showactive: !1,
                        attendanceList: [],
                        startDate: "",
                        endDate: "",
                        dayLength: 0,
                        canSign: Boolean,
                        isfirst: !1,
                        from: "",
                        imgoss: s.default.ossurl + "/images/attendance/",
                        imgoss_new: s.default.ossurl + "UX/attendance/",
                        fromzwheel: !1,
                        showloginDialog: !1,
                        checked: !1,
                        firstTime: 0,
                        secordTime: 0,
                        lastTime: 0,
                        isHasHeadimg: !1,
                        showPopup: !1,
                        isOpen: !1,
                        signType: "point",
                        width: 0,
                        nextday: 0,
                        resultIndex: "",
                        coffeeIndex: !1,
                        reusltDay: "",
                        config: {
                            statusBarFontColor: "#ffffff",
                            barPlaceholder: !1,
                            backgroundColor: [ 0, "#fff" ],
                            backgroundImg: s.default.ossurl + "UX/attendance/topBg.png"
                        },
                        pointAdd: 3,
                        isShowSetting: !1,
                        isBirth: !1,
                        scence: "",
                        gramRow: 0,
                        nowInfo: {},
                        gameNextDay: "",
                        lastSignInDate: "",
                        nowcanSign: ""
                    };
                },
                onLoad: function(n) {
                    a.default.setSource(n), this.from = n.from, "zwheel" == this.from && (this.fromzwheel = !0), 
                    this.isHeightPhone();
                },
                onShow: function() {
                    this.$refs.Loading.showLoading(), Object.keys(n.getStorageSync("logininfo")).length > 0 ? (this.signInSearch(), 
                    a.default.recordPv(), this.getRecord(), getApp().hxt.identify({
                        openid: n.getStorageSync("openId"),
                        unionid: n.getStorageSync("unionId")
                    }), getApp().hxt.sendAction("Checkin_clk"), this.getUserAll_w(), this.$refs.Loading.hideLoading()) : this.showloginDialog = !0;
                },
                computed: h(h({}, (0, c.mapState)([ "isHeightScreen", "points", "navbarHeight_a" ])), {}, {
                    shwidth: function() {
                        var n = this.dayLength;
                        n > 60 && n % 60 != 0 && (n %= 60);
                        var t = d[n];
                        return console.log(t), t;
                    }
                }),
                methods: h(h({
                    monthSwitch: function(n) {
                        console.log(n), this.$refs.Loading.showLoading(), this.signInSearch(n.nowDate), 
                        this.$refs.Loading.hideLoading();
                    },
                    getweekinfo: function(n) {
                        console.info("当天数据", n), n ? (this.nowInfo = n, n.lunar.isBirth ? this.isBirth = !0 : this.isBirth = !1) : this.isBirth = !1;
                    },
                    todayIsBirth: function() {
                        this.nowInfo && this.nowInfo.lunar.isBirth ? this.isBirth = !0 : this.isBirth = !1;
                    },
                    showWidth: function() {}
                }, (0, c.mapActions)([ "getPoint", "isHeightPhone" ])), {}, {
                    switchChange: function(n) {
                        n.detail, this.getUserAll();
                    },
                    closeShowPopup: function() {
                        this.showPopup = !1;
                    },
                    getUserAll_w: function() {
                        var t = this;
                        n.getSetting({
                            withSubscriptions: !0,
                            success: function(n) {
                                var e = n.subscriptionsSetting;
                                console.log(e), void 0 !== e.itemSettings && "accept" == e.itemSettings.Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00 ? (t.checked = !0, 
                                t.isShowSetting = !0) : void 0 !== e.itemSettings && "reject" == e.itemSettings.Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00 && (t.checked = !1, 
                                t.isShowSetting = !1);
                            }
                        });
                    },
                    getUserAll: function() {
                        var t = this;
                        n.getSetting({
                            withSubscriptions: !0,
                            success: function(e) {
                                console.log(e);
                                var i = e.subscriptionsSetting;
                                void 0 !== i.itemSettings && "accept" == i.itemSettings.Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00 ? (t.isOpen = !0, 
                                t.showPopup = !0) : void 0 !== i.itemSettings && "reject" == i.itemSettings.Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00 ? (t.isOpen = !1, 
                                t.showPopup = !0) : n.requestSubscribeMessage({
                                    tmplIds: [ "Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00" ],
                                    complete: function(n) {
                                        t.warnConfigFun(), t.getUserAll_w();
                                    }
                                });
                            }
                        });
                    },
                    warnConfigFun: function() {
                        i.default.warnConfig({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId")
                        }).then(function(n) {
                            console.log(n);
                        });
                    },
                    userInfoSuccess: function(t) {
                        "all" == t && (this.signInSearch(), this.getUserAll_w(), this.getRecord(), a.default.recordPv(), 
                        getApp().hxt.sendAction("Checkin_clk"), n.removeStorageSync("successInfo"), this.$refs.Loading.hideLoading());
                    },
                    getRecord: function() {
                        r.default.saveLoginRecord({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId"),
                            source: n.getStorageSync("smsSource")
                        }).then(function(n) {
                            console.log(n);
                        });
                    },
                    signInSearch: function() {
                        var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                        if (!e) {
                            var s = new Date(), a = s.getFullYear(), r = s.getMonth() + 1;
                            console.log(a, r), r < 10 && (r = "0" + r), e = a + "-" + r + "-10";
                        }
                        i.default.signInSearch({
                            unionId: n.getStorageSync("unionId"),
                            startTime: e,
                            endTime: o
                        }).then(function(e) {
                            if (0 == e.code) {
                                var i = [];
                                if (e.data.signInList.forEach(function(n) {
                                    i.push(h(h({}, n), {}, {
                                        date: n.signInDate
                                    }));
                                }), t.attendanceList = i, t.dayLength = e.data.continuingSignInCount, t.lastSignInDate = e.data.lastSignInDate, 
                                t.nowcanSign = e.data.currentSignIn, t.DayLengthResult(), t.canSign = !e.data.currentSignIn, 
                                0 == t.canSign) {
                                    t.getPoint();
                                    var o = t.dayLength;
                                    o > 60 && o % 60 != 0 && (o %= 60), o % 21 == 0 && o / 21 == 1 && (t.signType = "coupon");
                                }
                            } else n.showToast({
                                title: e.msg ? e.msg : "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    showLastGameTime: function(n) {
                        var t = this.lastSignInDate, e = 0;
                        this.nowcanSign && (e = 60 - this.gramRow);
                        var i = new Date(t);
                        i.setDate(i.getDate() + e), console.log(i);
                        var o = i.getMonth() + 1, s = i.getDate(), a = i.getFullYear() + "-" + (o < 10 ? "0" + o : o) + "-" + (s < 10 ? "0" + s : s);
                        console.log(a), this.gameNextDay = a;
                    },
                    changeDayLength: function() {
                        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                        "dosign" == n && (this.dayLength = this.dayLength + 1, this.DayLengthResult()), 
                        this.showPoint();
                    },
                    showPoint: function() {
                        var n = this.dayLength;
                        n > 60 && n % 60 != 0 ? n %= 60 : n > 60 && n % 60 == 0 && (n = 60), this.pointAdd = 3 == n ? 5 : 7 == n ? 10 : 14 == n ? 15 : 21 == n ? 3 : 30 == n ? 20 : 60 == n ? 200 : 3;
                    },
                    DayLengthResult: function() {
                        var n = this.dayLength;
                        n > 60 && n % 60 != 0 ? n %= 60 : n > 60 && n % 60 == 0 && (n = 60), this.gramRow = n, 
                        this.coffeeIndex = !1, n < 3 ? (this.nextday = 3 - n, this.resultIndex = f[0], this.reusltDay = 3) : n >= 3 && n < 7 ? (this.nextday = 7 - n, 
                        this.resultIndex = f[1], this.reusltDay = 7) : n >= 7 && n < 14 ? (this.nextday = 14 - n, 
                        this.resultIndex = f[2], this.reusltDay = 14) : n >= 14 && n < 21 ? (this.nextday = 21 - n, 
                        this.resultIndex = f[3], this.reusltDay = 21, this.coffeeIndex = !0) : n >= 21 && n < 30 ? (this.nextday = 30 - n, 
                        this.resultIndex = f[4], this.reusltDay = 30) : n >= 30 && n < 60 ? (this.nextday = 60 - n, 
                        this.resultIndex = f[5], this.reusltDay = 60) : 60 == n && (this.nextday = 0, this.resultIndex = 0);
                    },
                    doSign: function() {
                        var t = this;
                        if (!this.canSign) return this.showFlag = !0, void (this.isShowSetting && n.requestSubscribeMessage({
                            tmplIds: [ "Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00" ],
                            complete: function(n) {}
                        }));
                        if (this.isfirst) return !1;
                        this.isfirst = !0, getApp().hxt.sendAction("signin_clk");
                        var e = new Date().getTime();
                        i.default.signIn({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId"),
                            socialHubid: n.getStorageSync("socialhubId"),
                            mobile: n.getStorageSync("logininfo").mobilePhone,
                            sign: a.default.mdString(e, {
                                openId: n.getStorageSync("openId"),
                                unionId: n.getStorageSync("unionId")
                            }),
                            timestamp: e
                        }).then(function(e) {
                            0 == e.code ? (t.isShowSetting && n.requestSubscribeMessage({
                                tmplIds: [ "Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00" ],
                                complete: function(n) {}
                            }), "birth" != t.signType && (t.signType = e.data.type ? e.data.type : "point"), 
                            "coupon" == e.data.type ? (t.showFlag = !0, t.isfirst = !1) : t.getPoint().then(function(n) {
                                console.log(n), t.showFlag = !0, t.isfirst = !1;
                            }).catch(function() {
                                t.isfirst = !1;
                            }), t.changeDayLength("dosign")) : (n.showToast({
                                title: e.msg ? e.msg : "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), t.isfirst = !1);
                        });
                    },
                    gotoShop: function() {
                        if (getApp().hxt.sendAction("jixincoupon_clk"), this.isBirth) {
                            var t = this.nowInfo.lunar.ishasImg.url;
                            n.navigateTo({
                                url: t
                            });
                        } else "coupon" == this.signType ? n.navigateTo({
                            url: "/pages/mine/mycard"
                        }) : "shop" == this.from || "zwheel" == this.from ? n.navigateBack({
                            delta: -1
                        }) : n.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    getPoints: function() {
                        var t = this;
                        o.default.point({
                            idType: "1",
                            id: n.getStorageSync("socialhubId")
                        }).then(function(n) {
                            0 == n.resultCode ? (t.showFlag = !0, t.isfirst = !1) : t.isfirst = !1;
                        }).catch(function() {
                            t.isfirst = !1;
                        });
                    },
                    activeRule: function() {
                        this.showactive = !0;
                    },
                    changeWeek: function(t) {
                        console.log(t), t.lunar.ishasImg && t.lunar.ishasImg.url && (t.isDay && t.lunar.isBirth ? this.doSign() : n.navigateTo({
                            url: t.lunar.ishasImg.url
                        }));
                    },
                    goheart: function() {
                        n.navigateTo({
                            url: "/pages/mine/heart"
                        });
                    },
                    goshop: function() {
                        "shop" == this.from ? n.navigateBack({
                            delta: -1
                        }) : n.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    leaveAlert: function() {
                        this.canSign && (this.canSign = !1);
                    }
                })
            });
            t.default = p;
        }).call(this, e("543d").default);
    },
    cdb4: function(n, t, e) {
        e.d(t, "b", function() {
            return i;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {});
        var i = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(t) {
                n.showFlag = !1;
            }, n.e1 = function(t) {
                n.showFlag = !1;
            }, n.e2 = function(t) {
                n.showactive = !1;
            }, n.e3 = function(t) {
                n.showactive = !1;
            });
        }, o = [];
    },
    f018: function(n, t, e) {
        e.r(t);
        var i = e("cdb4"), o = e("2d53");
        for (var s in o) "default" !== s && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(s);
        e("56d7");
        var a = e("f0c5"), r = Object(a.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = r.exports;
    },
    fe32: function(n, t, e) {}
}, [ [ "2e34", "common/runtime", "common/vendor" ] ] ]);