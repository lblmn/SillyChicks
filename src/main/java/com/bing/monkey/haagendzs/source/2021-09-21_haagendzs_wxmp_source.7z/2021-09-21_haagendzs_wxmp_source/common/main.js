var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    "39cf": function(e, t, n) {},
    5724: function(e, t, n) {
        n.r(t);
        var o = n("83ad"), r = n.n(o);
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = r.a;
    },
    "793a": function(e, t, n) {
        n.r(t);
        var o = n("5724");
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n("d934");
        var a = n("f0c5"), u = Object(a.a)(o.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = u.exports;
    },
    "83ad": function(t, n, o) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0, function(e) {
                e && e.__esModule;
            }(o("d7df"));
            var r = {
                globalData: {
                    PointAccountResult: [],
                    PointAccount: 0,
                    PointJidou: 0,
                    deadHeart: 0,
                    deadBean: 0,
                    scene: Number,
                    N_ENV: {},
                    isbackfromSaveWXCard: "",
                    istransfer: !1,
                    globalNetWork: "",
                    isnewMember: !1,
                    getFirstTip: !1
                },
                methods: {
                    login: function() {
                        return new Promise(function(e, n) {
                            t.getStorageSync("token") ? e(t.getStorageSync("token")) : t.request({
                                url: "https://uatscrm-haagendazs.smarket.com.cn/v1/api/wxapp/banner/getList",
                                method: "get",
                                header: {
                                    Authorization: "Bearer " + t.getStorageSync("token")
                                }
                            }).then(function(e) {
                                console.log(e);
                            });
                        });
                    }
                },
                onLaunch: function() {
                    var e = this;
                    console.log("App Launch"), t.onNetworkStatusChange(function(n) {
                        e.globalData.globalNetWork = n.networkType, "none" == n.networkType && t.showModal({
                            title: "网络中断",
                            content: "请检查网络情况",
                            showCancel: !1
                        });
                    });
                },
                onShow: function(t) {
                    console.log("App Show", t, e(t.scene)), this.globalData.scene = t.scene, console.log(t.scene), 
                    this.globalData.N_ENV = this.$env;
                },
                onHide: function() {
                    t.removeStorageSync("detailinfo"), t.removeStorageSync("refreash"), t.removeStorageSync("token");
                }
            };
            n.default = r;
        }).call(this, o("543d").default);
    },
    d934: function(e, t, n) {
        var o = n("39cf");
        n.n(o).a;
    },
    ee9d: function(t, n, o) {
        (function(t, n) {
            function r() {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap();
                return r = function() {
                    return e;
                }, e;
            }
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function u(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function c(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            o("f4aa");
            var i = a(o("66fd")), f = a(o("793a")), l = a(o("3598")), d = a(o("811a")), p = a(o("1328")), s = function(t) {
                if (t && t.__esModule) return t;
                if (null === t || "object" !== (void 0 === t ? "undefined" : e(t)) && "function" != typeof t) return {
                    default: t
                };
                var n = r();
                if (n && n.has(t)) return n.get(t);
                var o = {}, a = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var u in t) if (Object.prototype.hasOwnProperty.call(t, u)) {
                    var c = a ? Object.getOwnPropertyDescriptor(t, u) : null;
                    c && (c.get || c.set) ? Object.defineProperty(o, u, c) : o[u] = t[u];
                }
                return o.default = t, n && n.set(t, o), o;
            }(o("9b5d")), b = a(o("0a10")), y = a(o("239f")), g = t.getAccountInfoSync().miniProgram.envVersion;
            "trial" != g && "release" != g || s.init({
                dsn: "https://139ce576166a4574b0f4f09a8b44513f@newsentry.smarket.com.cn/2"
            }), i.default.config.productionTip = !1, i.default.prototype.$toast = b.default, 
            i.default.prototype.$dialog = y.default, f.default.mpType = "app", i.default.prototype.$http = l.default, 
            i.default.prototype.$util = d.default, i.default.prototype.$env = p.default;
            var m = new i.default(function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(n), !0).forEach(function(t) {
                        c(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({}, f.default));
            n(m).$mount();
        }).call(this, o("543d").default, o("543d").createApp);
    }
}, [ [ "ee9d", "common/runtime", "common/vendor" ] ] ]);