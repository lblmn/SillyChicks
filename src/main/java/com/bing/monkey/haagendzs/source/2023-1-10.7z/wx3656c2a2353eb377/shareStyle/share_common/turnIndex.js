// shareStyle/share_common/turnIndex.js
Page({data: {}})