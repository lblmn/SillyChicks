(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/headerimg" ], {
    "03e8": function(e, t, n) {
        var r = n("cff2");
        n.n(r).a;
    },
    "720c": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    "7f80": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("a34a"));
            function o(e, t, n, r, o, a, c) {
                try {
                    var u = e[a](c), i = u.value;
                } catch (e) {
                    return void n(e);
                }
                u.done ? t(i) : Promise.resolve(i).then(r, o);
            }
            function a(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function c(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            var u = {
                name: "headerimg",
                data: function() {
                    return {
                        hasWxtX: !0,
                        avatarUrl: ""
                    };
                },
                mounted: function() {
                    var t = e.getStorageSync("wxuserinfoAvatar");
                    t ? (this.avatarUrl = t, this.$store.commit("wxuserinfoAvatar", t), this.hasWxtX = !1) : this.hasWxtX = !0;
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? a(Object(n), !0).forEach(function(t) {
                            c(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, n("26cb").mapState)([ "wxuserinfoAvatar" ])),
                methods: {
                    newInfoA: function() {
                        var t = this;
                        return function(e) {
                            return function() {
                                var t = this, n = arguments;
                                return new Promise(function(r, a) {
                                    var c = e.apply(t, n);
                                    function u(e) {
                                        o(c, r, a, u, i, "next", e);
                                    }
                                    function i(e) {
                                        o(c, r, a, u, i, "throw", e);
                                    }
                                    u(void 0);
                                });
                            };
                        }(r.default.mark(function n() {
                            var o;
                            return r.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.getNewUserInfo();

                                  case 2:
                                    o = n.sent, console.log(o), e.setStorageSync("wxuserinfoAvatar", o.userInfo.avatarUrl), 
                                    t.avatarUrl = o.userInfo.avatarUrl, t.$store.commit("wxuserinfoAvatar", o.userInfo.avatarUrl), 
                                    t.hasWxtX = !1;

                                  case 8:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getNewUserInfo: function() {
                        return new Promise(function(t, n) {
                            e.getUserProfile({
                                desc: "会员信息",
                                success: function(e) {
                                    console.log(e), getApp().hxt.sendAction("allow_alias"), t(e);
                                },
                                fail: function(e) {
                                    console.log(e), getApp().hxt.sendAction("deny_alias"), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, n("543d").default);
    },
    a806: function(e, t, n) {
        n.r(t);
        var r = n("720c"), o = n("eddb");
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("03e8");
        var c = n("f0c5"), u = Object(c.a)(o.default, r.b, r.c, !1, null, "4713dee0", null, !1, r.a, void 0);
        t.default = u.exports;
    },
    cff2: function(e, t, n) {},
    eddb: function(e, t, n) {
        n.r(t);
        var r = n("7f80"), o = n.n(r);
        for (var a in r) "default" !== a && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        t.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/headerimg-create-component", {
    "components/headerimg-create-component": function(e, t, n) {
        n("543d").createComponent(n("a806"));
    }
}, [ [ "components/headerimg-create-component" ] ] ]);