var e = require("../../@babel/runtime/helpers/interopRequireDefault");

require("../../@babel/runtime/helpers/Arrayincludes");

var o = e(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/exchange" ], {
    "4e02": function(e, o, n) {
        var t = n("dc3a");
        n.n(t).a;
    },
    "7c78": function(e, o, n) {
        (function(e) {
            var o = n("4ea4");
            n("a1ea"), o(n("66fd"));
            var t = o(n("f9cd"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, e(t.default);
        }).call(this, n("543d").createPage);
    },
    aa39: function(e, o, n) {
        n.r(o);
        var t = n("fb1f"), a = n.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(i);
        o.default = a.a;
    },
    dc3a: function(e, o, n) {},
    f9cd: function(e, o, n) {
        n.r(o);
        var t = n("fc23"), a = n("aa39");
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(o, e, function() {
                return a[e];
            });
        }(i);
        n("4e02");
        var c = n("f0c5"), r = Object(c.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = r.exports;
    },
    fb1f: function(e, t, a) {
        (function(e) {
            var i = a("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = i(a("9523")), r = i(a("fa26")), d = i(a("9296")), u = i(a("0098")), s = i(a("6c5a")), l = i(a("f3d4"));
            function h(e, o) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    o && (t = t.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), n.push.apply(n, t);
                }
                return n;
            }
            var f, p = getApp(), g = {
                components: {
                    uniIcons: function() {
                        Promise.all([ a.e("common/vendor"), a.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(a("6093"));
                        }.bind(null, a)).catch(a.oe);
                    }
                },
                data: function() {
                    return {
                        qrcode: "",
                        obj: {},
                        couponRuleId: "",
                        effectEnd: "",
                        effectBegin: "",
                        getcity: "",
                        isCanvasImg: "",
                        showbtn: !1,
                        typeFrom: !1,
                        isshowTl: !1,
                        isShowAct: !1,
                        lastTime: 180,
                        timeLast: null,
                        dynaCode: "",
                        flashToken: "",
                        loading: !1,
                        timer: null,
                        couponCode: "",
                        erweimaShow: !0,
                        vouchersource: "",
                        imgUX: l.default.ossurl + "UX"
                    };
                },
                onLoad: (f = n(o.default.mark(function e(n) {
                    var t, a, i;
                    return o.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (console.log(n), t = JSON.parse(decodeURIComponent(n.obj)), console.log(t), this.obj = function(e) {
                                for (var o = 1; o < arguments.length; o++) {
                                    var n = null != arguments[o] ? arguments[o] : {};
                                    o % 2 ? h(Object(n), !0).forEach(function(o) {
                                        (0, c.default)(e, o, n[o]);
                                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : h(Object(n)).forEach(function(o) {
                                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(n, o));
                                    });
                                }
                                return e;
                            }({}, t), null == t || !t.voucherDescUrl) {
                                e.next = 8;
                                break;
                            }
                            return e.next = 5, u.default.getJson(t.voucherDescUrl);

                          case 5:
                            a = e.sent, null != (i = JSON.parse(a)) && i.detail_img_url && (this.obj.giftPicUrl = i.detail_img_url), 
                            null != i && i.useInfo && (this.obj.ruleDesc = i.useInfo.replace(/\n/g, "<br>"));

                          case 8:
                            null != t && t.giftPicUrl && (this.obj.giftPicUrl = t.giftPicUrl), null != t && t.ruleDesc && (this.obj.ruleDesc = t.ruleDesc.replace(/\n/g, "<br>")), 
                            this.couponRuleId = n.couponRuleId, this.couponCode = n.couponCode, this.showbtn = n.showbtn, 
                            this.typeFrom = n.typeFrom, this.isShowAct = "active" == n.cardType, this.vouchersource = n.vouchersource ? n.vouchersource : "shopCard", 
                            2 == this.obj.dynaState && (this.isShowAct = !0), this.isshowTl = [ "16YoGt8H00020200", "16YoGrrk0001ff00", "16YoyYkc00003f00", "16YoyYqQ00005503", "16nLwZJZ00005e03", "16nLwZNe00004f00", "16nNBFBe00004f00" ].indexOf(t.couponRuleCode) > -1 ? "yes" : "no", 
                            this.vouchersource && this.vouchersource.indexOf("HD") > -1 ? 8 == t.voucherScope ? (this.erweimaShow = !0, 
                            "active" == n.cardType || "2" == this.obj.dynaState ? this.dynacodeGenerate() : (this.qrcode = n.couponCode, 
                            this.make())) : this.erweimaShow = !1 : "active" == n.cardType || "2" == this.obj.dynaState ? this.dynacodeGenerate() : (this.qrcode = n.couponCode, 
                            this.make()), n.effectBegin && (this.effectBegin = this.$util.dateFormat("YYYY-mm-dd", new Date(n.effectBegin.replace(/-/g, "/")))), 
                            n.effectEnd && (this.effectEnd = this.$util.dateFormat("YYYY-mm-dd", new Date(n.effectEnd.replace(/-/g, "/")))), 
                            this.getcity = s.default.filter(function(e) {
                                return e.code == t.cityCode;
                            }).length > 0 ? s.default.filter(function(e) {
                                return e.code == t.cityCode;
                            })[0].text : "";

                          case 10:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function(e) {
                    return f.apply(this, arguments);
                }),
                onShow: function() {
                    this.vouchersource && this.vouchersource.indexOf("HD") > -1 ? 8 == objTemp.voucherScope ? (this.erweimaShow = !0, 
                    this.isCanvasImg || (this.isShowAct ? this.timeLast && (clearInterval(this.timeLast), 
                    this.dynacodeGenerate()) : this.make())) : this.erweimaShow = !1 : this.isCanvasImg || (this.isShowAct ? this.timeLast && (clearInterval(this.timeLast), 
                    this.dynacodeGenerate()) : this.make());
                },
                destroyed: function() {
                    console.log("页面关闭1"), clearInterval(this.timeLast);
                },
                onUpload: function() {
                    console.log("页面关闭2"), clearInterval(this.timeLast);
                },
                onHide: function() {
                    p.globalData.istransfer = !1, clearInterval(this.timeLast);
                },
                methods: {
                    gotoMinipro: function(o) {
                        console.log(o);
                        var n;
                        n = "release" == l.default.envVersion ? "wxf83dc13b5390d17b" : "wx4840fa755ba3ce66";
                        var t = 1 == o ? "pages/menu/index?channel=SNMIN&orderChannel=delivery" : 2 == o ? "pages/menu/index?channel=SNMIN&orderType=2" : "pages/index/index?channel=SNMIN";
                        e.navigateToMiniProgram({
                            appId: n,
                            path: t,
                            success: function(e) {}
                        });
                    },
                    cardTl: function() {
                        var o, n = "";
                        if (o = "release" == l.default.envVersion ? "https://hd.rydeen.com.cn/coupon-booking/booking" : "https://hd-uat.rydeen.com.cn/coupon-booking/booking", 
                        this.obj.couponCode) n = o + "?couponNo=" + this.obj.couponCode, e.navigateTo({
                            url: "/pages/webView/indexN?url=" + encodeURIComponent(n)
                        }); else {
                            if (!this.qrcode) return !1;
                            n = o + "?couponNo=" + this.qrcode, e.navigateTo({
                                url: "/pages/webView/indexN?url=" + encodeURIComponent(n)
                            });
                        }
                    },
                    dynacodeGenerate: function() {
                        var o = this;
                        this.loading = !0, u.default.dynacodeGenerate({
                            unionId: e.getStorageSync("unionId"),
                            couponRuleCode: this.couponRuleId,
                            socialHubid: e.getStorageSync("socialhubId"),
                            couponCode: this.couponCode
                        }).then(function(e) {
                            console.log(e), o.qrcode = e.data.dyna_code, o.dynaCode = e.data.dyna_code, o.flashToken = e.data.flash_token, 
                            o.beginTime(), o.make(), o.loading = !1;
                        });
                    },
                    beginTime: function() {
                        var e = this, o = 180;
                        this.timeLast = setInterval(function() {
                            o--, e.lastTime = o, e.lastTime <= 0 && (o = 180, clearInterval(e.timeLast), e.resetCode());
                        }, 1e3);
                    },
                    resetCode: function() {
                        var o = this;
                        this.loading = !0, u.default.flashToken({
                            unionId: e.getStorageSync("unionId"),
                            dynaCode: this.dynaCode,
                            socialHubid: e.getStorageSync("socialhubId"),
                            flashToken: this.flashToken
                        }).then(function(e) {
                            o.qrcode = e.data.dyna_code, o.dynaCode = e.data.dyna_code, o.flashToken = e.data.flash_token, 
                            o.beginTime(), o.make();
                            var n = o, t = setTimeout(function() {
                                n.loading = !1, clearTimeout(t);
                            }, 700);
                        });
                    },
                    refreshFun: function() {
                        this.timer && clearTimeout(this.timer);
                        var e = this;
                        e.timer = setTimeout(function() {
                            clearInterval(e.timeLast), e.lastTime = 180, e.resetCode();
                        }, 700);
                    },
                    make: function() {
                        var o = this;
                        r.default.make({
                            canvasId: "qrcode",
                            componentInstance: this,
                            text: this.qrcode,
                            size: e.upx2px(292),
                            margin: 10,
                            backgroundColor: "#ffffff",
                            foregroundColor: "#000000",
                            fileType: "jpg",
                            correctLevel: r.default.defaults.correctLevel,
                            success: function(e) {
                                o.isCanvasImg = e;
                            }
                        });
                    },
                    transfer: function() {
                        var o = this;
                        e.showLoading({
                            mask: !0,
                            title: "加载中..."
                        });
                        var n = this.obj.couponCode ? this.obj.couponCode : this.couponCode, t = this.obj.couponRuleCode;
                        "mooncard" == this.typeFrom && (n = this.couponCode, t = this.couponRuleId), "16HYjDy800006e00" == this.obj.couponBagCode ? e.redirectTo({
                            url: "/pages/calendarActivity/turnIndex?couponCode=" + this.couponCode,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XQs8Ei00011c00" == this.obj.couponBagCode || "16XQs7SQ00001600" == this.obj.couponBagCode || "16XRa7Qr00003800" == this.obj.couponBagCode ? e.redirectTo({
                            url: "/pureFeeling/hdShare/turnIndex?couponCode=" + n,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : [ "16HaQ1eW0000ad00", "16HaQ1eu0000ae00", "16HaQ1fu0000af00", "16Hb25MK00008400", "16Hb25Mg00008500", "16Hb25My00008600" ].indexOf(this.obj.couponBagCode) >= 0 ? e.redirectTo({
                            url: "/pages/makeUpForever/turnIndex?couponCode=" + this.couponCode,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : [ "16XG7Fw20000a000", "16XG7Fub00009e00", "16XG23EQ00004100", "16XG23EA00004000", "16XG7Fw20000a000", "16XG7Fub00009e00", "16HZcEPN00009d00", "16HZsSWt00007800", "16X9Dn7D00009c00", "16HYYpXw00007b00", "16XG23Ch00003e00" ].indexOf(this.obj.couponBagCode) >= 0 ? "16X9Dn7D00009c00" == this.obj.couponBagCode || "16HYYpXw00007b00" == this.obj.couponBagCode || "16XG23Ch00003e00" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + n + "&activityType=newYearType",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XG7Fub00009e00" == this.obj.couponBagCode || "16XG23EA00004000" == this.obj.couponBagCode || "16XG7Fub00009e00" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + n + "&activityType=loveGolden",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XG7Fw20000a000" == this.obj.couponBagCode || "16XG23EQ00004100" == this.obj.couponBagCode || "16XG7Fw20000a000" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + n + "&activityType=lovePink",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + n,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : [ "16XHhMdG00009200", "16XHhMjT0000ad00", "16XHsckE0000b800", "16XHscoa0000d400", "16XHscs70000d700", "16XHseM60000da00", "16XHseQV0000dd00", "16XQfj9c0000dc00", "16XQfjBL0000df00", "16XQfjCv0000e200", "16XQgbRg0000e500", "16XQgbV40000e800", "16XQgbkL00010400", "16XQgbqV0000d500", "16XQs74E00000a00", "16XRZbF700002900", "16XRZbki00002f00", "16XQs7tW00011000" ].indexOf(t) >= 0 ? e.navigateTo({
                            url: "/pureFeeling/hdShare/turnIndex?couponCode=" + n,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : [ "16HZcE2q00008e00", "16HZcE4H00009100", "16HZcE5h00009400", "16HZcE6R00009700", "16HZcE7x00009a00", "16HaE49q00007900", "16HaE4Pe00007500", "16HaE4Uw00007f00", "16HaE4Uw00007f00", "16HaE4md00007800", "16HaE51V00007b00", "16Hb2EZz00008800", "16Hb2Eey00008700", "16HQ4edg00001d00", "16HQ4ebn00001a00", "16HaE1Vu0000a100", "16Hb2EWZ00008500" ].indexOf(t) >= 0 ? e.navigateTo({
                            url: "/pureFeeling/cameraHome/turnIndex?couponCode=" + n,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16X9DnM500002500" == this.obj.couponBagCode || "16XG7cAN0000a200" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pureFeeling/cameraHome/turnIndex?type=winterGet&couponCode=" + n + "&couponRuleCode=" + t,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : (t = t.indexOf("_") > 0 ? t.split("_")[0] : t, u.default.findGet({
                            couponRuleId: t,
                            ops: {
                                couponRuleId: "equal"
                            }
                        }).then(function(a) {
                            if (console.log(a), 0 == a.code) {
                                var i = a.data.forwardViewUrl;
                                i.includes("?") ? i += "&couponRuleCode=" + t + "&couponCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(a.data)) : i += "?couponRuleCode=" + t + "&couponCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(a.data)), 
                                1 == o.obj.moonState && (i += "&moonState=1"), e.navigateTo({
                                    url: i,
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            } else o.common_transfer();
                        }).catch(function() {
                            o.common_transfer();
                        }));
                    },
                    common_transfer: function() {
                        this.obj.name;
                        var o = this.obj.couponCode ? this.obj.couponCode : this.couponCode, n = this.obj.couponRuleCode, t = this.obj.moonState;
                        u.default.findGet_common({}).then(function(a) {
                            if (0 == a.code && Object.keys(a.data).length > 0) {
                                var i = a.data.forwardViewUrl;
                                i.includes("?") ? i += "&couponCode=" + o + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(a.data)) : i += "?couponCode=" + o + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(a.data)), 
                                1 == t && (i += "&moonState=1"), e.navigateTo({
                                    url: i,
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            } else {
                                var c;
                                c = 1 == t ? "/shareStyle/share_common/turnIndex?couponCode=" + o + "&moonState=1" : "/shareStyle/share_common/turnIndex?couponCode=" + o, 
                                e.navigateTo({
                                    url: c,
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            }
                        }).catch(function() {
                            var n;
                            n = 1 == t ? "/shareStyle/share_common/turnIndex?couponCode=" + o + "&moonState=1" : "/shareStyle/share_common/turnIndex?couponCode=" + o, 
                            e.navigateTo({
                                url: n,
                                complete: function() {
                                    e.hideLoading();
                                }
                            });
                        });
                    },
                    findWeixinCard: function() {
                        e.openCard({
                            cardList: [ {
                                cardId: this.obj.wxCardId,
                                code: this.couponCode
                            } ],
                            success: function(e) {}
                        });
                    },
                    changeCard: function() {
                        var o = encodeURIComponent("https://www.gmec.top/hgdz_dwz/ticketExchange.html");
                        e.navigateTo({
                            url: "../webView/indexN?url=" + o
                        });
                    },
                    addToWeixinCard: function() {
                        var o = this;
                        d.default.convertWxCardId({
                            couponRuleId: this.couponRuleId
                        }).then(function(n) {
                            d.default.getJsCardSignature({
                                code: o.qrcode,
                                cardId: n.data.wxCardId,
                                openId: e.getStorageSync("openId")
                            }).then(function(e) {
                                console.log("调getjscard签名", e);
                                var o = e.data, n = o.cardId, t = o.cardSign, a = o.openId, i = o.nonceStr, c = o.timestamp, r = {
                                    code: o.code,
                                    cardId: n,
                                    signature: t,
                                    openid: a,
                                    nonce_str: i,
                                    timestamp: c,
                                    outer_str: "miniProgram"
                                };
                                console.log(JSON.stringify(r)), wx.addCard({
                                    cardList: [ {
                                        cardId: n,
                                        cardExt: JSON.stringify(r)
                                    } ],
                                    success: function(e) {
                                        console.log(e);
                                    },
                                    fail: function(e) {
                                        console.log(e);
                                    }
                                });
                            });
                        });
                    }
                }
            };
            t.default = g;
        }).call(this, a("543d").default);
    },
    fc23: function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return a;
        }), n.d(o, "a", function() {});
        var t = function() {
            var e = this, o = (e.$createElement, e._self._c, e.getcity || "yes" == e.isshowTl ? null : "1" == e.obj.allowReGift && e.vouchersource.indexOf("HD") < 0), n = e.getcity || "yes" == e.isshowTl ? null : e.vouchersource.indexOf("HD") > -1 && !e.erweimaShow;
            e.$mp.data = Object.assign({}, {
                $root: {
                    g0: o,
                    g1: n
                }
            });
        }, a = [];
    }
}, [ [ "7c78", "common/runtime", "common/vendor" ] ] ]);