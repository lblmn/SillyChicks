(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/highspeed/highspeed" ], {
    "0239": function(e, n, o) {
        o.d(n, "b", function() {
            return t;
        }), o.d(n, "c", function() {
            return i;
        }), o.d(n, "a", function() {});
        var t = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(n) {
                e.highFail = !1;
            }, e.e1 = function(n) {
                e.highFail = !1;
            }, e.e2 = function(n) {
                e.highsuccess = !1;
            }, e.e3 = function(n) {
                e.highsuccess = !1;
            }, e.e4 = function(n) {
                e.showFlag = !1;
            }, e.e5 = function(n) {
                e.showFlag = !1;
            }, e.e6 = function(n) {
                e.showrule = !1;
            }, e.e7 = function(n) {
                e.showrule = !1;
            });
        }, i = [];
    },
    "2d2e": function(e, n, o) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            o("f4aa"), n(o("66fd")), e(n(o("6d0a")).default);
        }).call(this, o("543d").createPage);
    },
    "6d0a": function(e, n, o) {
        o.r(n);
        var t = o("0239"), i = o("acbe");
        for (var c in i) "default" !== c && function(e) {
            o.d(n, e, function() {
                return i[e];
            });
        }(c);
        o("cdef");
        var a = o("f0c5"), s = Object(a.a)(i.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        n.default = s.exports;
    },
    "738c": function(e, n, o) {},
    acbe: function(e, n, o) {
        o.r(n);
        var t = o("c6c1"), i = o.n(t);
        for (var c in t) "default" !== c && function(e) {
            o.d(n, e, function() {
                return t[e];
            });
        }(c);
        n.default = i.a;
    },
    c6c1: function(e, n, o) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(o("9607")), i = getApp().globalData.N_ENV.assetsRoot, c = {
                name: "highspeed",
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("a81e"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        showFlag: !1,
                        errorMsg: "",
                        intoObj: {},
                        hasReceive: !1,
                        peituSrc: "",
                        showloginDialog: !1,
                        highFail: !1,
                        highsuccess: !1,
                        showrule: !1,
                        ruleInfo: ""
                    };
                },
                onLoad: function(e) {
                    this.aid = e.aid ? e.aid : "3", this.peituSrc = i + "/oss/wxapp/highspeedbg.png";
                },
                onShow: function() {
                    this.showloginDialog = !0, e.getStorageSync("openId") && e.getStorageSync("unionId") && this.gethighspeedCard();
                },
                onHide: function() {
                    this.showloginDialog = !1;
                },
                methods: {
                    gethighspeedCard: function() {
                        var n = this;
                        t.default.into({
                            aid: this.aid,
                            unionId: e.getStorageSync("unionId"),
                            openid: e.getStorageSync("openId"),
                            source: e.getStorageSync("sourcefrom") ? e.getStorageSync("sourcefrom") : "",
                            channel: e.getStorageSync("channelfrom") ? e.getStorageSync("channelfrom") : ""
                        }, !1).then(function(o) {
                            500 == o.code ? (n.showFlag = !0, n.errorMsg = o.msg) : 0 == o.code ? n.intoObj = o.data.activity : e.showToast({
                                title: "获取券id请求异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    activityExchange: function() {
                        var n = this;
                        this.hasReceive || (this.hasReceive = !0, t.default.activityExchange({
                            aid: this.intoObj.id,
                            unionId: e.getStorageSync("unionId"),
                            openid: e.getStorageSync("openId")
                        }).then(function(e) {
                            console.log(e), 0 == e.code ? (n.highsuccess = !0, n.hasReceive = !1) : 1 == e.code ? (n.errorMsg = "该劵已领取,请勿重复领取", 
                            n.showFlag = !0, n.hasReceive = !1) : (n.highFail = !0, n.hasReceive = !1);
                        }));
                    },
                    showRuleInfo: function() {
                        this.intoObj.ruleDesc && this.intoObj.ruleDesc.length > 0 ? (this.ruleInfo = this.intoObj.ruleDesc.replace(/\n/g, "<br/>"), 
                        this.showrule = !0) : (this.showFlag = !0, this.errorMsg = "活动规则获取失败");
                    }
                }
            };
            n.default = c;
        }).call(this, o("543d").default);
    },
    cdef: function(e, n, o) {
        var t = o("738c");
        o.n(t).a;
    }
}, [ [ "2d2e", "common/runtime", "common/vendor" ] ] ]);