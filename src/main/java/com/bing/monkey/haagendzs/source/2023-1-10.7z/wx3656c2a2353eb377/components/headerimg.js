var e = require("../@babel/runtime/helpers/interopRequireDefault")(require("../@babel/runtime/regenerator")), t = require("../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/headerimg" ], {
    "09c2": function(e, t, n) {
        n.r(t);
        var r = n("f59d"), a = n("d937");
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        n("1ba2");
        var c = n("f0c5"), i = Object(c.a)(a.default, r.b, r.c, !1, null, "320b6c22", null, !1, r.a, void 0);
        t.default = i.exports;
    },
    "1ba2": function(e, t, n) {
        var r = n("7f43");
        n.n(r).a;
    },
    "7f43": function(e, t, n) {},
    a285: function(n, r, a) {
        (function(n) {
            var o = a("4ea4");
            Object.defineProperty(r, "__esModule", {
                value: !0
            }), r.default = void 0;
            var c = o(a("9523"));
            function i(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            var s, u = {
                name: "headerimg",
                data: function() {
                    return {
                        hasWxtX: !0,
                        avatarUrl: ""
                    };
                },
                mounted: function() {
                    var e = n.getStorageSync("wxuserinfoAvatar");
                    e ? (this.avatarUrl = e, this.$store.commit("wxuserinfoAvatar", e), this.hasWxtX = !1) : this.hasWxtX = !0;
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? i(Object(n), !0).forEach(function(t) {
                            (0, c.default)(e, t, n[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                        });
                    }
                    return e;
                }({}, (0, a("26cb").mapState)([ "wxuserinfoAvatar" ])),
                methods: {
                    onChooseAvatar: function(e) {
                        console.log(e);
                        var t = e.detail.avatarUrl;
                        n.setStorageSync("wxuserinfoAvatar", t), this.avatarUrl = t, this.$store.commit("wxuserinfoAvatar", t), 
                        this.hasWxtX = !1;
                    },
                    newInfoA: (s = t(e.default.mark(function t() {
                        var r;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.getNewUserInfo();

                              case 2:
                                r = e.sent, console.log(r), n.setStorageSync("wxuserinfoAvatar", r.userInfo.avatarUrl), 
                                this.avatarUrl = r.userInfo.avatarUrl, this.$store.commit("wxuserinfoAvatar", r.userInfo.avatarUrl), 
                                this.hasWxtX = !1;

                              case 4:
                              case "end":
                                return e.stop();
                            }
                        }, t, this);
                    })), function() {
                        return s.apply(this, arguments);
                    }),
                    getNewUserInfo: function() {
                        return new Promise(function(e, t) {
                            n.getUserProfile({
                                desc: "会员信息",
                                success: function(t) {
                                    console.log(t), getApp().hxt.sendAction("allow_alias"), e(t);
                                },
                                fail: function(e) {
                                    console.log(e), getApp().hxt.sendAction("deny_alias"), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    }
                }
            };
            r.default = u;
        }).call(this, a("543d").default);
    },
    d937: function(e, t, n) {
        n.r(t);
        var r = n("a285"), a = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        t.default = a.a;
    },
    f59d: function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/headerimg-create-component", {
    "components/headerimg-create-component": function(e, t, n) {
        n("543d").createComponent(n("09c2"));
    }
}, [ [ "components/headerimg-create-component" ] ] ]);