// newStore/winterRecordsBlack/index.js
Page({data: {}})