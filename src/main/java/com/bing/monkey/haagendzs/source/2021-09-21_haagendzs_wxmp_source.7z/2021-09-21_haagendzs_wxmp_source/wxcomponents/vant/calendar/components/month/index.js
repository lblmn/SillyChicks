var t = function() {
    function t(t, e) {
        var r = [], a = !0, n = !1, o = void 0;
        try {
            for (var i, s = t[Symbol.iterator](); !(a = (i = s.next()).done) && (r.push(i.value), 
            !e || r.length !== e); a = !0) ;
        } catch (t) {
            n = !0, o = t;
        } finally {
            try {
                !a && s.return && s.return();
            } finally {
                if (n) throw o;
            }
        }
        return r;
    }
    return function(e, r) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, r);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), e = require("../../../common/component"), r = require("../../utils");

(0, e.VantComponent)({
    props: {
        date: {
            type: null,
            observer: "setDays"
        },
        type: {
            type: String,
            observer: "setDays"
        },
        color: String,
        minDate: {
            type: null,
            observer: "setDays"
        },
        maxDate: {
            type: null,
            observer: "setDays"
        },
        showMark: Boolean,
        rowHeight: [ Number, String ],
        formatter: {
            type: null,
            observer: "setDays"
        },
        currentDate: {
            type: [ null, Array ],
            observer: "setDays"
        },
        allowSameDay: Boolean,
        showSubtitle: Boolean,
        showMonthTitle: Boolean
    },
    data: {
        visible: !0,
        days: []
    },
    methods: {
        onClick: function(t) {
            var e = t.currentTarget.dataset.index, r = this.data.days[e];
            "disabled" !== r.type && this.$emit("click", r);
        },
        setDays: function() {
            for (var t = [], e = new Date(this.data.date), a = e.getFullYear(), n = e.getMonth(), o = (0, 
            r.getMonthEndDay)(e.getFullYear(), e.getMonth() + 1), i = 1; i <= o; i++) {
                var s = new Date(a, n, i), y = this.getDayType(s), l = {
                    date: s,
                    type: y,
                    text: i,
                    bottomInfo: this.getBottomInfo(y)
                };
                this.data.formatter && (l = this.data.formatter(l)), t.push(l);
            }
            this.setData({
                days: t
            });
        },
        getMultipleDayType: function(t) {
            var e = this.data.currentDate;
            if (!Array.isArray(e)) return "";
            var a = function(t) {
                return e.some(function(e) {
                    return 0 === (0, r.compareDay)(e, t);
                });
            };
            if (a(t)) {
                var n = (0, r.getPrevDay)(t), o = (0, r.getNextDay)(t), i = a(n), s = a(o);
                return i && s ? "multiple-middle" : i ? "end" : s ? "start" : "multiple-selected";
            }
            return "";
        },
        getRangeDayType: function(e) {
            var a = this.data, n = a.currentDate, o = a.allowSameDay;
            if (Array.isArray(n)) {
                var i = t(n, 2), s = i[0], y = i[1];
                if (s) {
                    var l = (0, r.compareDay)(e, s);
                    if (!y) return 0 === l ? "start" : "";
                    var u = (0, r.compareDay)(e, y);
                    return 0 === l && 0 === u && o ? "start-end" : 0 === l ? "start" : 0 === u ? "end" : l > 0 && u < 0 ? "middle" : void 0;
                }
            }
        },
        getDayType: function(t) {
            var e = this.data, a = e.type, n = e.minDate, o = e.maxDate, i = e.currentDate;
            return (0, r.compareDay)(t, n) < 0 || (0, r.compareDay)(t, o) > 0 ? "disabled" : "single" === a ? 0 === (0, 
            r.compareDay)(t, i) ? "selected" : "" : "multiple" === a ? this.getMultipleDayType(t) : "range" === a ? this.getRangeDayType(t) : void 0;
        },
        getBottomInfo: function(t) {
            if ("range" === this.data.type) {
                if ("start" === t) return "开始";
                if ("end" === t) return "结束";
                if ("start-end" === t) return "开始/结束";
            }
        }
    }
});