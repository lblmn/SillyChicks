var e = require("../@babel/runtime/helpers/interopRequireDefault")(require("../@babel/runtime/regenerator")), n = require("../@babel/runtime/helpers/asyncToGenerator");

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/loginDialog" ], {
    "293b": function(e, n, o) {
        var t = o("4e50");
        o.n(t).a;
    },
    "4e50": function(e, n, o) {},
    "99eb": function(e, n, o) {
        o.d(n, "b", function() {
            return t;
        }), o.d(n, "c", function() {
            return r;
        }), o.d(n, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    "9ac7": function(e, n, o) {
        o.r(n);
        var t = o("a1bb"), r = o.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = r.a;
    },
    a1bb: function(o, t, r) {
        (function(o) {
            var i = r("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var s, a, l, c = i(r("9296")), u = i(r("ac3e")), d = {
                name: "loginDialog",
                data: function() {
                    return {
                        showLogin: !1,
                        showMobile: !1,
                        loginRes: {},
                        phone: "",
                        showLoading: !1,
                        canIUseGetUserProfile: !1
                    };
                },
                props: {
                    isfromqw: {
                        type: Boolean,
                        default: !1
                    }
                },
                mounted: (l = n(e.default.mark(function n() {
                    var t;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (console.log("jiazaizujian"), 0 != Object.keys(o.getStorageSync("logininfo")).length) {
                                e.next = 9;
                                break;
                            }
                            return console.log("logindialog,微信登录"), e.next = 4, this.doLogin();

                          case 4:
                            return this.loginRes = e.sent, e.next = 7, this.getOpenid(this.loginRes);

                          case 7:
                            t = e.sent, o.setStorageSync("openId", t.data.openid), o.setStorageSync("sessionKey", t.data.sessionKey), 
                            console.log("code换的值", t), t.data.unionId ? (o.setStorageSync("unionId", t.data.unionId), 
                            getApp().hxt.identify({
                                openid: t.data.openid,
                                unionid: t.data.unionId
                            }), console.log(this.isfromqw), this.isfromqw && this.customerinfo(), this.getMemberinfo()) : (o.getUserProfile && (this.canIUseGetUserProfile = !0), 
                            this.showLogin = !0, o.hideLoading());

                          case 9:
                          case "end":
                            return e.stop();
                        }
                    }, n, this);
                })), function() {
                    return l.apply(this, arguments);
                }),
                methods: {
                    customerinfo: function() {
                        u.default.customerinfo(o.getStorageSync("unionId")).then(function(e) {
                            0 == e.code && (o.setStorageSync("shopCode", e.data.store_info[0].store_code), o.setStorageSync("channelLabel", "Work-WeChat"));
                        });
                    },
                    cancelFun: function() {
                        o.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    getNewUserInfo: function() {
                        return new Promise(function(e, n) {
                            o.getUserProfile({
                                desc: "会员信息",
                                success: function(n) {
                                    console.log(n), e(n);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    newInfo: (a = n(e.default.mark(function n() {
                        var t, r;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.getNewUserInfo();

                              case 2:
                                return t = e.sent, o.setStorageSync("wxinfo", t.userInfo), e.next = 6, this.getUnionid(t);

                              case 6:
                                r = e.sent, o.setStorageSync("unionId", r.data.unionId);

                              case 8:
                              case "end":
                                return e.stop();
                            }
                        }, n, this);
                    })), function() {
                        return a.apply(this, arguments);
                    }),
                    onGetUserInfo: (s = n(e.default.mark(function n() {
                        var t, r;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.getUserinfo(this.loginRes);

                              case 2:
                                return t = e.sent, o.setStorageSync("wxinfo", t.userInfo), e.next = 6, this.getUnionid(t);

                              case 6:
                                r = e.sent, o.setStorageSync("unionId", r.data.unionId), this.getMemberinfo();

                              case 8:
                              case "end":
                                return e.stop();
                            }
                        }, n, this);
                    })), function() {
                        return s.apply(this, arguments);
                    }),
                    doLogin: function() {
                        return new Promise(function(e, n) {
                            o.login({
                                success: function(n) {
                                    e(n);
                                }
                            });
                        });
                    },
                    getOpenid: function(e) {
                        return c.default.login({
                            code: e.code,
                            appId: this.$env.appId
                        }, !1);
                    },
                    getUserinfo: function(e) {
                        var n = this;
                        return new Promise(function(t, r) {
                            e.code ? o.getUserInfo({
                                success: function(e) {
                                    t(e);
                                },
                                fail: function(e) {
                                    n.showLogin = !0, console.log("拒绝了用户信息授权");
                                }
                            }) : (r("登录失败！" + e.errMsg), console.log("登录失败！" + e.errMsg));
                        });
                    },
                    getUnionid: function(e) {
                        return c.default.decrypt({
                            encryptedData: e.encryptedData,
                            openId: o.getStorageSync("openId"),
                            iv: e.iv
                        }, !1);
                    },
                    getMemberinfo: function() {
                        var e = this;
                        return new Promise(function(n, t) {
                            c.default.getmember({
                                idType: "2",
                                id: o.getStorageSync("unionId")
                            }, !1).then(function(r) {
                                console.log("getmemberinfo", r), 0 == r.resultCode ? (o.setStorageSync("logininfo", r.data), 
                                o.setStorageSync("socialhubId", r.data.socialhubId), console.log(e.returnUrl), console.log("即将刷新", e.returnUrl()[2]), 
                                console.log(e.$store.state), e.$store.commit("userinfo", r.data), e.$store.dispatch("getPoint"), 
                                o.setStorageSync("successInfo", "all"), "/pages/mine/mine" == e.returnUrl()[2] ? o.reLaunch({
                                    url: e.returnUrl()[2]
                                }) : (console.log("地址:", e.returnUrl()[2]), e.returnUrl()[2].includes("/pages/shop/shop") > 0 || e.returnUrl()[2].includes("/pages/attendance/attendance") > 0 || e.returnUrl()[2].includes("evaluation/repurchase/index") > 0 ? e.$emit("userInfoSuccess", "all") : o.redirectTo({
                                    url: e.returnUrl()[2]
                                })), n(r)) : (0 == Object.keys(o.getStorageSync("logininfo")).length ? (e.showMobile = !0, 
                                o.hideLoading()) : o.showToast({
                                    title: "请求会员信息异常请稍后重试",
                                    icon: "none"
                                }), t(r));
                            });
                        });
                    },
                    onGetPhoneNumber: function(e) {
                        this.showMobile = !1;
                        var n = this;
                        console.log(e), "getPhoneNumber:fail user deny" == e.detail.errMsg || "getPhoneNumber:fail:user deny" == e.detail.errMsg ? (console.log("取消授权"), 
                        n.$nextTick(function() {
                            n.showMobile = !0;
                        })) : c.default.decrypt({
                            encryptedData: e.detail.encryptedData,
                            openId: o.getStorageSync("openId"),
                            iv: e.detail.iv
                        }).then(function(e) {
                            n.phone = e.data.phoneNumber, o.setStorageSync("userinfoPhone", n.phone), n.bindQuery();
                        });
                    },
                    bindQuery: function() {
                        var e = this, n = o.getStorageSync("unionId"), t = o.getStorageSync("openId");
                        c.default.bindquery({
                            thirdPartyId: n,
                            openid: t,
                            source: 2,
                            mobilePhone: this.phone
                        }).then(function(r) {
                            console.log("会员绑定查询入参" + JSON.stringify({
                                thirdPartyId: n,
                                openid: t,
                                source: 2,
                                mobilePhone: e.phone
                            })), console.log("校验登录返回" + JSON.stringify(r)), 0 == r.resultCode ? "E000101" == r.resultDesc ? (console.log(e.returnUrl()), 
                            e.returnUrl()[2].includes("thanksgiving/getShareCard/index") ? (o.setStorageSync("channelLabel", "F22GEJ-Track"), 
                            o.redirectTo({
                                url: "/pages/register/register?url=" + e.returnUrl()[0] + "&param=" + JSON.stringify(e.returnUrl()[1])
                            })) : e.returnUrl()[2].includes("moonActive/rule/index") || e.returnUrl()[2].includes("source=CDPQ-MDNewActLAL2") || e.returnUrl()[2].includes("source=CDPS-MDNewActLAL2") || e.returnUrl()[2].includes("source=CDPQ-MDNewRet2") || e.returnUrl()[2].includes("source=CDPS-MDNewRet2") || e.returnUrl()[2].includes("source=CDPQ-MDNewLov2") || e.returnUrl()[2].includes("source=CDPS-MDNewLov2") ? o.navigateTo({
                                url: "/pages/register/register?fromType=mycard&url=" + e.returnUrl()[0] + "&param=" + JSON.stringify(e.returnUrl()[1])
                            }) : o.redirectTo({
                                url: "/pages/register/register?url=" + e.returnUrl()[0] + "&param=" + JSON.stringify(e.returnUrl()[1])
                            })) : "E000102" == r.resultDesc ? c.default.bind({
                                thirdPartyId: o.getStorageSync("unionId"),
                                thirdPartyName: o.getStorageSync("wxinfo").nickName,
                                openid: o.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: e.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: o.getStorageSync("unionId"),
                                    thirdPartyName: o.getStorageSync("wxinfo").nickName,
                                    openid: o.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: e.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (o.setStorageSync("socialhubId", n.data.socialhubId), 
                                e.showLoading = !0, Promise.all([ e.getMemberinfo() ]).then(function(e) {
                                    console.log("Promise.all:", e);
                                }).catch(function(e) {
                                    console.log("promiseall-error", e);
                                }).finally(function(n) {
                                    console.log("promiseall-finally", n), e.showLoading = !1, o.reLaunch({
                                        url: e.returnUrl()[2]
                                    });
                                })) : o.showToast({
                                    title: "请求异常请稍后重试",
                                    icon: "none"
                                });
                            }) : "E000103" == r.resultDesc ? (o.setStorageSync("socialhubId", r.data.socialhubId), 
                            e.showLoading = !0, Promise.all([ e.getMemberinfo() ]).then(function(e) {
                                console.log("Promise.all:", e);
                            }).catch(function(e) {
                                console.log("promiseall-error", e);
                            }).finally(function(n) {
                                console.log("promiseall-finally", n), e.showLoading = !1, "/pages/coffee/coffee" == e.returnUrl()[2] ? o.reLaunch({
                                    url: e.returnUrl()[2]
                                }) : o.redirectTo({
                                    url: e.returnUrl()[2]
                                });
                            })) : o.showToast({
                                title: "会员已被他人绑定",
                                icon: "none"
                            }) : 1 == r.resultCode && "E000107" == r.resultDesc ? c.default.bind({
                                thirdPartyId: o.getStorageSync("unionId"),
                                thirdPartyName: o.getStorageSync("wxinfo").nickName,
                                openid: o.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: e.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: o.getStorageSync("unionId"),
                                    thirdPartyName: o.getStorageSync("wxinfo").nickName,
                                    openid: o.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: e.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (o.setStorageSync("socialhubId", n.data.socialhubId), 
                                e.showLoading = !0, Promise.all([ e.getMemberinfo() ]).then(function(e) {
                                    console.log("Promise.all:", e);
                                }).catch(function(e) {
                                    console.log("promiseall-error", e);
                                }).finally(function(n) {
                                    console.log("promiseall-finally", n), e.showLoading = !1, o.reLaunch({
                                        url: "/pages/index/index"
                                    });
                                })) : o.showToast({
                                    title: "请求异常请稍后重试",
                                    icon: "none"
                                });
                            }) : o.showToast({
                                title: "请求异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    returnUrl: function() {
                        var e = getCurrentPages(), n = e[e.length - 1].route, o = e[e.length - 1].options, t = "";
                        if ("" == Object.keys(o)) t = "/" + n; else if (Object.keys(o).length > 0) {
                            var r = "";
                            for (var i in o) r += ("" == r ? "" : "&") + i + "=" + o[i];
                            t = "/" + n + "?" + r;
                        } else t = "/" + n;
                        return [ n, o, t ];
                    }
                }
            };
            t.default = d;
        }).call(this, r("543d").default);
    },
    d6e5: function(e, n, o) {
        o.r(n);
        var t = o("99eb"), r = o("9ac7");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(n, e, function() {
                return r[e];
            });
        }(i);
        o("293b");
        var s = o("f0c5"), a = Object(s.a)(r.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        n.default = a.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/loginDialog-create-component", {
    "components/loginDialog-create-component": function(e, n, o) {
        o("543d").createComponent(o("d6e5"));
    }
}, [ [ "components/loginDialog-create-component" ] ] ]);