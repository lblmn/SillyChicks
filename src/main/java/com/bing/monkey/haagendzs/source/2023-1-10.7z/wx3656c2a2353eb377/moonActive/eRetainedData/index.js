// moonActive/eRetainedData/index.js
Page({data: {}})