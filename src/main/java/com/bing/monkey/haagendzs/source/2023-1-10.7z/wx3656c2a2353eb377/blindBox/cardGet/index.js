// blindBox/cardGet/index.js
Page({data: {}})