(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/common_rule/index" ], {
    "47eb": function(e, t, n) {
        (function(e) {
            var o = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(n("f3d4")), c = o(n("0098")), i = o(n("8865")), u = (a.default.assetsRoot, 
            {
                props: {
                    showRule: {
                        type: Boolean,
                        default: !1
                    },
                    aid: {
                        type: String,
                        default: ""
                    },
                    type: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        ruleinfo: "",
                        name: ""
                    };
                },
                mounted: function() {
                    console.log(this.aid);
                },
                watch: {
                    showRule: function(e, t) {
                        t || (this.aid ? this.getActivityRecord() : this.type && this.getRule()), console.log(e, t);
                    }
                },
                methods: {
                    showRuleClose: function() {
                        this.$emit("showRuleClose", !1);
                    },
                    getRule: function() {
                        var e = this;
                        c.default.getRuledesc({
                            type: this.type
                        }).then(function(t) {
                            e.ruleinfo = t.data[0].content;
                        }).catch(function() {
                            e.ruleinfo = "暂无规则";
                        });
                    },
                    getActivityRecord: function() {
                        var t = this;
                        i.default.into({
                            aid: this.aid,
                            unionId: e.getStorageSync("unionId"),
                            openid: e.getStorageSync("openId"),
                            source: e.getStorageSync("smsSource") ? e.getStorageSync("smsSource") : "",
                            channel: e.getStorageSync("channelLabel") ? e.getStorageSync("channelLabel") : ""
                        }, !1).then(function(n) {
                            0 == n.code ? (console.log(n.data.activity.ruleDesc), t.ruleinfo = n.data.activity.ruleDesc ? n.data.activity.ruleDesc.replace(/\n/g, "<br/>") : "暂无规则", 
                            t.name = n.data.activity.name ? n.data.activity.name : "会员规则") : 500 == n.code && e.showToast({
                                icon: "none",
                                title: "抱歉来晚啦！活动已结束"
                            });
                        });
                    }
                }
            });
            t.default = u;
        }).call(this, n("543d").default);
    },
    "6aa8": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    "7a9b": function(e, t, n) {
        n.r(t);
        var o = n("6aa8"), a = n("85e0");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(c);
        n("bd14");
        var i = n("f0c5"), u = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = u.exports;
    },
    "85e0": function(e, t, n) {
        n.r(t);
        var o = n("47eb"), a = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        t.default = a.a;
    },
    9032: function(e, t, n) {},
    bd14: function(e, t, n) {
        var o = n("9032");
        n.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/common_rule/index-create-component", {
    "components/common_rule/index-create-component": function(e, t, n) {
        n("543d").createComponent(n("7a9b"));
    }
}, [ [ "components/common_rule/index-create-component" ] ] ]);