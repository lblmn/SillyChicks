// winterActivity/prize/index.js
Page({data: {}})