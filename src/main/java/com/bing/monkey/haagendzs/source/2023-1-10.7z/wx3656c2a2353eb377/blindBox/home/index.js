// blindBox/home/index.js
Page({data: {}})