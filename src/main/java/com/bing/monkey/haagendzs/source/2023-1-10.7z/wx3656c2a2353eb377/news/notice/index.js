// news/notice/index.js
Page({data: {}})