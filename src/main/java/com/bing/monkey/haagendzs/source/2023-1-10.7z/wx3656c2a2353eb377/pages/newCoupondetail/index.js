(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/newCoupondetail/index" ], {
    "052e": function(e, t, o) {
        (function(e) {
            var n = o("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = n(o("9523")), s = n(o("f9e2")), c = n(o("9619")), a = n(o("6c5a")), d = (n(o("9296")), 
            n(o("62aa"))), r = n(o("6638")), u = n(o("0098")), l = n(o("7d43")), h = n(o("f3d4")), f = n(o("8865")), g = n(o("d505")), p = o("26cb");
            function y(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function m(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? y(Object(o), !0).forEach(function(t) {
                        (0, i.default)(e, t, o[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : y(Object(o)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
                    });
                }
                return e;
            }
            var S = getApp().globalData.N_ENV.assetsRoot, b = "", I = {
                data: function() {
                    return {
                        show_productInfo: !1,
                        imgoss: h.default.ossurl + "images/home",
                        obj: {},
                        confirmVisible: !1,
                        showObtain: !1,
                        errorShowBtn: !1,
                        showShopCard: !1,
                        shopCodeInfo: "",
                        errorMsg: "",
                        selectCityVisible: !1,
                        cityShow: !1,
                        cityObj: {
                            text: "",
                            code: ""
                        },
                        cityArr: a.default,
                        cityAddress: d.default,
                        canChange: !0,
                        couponCode: "",
                        selectAddress: !1,
                        province: "请选择省份",
                        city: "请选择城市",
                        provinceShow: !1,
                        cityList: "",
                        cityListShow: !1,
                        typeShow: !1,
                        addressDetailShow: !1,
                        addressDetaillist: [],
                        addressId: "",
                        showDeleteAddress: !1,
                        deleteId: "",
                        showSumbit: !1,
                        pickType: "",
                        cityAddressGet: "",
                        cityAddObj: "",
                        moonTypeList: [ {
                            name: "电子券",
                            selected: !0,
                            ispay: !1
                        }, {
                            name: "纸质券",
                            selected: !1,
                            ispay: !0
                        } ],
                        today: "",
                        nouseCards: !1,
                        moonGetWarming: "",
                        ruleDesc_a: "",
                        showbuild_a: !1,
                        showIcon_btn: !1,
                        qty: 1,
                        showPick: !1,
                        showDetailInfo: !1,
                        imgossDetail: h.default.ossurl + "/UX/detail/",
                        nopadding: !1,
                        canUseMore: !0,
                        usePointType: 2,
                        isAuth: !1,
                        resultlast: !1,
                        resultlastName: -1,
                        resultText: "恭喜您获得限定化妆品收纳盒一份",
                        moonType: "",
                        resultlast_pack: !1,
                        ruleDesc_a_title: "",
                        noChangeCard: !1,
                        showLastWarn: !1,
                        isCardPackage: !1,
                        itemvalue: "selected",
                        checked: !1,
                        showRule: !1,
                        ruletype: 9
                    };
                },
                onLoad: function(e) {
                    this.$refs.Loading.showLoading(), this.getDetails(e.couponRuleId);
                },
                components: {
                    Loading: function() {
                        o.e("components/loading").then(function() {
                            return resolve(o("64ff"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                computed: m(m({}, (0, p.mapState)([ "navbarHeight_a", "moonCakeAvailablePoint", "points_other", "nextMonthExpiredPoints" ])), {}, {
                    moonCakeAvailablePoint_btn: function() {
                        var e = new Date(), t = l.default.dateFormat("YYYY-mm-dd", e);
                        return l.default.timeDiff(t, "2022-09-01") || this.moonCakeAvailablePoint <= 0 ? (this.usePointType = 1, 
                        !1) : (this.usePointType = 2, !0);
                    },
                    allPrice: function() {
                        return this.obj.requiredPoints * this.qty;
                    }
                }),
                onShow: function() {
                    this.addressList(), console.log("重新加载");
                    var t = new Date();
                    this.today = l.default.dateFormat("YYYY-mm-dd", t), l.default.timeDiff(this.today, "2022-09-08") ? this.noChangeCard = !0 : this.noChangeCard = !1, 
                    e.getStorageSync("isDuihuan") && e.removeStorageSync("isDuihuan");
                },
                onHide: function() {
                    this.confirmVisible = !1, this.selectCityVisible = !1, this.showObtain = !1;
                },
                methods: {
                    showRuleClose: function(e) {
                        console.log(e), this.showRule = e;
                    },
                    lineshowrule: function() {
                        this.showRule = !0;
                    },
                    checkboxChange: function(e) {
                        console.log(e), e.detail.value.length > 0 ? this.checked = !0 : this.checked = !1;
                    },
                    gotoResult: function() {
                        "1" == this.resultlastName ? e.redirectTo({
                            url: "../mine/mycard?indexs=2",
                            complete: function() {
                                e.removeStorageSync("pickResult");
                            }
                        }) : "2" == this.resultlastName ? e.redirectTo({
                            url: "../mine/order",
                            complete: function() {
                                e.removeStorageSync("pickResult");
                            }
                        }) : e.redirectTo({
                            url: "../mine/mycard?indexs=2",
                            complete: function() {
                                e.removeStorageSync("pickResult");
                            }
                        });
                    },
                    changePointsType: function(e) {
                        this.usePointType = e;
                    },
                    close_show_productInfo: function() {
                        this.show_productInfo = !1, this.qty = 1;
                    },
                    getDetails: function(t) {
                        var o = this, n = this;
                        u.default.getDetail({
                            unionId: e.getStorageSync("unionId"),
                            couponRuleId: t,
                            openId: e.getStorageSync("openId")
                        }).then(function(e) {
                            if (console.log(e), 0 == e.code) {
                                var t, i = e.data;
                                2 == (null === (t = e.data) || void 0 === t ? void 0 : t.ebuyCheck) ? o.canUseMore = !1 : o.canUseMore = !0, 
                                n.obj = m(m({}, i), {}, {
                                    giftPicUrl: i.giftPicUrl ? S + i.giftPicUrl : S + "/oss/wxapp/big.jpg",
                                    couponPicUrl: i.couponPicUrl ? S + i.couponPicUrl : S + "/oss/wxapp/big.jpg",
                                    ruleDesc: i.ruleDesc ? i.ruleDesc.replace(/\n/g, "<br/>") : "",
                                    requireAll: i.requiredPoints + (1 == i.channel ? "积心" : "集豆"),
                                    points: i.requiredPoints,
                                    channelType: 1 == i.channel ? "积心" : "集豆",
                                    name: i.giftName,
                                    time: "".concat(n.$util.dateFormat("YYYY年mm月dd日", new Date(i.startTime.replace(/-/g, "/"))), "- ").concat(n.$util.dateFormat("YYYY年mm月dd日", new Date(i.endTime.replace(/-/g, "/"))))
                                }), "1" == n.obj.moonType && (l.default.timeDiffAll(o.today, "2022-08-15", "2022-09-10") ? o.showIcon_btn = !0 : o.showIcon_btn = !1), 
                                2 == n.obj.ebuyCheck ? n.isCardPackage = !0 : n.isCardPackage = !1, n.showDetailInfo = !0, 
                                n.$refs.Loading.hideLoading(1500);
                            }
                        }).catch(function() {
                            n.$refs.Loading.hideLoading(1500);
                        }), n.getCity(), l.default.recordPv("/pages/coupondetail/coupondetail?idpv=" + n.obj.id);
                    },
                    reduceFun: function() {
                        if (this.qty <= 1) return e.showToast({
                            title: "不能再减啦~",
                            icon: "none",
                            mask: !0
                        }), !1;
                        this.qty = this.qty - 1;
                    },
                    addFun: function() {
                        return console.log(this.qty, this.obj.canNum), this.obj.canNum >= 20 && this.qty >= 20 ? (this.qty = 20, 
                        e.showToast({
                            title: "单次兑换上限是" + this.qty + "张",
                            icon: "none",
                            mask: !0
                        }), !1) : this.qty >= this.obj.canNum && this.obj.canNum <= 20 ? (e.showToast({
                            title: "单次兑换上限是" + this.obj.canNum + "张",
                            icon: "none",
                            mask: !0
                        }), !1) : void (this.qty = this.qty + 1);
                    },
                    getRuleDesc_a: function() {
                        var t = this;
                        "release" == h.default.envVersion ? this.aid_a = "120" : this.aid_a = "78", f.default.activityGet(this.aid_a, {
                            openId: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            console.log(e), t.ruleDesc_a = e.data.activity.ruleDesc ? e.data.activity.ruleDesc.replace(/\n/g, "<br/>") : "暂无活动规则", 
                            t.ruleDesc_a_title = e.data.activity.name, t.showIcon_btn = !1, t.showbuild_a = !0;
                        }).catch(function() {
                            t.ruleDesc_a = "暂无活动规则", t.showIcon_btn = !1, t.showbuild_a = !0;
                        });
                    },
                    addressDetailShowFun: function() {
                        this.addressDetailShow = !1, l.default.timeDiffAll(this.today, "2022-08-15", "2022-09-10") ? this.showIcon_btn = !0 : this.showIcon_btn = !1;
                    },
                    nousePopup: function() {
                        this.nouseCards = !1, this.addressDetailShow = !1, this.moonTypeList[0].selected = !0, 
                        this.moonTypeList.length > 1 && (this.moonTypeList[1].selected = !1), this.pickType = 1, 
                        e.setStorageSync("pickType", 1);
                    },
                    buildhide_a: function() {
                        this.showbuild_a = !1, this.showIcon_btn = !0;
                    },
                    PaperMoonSubmit: function() {
                        var t = new Date().getTime(), o = {
                            unionId: e.getStorageSync("unionId"),
                            channel: this.obj.channel,
                            openId: e.getStorageSync("openId"),
                            cityName: "021",
                            pickType: this.pickType,
                            addressId: this.addressId,
                            qty: this.qty,
                            couponRuleId: this.obj.couponRuleId,
                            sign: l.default.mdString(t, {
                                openId: e.getStorageSync("openId"),
                                unionId: e.getStorageSync("unionId"),
                                couponRuleId: this.obj.couponRuleId
                            }),
                            timestamp: t,
                            usePointType: this.usePointType
                        };
                        this.exchangeFun(o);
                    },
                    sumbitMoon: function() {
                        if ("" == this.addressId) return e.showToast({
                            icon: "none",
                            title: "选择寄送纸质券地址"
                        }), !1;
                        this.showSumbit = !0;
                    },
                    selectAddressF: function() {
                        this.selectAddress = !1, this.pickType = "", this.moonTypeList[0].selected = !0, 
                        this.moonTypeList.length > 1 && (this.moonTypeList[1].selected = !1), this.cityAddObj = "", 
                        this.city = "请选择城市", this.qty = 1, this.confirmVisible = !1, this.show_productInfo = !1, 
                        e.removeStorageSync("pickType"), this.showLastWarn = !1;
                    },
                    selectMoonType: function(t, o) {
                        console.log(t), this.moonTypeList.length > 1 ? 0 == o ? (this.moonTypeList[0].selected = !0, 
                        this.moonTypeList[1].selected = !1, this.pickType = 1, e.setStorageSync("pickType", 1)) : (this.moonTypeList[0].selected = !1, 
                        this.moonTypeList[1].selected = !0, this.pickType = 2, e.setStorageSync("pickType", 2)) : (this.moonTypeList[0].selected = !0, 
                        this.pickType = 1, e.setStorageSync("pickType", 1));
                    },
                    getCityByRuleId: function() {
                        var e = this;
                        c.default.getCityByRuleId(this.obj.couponRuleId).then(function(t) {
                            console.log(t), 0 == t.code ? e.cityAddressGet = t.data : (e.cityAddressGet = r.default.cityArrMoon, 
                            e.filterMoonCity());
                        }).catch(function() {
                            e.cityAddressGet = r.default.cityArrMoon, e.filterMoonCity();
                        });
                    },
                    getCity: function() {
                        var e = this;
                        c.default.getCity().then(function(t) {
                            console.log(t), 0 == t.code ? (e.cityAddressGet = t.data, e.filterMoonCity()) : (e.cityAddressGet = r.default.cityArrMoon, 
                            e.filterMoonCity());
                        }).catch(function() {
                            e.cityAddressGet = r.default.cityArrMoon, e.filterMoonCity();
                        });
                    },
                    filterMoonCity: function() {
                        var e = [ "312", "315", "311" ];
                        "CS03" != this.obj.couponRuleId && "jfsc003" != this.obj.couponRuleId || (this.cityAddressGet = this.cityAddressGet.filter(function(t) {
                            return -1 == e.indexOf(t.codeSn);
                        }));
                    },
                    accout: function() {
                        u.default.point({
                            idType: "1",
                            id: e.getStorageSync("socialhubId")
                        }).then(function(t) {
                            0 == t.resultCode ? (getApp().globalData.PointAccount = t.data, t.data.filter(function(e) {
                                return e.pointAccountName.indexOf("积心") > -1;
                            })[0]) : e.showToast({
                                title: "请求积分异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    gotoAttend: function() {
                        e.navigateTo({
                            url: "/pages/attendance/attendance",
                            complete: function() {}
                        });
                    },
                    deleteAddress: function(e) {
                        this.deleteId = e, this.showDeleteAddress = !0;
                    },
                    deleteAddressF: function() {
                        var t = this;
                        c.default.removeAddress({
                            id: this.deleteId,
                            openId: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            console.log(e), 0 == e.code ? (t.addressList(), t.deleteId = "", t.showDeleteAddress = !1) : t.showDeleteAddress = !1;
                        });
                    },
                    addressList: function() {
                        var t = this;
                        c.default.addressList({
                            openId: e.getStorageSync("openId"),
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            if (404 == e.code) t.addressDetaillist = []; else if (0 == e.code) {
                                var o = e.data;
                                o.forEach(function(e) {
                                    e.selected = !1;
                                }), t.addressDetaillist = o;
                            }
                        });
                    },
                    navigateTo: function(t, o) {
                        o && (t = t + "?addressId=" + o + "&from=coupondetail"), e.navigateTo({
                            url: t + "?from=coupondetail"
                        }), console.log(t);
                    },
                    onRuleChange: function(e, t) {
                        console.log(e), console.log(t), this.addressId == e.id ? (this.addressDetaillist[t].selected = !1, 
                        this.addressId = "") : (this.addressDetaillist.forEach(function(e) {
                            e.selected = !1;
                        }), l.default.timeDiff(this.today, "2022-09-10") ? e.cityName.indexOf("上海") > -1 ? (this.addressDetaillist[t].selected = !e.selected, 
                        this.addressId = e.id) : this.nouseCards = !0 : (this.addressDetaillist[t].selected = !e.selected, 
                        this.addressId = e.id));
                    },
                    selectProvince: function() {
                        this.provinceShow = !0;
                    },
                    onprovinceConfirm: function(e) {
                        console.log(e), this.province = e.detail.value, this.city = "请选择城市", this.provinceShow = !1;
                    },
                    selectCity: function() {
                        var e = this, t = [];
                        this.cityAddressGet.forEach(function(o) {
                            ("jfsc003" == e.obj.couponRuleId || "jfsc003_01" == e.obj.couponRuleId || "jfsc003_02" == e.obj.couponRuleId || "jfsc003_03" == e.obj.couponRuleId || "CS03_03" == e.obj.couponRuleId || "CS03_02" == e.obj.couponRuleId || "CS03" == e.obj.couponRuleId) && ("石家庄" == o.name || "唐山" == o.name || "保定" == o.name) || t.push(o.name);
                        }), console.log(t), this.cityList = t, this.cityListShow = !0;
                    },
                    onCityConfirm: function(e) {
                        var t = this;
                        console.log(e), this.city = e.detail.value, this.cityAddressGet.forEach(function(o) {
                            o.name == e.detail.value && (t.cityAddObj = o);
                        }), this.cityListShow = !1;
                    },
                    closeShowShopCard: function() {
                        this.showShopCard = !1, this.confirmVisible = !1;
                    },
                    showGrantFun: function() {
                        var t = this;
                        c.default.isKhbAuth(e.getStorageSync("unionId")).then(function(e) {
                            console.log(e), 0 == e.code ? t.isAuth = !0 : t.isAuth = !1;
                        }).catch(function() {
                            t.isAuth = !1;
                        });
                    },
                    confirmExchange: function() {
                        var e = this;
                        if (e.obj.requiredAmount > 0) if ("1" == e.obj.useAddress) e.selectCityVisible = !0; else if ("1" == e.obj.moonType) {
                            var t = new Date(), o = l.default.dateFormat("YYYY-mm-dd", t);
                            l.default.timeDiffAll(o, "2022-08-15", "2022-09-10") ? c.default.moonGet().then(function(t) {
                                console.log(t), 0 == t.code ? (t.data.exCount >= t.data.store ? e.moonGetWarming = "活动火爆，限量周边已全部领完，是否继续兑购" : (e.moonGetWarming = "", 
                                e.showGrantFun()), e.confirmVisible = !0) : e.confirmVisible = !0;
                            }).catch(function() {
                                e.confirmVisible = !0;
                            }) : e.confirmVisible = !0;
                        } else "5" == e.obj.moonType ? e.confirmVisible = !0 : e.handleExchange(); else e.handleExchange();
                    },
                    authFun: function() {
                        var t = this;
                        e.requestSubscribeMessage({
                            tmplIds: [ "x7jigI-jwliSYQsZw6kTWQ6WPkUHQGJDgHfoCHppjTI", "k7IePaN3GhM_le23Smb1B9io6h96gOT5jEO6jz_wH78" ],
                            complete: function() {
                                t.handleExchange();
                            }
                        });
                    },
                    handleExchange: function() {
                        var t = this;
                        if (this.confirmVisible = !1, this.obj.requiredAmount > 0 && "" == this.cityObj.code && "1" == this.obj.useAddress) e.showToast({
                            title: "请选择领取城市",
                            icon: "none"
                        }); else if ("1" == this.obj.moonType || "5" == this.obj.moonType) {
                            if (!this.canChange) return;
                            this.canChange = !1, this.$toast.loading({
                                mask: !0,
                                message: "正在加载...",
                                duration: 1e4
                            }), s.default.isbuy({
                                id: this.obj.id,
                                unionId: e.getStorageSync("unionId"),
                                channel: this.obj.channel,
                                socialHubid: e.getStorageSync("socialhubId")
                            }).then(function(o) {
                                0 == o.code ? (l.default.timeDiff(t.today, "2022-09-08") && (t.moonTypeList = [ {
                                    name: "电子券",
                                    selected: !0,
                                    ispay: !1
                                } ]), t.selectAddress = !0, t.pickType = 1, t.showPick = !1, e.setStorageSync("pickType", 1)) : 407 == o.code ? (t.moonTypeList = [ {
                                    name: "电子券",
                                    selected: !0,
                                    ispay: !1
                                } ], t.selectAddress = !0, t.pickType = 1, t.showPick = !0, e.setStorageSync("pickType", 1)) : (o.msg.includes("E000115") ? (t.errorMsg = "您已达到限购次数", 
                                t.selectAddressF()) : o.msg.includes("E000113") ? (t.errorMsg = "积心余额不足，无法支付", t.selectAddressF()) : -1 == o.code ? ("请勿刷单" == o.msg || "" == o.msg ? (t.errorShowBtn = !1, 
                                t.errorMsg = "兑换失败，请联系客服") : (t.errorShowBtn = !0, t.errorMsg = o.msg), t.selectAddressF()) : (t.errorMsg = "" == o.msg || "请勿刷单" == o.msg ? "兑换失败，请联系客服" : o.msg, 
                                t.selectAddressF()), t.showObtain = !0);
                            }).finally(function(e) {
                                t.canChange = !0, t.selectCityVisible = !1, t.$toast.clear();
                            });
                        } else this.canIsBuy();
                    },
                    canIsBuy: function() {
                        var t = this;
                        getApp().hxt.sendAction("redeem_clk"), this.canChange && (this.canChange = !1, s.default.isbuy({
                            id: this.obj.id,
                            unionId: e.getStorageSync("unionId"),
                            channel: this.obj.channel,
                            socialHubid: e.getStorageSync("socialhubId")
                        }).then(function(e) {
                            0 == e.code ? t.show_productInfo = !0 : -1 == e.code || -8 == e.code ? (0, g.default)({
                                message: "积心不足",
                                type: "warning-o"
                            }) : (t.errorMsg = "" == e.msg || "请勿刷单" == e.msg ? "兑换失败，请联系客服" : e.msg, t.showObtain = !0);
                        }).catch(function() {
                            t.errorMsg = "访问异常，小哈正在努力恢复，请稍后重试", t.showObtain = !0;
                        }).finally(function(e) {
                            t.canChange = !0;
                        }));
                    },
                    lastExchangeFun: function() {
                        var t = new Date().getTime();
                        if (this.isCardPackage && !this.checked) return e.showToast({
                            title: "请先阅读规则",
                            icon: "none"
                        }), !1;
                        var o = {
                            unionId: e.getStorageSync("unionId"),
                            channel: this.obj.channel,
                            openId: e.getStorageSync("openId"),
                            qty: this.qty,
                            couponRuleId: this.obj.couponRuleId,
                            shopCodeSign: e.getStorageSync("qycode"),
                            sign: l.default.mdString(t, {
                                openId: e.getStorageSync("openId"),
                                unionId: e.getStorageSync("unionId"),
                                couponRuleId: this.obj.couponRuleId
                            }),
                            timestamp: t
                        };
                        getApp().hxt.sendAction("redeem_confirm", {
                            coupon_id: this.obj.id,
                            coupon_name: this.obj.giftName,
                            coupon_num: this.qty,
                            cost_point: this.obj.requiredPoints + "积分" + (this.obj.requiredAmount > 0 ? this.obj.requiredAmount + "元" : "")
                        }), this.exchangeFun(o);
                    },
                    showLastWarning: function() {
                        var t = new Date().getTime(), o = {
                            unionId: e.getStorageSync("unionId"),
                            channel: this.obj.channel,
                            openId: e.getStorageSync("openId"),
                            cityName: this.cityAddObj.codeSn,
                            pickType: this.pickType,
                            addressId: this.addressId,
                            qty: this.qty,
                            couponRuleId: this.obj.couponRuleId,
                            sign: l.default.mdString(t, {
                                openId: e.getStorageSync("openId"),
                                unionId: e.getStorageSync("unionId"),
                                couponRuleId: this.obj.couponRuleId
                            }),
                            timestamp: t,
                            usePointType: this.usePointType
                        };
                        this.exchangeFun(o);
                    },
                    exchangeMoon: function() {
                        if (1 == this.pickType) {
                            if ("" == this.cityAddObj) return e.showToast({
                                icon: "none",
                                title: "请选择提领城市"
                            }), !1;
                            this.showLastWarn = !0;
                        } else 2 == this.pickType && (this.showIcon_btn = !1, this.addressDetailShow = !0);
                    },
                    exchangeFun: function(t) {
                        var o = this;
                        this.canChange = !1, this.$toast.loading({
                            mask: !0,
                            message: "正在加载...",
                            duration: 1e4
                        }), s.default.exchange(m(m({}, t), {}, {
                            socialHubid: e.getStorageSync("socialhubId")
                        })).then(function(t) {
                            if (console.log("兑换月饼券返回参数天正", t), 0 == t.code) e.showToast({
                                title: "兑换成功..."
                            }), b = Array.isArray(t.data) ? t.data[0] : t.data, "2" == o.obj.orderType || t.data.length > 1 ? setTimeout(function() {
                                e.redirectTo({
                                    url: "../mine/mycard"
                                });
                            }, 800) : setTimeout(function() {
                                e.redirectTo({
                                    url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(o.obj)) + "&couponCode=" + b.couponCode + "&couponRuleId=" + b.couponRuleId + "&effectEnd=" + b.effectEnd + "&effectBegin=" + b.effectBegin
                                });
                            }, 800); else if (200 == t.code) {
                                console.log(t);
                                var n = t.data, i = n.timeStamp, s = n.nonceStr, a = n.signType, d = n.paySign, r = n.couponRuleId, u = n.giftExchangeRecordId, h = n.orderCode, f = n.pointRecordId;
                                e.requestPayment({
                                    provider: "wxpay",
                                    timeStamp: i,
                                    nonceStr: s,
                                    package: t.data.package,
                                    signType: a,
                                    paySign: d,
                                    success: function(t) {
                                        console.log("success:" + JSON.stringify(t)), o.$toast.loading({
                                            mask: !0,
                                            message: "正在生成...",
                                            duration: 1e4
                                        });
                                        var n = new Date().getTime();
                                        c.default.exchangeSave({
                                            couponRuleId: r,
                                            giftExchangeRecordId: u,
                                            orderCode: h,
                                            pointRecordId: f,
                                            provinceCode: "",
                                            cityCode: o.cityObj.code,
                                            id: e.getStorageSync("unionId"),
                                            pickType: o.pickType,
                                            addressId: o.addressId,
                                            openid: e.getStorageSync("openId"),
                                            unionId: e.getStorageSync("unionId"),
                                            sign: l.default.mdString(n, {
                                                openid: e.getStorageSync("openId"),
                                                unionId: e.getStorageSync("unionId"),
                                                giftExchangeRecordId: u
                                            }),
                                            timestamp: n
                                        }).then(function(t) {
                                            console.log("save", JSON.stringify(t));
                                            var n = o;
                                            if (0 == t.code) if (n.obj.cityCode = n.cityObj.code, "3" == n.obj.moonType) setTimeout(function() {
                                                e.redirectTo({
                                                    url: "../mine/mycard"
                                                });
                                            }, 800); else if ("1" == n.obj.moonType) {
                                                1 == e.getStorageSync("pickType") ? (n.selectAddressF(), e.setStorageSync("pickResult", 1), 
                                                n.resultlastName = 1) : 2 == e.getStorageSync("pickType") && (n.selectAddressF(), 
                                                n.resultlastName = 2, e.setStorageSync("pickResult", 2));
                                                var i = new Date(), s = l.default.dateFormat("YYYY-mm-dd", i);
                                                l.default.timeDiffAll(s, "2022-08-15", "2022-09-10") && "" == n.moonGetWarming ? n.resultlast = !0 : n.resultlast_pack = !0;
                                            } else "5" == n.obj.moonType ? 1 == e.getStorageSync("pickType") ? (n.selectAddressF(), 
                                            e.setStorageSync("pickResult", 1), n.resultlastName = 1, n.resultlast_pack = !0) : 2 == e.getStorageSync("pickType") && (n.selectAddressF(), 
                                            n.resultlastName = 2, e.setStorageSync("pickResult", 2), n.resultlast_pack = !0) : Array.isArray(t.data) ? t.data.length > 1 ? 2 == e.getStorageSync("pickType") ? setTimeout(function() {
                                                e.redirectTo({
                                                    url: "../mine/order",
                                                    complete: function() {
                                                        e.removeStorageSync("pickType");
                                                    }
                                                });
                                            }, 800) : setTimeout(function() {
                                                e.redirectTo({
                                                    url: "../mine/mycard"
                                                });
                                            }, 800) : e.navigateTo({
                                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(o.obj)) + "&couponCode=" + t.data[0].couponCode + "&couponRuleId=" + t.data[0].couponRuleId + "&effectEnd=" + t.data[0].effectEnd + "&effectBegin=" + t.data[0].effectBegin
                                            }) : e.navigateTo({
                                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(o.obj)) + "&couponCode=" + t.data.couponCode + "&couponRuleId=" + t.data.couponRuleId + "&effectEnd=" + t.data.effectEnd + "&effectBegin=" + t.data.effectBegin
                                            }); else "E000115" == t.msg ? (o.errorMsg = "兑换已达上限，如有疑问请联系客服热线~", o.selectAddressF(), 
                                            o.showObtain = !0) : (console.log("save接口出错了"), (0, g.default)("兑换失败，请重试"));
                                        }).finally(function() {
                                            o.$toast.clear();
                                        });
                                    },
                                    fail: function(e) {
                                        console.log("fail:" + JSON.stringify(e)), o.selectAddressF(), (0, g.default)("支付失败，请重试");
                                    }
                                });
                            } else o.$toast.clear(), t.msg.includes("E000115") ? (o.errorMsg = "您已达到限购次数", o.showObtain = !0) : t.msg.includes("E000113") ? (o.errorMsg = "积心余额不足，无法支付", 
                            o.showObtain = !0) : -1 == t.code ? ("兑换失败！" == t.msg ? (o.errorMsg = "" == t.msg || "请勿刷单" == t.msg ? "兑换失败，请联系客服" : t.msg, 
                            o.showObtain = !0) : (0, g.default)({
                                message: "积心不足",
                                type: "warning-o"
                            }), o.selectAddressF()) : (o.errorMsg = "" == t.msg || "请勿刷单" == t.msg ? "兑换失败，请联系客服" : t.msg, 
                            o.selectAddressF(), o.showObtain = !0);
                        }).finally(function(e) {
                            o.canChange = !0, o.selectCityVisible = !1, o.addressDetailShow = !1, o.showSumbit = !1, 
                            o.addressId = "", o.addressDetaillist.forEach(function(e) {
                                e.selected = !1;
                            });
                        });
                    }
                }
            };
            t.default = I;
        }).call(this, o("543d").default);
    },
    "08e3": function(e, t, o) {
        o.r(t);
        var n = o("3351"), i = o("3959");
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(e) {
            o.d(t, e, function() {
                return i[e];
            });
        }(s);
        o("5b82");
        var c = o("f0c5"), a = Object(c.a)(i.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        t.default = a.exports;
    },
    3351: function(e, t, o) {
        o.d(t, "b", function() {
            return n;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {});
        var n = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.confirmVisible = !1;
            }, e.e1 = function(t) {
                e.confirmVisible = !1;
            }, e.e2 = function(t) {
                e.isAuth ? e.authFun() : e.handleExchange();
            }, e.e3 = function(t) {
                e.showObtain = !1;
            }, e.e4 = function(t) {
                e.showObtain = !1;
            }, e.e5 = function(t) {
                e.selectCityVisible = !1;
            }, e.e6 = function(t) {
                e.cityShow = !0;
            }, e.e7 = function(t) {
                e.selectCityVisible = !1;
            }, e.e8 = function(t) {
                e.cityShow = !1;
            }, e.e9 = function(t) {
                e.cityShow = !1;
            }, e.e10 = function(t) {
                e.provinceShow = !1;
            }, e.e11 = function(t) {
                e.provinceShow = !1;
            }, e.e12 = function(t) {
                e.cityListShow = !1;
            }, e.e13 = function(t) {
                e.cityListShow = !1;
            }, e.e14 = function(t) {
                e.typeShow = !1;
            }, e.e15 = function(t) {
                e.typeShow = !1;
            }, e.e16 = function(t) {
                e.showDeleteAddress = !1;
            }, e.e17 = function(t) {
                e.showDeleteAddress = !1;
            }, e.e18 = function(t) {
                e.nouseCards = !1;
            }, e.e19 = function(t) {
                e.nouseCards = !1;
            }, e.e20 = function(t) {
                e.showSumbit = !1;
            }, e.e21 = function(t) {
                e.showSumbit = !1;
            }, e.e22 = function(t) {
                e.showLastWarn = !1;
            }, e.e23 = function(t) {
                e.showIcon_btn = !1;
            });
        }, i = [];
    },
    3959: function(e, t, o) {
        o.r(t);
        var n = o("052e"), i = o.n(n);
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(s);
        t.default = i.a;
    },
    "5b82": function(e, t, o) {
        var n = o("9728");
        o.n(n).a;
    },
    9728: function(e, t, o) {},
    efde: function(e, t, o) {
        (function(e) {
            var t = o("4ea4");
            o("a1ea"), t(o("66fd"));
            var n = t(o("08e3"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = o, e(n.default);
        }).call(this, o("543d").createPage);
    }
}, [ [ "efde", "common/runtime", "common/vendor" ] ] ]);