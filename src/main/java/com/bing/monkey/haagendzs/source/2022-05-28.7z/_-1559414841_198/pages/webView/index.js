(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/webView/index" ], {
    "4e28": function(e, n, t) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            t("c0e2"), n(t("66fd")), e(n(t("595a")).default);
        }).call(this, t("543d").createPage);
    },
    "595a": function(e, n, t) {
        t.r(n);
        var o = t("dbe4"), r = t("ea6b");
        for (var c in r) "default" !== c && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        var u = t("f0c5"), l = Object(u.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = l.exports;
    },
    ceb1: function(e, n, t) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var o = {
            data: function() {
                return {
                    webviewStyles: {
                        progress: {
                            color: "#FF3333"
                        }
                    },
                    url: ""
                };
            },
            onLoad: function(e) {
                console.log(e), console.log(Object.keys(e));
                var n = "https://www.gmfs-ecoupon.com/hgdz_delivery/doEntry", t = "";
                if (Object.keys(e).length > 0) {
                    for (var o in e) t += "".concat(o, "=").concat(e[o], "&");
                    t = t.substring(0, t.length - 1), this.url = n + "?serviceMethod=deliveryEntry&" + t;
                } else this.url = n + "?serviceMethod=deliveryEntry";
                console.log(this.url);
            }
        };
        n.default = o;
    },
    dbe4: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    ea6b: function(e, n, t) {
        t.r(n);
        var o = t("ceb1"), r = t.n(o);
        for (var c in o) "default" !== c && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = r.a;
    }
}, [ [ "4e28", "common/runtime", "common/vendor" ] ] ]);