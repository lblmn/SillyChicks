(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/order" ], {
    "5a3e": function(t, e, n) {
        (function(t) {
            var e = n("4ea4");
            n("a1ea"), e(n("66fd"));
            var o = e(n("e92c"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = n, t(o.default);
        }).call(this, n("543d").createPage);
    },
    "7a12": function(t, e, n) {
        var o = n("fcfe");
        n.n(o).a;
    },
    "912e": function(t, e, n) {
        n.r(e);
        var o = n("9de5"), i = n.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        e.default = i.a;
    },
    "9de5": function(t, e, n) {
        (function(t) {
            var o = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = o(n("9523")), a = o(n("8be7")), r = (o(n("0098")), o(n("9619"))), c = o(n("7d43"));
            function s(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function d(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? s(Object(n), !0).forEach(function(e) {
                        (0, i.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            var u = (getApp().globalData.N_ENV.assetsRoot, {
                components: {
                    Zduihuan: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/Zduihuan") ]).then(function() {
                            return resolve(n("524a"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        tabActive: "100000000",
                        tabs: [ {
                            name: "100000000",
                            title: "购买信息订单"
                        }, {
                            name: "100000001",
                            title: "积心兑换订单"
                        } ],
                        cardList: [],
                        nextId: "",
                        pageSize: 10,
                        noMore: !1,
                        order: "",
                        showOrder: !1,
                        showOrderFail: !1,
                        errtext: "预计将于3-5个工作日内安排寄送纸质券，<br/>敬请关注～",
                        popup_text: "您可点击“复制”运单号，前往顺丰官方网站，\n查询您的物流配送信息哦~"
                    };
                },
                onLoad: function(e) {
                    console.log(e), this.source = e.soure ? e.soure : e.source, t.setStorageSync("source", this.source), 
                    this.tabActive = e.tabActive ? e.tabActive : "100000000", "100000001" == this.tabActive || "100000002" == this.tabActive ? this.getList() : "100000000" == this.tabActive && this.getList_cash();
                },
                onShow: function() {
                    c.default.recordPv();
                },
                methods: {
                    copy: function() {
                        var e = this;
                        t.setClipboardData({
                            data: this.order,
                            success: function(n) {
                                t.getClipboardData({
                                    success: function(n) {
                                        t.showToast({
                                            title: "复制成功"
                                        }), e.showOrder = !1;
                                    }
                                });
                            }
                        });
                    },
                    getBillNoF: function(e) {
                        var n = this;
                        if (console.log(e), !e) return this.showOrderFail = !0, !1;
                        r.default.getBillNo(e).then(function(t) {
                            console.log(e), 0 == t.code ? (n.order = t.data, n.showOrder = !0) : n.showOrderFail = !0;
                        }).catch(function() {
                            return t.showToast({
                                title: "预计将于3-5个工作日内安排寄送纸质券，敬请关注～",
                                icon: "none",
                                mask: !0,
                                duration: 1500
                            }), !1;
                        });
                    },
                    getRecord: function() {
                        commonApi.saveLoginRecord({
                            unionId: t.getStorageSync("unionId"),
                            openId: t.getStorageSync("openId"),
                            source: t.getStorageSync("source")
                        }).then(function(t) {
                            console.log(t);
                        });
                    },
                    getList: function() {
                        var e = this, n = "";
                        "100000001" == this.tabActive ? n = {
                            idType: 1,
                            id: t.getStorageSync("socialhubId"),
                            pointAccountId: t.getStorageSync("pointAccountId"),
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        } : "100000002" == this.tabActive && (n = {
                            idType: 1,
                            id: t.getStorageSync("socialhubId"),
                            pointAccountId: t.getStorageSync("beansAccountId"),
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        }), "" == this.nextId && delete n.nextId, a.default.pointexchangeList(n).then(function(n) {
                            t.hideLoading(), 0 == n.resultCode && (n.data.nextId && (e.nextId = n.data.nextId), 
                            e.tabActive, n.data.list.forEach(function(t) {
                                e.cardList.push(d(d({}, t), {}, {
                                    value: t.score,
                                    num: t.qty
                                }));
                            }), e.cardList = e.cardList.filter(function(t) {
                                return -1 == t.name.indexOf("月饼冰淇淋券");
                            }).filter(function(t) {
                                return -1 == t.name.indexOf("积心兑换卡券");
                            }), n.data.nextId || (e.noMore = !0));
                        });
                    },
                    getList_cash: function() {
                        var e = this, n = {
                            idType: 1,
                            id: t.getStorageSync("socialhubId"),
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        };
                        "" == this.nextId && delete n.nextId, r.default.mooncakeorderList(n).then(function(n) {
                            if (t.hideLoading(), 0 == n.resultCode) {
                                n.data.nextId && (e.nextId = n.data.nextId);
                                for (var o = [], i = [], a = 0; a < n.data.list.length; a++) if ("couponBagName" in n.data.list[a]) if (-1 === o.indexOf(n.data.list[a].couponBagName) && "" != o.indexOf(n.data.list[a].couponBagName)) i.push({
                                    id: n.data.list[a].couponBagName,
                                    list: [ n.data.list[a] ],
                                    type2: "haveBag"
                                }), o.push(n.data.list[a].couponBagName); else for (var r = 0; r < i.length; r++) i[r].id == n.data.list[a].couponBagName && i[r].list.push(n.data.list[a]); else n.data.list[a].type2 = "haveBag", 
                                i.push(n.data.list[a]);
                                e.cardList = e.cardList.concat(i), console.log(i), n.data.nextId || (e.noMore = !0);
                            }
                        });
                    },
                    onChange: function(t) {
                        this.tabActive = t.detail.name, this.cardList = [], this.nextId = "", this.noMore = !1, 
                        "100000000" == t.detail.name ? this.getList_cash() : this.getList();
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (t.showLoading({
                            title: "加载中...",
                            mask: !0
                        }), "100000001" == this.tabActive || "100000002" == this.tabActive ? this.getList() : "100000000" == this.tabActive && this.getList_cash());
                    }
                }
            });
            e.default = u;
        }).call(this, n("543d").default);
    },
    dedd: function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c, t._isMounted || (t.e0 = function(e) {
                t.showOrder = !1;
            }, t.e1 = function(e) {
                t.showOrder = !1;
            }, t.e2 = function(e) {
                t.showOrderFail = !1;
            }, t.e3 = function(e) {
                t.showOrderFail = !1;
            });
        }, i = [];
    },
    e92c: function(t, e, n) {
        n.r(e);
        var o = n("dedd"), i = n("912e");
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        n("7a12");
        var r = n("f0c5"), c = Object(r.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = c.exports;
    },
    fcfe: function(t, e, n) {}
}, [ [ "5a3e", "common/runtime", "common/vendor" ] ] ]);