(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/makeUpForever/turnIndex" ], {
    1017: function(e, o, n) {
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var t = r(n("2fa1")), a = r(n("f0fd")), i = r(n("500b"));
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            getApp();
            var u = {
                data: function() {
                    return {
                        placeholderInfo: "在此输入您的新年祝福",
                        textareaValue: "",
                        userName: "",
                        imgUrl: a.default.assetsRoot,
                        isshare: !0,
                        isShowSharePopup: !1,
                        isShowSharePopup2: !1,
                        isShowSharePopup3: !1,
                        helpinfo: "",
                        helpinfo2: ""
                    };
                },
                onLoad: function(o) {
                    this.couponCode = o.couponCode, this.userName = e.getStorageSync("logininfo").fullName, 
                    this.detailInfo = JSON.parse(decodeURIComponent(o.detailinfo));
                },
                onShow: function() {
                    e.getStorageSync("shareback") && (this.isshare = !1, this.isShowSharePopup = !1, 
                    this.isShowSharePopup2 = !1, this.helpinfo = "", this.helpinfo2 = "", this.isShowSharePopup3 = !0, 
                    e.removeStorageSync("shareback"));
                },
                destroyed: function() {},
                methods: {
                    textareaValueFun: function(e) {
                        console.log(e), this.textareaValue = e.detail.value;
                    },
                    cancelFun: function() {
                        var o = this;
                        t.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "2",
                            remark: this.textareaValue
                        }).then(function(e) {
                            console.log(e), "0" == e.code ? (o.isshare = !0, o.isShowSharePopup = !1, o.isShowSharePopup2 = !0, 
                            o.helpinfo2 = "取消转赠成功\n该券已可以使用\n请去【我的券包】") : (o.isShowSharePopup2 = !0, o.helpinfo2 = "取消转赠失败");
                        });
                    },
                    sendCard: function() {
                        var o = this;
                        console.log(this.textareaValue), t.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: this.couponCode,
                            actionType: "1",
                            remark: "" == this.textareaValue ? "邀请你来哈根达斯体验哦~" : this.textareaValue
                        }).then(function(e) {
                            console.log(e.code), 0 == e.code ? (o.textid = e.data, o.isshare = !1, o.isShowSharePopup = !0, 
                            o.helpinfo = "提交成功\n请点分享将券转赠给指定好友") : (o.isShowSharePopup2 = !0, o.helpinfo2 = "提交失败\n请稍后重试");
                        });
                    }
                },
                onShareAppMessage: function(o) {
                    e.setStorageSync("shareback", !0);
                    var n = "叮~您有一份来自好友的哈根达斯好礼~", t = "".concat(a.default.assetsRoot, "/oss/wxapp/201210/makeupShare.jpg");
                    if (this.detailInfo.forwardTitle && (n = this.detailInfo.forwardTitle), this.detailInfo.forwardPictureUrl && (t = "".concat(a.default.assetsRoot) + this.detailInfo.forwardPictureUrl), 
                    i.default.shareRecord({
                        aid: "",
                        unionId: e.getStorageSync("unionId"),
                        openid: e.getStorageSync("openId"),
                        path: "pages/makeUpForever/turnIndex",
                        button: "",
                        invitedOpenid: "",
                        type: "1"
                    }).then(function(e) {
                        console.log(e);
                    }).catch(function(e) {
                        console.log(e);
                    }), "button" === o.from) return {
                        title: n,
                        path: "pages/makeUpForever/turnGet?textid=".concat(this.textid),
                        imageUrl: t
                    };
                }
            };
            o.default = u;
        }).call(this, n("543d").default);
    },
    1050: function(e, o, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("c0e2"), o(n("66fd")), e(o(n("9cf7")).default);
        }).call(this, n("543d").createPage);
    },
    "4bd3": function(e, o, n) {},
    "5b30": function(e, o, n) {
        n.r(o);
        var t = n("1017"), a = n.n(t);
        for (var i in t) "default" !== i && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(i);
        o.default = a.a;
    },
    "98c2": function(e, o, n) {
        var t = n("4bd3");
        n.n(t).a;
    },
    "9cf7": function(e, o, n) {
        n.r(o);
        var t = n("f2d1"), a = n("5b30");
        for (var i in a) "default" !== i && function(e) {
            n.d(o, e, function() {
                return a[e];
            });
        }(i);
        n("98c2");
        var r = n("f0c5"), u = Object(r.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = u.exports;
    },
    f2d1: function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return a;
        }), n.d(o, "a", function() {});
        var t = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(o) {
                e.isShowSharePopup2 = !1;
            }, e.e1 = function(o) {
                e.isShowSharePopup3 = !1;
            });
        }, a = [];
    }
}, [ [ "1050", "common/runtime", "common/vendor" ] ] ]);