// blindBox/member/coffeeDetail.js
Page({data: {}})