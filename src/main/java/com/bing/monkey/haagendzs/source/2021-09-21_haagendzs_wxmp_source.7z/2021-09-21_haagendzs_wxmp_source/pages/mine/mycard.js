(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/mycard" ], {
    "0683": function(e, o, n) {},
    "34bf": function(e, o, n) {
        n.r(o);
        var t = n("52fb"), i = n("3b31");
        for (var a in i) "default" !== a && function(e) {
            n.d(o, e, function() {
                return i[e];
            });
        }(a);
        n("b0d3");
        var c = n("f0c5"), d = Object(c.a)(i.default, t.b, t.c, !1, null, "07ee518c", null, !1, t.a, void 0);
        o.default = d.exports;
    },
    "3b31": function(e, o, n) {
        n.r(o);
        var t = n("56ea"), i = n.n(t);
        for (var a in t) "default" !== a && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(a);
        o.default = i.a;
    },
    "52fb": function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return i;
        }), n.d(o, "a", function() {});
        var t = function() {
            var e = this, o = (e.$createElement, e._self._c, 0 != e.indexs ? e.__map(e.tabs2, function(o, n) {
                return {
                    $orig: e.__get_orig(o),
                    l0: e.cardList.length > 0 || e.voucherList.length > 0 ? e.__map(e.cardList, function(o, n) {
                        return {
                            $orig: e.__get_orig(o),
                            m0: o.validStartTime ? e.formTime(o.validStartTime) : null,
                            m1: o.validStartTime ? e.formTime(o.validEndTime) : null
                        };
                    }) : null,
                    l1: e.cardList.length > 0 || e.voucherList.length > 0 ? e.__map(e.voucherList, function(o, n) {
                        return {
                            $orig: e.__get_orig(o),
                            m2: o.validStartTime ? e.formTime(o.validStartTime) : null,
                            m3: o.validStartTime ? e.formTime(o.validEndTime) : null
                        };
                    }) : null
                };
            }) : null);
            e.$mp.data = Object.assign({}, {
                $root: {
                    l2: o
                }
            });
        }, i = [];
    },
    "56ea": function(e, o, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function i(e, o) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    o && (t = t.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), n.push.apply(n, t);
                }
                return n;
            }
            function a(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var n = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? i(Object(n), !0).forEach(function(o) {
                        c(e, o, n[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(n, o));
                    });
                }
                return e;
            }
            function c(e, o, n) {
                return o in e ? Object.defineProperty(e, o, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[o] = n, e;
            }
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0, t(n("c1b5"));
            var d = t(n("d7df")), r = t(n("1d54")), s = t(n("57d0")), u = (t(n("bdeb")), t(n("11e1"))), l = t(n("00a7")), g = t(n("1328")), f = getApp(), p = f.globalData.N_ENV.assetsRoot, h = {
                components: {
                    uniIcons: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(n("349f"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/loginDialog") ]).then(function() {
                            return resolve(n("a81e"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    Loading: function() {
                        n.e("components/loading").then(function() {
                            return resolve(n("df16"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        indexs: 0,
                        tabActive: 1e8,
                        tabs: [ {
                            name: 1e8,
                            title: "可使用"
                        }, {
                            name: 100000001,
                            title: "已使用"
                        }, {
                            name: 100000002,
                            title: "已过期"
                        }, {
                            name: 100000007,
                            title: "券转赠"
                        } ],
                        tabActive2: 1e8,
                        tabs2: [ {
                            name: 1e8,
                            title: "可使用"
                        }, {
                            name: 100000001,
                            title: "已失效"
                        } ],
                        resultList: [],
                        nextId: "",
                        pageSize: 10,
                        noMore: !1,
                        isFirstNoChange: !0,
                        showloginDialog: !1,
                        cardList: [],
                        voucherList: [],
                        imgoss: g.default.ossurl + "images/home/"
                    };
                },
                onLoad: function(o) {
                    console.log(o), this.source = o.soure ? o.soure : o.source, e.setStorageSync("source", this.source), 
                    this.tabActive = o.tabActive ? +o.tabActive : 1e8, 1e8 != this.tabActive && (this.isFirstNoChange = !1), 
                    console.log("执行onLoad1");
                },
                onShow: function() {
                    this.nextId = "", this.resultList = [], "all" == e.getStorageSync("successInfo") && e.removeStorageSync("successInfo"), 
                    console.log("执行onshow1"), e.getStorageSync("logininfo") ? (console.log("执行onshow2"), 
                    100000007 == this.tabActive ? (console.log("这是转赠记录"), this.getList_records()) : this.getList(), 
                    e.getStorageSync("source") && this.getRecord()) : (console.log("执行onshow3"), this.showloginDialog = !0);
                },
                methods: {
                    gotoType: function(o) {
                        if (console.log(o), 1e8 != this.tabActive2) return !1;
                        if (o.canGogoMiniProgram) this.gotoMiniprogram(o); else {
                            var n = o.templateUrl, t = encodeURIComponent(n);
                            e.navigateTo({
                                url: "/pages/webView/indexN?url=" + t
                            });
                        }
                    },
                    gotoMiniprogram: function(o) {
                        var n, t;
                        console.log(o);
                        var i = null === (n = o.voucherExtend.jumpInfo) || void 0 === n ? void 0 : n.jumpAppId, a = null === (t = o.voucherExtend.jumpInfo) || void 0 === t ? void 0 : t.jumpButtonParam;
                        e.navigateToMiniProgram({
                            appId: i,
                            path: a,
                            success: function(e) {}
                        });
                    },
                    gotoUrl: function(o) {
                        console.log(o);
                        var n = o.templateUrl, t = encodeURIComponent(n);
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + t
                        });
                    },
                    formTime: function(e) {
                        var o = /(\d{4})(\d{2})(\d{2})/;
                        return e.substring(0, 8).replace(o, "$1-$2-$3");
                    },
                    onChange2: function(e) {
                        this.$refs.Loading.showLoading(), this.tabActive2 = e.detail.name, this.cardList = [], 
                        this.voucherList = [], this.getList_cards();
                    },
                    getList_cards: function() {
                        var o = this, n = {
                            socialhubId: e.getStorageSync("socialhubId"),
                            cardType: ""
                        };
                        100000001 == this.tabActive2 && (n = {
                            socialhubId: e.getStorageSync("socialhubId"),
                            cardType: "1"
                        }), l.default.getList(n).then(function(e) {
                            console.log("列表", e.resultCode), 0 == e.code && (0 == e.data.cardList.length && 0 == e.data.voucherList.length && (o.noMore = !0), 
                            o.cardList = e.data.cardList.map(function(e) {
                                var o = JSON.parse(e.voucherExtend).jumpInfo;
                                return console.log(JSON.parse(e.voucherExtend)), e.voucherExtend = JSON.parse(e.voucherExtend), 
                                (null === o || void 0 === o ? void 0 : o.jumpAppId) && (null === o || void 0 === o ? void 0 : o.jumpButtonType) ? e.canGogoMiniProgram = !0 : e.canGogoMiniProgram = !1, 
                                e;
                            }), o.voucherList = e.data.voucherList.map(function(e) {
                                var o = JSON.parse(e.voucherExtend).jumpInfo;
                                return console.log(JSON.parse(e.voucherExtend)), e.voucherExtend = JSON.parse(e.voucherExtend), 
                                (null === o || void 0 === o ? void 0 : o.jumpAppId) && (null === o || void 0 === o ? void 0 : o.jumpButtonType) ? e.canGogoMiniProgram = !0 : e.canGogoMiniProgram = !1, 
                                e;
                            }));
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    changeIndex: function(e) {
                        this.$refs.Loading.showLoading(), 0 == e ? (this.resultList = [], this.indexs = 0, 
                        this.tabActive = 1e8, this.nextId = "", this.getList()) : (this.indexs = 1, this.tabActive2 = 1e8, 
                        this.nextId = "", this.getList_cards());
                    },
                    getRecord: function() {
                        s.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: e.getStorageSync("source")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getList_records: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var n = {
                            idType: 1,
                            id: e.getStorageSync("socialhubId"),
                            flag: 0,
                            nextId: this.nextId,
                            pageSize: this.pageSize,
                            state: 0
                        };
                        "" == this.nextId && delete n.nextId, u.default.coupontransferlist(n).then(function(e) {
                            o.$refs.Loading.hideLoading(), console.log(e), 0 == e.resultCode && (e.data.nextId && (o.nextId = e.data.nextId), 
                            e.data.list && e.data.list.length > 0 && e.data.list.forEach(function(e) {
                                o.resultList.push(a(a({}, e), {}, {
                                    imgUrlAll: e.imgUrl ? p + e.imgUrl : p + "/oss/wxapp/small.jpg"
                                }));
                            }), e.data.nextId || (o.noMore = !0));
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    getList: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var n = {
                            idType: 1,
                            id: e.getStorageSync("logininfo").socialhubId,
                            state: this.tabActive,
                            nextId: this.nextId,
                            pageSize: this.pageSize
                        };
                        "" == this.nextId && delete n.nextId, r.default.couponList(n).then(function(n) {
                            if (console.log("列表", n.resultCode), 0 == n.resultCode) {
                                if (n.data.nextId && (o.nextId = n.data.nextId), 0 == n.data.list.length) return void (o.noMore = !0);
                                n.data.list.forEach(function(e) {
                                    o.resultList.push(a(a({}, e), {}, {
                                        imgUrlAll: e.imgUrl ? p + e.imgUrl : p + "/oss/wxapp/small.jpg",
                                        validTime: e.validTime ? e.validTime.slice(0, 11) : e.validTime,
                                        invalidTime: "jfsc004" == e.couponRuleCode ? "2021-09-21" : e.invalidTime ? e.invalidTime.slice(0, 11) : e.invalidTime
                                    }));
                                });
                            } else 1 == n.resultCode && (e.removeStorageSync("logininfo"), o.showloginDialog = !0);
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    goexchange: function(o) {
                        if (1e8 == this.tabActive) {
                            var n = a(a({}, o), {}, {
                                giftName: o.name,
                                endTime: o.invalidTime,
                                giftPicUrl: p + o.giftPicUrl
                            });
                            "1" == o.isAddedWechat ? e.navigateTo({
                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(n)) + "&couponCode=" + o.couponCode + "&couponRuleId=" + o.couponRuleCode + "&showbtn=true"
                            }) : (console.log("点击详情"), console.log(n), e.navigateTo({
                                url: "../mine/exchange?obj=" + encodeURIComponent(JSON.stringify(n)) + "&couponCode=" + o.couponCode + "&couponRuleId=" + o.couponRuleCode
                            }));
                        }
                    },
                    cancalCard: function(o) {
                        console.log(o);
                        var n = this;
                        u.default.transfer({
                            openid: e.getStorageSync("openId"),
                            nickName: e.getStorageSync("logininfo").fullName,
                            unionId: e.getStorageSync("unionId"),
                            idType: "2",
                            couponCode: o.couponCode,
                            actionType: "2",
                            remark: ""
                        }, !1).then(function(o) {
                            console.log(o), "0" == o.code ? e.showToast({
                                icon: "none",
                                title: "取消成功",
                                success: function() {
                                    setTimeout(function() {
                                        n.resultList = [], n.nextId = "", n.getList_records();
                                    }, 1e3);
                                }
                            }) : e.showToast({
                                icon: "none",
                                title: "取消失败，请稍后重试"
                            });
                        });
                    },
                    onChange: function(e) {
                        if (!this.isFirstNoChange) return this.isFirstNoChange = !0, !1;
                        this.tabActive = e.detail.name, this.resultList = [], this.nextId = "", this.noMore = !1, 
                        "100000007" == e.detail.name ? (console.log("这是转赠记录"), this.getList_records()) : this.getList();
                    },
                    scrolltolowerFn: function() {
                        this.noMore || (this.$refs.Loading.showLoading(), 100000007 === this.tabActive ? this.getList_records() : this.getList());
                    },
                    transfer: function(o) {
                        if (this.$refs.Loading.showLoading(), 100000002 != this.tabActive) if (100000001 != this.tabActive) {
                            console.log(o);
                            var n = [ "16HZcE2q00008e00", "16HZcE4H00009100", "16HZcE5h00009400", "16HZcE6R00009700", "16HZcE7x00009a00", "16HaE49q00007900", "16HaE4Pe00007500", "16HaE4Uw00007f00", "16HaE4Uw00007f00", "16HaE4md00007800", "16HaE51V00007b00", "16Hb2EZz00008800", "16Hb2Eey00008700", "16HQ4edg00001d00", "16HQ4ebn00001a00", "16HaE1Vu0000a100", "16Hb2EWZ00008500" ], t = [ "16HaQ1eW0000ad00", "16HaQ1eu0000ae00", "16HaQ1fu0000af00", "16Hb25MK00008400", "16Hb25Mg00008500", "16Hb25My00008600" ], i = [ "16XHhMdG00009200", "16XHhMjT0000ad00", "16XHsckE0000b800", "16XHscoa0000d400", "16XHscs70000d700", "16XHseM60000da00", "16XHseQV0000dd00", "16XQfj9c0000dc00", "16XQfjBL0000df00", "16XQfjCv0000e200", "16XQgbRg0000e500", "16XQgbV40000e800", "16XQgbkL00010400", "16XQgbqV0000d500", "16XQs74E00000a00", "16XRZbF700002900", "16XRZbki00002f00", "16XQs7tW00011000" ], a = o.couponCode, c = o.couponRuleCode, d = this;
                            console.log(c), console.log(i), console.log(i.indexOf(c)), "16HYjDy800006e00" == o.couponBagCode ? e.navigateTo({
                                url: "/pages/calendarActivity/turnIndex?couponCode=" + a,
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : "16XQs7SQ00001600" == o.couponBagCode || "16XRa7Qr00003800" == o.couponBagCode || "16XQs8Ei00011c00" == o.couponBagCode ? e.navigateTo({
                                url: "/pureFeeling/hdShare/turnIndex?couponCode=" + a + "&couponRuleCode=" + c,
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : t.indexOf(o.couponBagCode) >= 0 ? e.navigateTo({
                                url: "/pages/makeUpForever/turnIndex?couponCode=" + a,
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : "16XG7Fw20000a000" == o.couponBagCode || "16XG7Fub00009e00" == o.couponBagCode || "16XG23EA00004000" == o.couponBagCode || "16XG23EQ00004100" == o.couponBagCode || "16XG23Ch00003e00" == o.couponBagCode || "16HZcEPN00009d00" == o.couponBagCode || "16HZsSWt00007800" == o.couponBagCode || "16X9Dn7D00009c00" == o.couponBagCode || "16HYYpXw00007b00" == o.couponBagCode ? "16X9Dn7D00009c00" == o.couponBagCode || "16HYYpXw00007b00" == o.couponBagCode || "16XG23Ch00003e00" == o.couponBagCode ? e.navigateTo({
                                url: "/pages/CNYactivity/turnIndex?couponCode=" + a + "&activityType=newYearType",
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : "16XG7Fub00009e00" == o.couponBagCode || "16XG23EA00004000" == o.couponBagCode || "16XG7Fub00009e00" == o.couponBagCode ? e.navigateTo({
                                url: "/pages/CNYactivity/turnIndex?couponCode=" + a + "&activityType=loveGolden",
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : "16XG7Fw20000a000" == o.couponBagCode || "16XG23EQ00004100" == o.couponBagCode || "16XG7Fw20000a000" == o.couponBagCode ? e.navigateTo({
                                url: "/pages/CNYactivity/turnIndex?couponCode=" + a + "&activityType=lovePink",
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : e.navigateTo({
                                url: "/pages/CNYactivity/turnIndex?couponCode=" + a,
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : i.indexOf(c) >= 0 ? e.navigateTo({
                                url: "/pureFeeling/hdShare/turnIndex?couponCode=" + a + "&couponRuleCode=" + c,
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : n.indexOf(c) >= 0 ? e.navigateTo({
                                url: "/pureFeeling/cameraHome/turnIndex?couponCode=" + a + "&couponRuleCode=" + c,
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : "16X9DnM500002500" == o.couponBagCode || "16XG7cAN0000a200" == o.couponBagCode ? e.navigateTo({
                                url: "/pureFeeling/cameraHome/turnIndex?type=winterGet&couponCode=" + a + "&couponRuleCode=" + c,
                                complete: function() {
                                    d.$refs.Loading.hideLoading();
                                }
                            }) : r.default.findGet({
                                couponRuleId: c,
                                ops: {
                                    couponRuleId: "equal"
                                }
                            }).then(function(o) {
                                if (console.log(o), 0 == o.code) {
                                    var n = o.data.forwardViewUrl;
                                    n.includes("?") ? n += "&couponCode=" + a + "&couponRuleCode=" + c + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)) : n += "?couponCode=" + a + "&couponRuleCode=" + c + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)), 
                                    e.navigateTo({
                                        url: n,
                                        complete: function() {
                                            d.$refs.Loading.hideLoading();
                                        }
                                    });
                                } else e.navigateTo({
                                    url: "/pages/luckbag/turnIndex?couponCode=" + a,
                                    complete: function() {
                                        d.$refs.Loading.hideLoading();
                                    }
                                });
                            }).catch(function() {
                                e.navigateTo({
                                    url: "/pages/luckbag/turnIndex?couponCode=" + a,
                                    complete: function() {
                                        d.$refs.Loading.hideLoading();
                                    }
                                });
                            });
                        } else e.showToast({
                            title: "券已使用无法转赠",
                            icon: "none"
                        }); else e.showToast({
                            title: "券已过期无法转赠",
                            icon: "none"
                        });
                    },
                    openWeixinCard: function(o) {
                        1e8 == this.tabActive && (console.log(o), e.openCard({
                            cardList: [ {
                                cardId: o.wxCardId,
                                code: o.couponCode
                            } ],
                            success: function(e) {}
                        }));
                    },
                    addToWeixinCard: function(o) {
                        1e8 == this.tabActive && d.default.convertWxCardId({
                            couponRuleId: o.couponRuleCode
                        }).then(function(n) {
                            d.default.getJsCardSignature({
                                code: o.couponCode,
                                cardId: n.data.wxCardId,
                                openId: e.getStorageSync("openId")
                            }).then(function(o) {
                                var n = o.data, t = n.cardId, i = n.cardSign, a = n.openId, c = n.nonceStr, d = n.timestamp, r = {
                                    code: n.code,
                                    cardId: t,
                                    signature: i,
                                    openid: a,
                                    nonce_str: c,
                                    timestamp: d,
                                    outer_str: "miniProgram"
                                };
                                console.log(JSON.stringify(r)), e.addCard({
                                    cardList: [ {
                                        cardId: t,
                                        cardExt: JSON.stringify(r)
                                    } ],
                                    success: function(e) {
                                        console.log(e), f.globalData.isbackfromSaveWXCard = !0, console.log(f.globalData.isbackfromSaveWXCard);
                                    },
                                    fail: function(e) {
                                        console.log(e), f.globalData.isbackfromSaveWXCard = !1, console.log(f.globalData.isbackfromSaveWXCard);
                                    }
                                });
                            });
                        });
                    }
                }
            };
            o.default = h;
        }).call(this, n("543d").default);
    },
    b0d3: function(e, o, n) {
        var t = n("0683");
        n.n(t).a;
    },
    e941: function(e, o, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("f4aa"), o(n("66fd")), e(o(n("34bf")).default);
        }).call(this, n("543d").createPage);
    }
}, [ [ "e941", "common/runtime", "common/vendor" ] ] ]);