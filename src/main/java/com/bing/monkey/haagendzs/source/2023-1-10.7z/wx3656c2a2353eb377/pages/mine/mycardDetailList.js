require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/mycardDetailList" ], {
    3171: function(e, o, t) {
        t.d(o, "b", function() {
            return n;
        }), t.d(o, "c", function() {
            return i;
        }), t.d(o, "a", function() {});
        var n = function() {
            var e = this, o = (e.$createElement, e._self._c, e.__map(e.tabs, function(o, t) {
                return {
                    $orig: e.__get_orig(o),
                    l0: 100000007 != o.name ? e.__map(e.resultList, function(o, t) {
                        var n = e.__get_orig(o), i = e.showIcon(o), c = e.showIcon(o);
                        return {
                            $orig: n,
                            m0: i,
                            m1: c,
                            m2: c ? e.iconFun(o.voucherScope) : null,
                            g0: "100000000" == e.tabActive ? "100000000" == e.tabActive && "1" == o.allowReGift && e.vouchersource.indexOf("HD") < 0 : null,
                            m3: "100000000" == e.tabActive ? e.showRule(o.voucherScope) : null,
                            m4: "100000000" == e.tabActive ? e.showRule(o.voucherScope) : null
                        };
                    }) : null
                };
            }));
            e.$mp.data = Object.assign({}, {
                $root: {
                    l1: o
                }
            });
        }, i = [];
    },
    "461b": function(e, o, t) {
        (function(e) {
            var o = t("4ea4");
            t("a1ea"), o(t("66fd"));
            var n = o(t("a05a"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t("543d").createPage);
    },
    "632c": function(e, o, t) {
        var n = t("c77b");
        t.n(n).a;
    },
    "7fb8": function(e, o, t) {
        (function(e) {
            var n = t("4ea4");
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var i = n(t("9523")), c = n(t("0098")), a = n(t("5db4")), s = n(t("3724")), r = n(t("f3d4")), u = n(t("7d43"));
            function l(e, o) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    o && (n = n.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), t.push.apply(t, n);
                }
                return t;
            }
            function d(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var t = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? l(Object(t), !0).forEach(function(o) {
                        (0, i.default)(e, o, t[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : l(Object(t)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(t, o));
                    });
                }
                return e;
            }
            var g = getApp().globalData.N_ENV.assetsRoot, h = {
                components: {
                    loginDialog: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/loginDialog_new") ]).then(function() {
                            return resolve(t("5972"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    Loading: function() {
                        t.e("components/loading").then(function() {
                            return resolve(t("64ff"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        indexs: 0,
                        tabActive: 1e8,
                        tabs: [ {
                            name: 1e8,
                            title: "可使用"
                        }, {
                            name: 100000001,
                            title: "已使用"
                        }, {
                            name: 100000002,
                            title: "已过期/失效"
                        }, {
                            name: 100000007,
                            title: "券转赠"
                        } ],
                        resultList: [],
                        nextId: "",
                        pageSize: 10,
                        noMore: !1,
                        isFirstNoChange: !0,
                        showloginDialog: !1,
                        imgoss: r.default.ossurl + "images/home/",
                        isGongGao: !0,
                        isHeightScreen: !1,
                        pageNumber: 1,
                        pageTotal: 0,
                        pageListTotal: 0,
                        vouchersource: ""
                    };
                },
                onLoad: function(o) {
                    var t = this;
                    u.default.isHeightPhone().then(function(e) {
                        t.isHeightScreen = e;
                    }).catch(function(e) {
                        t.isHeightScreen = e;
                    }), this.source = o.soure ? o.soure : o.source, this.vouchersource = o.vouchersource, 
                    !this.vouchersource || this.vouchersource.indexOf("evoucher") > -1 ? (e.setNavigationBarTitle({
                        title: "会员权益券"
                    }), this.tabs = [ {
                        name: 1e8,
                        title: "可使用"
                    }, {
                        name: 100000001,
                        title: "已使用"
                    }, {
                        name: 100000002,
                        title: "已过期/失效"
                    }, {
                        name: 100000007,
                        title: "券转赠"
                    } ]) : (e.setNavigationBarTitle({
                        title: "外卖/自取/堂食券"
                    }), this.tabs = [ {
                        name: 1e8,
                        title: "可使用"
                    }, {
                        name: 100000001,
                        title: "已使用"
                    }, {
                        name: 100000002,
                        title: "已过期/失效"
                    } ]), e.setStorageSync("source", this.source), u.default.setSource(o), this.indexs = o.indexs ? +o.indexs : 0, 
                    o.indexs && 0 != o.indexs || (this.tabActive = o.tabActive ? +o.tabActive : 1e8), 
                    1e8 != this.tabActive && (this.isFirstNoChange = !1), console.log("执行onLoad1");
                },
                onShow: function() {
                    this.nextId = "", this.resultList = [], this.pageNumber = 1, this.pageListTotal = 0, 
                    this.noMore = !1, "all" == e.getStorageSync("successInfo") && e.removeStorageSync("successInfo"), 
                    console.log("执行onshow1"), e.getStorageSync("logininfo") ? (u.default.recordPv(), 
                    console.log("执行onshow2"), this.getCardList()) : (console.log("执行onshow3"), this.showloginDialog = !0);
                },
                methods: {
                    showRule: function(e) {
                        return !!(this.vouchersource && this.vouchersource.indexOf("HD") > -1) && 1e8 == this.tabActive && (1 == e || 2 == e || 8 != e);
                    },
                    showIcon: function(e) {
                        return !(!this.vouchersource || this.vouchersource.indexOf("evoucher") > -1 || 1e8 != this.tabActive || !e.voucherScope);
                    },
                    iconFun: function(e) {
                        var o = r.default.ossurl + "UX/mine/mycard/";
                        return 1 == e ? o + "wm.png" : 2 == e ? o + "zq.png" : 8 == e ? o + "ts.png" : o + "ty.png";
                    },
                    getmemberSuccess: function(e) {
                        console.log(e), "all" == e ? (this.showloginDialog = !1, u.default.recordPv(), console.log("执行onshow2"), 
                        this.getCardList(), this.$refs.Loading.hideLoading()) : "error" == e && this.$refs.Loading.hideLoading();
                    },
                    gotoTl: function(o) {
                        var t = ("release" == r.default.envVersion ? "https://hd.rydeen.com.cn/coupon-booking/booking" : "https://hd-uat.rydeen.com.cn/coupon-booking/booking") + "?couponNo=" + o.couponCode;
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + encodeURIComponent(t)
                        });
                    },
                    getCardList: function() {
                        0 == this.indexs && (100000007 == this.tabActive ? (console.log("这是转赠记录"), getApp().hxt.sendAction("electronic_coupon_handsel_clk"), 
                        this.getList_records()) : (1e8 == this.tabActive ? getApp().hxt.sendAction("electronic_coupon_available_clk") : 100000001 == this.tabActive ? getApp().hxt.sendAction("electronic_coupon_used_clk") : 100000002 == this.tabActive && getApp().hxt.sendAction("electronic_coupon_expired_clk"), 
                        this.getList()), e.getStorageSync("source") && this.getRecord());
                    },
                    gotoMiniprogramBoth: function() {
                        getApp().hxt.sendAction("gift_card_available_use_now", {
                            gift_card_name: "额外小程序",
                            gift_card_id: "wxf83dc13b5390d17b"
                        }), e.navigateToMiniProgram({
                            appId: "wxf83dc13b5390d17b",
                            path: "pages/index/index",
                            success: function(e) {}
                        });
                    },
                    gotoMiniprogram: function(o) {
                        var t, n;
                        console.log(o), getApp().hxt.sendAction("gift_card_available_use_now", {
                            gift_card_name: null == o ? void 0 : o.voucherName,
                            gift_card_id: null == o ? void 0 : o.ebuyMemberId
                        });
                        var i = null === (t = o.voucherExtend.jumpInfo) || void 0 === t ? void 0 : t.jumpAppId, c = null === (n = o.voucherExtend.jumpInfo) || void 0 === n ? void 0 : n.jumpButtonParam;
                        e.navigateToMiniProgram({
                            appId: i,
                            path: c,
                            success: function(e) {}
                        });
                    },
                    gotoUrl: function(o) {
                        console.log(o), getApp().hxt.sendAction("gift_card_available_to_order", {
                            gift_card_name: o.voucherName,
                            gift_card_id: o.ebuyMemberId
                        });
                        var t = o.templateUrl, n = encodeURIComponent(t);
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + n
                        });
                    },
                    formTime: function(e) {
                        return e.substring(0, 8).replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");
                    },
                    getRecord: function() {
                        a.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: e.getStorageSync("source")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getList_records: function() {
                        var o = this;
                        this.$refs.Loading.showLoading();
                        var t = new Date().getTime(), n = {
                            thirdOpenId: e.getStorageSync("socialhubId"),
                            pageSize: this.pageSize,
                            pageNumber: this.pageNumber,
                            packageStatus: "DELIVERING,CANCELED,SUCCESS",
                            timestamp: t,
                            sign: u.default.mdString(t, {
                                openid: e.getStorageSync("openId"),
                                unionId: e.getStorageSync("unionId")
                            })
                        };
                        s.default.ebuyGetTransferRecord(n).then(function(e) {
                            if (o.$refs.Loading.hideLoading(), console.log(e), o.pageTotal = e.totalCount, 0 == e.dataList.length) return o.noMore = !0, 
                            !1;
                            e.dataList && e.dataList.length > 0 && e.dataList.forEach(function(e) {
                                o.resultList.push(d(d({}, e), {}, {
                                    imgUrlAll: e.imgUrl ? g + e.imgUrl : g + "/oss/wxapp/small.jpg"
                                }));
                            });
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    getList: function() {
                        var o = this;
                        this.$refs.Loading.showLoading(), console.log(this.tabActive);
                        var t = {
                            status: "100000000" == this.tabActive ? "enabled" : "100000001" == this.tabActive ? "used" : "100000002" == this.tabActive ? "expire" : "",
                            socialhubId: e.getStorageSync("socialhubId"),
                            pageNumber: this.pageNumber,
                            pageSize: 10,
                            voucherSource: this.vouchersource
                        };
                        console.log("getList执行了"), c.default.couponList_ebuy(t).then(function(t) {
                            if (0 == t.code) {
                                var n;
                                if (null === (n = t.data) || void 0 === n || !n.couponList) return void (o.noMore = !0);
                                if (t.data.couponList.forEach(function(e) {
                                    o.resultList.push(d(d({}, e), {}, {
                                        imgUrlAll: e.imgUrl ? g + e.imgUrl : g + "/oss/wxapp/small.jpg",
                                        validTime: e.validTime ? e.validTime.slice(0, 11) : e.validTime,
                                        invalidTime: "jfsc004" == e.couponRuleCode ? "2021-09-21" : e.invalidTime ? e.invalidTime.slice(0, 11) : e.invalidTime,
                                        showTl: "16nNBFBe00004f00" == e.couponRuleCode || "16YoGt8H00020200" == e.couponRuleCode || "16YoGrrk0001ff00" == e.couponRuleCode || "16YoyYkc00003f00" == e.couponRuleCode || "16YoyYqQ00005503" == e.couponRuleCode || "16nLwZJZ00005e03" == e.couponRuleCode || "16nLwZNe00004f00" == e.couponRuleCode ? "yes" : "no"
                                    }));
                                }), console.log("数据总数", t.data.totalCount), o.pageListTotal = t.data.totalCount, 
                                t.data.couponList.length < 10) return void (o.noMore = !0);
                            } else 1 == t.resultCode && (e.removeStorageSync("logininfo"), o.showloginDialog = !0);
                        }).finally(function() {
                            o.$refs.Loading.hideLoading();
                        });
                    },
                    gotoRule: function(e) {
                        this.vouchersource && this.vouchersource.indexOf("HD") > -1 && this.goexchangeNew(e);
                    },
                    goexchange: function(o) {
                        if (console.log(o), 0 == this.indexs) {
                            if (1e8 != this.tabActive) return;
                            getApp().hxt.sendAction("electronic_coupon_available_use_now", {
                                electronic_coupon_name: o.name,
                                electronic_coupon_id: o.couponCode
                            });
                        } else if (2 == this.indexs && 1e8 != this.tabActive1) return;
                        if (this.vouchersource && this.vouchersource.indexOf("HD") > -1) {
                            var t;
                            if (t = "release" == r.default.envVersion ? "wxf83dc13b5390d17b" : "wx4840fa755ba3ce66", 
                            8 == o.voucherScope) return e.showToast({
                                title: "该优惠券可通过堂食扫码点餐使用",
                                icon: "none"
                            }), !1;
                            this.gotoMiniEc(t, o.voucherScope);
                        } else this.goexchangeNew(o);
                    },
                    gotoMiniEc: function(o, t) {
                        getApp().hxt.sendAction("gift_card_available_use_now", {
                            gift_card_name: "额外小程序",
                            gift_card_id: o
                        });
                        var n = 1 == t ? "pages/menu/index?channel=SNMIN&orderChannel=delivery" : 2 == t ? "pages/menu/index?channel=SNMIN&orderType=2" : "pages/index/index?channel=SNMIN";
                        e.navigateToMiniProgram({
                            appId: o,
                            path: n,
                            success: function(e) {}
                        });
                    },
                    goexchangeNew: function(o) {
                        var t = d(d({}, o), {}, {
                            giftName: o.name,
                            endTime: o.invalidTime
                        });
                        null != o && o.giftPicUrl && (t.giftPicUrl = g + o.giftPicUrl), o.templateUrl && "" != o.templateUrl ? e.navigateTo({
                            url: "/pages/mine/exchange?obj=" + encodeURIComponent(JSON.stringify(t)) + "&couponCode=" + o.couponCode + "&vouchersource=" + this.vouchersource + "&couponRuleId=" + o.couponRuleCode + "&cardType=active"
                        }) : "1" == o.isAddedWechat ? e.navigateTo({
                            url: "/pages/mine/exchange?obj=" + encodeURIComponent(JSON.stringify(t)) + "&couponCode=" + o.couponCode + "&vouchersource=" + this.vouchersource + "&couponRuleId=" + o.couponRuleCode + "&showbtn=true"
                        }) : (console.log("点击详情"), console.log(t), e.navigateTo({
                            url: "/pages/mine/exchange?obj=" + encodeURIComponent(JSON.stringify(t)) + "&couponCode=" + o.couponCode + "&vouchersource=" + this.vouchersource + "&couponRuleId=" + o.couponRuleCode
                        }));
                    },
                    cancalCard: function(o) {
                        var t = new Date().getTime();
                        console.log(o);
                        var n = this;
                        s.default.ebuyCancelTransfer({
                            openid: e.getStorageSync("openId"),
                            socialHubid: e.getStorageSync("socialhubId"),
                            unionId: e.getStorageSync("unionId"),
                            couponKey: o.packageId,
                            timestamp: t,
                            sign: u.default.mdString(t, {
                                openid: e.getStorageSync("openId"),
                                socialHubid: e.getStorageSync("socialhubId"),
                                unionId: e.getStorageSync("unionId"),
                                couponKey: o.packageId
                            })
                        }, !1).then(function(o) {
                            console.log(o), "0" == o.code ? e.showToast({
                                icon: "none",
                                title: "取消成功",
                                success: function() {
                                    setTimeout(function() {
                                        n.resultList = [], n.pageNumber = 1, n.getList_records();
                                    }, 1e3);
                                }
                            }) : e.showToast({
                                icon: "none",
                                title: "取消失败，请稍后重试"
                            });
                        });
                    },
                    onChange: function(e) {
                        if (!this.isFirstNoChange) return this.isFirstNoChange = !0, !1;
                        this.tabActive = e.detail.name, "100000000" == this.tabActive ? getApp().hxt.sendAction("electronic_coupon_available_clk") : "100000001" == this.tabActive ? getApp().hxt.sendAction("electronic_coupon_used_clk") : "100000002" == this.tabActive ? getApp().hxt.sendAction("electronic_coupon_expired_clk") : "100000007" == this.tabActive && getApp().hxt.sendAction("electronic_coupon_handsel_clk"), 
                        this.resultList = [], this.pageNumber = 1, this.nextId = "", this.noMore = !1, "100000007" == e.detail.name ? (console.log("这是转赠记录"), 
                        this.getList_records()) : this.getList();
                    },
                    scrolltolowerFn: function() {
                        console.log("到底了"), this.noMore || (this.$refs.Loading.showLoading(), 0 == this.indexs && (100000007 === this.tabActive ? this.pageTotal > this.resultList.length ? (this.pageNumber += 1, 
                        this.getList_records()) : (this.noMore = !0, this.$refs.Loading.hideLoading()) : this.pageListTotal > this.resultList.length ? (this.pageNumber += 1, 
                        this.getList()) : (this.noMore = !0, this.$refs.Loading.hideLoading())));
                    },
                    common_transfer: function(o) {
                        var t = null == o ? void 0 : o.couponCode, n = null == o ? void 0 : o.couponRuleCode, i = (null == o || o.name, 
                        null == o ? void 0 : o.moonState), a = this;
                        c.default.findGet_common({}).then(function(o) {
                            if (0 == o.code && Object.keys(o.data).length > 0) {
                                var c = o.data.forwardViewUrl;
                                c.includes("?") ? c += "&couponCode=" + t + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)) : c += "?couponCode=" + t + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(o.data)), 
                                1 == i && (c += "&moonState=1"), e.navigateTo({
                                    url: c,
                                    complete: function() {
                                        a.$refs.Loading.hideLoading();
                                    }
                                });
                            } else {
                                var s;
                                s = 1 == i ? "/shareStyle/share_common/turnIndex?couponCode=" + t + "&moonState=1" : "/shareStyle/share_common/turnIndex?couponCode=" + t, 
                                e.navigateTo({
                                    url: s,
                                    complete: function() {
                                        a.$refs.Loading.hideLoading();
                                    }
                                });
                            }
                        }).catch(function() {
                            var o;
                            o = 1 == i ? "/shareStyle/share_common/turnIndex?couponCode=" + t + "&moonState=1" : "/shareStyle/share_common/turnIndex?couponCode=" + t, 
                            e.navigateTo({
                                url: o,
                                complete: function() {
                                    a.$refs.Loading.hideLoading();
                                }
                            });
                        });
                    },
                    transfer: function(o) {
                        if (this.$refs.Loading.showLoading(), 0 != this.indexs || 100000002 != this.tabActive) if (0 != this.indexs || 100000001 != this.tabActive) if (2 != this.indexs || 100000001 != this.tabActive1) if (2 != this.indexs || 100000001 != this.tabActive1) {
                            var t = null == o ? void 0 : o.couponCode, n = null == o ? void 0 : o.couponRuleCode, i = null == o ? void 0 : o.name, a = null == o ? void 0 : o.moonState;
                            if (!t) return e.showToast({
                                title: "此券暂时无法转赠",
                                icon: "none"
                            }), !1;
                            0 == this.indexs && getApp().hxt.sendAction("electronic_coupon_available_give_ta", {
                                electronic_coupon_name: i,
                                electronic_coupon_id: t
                            });
                            var s = this;
                            c.default.findGet({
                                couponRuleId: n,
                                ops: {
                                    couponRuleId: "equal"
                                }
                            }).then(function(i) {
                                if (console.log(i), 0 == i.code && Object.keys(i.data).length > 0) {
                                    var c = i.data.forwardViewUrl;
                                    c.includes("?") ? c += "&couponCode=" + t + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(i.data)) : c += "?couponCode=" + t + "&couponRuleCode=" + n + "&detailinfo=" + encodeURIComponent(JSON.stringify(i.data)), 
                                    1 == a && (c += "&moonState=1"), e.navigateTo({
                                        url: c,
                                        complete: function() {
                                            s.$refs.Loading.hideLoading();
                                        }
                                    });
                                } else s.common_transfer(o);
                            }).catch(function() {
                                s.common_transfer(o);
                            });
                        } else e.showToast({
                            title: "券已使用无法转赠",
                            icon: "none"
                        }); else e.showToast({
                            title: "券已过期无法转赠",
                            icon: "none"
                        }); else e.showToast({
                            title: "券已使用无法转赠",
                            icon: "none"
                        }); else e.showToast({
                            title: "券已过期无法转赠",
                            icon: "none"
                        });
                    }
                }
            };
            o.default = h;
        }).call(this, t("543d").default);
    },
    a05a: function(e, o, t) {
        t.r(o);
        var n = t("3171"), i = t("c5c0");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(o, e, function() {
                return i[e];
            });
        }(c);
        t("632c");
        var a = t("f0c5"), s = Object(a.a)(i.default, n.b, n.c, !1, null, "78e9dbea", null, !1, n.a, void 0);
        o.default = s.exports;
    },
    c5c0: function(e, o, t) {
        t.r(o);
        var n = t("7fb8"), i = t.n(n);
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(o, e, function() {
                return n[e];
            });
        }(c);
        o.default = i.a;
    },
    c77b: function(e, o, t) {}
}, [ [ "461b", "common/runtime", "common/vendor" ] ] ]);