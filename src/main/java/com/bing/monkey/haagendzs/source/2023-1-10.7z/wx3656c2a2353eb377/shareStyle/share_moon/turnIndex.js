// shareStyle/share_moon/turnIndex.js
Page({data: {}})