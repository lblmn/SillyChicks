// newStore/newStore/index.js
Page({data: {}})