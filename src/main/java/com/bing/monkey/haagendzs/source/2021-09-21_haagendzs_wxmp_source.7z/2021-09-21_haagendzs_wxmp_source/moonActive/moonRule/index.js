// moonActive/moonRule/index.js
Page({data: {}})