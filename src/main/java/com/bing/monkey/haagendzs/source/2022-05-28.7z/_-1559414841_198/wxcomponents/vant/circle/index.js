var e = require("../common/component"), t = require("../common/utils"), r = require("../common/color"), n = require("./canvas");

var a = 2 * Math.PI, i = -Math.PI / 2;

(0, e.VantComponent)({
    props: {
        text: String,
        lineCap: {
            type: String,
            value: "round"
        },
        value: {
            type: Number,
            value: 0,
            observer: "reRender"
        },
        speed: {
            type: Number,
            value: 50
        },
        size: {
            type: Number,
            value: 100,
            observer: function() {
                this.drawCircle(this.currentValue);
            }
        },
        fill: String,
        layerColor: {
            type: String,
            value: r.WHITE
        },
        color: {
            type: [ String, Object ],
            value: r.BLUE,
            observer: function() {
                var e = this;
                this.setHoverColor().then(function() {
                    e.drawCircle(e.currentValue);
                });
            }
        },
        type: {
            type: String,
            value: ""
        },
        strokeWidth: {
            type: Number,
            value: 4
        },
        clockwise: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        hoverColor: r.BLUE
    },
    methods: {
        getContext: function() {
            var e = this, t = this.data, r = t.type, a = t.size;
            if ("" === r) {
                var i = wx.createCanvasContext("van-circle", this);
                return Promise.resolve(i);
            }
            var o = wx.getSystemInfoSync().pixelRatio;
            return new Promise(function(t) {
                wx.createSelectorQuery().in(e).select("#van-circle").node().exec(function(i) {
                    var l = i[0].node, s = l.getContext(r);
                    e.inited || (e.inited = !0, l.width = a * o, l.height = a * o, s.scale(o, o)), t((0, 
                    n.adaptor)(s));
                });
            });
        },
        setHoverColor: function() {
            var e = this, r = this.data, n = r.color, a = r.size;
            return (0, t.isObj)(n) ? this.getContext().then(function(t) {
                var r = t.createLinearGradient(a, 0, 0, 0);
                Object.keys(n).sort(function(e, t) {
                    return parseFloat(e) - parseFloat(t);
                }).map(function(e) {
                    return r.addColorStop(parseFloat(e) / 100, n[e]);
                }), e.hoverColor = r;
            }) : (this.hoverColor = n, Promise.resolve());
        },
        presetCanvas: function(e, t, r, n, a) {
            var i = this.data, o = i.strokeWidth, l = i.lineCap, s = i.clockwise, c = i.size / 2, u = c - o / 2;
            e.setStrokeStyle(t), e.setLineWidth(o), e.setLineCap(l), e.beginPath(), e.arc(c, c, u, r, n, !s), 
            e.stroke(), a && (e.setFillStyle(a), e.fill());
        },
        renderLayerCircle: function(e) {
            var t = this.data, r = t.layerColor, n = t.fill;
            this.presetCanvas(e, r, 0, a, n);
        },
        renderHoverCircle: function(e, t) {
            var r = this.data.clockwise, n = a * (t / 100), o = r ? i + n : 3 * Math.PI - (i + n);
            this.presetCanvas(e, this.hoverColor, i, o);
        },
        drawCircle: function(e) {
            var t = this, r = this.data.size;
            this.getContext().then(function(n) {
                n.clearRect(0, 0, r, r), t.renderLayerCircle(n);
                var a, i = (a = e, Math.min(Math.max(a, 0), 100));
                0 !== i && t.renderHoverCircle(n, i), n.draw();
            });
        },
        reRender: function() {
            var e = this, t = this.data, r = t.value, n = t.speed;
            n <= 0 || n > 1e3 ? this.drawCircle(r) : (this.clearInterval(), this.currentValue = this.currentValue || 0, 
            this.interval = setInterval(function() {
                e.currentValue !== r ? (e.currentValue < r ? e.currentValue += 1 : e.currentValue -= 1, 
                e.drawCircle(e.currentValue)) : e.clearInterval();
            }, 1e3 / n));
        },
        clearInterval: function(e) {
            function t() {
                return e.apply(this, arguments);
            }
            return t.toString = function() {
                return e.toString();
            }, t;
        }(function() {
            this.interval && (clearInterval(this.interval), this.interval = null);
        })
    },
    mounted: function() {
        var e = this;
        this.currentValue = this.data.value, this.setHoverColor().then(function() {
            e.drawCircle(e.currentValue);
        });
    },
    destroyed: function() {
        this.clearInterval();
    }
});