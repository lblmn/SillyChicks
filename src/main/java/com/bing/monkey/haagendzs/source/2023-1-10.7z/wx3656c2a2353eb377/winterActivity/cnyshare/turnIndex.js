// winterActivity/cnyshare/turnIndex.js
Page({data: {}})