var o = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof"));

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/hx-navbar/hx-navbar" ], {
    "38fb": function(o, n, t) {
        t.r(n);
        var r = t("cfb6"), a = t.n(r);
        for (var e in r) "default" !== e && function(o) {
            t.d(n, o, function() {
                return r[o];
            });
        }(e);
        n.default = a.a;
    },
    "5b0f": function(o, n, t) {
        var r = t("7c77");
        t.n(r).a;
    },
    "7c77": function(o, n, t) {},
    a006: function(o, n, t) {
        t.r(n);
        var r = t("d2b9"), a = t("38fb");
        for (var e in a) "default" !== e && function(o) {
            t.d(n, o, function() {
                return a[o];
            });
        }(e);
        t("5b0f");
        var c = t("f0c5"), l = Object(c.a)(a.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        n.default = l.exports;
    },
    cfb6: function(n, t, r) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = {
                name: "hxNavbar",
                components: {},
                data: function() {
                    return {
                        title: "",
                        backgroundColorRgba: "",
                        backgroundColorRgb: "rgb(222,222,222)",
                        backgroundImage: null,
                        backgroundImageEnd: null,
                        txtColor: "#333333",
                        bgArr: [],
                        colorArr: [],
                        statusBarBackground: "",
                        bgTransparent: 1,
                        bgImgTransparent: [ 1, 1 ],
                        jnWidth: 0,
                        bgIsLine: !1,
                        slotSwitchOpacity: 1,
                        conf: {
                            title: "",
                            height: 44,
                            fixed: !0,
                            statusBar: !0,
                            statusBarFontColor: "#000000",
                            statusBarBackground: null,
                            font: "hxicon",
                            fontSize: "18px",
                            color: "#fff",
                            backgroundColor: [ 1, "#ffffff" ],
                            backgroundImg: null,
                            backgroundColorLinearDeg: "to right",
                            slideHeight: 100,
                            slideBackgroundColor: null,
                            back: !0,
                            backTxt: null,
                            backTabPage: null,
                            backPage: null,
                            leftButton: null,
                            rightButton: null,
                            search: null,
                            shadow: !1,
                            border: !1,
                            barPlaceholder: !0,
                            slotSwitch: 0,
                            rightSlot: !1,
                            rightSlotSwitch: !1
                        }
                    };
                },
                props: {
                    config: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    }
                },
                computed: {
                    statusBarHeight: function() {
                        return n.getSystemInfoSync().statusBarHeight;
                    },
                    navbarHeight: function() {
                        return n.getSystemInfoSync().statusBarHeight + this.conf.height + "px";
                    },
                    screenWidth: function() {
                        return n.getSystemInfoSync().screenWidth;
                    }
                },
                created: function() {
                    var o = n.getMenuButtonBoundingClientRect();
                    console.log(o), this.jnWidth = o.width, this.init();
                },
                mounted: function() {},
                watch: {
                    "config.backgroundImg": {
                        handler: function(o, n) {
                            console.log(o), console.log(n), this.backgroundImage = o, console.info(this.conf);
                        },
                        deep: !0
                    }
                },
                methods: {
                    iconHandle: function(o) {
                        return o = o.replace(/(&#x|;)/g, ""), unescape("%u" + o);
                    },
                    init: function() {
                        var t = this;
                        if (t.conf = Object.assign(t.conf, t.config), "" != t.conf.title && n.setNavigationBarTitle({
                            title: t.conf.title
                        }), t.conf.title && ("object" == (0, o.default)(t.conf.title) && 2 == t.conf.title.length ? t.title = t.conf.title[0] : t.title = t.conf.title), 
                        t.conf.statusBarBackground && ("object" == (0, o.default)(t.conf.statusBarBackground) && 2 == t.conf.statusBarBackground.length ? t.statusBarBackground = t.conf.statusBarBackground[0] : t.statusBarBackground = t.conf.statusBarBackground), 
                        t.conf.statusBarFontColor && n.setNavigationBarColor({
                            frontColor: "object" == (0, o.default)(t.conf.statusBarFontColor) ? t.conf.statusBarFontColor[0] : t.conf.statusBarFontColor,
                            backgroundColor: "#000000"
                        }), "" != t.conf.color && ("object" == (0, o.default)(t.conf.color) && 2 == t.conf.color.length ? (t.txtColor = t.conf.color[0], 
                        t.colorArr = t.gradientColor(t.conf.color[0], t.conf.color[1], t.conf.slideHeight)) : t.txtColor = t.conf.color), 
                        t.conf.backgroundImg) {
                            var r = "";
                            "object" == (0, o.default)(t.conf.backgroundImg) ? (r = t.conf.backgroundImg[0], 
                            t.conf.backgroundImg.length > 2 && (t.bgTransparent = t.conf.backgroundImg[2])) : (r = t.conf.backgroundImg, 
                            t.bgTransparent = 1), t.backgroundImage = t.bgImgStringHandle(r);
                        }
                        if (t.conf.backgroundColor) {
                            var a = t.conf.backgroundColor[0], e = t.conf.backgroundColor[1];
                            if ("object" == (0, o.default)(e) && e.length > 1 && (t.bgIsLine = !0), t.conf.slideBackgroundColor) {
                                var c = t.conf.slideBackgroundColor[1];
                                if (t.bgArr = [], e && "object" == (0, o.default)(e) && e.length > 0) for (var l in e) t.bgArr.push(t.gradientColor(e[l], c[l], t.conf.slideHeight)); else t.bgArr.push(t.gradientColor(e, c, t.conf.slideHeight));
                            }
                            t.bgTransparent = a, t.setBgColor(e, a);
                        }
                        t.conf.rightButton && t.conf.rightButton.length;
                    },
                    onBack: function() {
                        var o = this;
                        o.conf.backTabPage ? n.switchTab({
                            url: o.conf.backTabPage
                        }) : o.conf.backPage ? n.redirectTo({
                            url: o.conf.backPage
                        }) : getCurrentPages().length > 1 ? n.navigateBack() : 1 == getCurrentPages().length && n.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    onClickBtn: function(o) {
                        this.$emit("clickBtn", o);
                    },
                    pageScroll: function(t) {
                        var r = this, a = parseFloat(t.scrollTop.toFixed(2)), e = r.conf.slideHeight, c = Math.round(a);
                        if (c > 0 ? c -= 1 : c = 0, r.conf.title && "object" == (0, o.default)(r.conf.title) && 2 == r.conf.title.length && (r.title = a <= e ? r.conf.title[0] : r.conf.title[1]), 
                        r.conf.color && "object" == (0, o.default)(r.conf.color) && 2 == r.conf.color.length) {
                            var l = r.colorArr, i = c <= l.length - 1 ? l[c] : l[l.length - 1];
                            r.txtColor = i;
                        }
                        r.slotSwitchOpacity = r.transHandle(a, e, 1, 0), r.conf.statusBarFontColor && "object" == (0, 
                        o.default)(r.conf.statusBarFontColor) && 2 == r.conf.statusBarFontColor.length && (a <= e ? n.setNavigationBarColor({
                            frontColor: r.conf.statusBarFontColor[0],
                            backgroundColor: "#ffffff"
                        }) : n.setNavigationBarColor({
                            frontColor: r.conf.statusBarFontColor[1],
                            backgroundColor: "#ffffff"
                        })), r.conf.statusBarBackground && "object" == (0, o.default)(r.conf.statusBarBackground) && 2 == r.conf.statusBarBackground.length && (r.statusBarBackground = a <= e ? r.conf.statusBarBackground[0] : r.conf.statusBarBackground[1]);
                        var f = r.conf.backgroundImg;
                        if (r.conf.backgroundImg && "object" == (0, o.default)(r.conf.backgroundImg) && f.length > 1) {
                            var g = f.length;
                            r.bgTransparent = g <= 3 ? 1 : r.transHandle(a, e, f[2], f[3]), r.bgImgTransparent[0] = g <= 3 ? 1 : r.transHandle(a, e, f[2], 0), 
                            r.bgImgTransparent[1] = f[3], a <= e ? f[0] : f[1], r.backgroundImage = r.bgImgStringHandle(f[0]), 
                            r.backgroundImageEnd = r.bgImgStringHandle(f[1]);
                        }
                        if (r.conf.slideBackgroundColor) {
                            var u = r.bgArr, s = [];
                            for (var d in r.bgArr) {
                                var b = c <= u[d].length - 1 ? u[d][c] : u[d][u[d].length - 1];
                                s.push(b.replace(/(?:\(|\)|rgb|RGB)*/g, "").split(","));
                            }
                            var h = r.conf.backgroundColor[0], p = r.conf.slideBackgroundColor[0], B = p;
                            if (a <= e) {
                                var k = Math.abs(p - h), v = parseFloat(k / e).toFixed(4), C = parseFloat(v * a).toFixed(2);
                                B = h > p ? h - C : h + C, B = parseFloat(B).toFixed(2);
                            }
                            var m = r.conf.slideBackgroundColor[1], I = "";
                            if ("object" == (0, o.default)(m) && m.length > 1) {
                                I = "linear-gradient(" + r.conf.backgroundColorLinearDeg + ",";
                                var x = s.length;
                                for (var d in s) {
                                    var F = s[d];
                                    I += "rgba(" + F[0] + "," + F[1] + "," + F[2] + "," + B + ")", x != 1 * d + 1 && (I += ",");
                                }
                                I += ")";
                            } else I = "rgba(" + s[0][0] + "," + s[0][1] + "," + s[0][2] + "," + B + ")";
                            r.bgTransparent = B, r.backgroundColorRgba = I;
                        }
                    },
                    transHandle: function(o, n, t, r) {
                        var a = r;
                        if (o <= n) {
                            var e = Math.abs(r - t), c = parseFloat(e / n).toFixed(4), l = parseFloat(c * o).toFixed(2);
                            a = t > r ? t - l : t + l, a = parseFloat(a).toFixed(2);
                        }
                        return a;
                    },
                    gradientColor: function(o, n, t) {
                        for (var r = this, a = r.colorRgb(o), e = a[0], c = a[1], l = a[2], i = r.colorRgb(n), f = (i[0] - e) / t, g = (i[1] - c) / t, u = (i[2] - l) / t, s = [], d = 0; d < t; d++) {
                            var b = "rgb(" + parseInt(f * d + e) + "," + parseInt(g * d + c) + "," + parseInt(u * d + l) + ")", h = r.colorHex(b);
                            s.push(h);
                        }
                        return s;
                    },
                    colorRgb: function(o) {
                        if ((o = o.toLowerCase()) && /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/.test(o)) {
                            if (4 === o.length) {
                                for (var n = "#", t = 1; t < 4; t += 1) n += o.slice(t, t + 1).concat(o.slice(t, t + 1));
                                o = n;
                            }
                            var r = [];
                            for (t = 1; t < 7; t += 2) r.push(parseInt("0x" + o.slice(t, t + 2)));
                            return r;
                        }
                        return o;
                    },
                    colorHex: function(o) {
                        var n = o;
                        if (/^(rgb|RGB)/.test(n)) {
                            for (var t = n.replace(/(?:(|)|rgb|RGB)*/g, "").split(","), r = "#", a = 0; a < t.length; a++) {
                                var e = Number(t[a]).toString(16);
                                "0" === (e = e < 10 ? "0" + e : e) && (e += e), r += e;
                            }
                            return 7 !== r.length && (r = n), r;
                        }
                        if (!/^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/.test(n)) return n;
                        var c = n.replace(/#/, "").split("");
                        if (6 === c.length) return n;
                        if (3 === c.length) {
                            var l = "#";
                            for (a = 0; a < c.length; a += 1) l += c[a] + c[a];
                            return l;
                        }
                    },
                    setBgColor: function(n, t) {
                        var r = this;
                        if ("object" == (0, o.default)(n) && n.length > 0) {
                            var a = "linear-gradient(" + r.conf.backgroundColorLinearDeg + ",", e = null;
                            for (var c in n) {
                                e = n[c];
                                var l = r.colorRgb(e);
                                a += "rgba(".concat(l[0], ", ").concat(l[1], ", ").concat(l[2], ", ").concat(t, ")"), 
                                n.length != 1 * c + 1 && (a += ",");
                            }
                            a += ")", r.backgroundColorRgba = a;
                        } else {
                            var i = n, f = r.colorRgb(i);
                            r.backgroundColorRgba = "rgba(".concat(f[0], ", ").concat(f[1], ", ").concat(f[2], ", ").concat(t, ")");
                        }
                    },
                    bgImgStringHandle: function(o) {
                        return o;
                    },
                    searchConfirm: function(o) {
                        this.$emit("searchConfirm", o.detail);
                    },
                    searchClick: function(o) {
                        this.$emit("searchClick", !0);
                    }
                }
            };
            t.default = r;
        }).call(this, r("543d").default);
    },
    d2b9: function(o, n, t) {
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var r = function() {
            var o = this, n = (o.$createElement, o._self._c, o.conf.leftButton ? o.__map(o.conf.leftButton, function(n, t) {
                return {
                    $orig: o.__get_orig(n),
                    m0: n.position && "left" == n.position ? o.iconHandle(n.icon) : null,
                    m1: n.position && "left" == n.position ? null : o.iconHandle(n.icon)
                };
            }) : null), t = o.conf.rightButton ? o.__map(o.conf.rightButton, function(n, t) {
                return {
                    $orig: o.__get_orig(n),
                    m2: n.position && "left" == n.position ? o.iconHandle(n.icon) : null,
                    m3: n.position && "left" == n.position ? null : o.iconHandle(n.icon)
                };
            }) : null;
            o.$mp.data = Object.assign({}, {
                $root: {
                    l0: n,
                    l1: t
                }
            });
        }, a = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/hx-navbar/hx-navbar-create-component", {
    "components/hx-navbar/hx-navbar-create-component": function(o, n, t) {
        t("543d").createComponent(t("a006"));
    }
}, [ [ "components/hx-navbar/hx-navbar-create-component" ] ] ]);