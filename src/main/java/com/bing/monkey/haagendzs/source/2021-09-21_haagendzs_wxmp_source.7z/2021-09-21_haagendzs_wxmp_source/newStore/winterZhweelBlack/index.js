// newStore/winterZhweelBlack/index.js
Page({data: {}})