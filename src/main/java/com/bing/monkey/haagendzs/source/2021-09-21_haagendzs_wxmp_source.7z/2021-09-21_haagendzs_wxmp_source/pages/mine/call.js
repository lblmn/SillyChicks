(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/call" ], {
    "0e4b": function(n, e, o) {},
    "27d5": function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return u;
        }), o.d(e, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, u = [];
    },
    "295b": function(n, e, o) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("f4aa"), e(o("66fd")), n(e(o("a0ee")).default);
        }).call(this, o("543d").createPage);
    },
    8764: function(n, e, o) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                components: {
                    uniIcons: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(o("349f"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Zswiper: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/Zswiper") ]).then(function() {
                            return resolve(o("f95d"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        showBtn: !0
                    };
                },
                onLoad: function() {},
                methods: {
                    callPhone: function() {
                        n.makePhoneCall({
                            phoneNumber: "400 820 7917"
                        });
                    }
                }
            };
            e.default = t;
        }).call(this, o("543d").default);
    },
    a0ee: function(n, e, o) {
        o.r(e);
        var t = o("27d5"), u = o("a63a");
        for (var a in u) "default" !== a && function(n) {
            o.d(e, n, function() {
                return u[n];
            });
        }(a);
        o("e156");
        var c = o("f0c5"), i = Object(c.a)(u.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = i.exports;
    },
    a63a: function(n, e, o) {
        o.r(e);
        var t = o("8764"), u = o.n(t);
        for (var a in t) "default" !== a && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(a);
        e.default = u.a;
    },
    e156: function(n, e, o) {
        var t = o("0e4b");
        o.n(t).a;
    }
}, [ [ "295b", "common/runtime", "common/vendor" ] ] ]);