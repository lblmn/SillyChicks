var e = require("../../@babel/runtime/helpers/interopRequireDefault");

require("../../@babel/runtime/helpers/Arrayincludes");

var t = e(require("../../@babel/runtime/helpers/typeof"));

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    "138a": function(e, t, n) {
        n.r(t);
        var o = n("5b6a"), i = n("5bf3");
        for (var r in i) "default" !== r && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n("6b1d");
        var a = n("f0c5"), s = Object(a.a)(i.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = s.exports;
    },
    "5b6a": function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c, e._isMounted || (e.e0 = function(t) {
                e.showindex = !1;
            }, e.e1 = function(t) {
                e.showindex = !1;
            }, e.e2 = function(t) {
                e.showLogin = !1;
            }, e.e3 = function(t) {
                e.showFlag = !1;
            }, e.e4 = function(t) {
                e.showFlag = !1;
            }, e.e5 = function(t) {
                e.showActivity = !1;
            }, e.e6 = function(t) {
                e.showBannerAct = !1;
            }, e.e7 = function(t) {
                e.showBannerAct = !1;
            }, e.e8 = function(t) {
                e.showrulePop = !1;
            });
        }, i = [];
    },
    "5bf3": function(e, t, n) {
        n.r(t);
        var o = n("d961"), i = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = i.a;
    },
    "62ed": function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("c0e2"), t(n("66fd")), e(t(n("138a")).default);
        }).call(this, n("543d").createPage);
    },
    "6b1d": function(e, t, n) {
        var o = n("bb8b");
        n.n(o).a;
    },
    bb8b: function(e, t, n) {},
    d961: function(e, n, o) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = m(o("a34a")), r = m(o("500b")), a = m(o("f0fd")), s = m(o("c1f6")), c = m(o("6bd2")), u = m(o("394d")), d = m(o("234f")), l = (function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== (0, t.default)(e) && "function" != typeof e) return {
                    default: e
                };
                var n = y();
                if (n && n.has(e)) return n.get(e);
                var o = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var r in e) if (Object.prototype.hasOwnProperty.call(e, r)) {
                    var a = i ? Object.getOwnPropertyDescriptor(e, r) : null;
                    a && (a.get || a.set) ? Object.defineProperty(o, r, a) : o[r] = e[r];
                }
                o.default = e, n && n.set(e, o);
            }(o("c8e8")), m(o("93f4"))), g = m(o("e53f")), f = m(o("6258")), p = m(o("f3d6")), h = o("26cb");
            function y() {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap();
                return y = function() {
                    return e;
                }, e;
            }
            function m(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function v(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function S(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? v(Object(n), !0).forEach(function(t) {
                        b(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : v(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function b(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function w(e, t, n, o, i, r, a) {
                try {
                    var s = e[r](a), c = s.value;
                } catch (e) {
                    return void n(e);
                }
                s.done ? t(c) : Promise.resolve(c).then(o, i);
            }
            function x(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(o, i) {
                        var r = e.apply(t, n);
                        function a(e) {
                            w(r, o, i, a, s, "next", e);
                        }
                        function s(e) {
                            w(r, o, i, a, s, "throw", e);
                        }
                        a(void 0);
                    });
                };
            }
            var k = getApp(), I = {
                components: {
                    uniIcons: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(o("fafe"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Zswiper: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/Zswiper") ]).then(function() {
                            return resolve(o("5d9b"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    hansTabber: function() {
                        o.e("components/hans-tabbar/hans-tabbar").then(function() {
                            return resolve(o("8f35"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    headerimg: function() {
                        o.e("components/headerimg").then(function() {
                            return resolve(o("a806"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    Baffle: function() {
                        o.e("components/baffle").then(function() {
                            return resolve(o("f9f6"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        tzQueryType: "2,7",
                        backQqueryType: "",
                        textinfo: "《隐私政策》",
                        img_home_shouye: f.default.img_home_shouye,
                        imgUrl: a.default.assetsRoot + "/oss",
                        imgoss: a.default.ossurl + "/images/home/",
                        imgossBath: a.default.ossurl + "/images",
                        imgUx: a.default.ossurl + "/UX/index",
                        phone: "",
                        isLogin: !0,
                        hasWxtX: !0,
                        avatarUrl: "",
                        showLogin: !1,
                        cardNum: -1,
                        showindex: !1,
                        showLoading: !1,
                        ruleDesc: "",
                        wxgetPhone: !1,
                        loginRes: {},
                        isnoUnionid: !1,
                        swiper: {
                            imgUrls: [],
                            indicatorDots: !0,
                            autoplay: !0,
                            interval: 3e3,
                            duration: 500,
                            current: 0
                        },
                        swiper2: {
                            imgUrls: [],
                            indicatorDots: !1,
                            autoplay: !0,
                            interval: 2500,
                            duration: 500,
                            current: 0,
                            radius: 20
                        },
                        showFlag: !1,
                        showActivity: !1,
                        isHeightScreen: !1,
                        canIUseGetUserProfile: !1,
                        imgActivityUrl: "",
                        pictype: "",
                        isHasUserInfo: !1,
                        iserror: !1,
                        my_voucher: "",
                        points_mall: "",
                        check_in: "",
                        home_delivery: "",
                        isshowFirst: !1,
                        isGongGao: !1,
                        cangoNext: !1,
                        showIndexRule: !1,
                        showrulePop: !1,
                        ruleDescRule: "",
                        updateScoreValue2: 0,
                        showBannerAct: !1,
                        typeList: [ 2, 7 ],
                        typeVal: [],
                        isBuyCount: -1,
                        backStartDate: "",
                        backEndDate: ""
                    };
                },
                onLoad: function(t) {
                    var n = this;
                    return x(i.default.mark(function o() {
                        return i.default.wrap(function(o) {
                            for (;;) switch (o.prev = o.next) {
                              case 0:
                                e.removeStorageSync("hdAid"), e.removeStorageSync("shareback"), e.removeStorageSync("successInfo"), 
                                e.removeStorageSync("detailinfo"), e.removeStorageSync("refreash"), d.default.setSource(t), 
                                n.pictype = t.pictype ? t.pictype : "", console.log(n.pictype), d.default.isHeightPhone().then(function(e) {
                                    n.isHeightScreen = e;
                                }).catch(function(e) {
                                    n.isHeightScreen = e;
                                }), e.getUserProfile && (n.canIUseGetUserProfile = !0);

                              case 10:
                              case "end":
                                return o.stop();
                            }
                        }, o);
                    }))();
                },
                onShow: function() {
                    var t = this;
                    return x(i.default.mark(function n() {
                        return i.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                if (e.getBackgroundAudioManager().stop(), !e.getStorageSync("isFirstGoIndex")) {
                                    n.next = 11;
                                    break;
                                }
                                if (t.isshowFirst = !1, !(Object.keys(e.getStorageSync("logininfo")).length <= 0)) {
                                    n.next = 8;
                                    break;
                                }
                                return n.next = 8, t.getList();

                              case 8:
                                t.mainFun(), n.next = 17;
                                break;

                              case 11:
                                return n.next = 13, t.getList();

                              case 13:
                                return n.next = 15, t.getBottomBanner();

                              case 15:
                                t.isshowFirst = !0, e.hideTabBar();

                              case 17:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                onShareAppMessage: function(e) {
                    return "button" === e.from && console.log(e.target), {
                        title: "哈根达斯会员中心小程序",
                        path: "pages/index/index",
                        imageUrl: "".concat(a.default.assetsRoot, "/oss/wxapp/miniprogram.jpg")
                    };
                },
                computed: S(S({}, (0, h.mapState)([ "points", "navbarHeight_a", "wxuserinfoAvatar", "updateAmountValue", "updateScoreValue" ])), (0, 
                h.mapGetters)([ "userinfoBg", "userinfoType", "signInCountNum", "signAgain", "prograss" ])),
                methods: S(S({}, (0, h.mapActions)([ "getPoint" ])), {}, {
                    onChooseAvatar: function(e) {
                        console.log(e);
                    },
                    gotoRights: function(t) {
                        var n;
                        n = "a" == t ? 0 : "b" == t ? 1 : "c" == t ? 2 : "d" == t ? 3 : 4, e.navigateTo({
                            url: "/evaluation/interests/index?current=" + n
                        });
                    },
                    widthFun: function(e, t) {
                        return -1 == t ? 100 : 100 * parseFloat((t - e) / t).toFixed(2);
                    },
                    showIndexRuleFun: function() {
                        var t = this, n = "69";
                        a.default.envVersion, n = "69", p.default.activityGet(n, {
                            unionId: e.getStorageSync("unionId")
                        }).then(function(e) {
                            console.log(e), 0 == e.code ? (t.ruleDescRule = e.data.activity.ruleDesc ? e.data.activity.ruleDesc.replace(/\n/g, "<br/>") : "暂无规则", 
                            t.showrulePop = !0) : (t.ruleDescRule = "暂无规则", t.showrulePop = !0);
                        }).catch(function() {
                            t.ruleDescRule = "暂无规则", t.showrulePop = !0;
                        });
                    },
                    hotAct: function() {
                        e.showLoading({
                            mask: !0,
                            title: "Loading"
                        }), r.default.hotHome().then(function(t) {
                            console.log(t), 0 == t.code ? "h5" == t.data.type ? (d.default.recordPv(t.data.redirectUrl + "?url=" + t.data.redirectParams + "&hot=h5"), 
                            e.navigateTo({
                                url: t.data.redirectUrl + "?url=" + t.data.redirectParams
                            })) : "ext_mini" == t.data.type ? (d.default.recordPv(t.data.redirectUrl + "?extAppId=" + t.data.extAppId + "&hot=ext_mini"), 
                            e.hideLoading(), e.navigateToMiniProgram({
                                appId: t.data.extAppId,
                                path: t.data.redirectUrl
                            })) : "my_mini" == t.data.type ? (t.data.redirectUrl.indexOf("?") > -1 ? d.default.recordPv(t.data.redirectUrl + "&hot=my_mini") : d.default.recordPv(t.data.redirectUrl + "?hot=my_mini"), 
                            e.navigateTo({
                                url: t.data.redirectUrl,
                                complete: function() {
                                    e.hideLoading();
                                }
                            })) : (d.default.recordPv("/pages/index/noHot"), e.navigateTo({
                                url: "/pages/index/noHot"
                            })) : (d.default.recordPv("/pages/index/noHot"), e.navigateTo({
                                url: "/pages/index/noHot"
                            }));
                        }).catch(function() {
                            d.default.recordPv("/pages/index/noHot"), e.navigateTo({
                                url: "/pages/index/noHot"
                            });
                        }), getApp().hxt.sendAction("lastestcam_clk");
                    },
                    gotoH5: function(t) {
                        e.navigateTo({
                            url: "/pages/webView/indexN?url=" + encodeURIComponent(t)
                        });
                    },
                    getBottomBanner: function() {
                        var e = this;
                        g.default.getBanner("btm").then(function(t) {
                            0 == t.code && (e.swiper2.imgUrls = t.data.map(function(e) {
                                return S(S({}, e), {}, {
                                    newpicUrl: a.default.assetsRoot + e.picUrl,
                                    swiperheight: 210
                                });
                            }));
                        });
                    },
                    checkIn: function() {
                        var e = [ "onoRB5iIf1YVsAhd9P1pePeZHO8g" ];
                        for (var t in e) {
                            var n = new Date().getTime();
                            l.default.signIn({
                                unionId: e[t],
                                sign: d.default.mdString(n, {
                                    unionId: e[t]
                                }),
                                timestamp: n
                            }).then(function(e) {
                                console.log(e);
                            });
                        }
                    },
                    gotorule: function() {
                        e.navigateTo({
                            url: "/pages/mine/rule?frompath=index"
                        });
                    },
                    showAgain: function() {
                        getApp().hxt.sendAction("private_accept"), this.isshowFirst = !1, e.setStorageSync("isFirstGoIndex", !0), 
                        this.mainFun();
                    },
                    mainFun: function() {
                        var t = this;
                        return x(i.default.mark(function n() {
                            var o, s, c, u, l, g, f, p;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return d.default.recordPv(), n.next = 3, t.getBottomBanner();

                                  case 3:
                                    if (t.getHome_delivery(), !(Object.keys(e.getStorageSync("logininfo")).length > 0)) {
                                        n.next = 39;
                                        break;
                                    }
                                    if (console.log(k.hxt), k.hxt.identify({
                                        openid: e.getStorageSync("openId"),
                                        unionid: e.getStorageSync("unionId")
                                    }), console.log("获取信息"), t.isHasUserInfo = !0, e.getStorageSync("startTime")) {
                                        n.next = 14;
                                        break;
                                    }
                                    t.getMemberinfo(), e.setStorageSync("startTime", new Date().getTime()), n.next = 34;
                                    break;

                                  case 14:
                                    if (o = e.getStorageSync("startTime"), s = new Date().getTime(), u = (c = s - o) / 1e3 / 60 / 60 / 24, 
                                    l = Math.floor(u), g = c / 1e3 / 60 / 60 - 12 * l, f = Math.floor(g), console.log("天数", l), 
                                    console.log("小时", f), !(f >= 12)) {
                                        n.next = 28;
                                        break;
                                    }
                                    t.getMemberinfo(), e.setStorageSync("startTime", new Date().getTime()), n.next = 34;
                                    break;

                                  case 28:
                                    return t.typeParamList(), t.getPoint(), n.next = 32, t.getCardnum();

                                  case 32:
                                    n.sent, t.getRecord();

                                  case 34:
                                    t.pictype && t.getByType(), e.showTabBar(), t.cangoNext = !0, n.next = 47;
                                    break;

                                  case 39:
                                    return t.isHasUserInfo = !1, e.hideTabBar(), n.next = 43, t.doLogin();

                                  case 43:
                                    t.loginRes = n.sent, console.log(t.loginRes), p = t, setTimeout(function() {
                                        r.default.login({
                                            code: p.loginRes.code,
                                            appId: a.default.appId
                                        }).then(function(t) {
                                            console.log(t), 0 == t.code ? (e.setStorageSync("openId", t.data.openid), p.iserror = !1, 
                                            t.data.unionId ? (console.log("有unionid"), e.setStorageSync("unionId", t.data.unionId), 
                                            k.hxt.identify({
                                                openid: t.data.openid,
                                                unionid: t.data.unionId
                                            }), p.getMemberinfo()) : (e.hideTabBar(), console.log("没unionid"), setTimeout(function() {
                                                p.isnoUnionid = !0, p.isLogin = !1;
                                            }, 150))) : (e.showToast({
                                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                                icon: "none"
                                            }), p.iserror = !0);
                                        }).catch(function(t) {
                                            e.showToast({
                                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                                icon: "none"
                                            }), p.iserror = !0;
                                        });
                                    }, 300);

                                  case 47:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    queryInfo: function(t) {
                        var n = this;
                        r.default.queryBannerByType(S({
                            unionid: e.getStorageSync("unionId"),
                            backQqueryType: this.backQqueryType
                        }, t)).then(function(e) {
                            if (0 == e.code) {
                                if (e.data.bannerList.length > 0) {
                                    var t = e.data.bannerList.map(function(e) {
                                        return S(S({}, e), {}, {
                                            newpicUrl: a.default.assetsRoot + e.picUrl
                                        });
                                    });
                                    n.swiper.imgUrls = t;
                                }
                                e.data.popupList.length > 0 && (n.pictype || n.getPopupList(e.data.popupList));
                            }
                        });
                    },
                    typeParamList: function() {
                        var t = this;
                        r.default.typeParamList({
                            unionid: e.getStorageSync("unionId"),
                            frontQueryType: "2,7"
                        }).then(function(e) {
                            console.log(e), 0 == e.code ? (t.tzQueryType = e.data.tzQueryType, t.backQqueryType = e.data.backQqueryType, 
                            1 == e.data.isBuyCount && (t.isBuyCount = 1, t.backStartDate = e.data.backStartDate, 
                            t.backEndDate = e.data.backEndDate), t.getuserinfoState()) : t.getuserinfoState();
                        }).catch(function() {
                            t.getuserinfoState();
                        });
                    },
                    queryBanner: function(e) {
                        var t = this;
                        console.log(this.typeVal);
                        var n = {};
                        if (this.typeVal.length > 0) console.log(e), n = {
                            queryType: this.typeVal.join()
                        }, this.typeVal.forEach(function(t) {
                            n[t] = e[t] ? e[t] : "";
                        }), console.log(n); else {
                            var o = e.tierName, i = e.updateScoreValue;
                            n = {
                                queryType: "tierName,updateScoreValue",
                                tierName: o,
                                updateScoreValue: i
                            };
                        }
                        r.default.queryBanner(n).then(function(e) {
                            console.log(e), 0 == e.code && (e.data.bannerList.length > 0 && (t.swiper.imgUrls = e.data.bannerList.map(function(e) {
                                return S(S({}, e), {}, {
                                    newpicUrl: a.default.assetsRoot + e.picUrl
                                });
                            })), e.data.popupList.length > 0 && (t.pictype || t.getPopupList(e.data.popupList)));
                        });
                    },
                    getuserinfoState: function() {
                        var t = this, n = {
                            idType: "2",
                            id: e.getStorageSync("unionId"),
                            type: this.tzQueryType
                        };
                        1 == this.isBuyCount && (n.startDate = this.backStartDate, n.endDate = this.backEndDate), 
                        r.default.getmemberForProgress(n).then(function(e) {
                            if (0 == e.resultCode) {
                                var n = e.data, o = n.tierName, i = n.updateScoreValue;
                                e.data.tzCode = 0, console.log(e.data), t.queryInfo(e.data), t.$store.commit("updateUserInfo", o), 
                                t.$store.commit("updateScoreValue", i || 0), t.updateScoreValue2 = i || 0;
                            } else {
                                t.queryInfo({
                                    tzCode: -1
                                });
                            }
                        }).catch(function() {
                            t.queryInfo({
                                tzCode: -1
                            });
                        });
                    },
                    getHome_delivery: function() {
                        var e = this;
                        r.default.home_delivery().then(function(t) {
                            if (console.log(t), 0 == t.code && t.data.length > 0) {
                                e.my_voucher = "", e.points_mall = "", e.check_in = "", e.home_delivery = "";
                                for (var n = 0; n < t.data.length; n++) "home_delivery" == t.data[n].type ? e.home_delivery = t.data[n].name : "my_voucher" == t.data[n].type ? e.my_voucher = t.data[n].name : "points_mall" == t.data[n].type ? e.points_mall = t.data[n].name : "check_in" == t.data[n].type && (e.check_in = t.data[n].name);
                            }
                        });
                    },
                    navigateToNo: function(t) {
                        e.navigateTo({
                            url: t
                        });
                    },
                    gotoMiniProgram: function() {
                        d.default.recordPv("pages/index/index?appid=wxf83dc13b5390d17b"), getApp().hxt.sendAction("homedelivery_clk"), 
                        e.navigateToMiniProgram({
                            appId: "wxf83dc13b5390d17b",
                            path: "pages/index/index",
                            success: function(e) {
                                getApp.hxt.sendAction("hd_allow");
                            },
                            fail: function() {
                                getApp.hxt.sendAction("hd_cancel");
                            }
                        });
                    },
                    gotoLink: function() {
                        this.imgActiveLink.indexOf("/mine/mine") > 0 ? e.switchTab({
                            url: this.imgActiveLink
                        }) : this.pictype ? Object.keys(e.getStorageSync("logininfo")).length > 0 && (this.showActivity = !1, 
                        this.getRecord("HD-618")) : this.imgActiveLink.indexOf("moonActive/rule/index") > 0 && "success" == e.getStorageSync("isGetMoonRule") ? e.navigateTo({
                            url: "/pages/shop/shop"
                        }) : e.navigateTo({
                            url: this.imgActiveLink
                        });
                    },
                    closeActivity: function() {
                        this.pictype && Object.keys(e.getStorageSync("logininfo")).length > 0 && this.getRecord("HD-618"), 
                        this.showActivity = !1;
                    },
                    getPopupList: function(t) {
                        var n = this;
                        return x(i.default.mark(function o() {
                            var r, s, c, u, d;
                            return i.default.wrap(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    if (!e.getStorageSync("unionId")) {
                                        o.next = 9;
                                        break;
                                    }
                                    if ("/evaluation/repurchase/index" != t[0].linkUrl) {
                                        o.next = 9;
                                        break;
                                    }
                                    return o.next = 4, n.existsGive();

                                  case 4:
                                    if (r = o.sent, console.log(r), 602 != r.code && 604 != r.code && 601 != r.code) {
                                        o.next = 9;
                                        break;
                                    }
                                    return n.showActivity = !1, o.abrupt("return", !1);

                                  case 9:
                                    t.length > 0 && (t && "/evaluation/repurchase/index" == t[0].linkUrl ? n.showIndexRule = !0 : n.showIndexRule = !1, 
                                    "1" == t[0].frequency ? (e.removeStorageSync("isFirstPopupList"), n.imgActivityUrl = a.default.assetsRoot + t[0].picUrl, 
                                    n.imgActiveLink = t[0].linkUrl, n.showActivity = !0) : "3" == t[0].frequency ? (s = new Date(), 
                                    s.getHours() > 12 ? (1 == e.getStorageSync("unionid_back") && e.removeStorageSync("unionid_back"), 
                                    e.getStorageSync("unionid_back") || (n.imgActivityUrl = a.default.assetsRoot + t[0].picUrl, 
                                    n.imgActiveLink = t[0].linkUrl, n.showActivity = !0, e.setStorageSync("unionid_back", 2))) : (2 == e.getStorageSync("unionid_back") && e.removeStorageSync("unionid_back"), 
                                    e.getStorageSync("unionid_back") || (n.imgActivityUrl = a.default.assetsRoot + t[0].picUrl, 
                                    n.imgActiveLink = t[0].linkUrl, n.showActivity = !0, e.setStorageSync("unionid_back", 1)))) : (c = new Date(new Date(new Date().toLocaleDateString()).getTime() + 864e5 - 1), 
                                    u = new Date().getTime(), d = new Date(c).getTime(), console.log(d, "........"), 
                                    d - u <= 0 && e.removeStorageSync("isFirstPopupList"), e.getStorageSync("isFirstPopupList") || (n.imgActivityUrl = a.default.assetsRoot + t[0].picUrl, 
                                    n.imgActiveLink = t[0].linkUrl, n.showActivity = !0, e.setStorageSync("isFirstPopupList", !0))));

                                  case 10:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    getPopupList2: function() {
                        var t = this;
                        r.default.getPopupList().then(function() {
                            var n = x(i.default.mark(function n(o) {
                                var r, s, c, u, d;
                                return i.default.wrap(function(n) {
                                    for (;;) switch (n.prev = n.next) {
                                      case 0:
                                        if (console.log(o), !e.getStorageSync("unionId")) {
                                            n.next = 10;
                                            break;
                                        }
                                        if (!o.data || "/evaluation/repurchase/index" != o.data[0].linkUrl) {
                                            n.next = 10;
                                            break;
                                        }
                                        return n.next = 5, t.existsGive();

                                      case 5:
                                        if (r = n.sent, console.log(r), 602 != r.code && 604 != r.code && 601 != r.code) {
                                            n.next = 10;
                                            break;
                                        }
                                        return t.showActivity = !1, n.abrupt("return", !1);

                                      case 10:
                                        0 == o.code && o.data.length > 0 && (o.data && "/evaluation/repurchase/index" == o.data[0].linkUrl ? t.showIndexRule = !0 : t.showIndexRule = !1, 
                                        "1" == o.data[0].frequency ? (e.removeStorageSync("isFirstPopupList"), t.imgActivityUrl = a.default.assetsRoot + o.data[0].picUrl, 
                                        t.imgActiveLink = o.data[0].linkUrl, t.showActivity = !0) : "3" == o.data[0].frequency ? (s = new Date(), 
                                        s.getHours() > 12 ? (1 == e.getStorageSync("unionid_back") && e.removeStorageSync("unionid_back"), 
                                        e.getStorageSync("unionid_back") || (t.imgActivityUrl = a.default.assetsRoot + o.data[0].picUrl, 
                                        t.imgActiveLink = o.data[0].linkUrl, t.showActivity = !0, e.setStorageSync("unionid_back", 2))) : (2 == e.getStorageSync("unionid_back") && e.removeStorageSync("unionid_back"), 
                                        e.getStorageSync("unionid_back") || (t.imgActivityUrl = a.default.assetsRoot + o.data[0].picUrl, 
                                        t.imgActiveLink = o.data[0].linkUrl, t.showActivity = !0, e.setStorageSync("unionid_back", 1)))) : (c = new Date(new Date(new Date().toLocaleDateString()).getTime() + 864e5 - 1), 
                                        u = new Date().getTime(), d = new Date(c).getTime(), console.log(d, "........"), 
                                        d - u <= 0 && e.removeStorageSync("isFirstPopupList"), e.getStorageSync("isFirstPopupList") || (t.imgActivityUrl = a.default.assetsRoot + o.data[0].picUrl, 
                                        t.imgActiveLink = o.data[0].linkUrl, t.showActivity = !0, e.setStorageSync("isFirstPopupList", !0))));

                                      case 11:
                                      case "end":
                                        return n.stop();
                                    }
                                }, n);
                            }));
                            return function(e) {
                                return n.apply(this, arguments);
                            };
                        }());
                    },
                    existsGive: function() {
                        return r.default.existsGive(e.getStorageSync("unionId"));
                    },
                    getByType: function() {
                        var e = this;
                        r.default.getByType(this.pictype).then(function(t) {
                            console.log(t), 0 == t.code && (e.imgActivityUrl = a.default.assetsRoot + t.data.picUrl, 
                            e.imgActiveLink = t.data.linkUrl, e.showActivity = !0);
                        });
                    },
                    gotoWebView: function() {
                        e.navigateTo({
                            url: "../webView/index"
                        });
                    },
                    newInfoA: function() {
                        var t = this;
                        return x(i.default.mark(function n() {
                            var o;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.getNewUserInfo();

                                  case 2:
                                    o = n.sent, console.log(o), e.setStorageSync("wxuserinfoAvatar", o.userInfo.avatarUrl), 
                                    t.avatarUrl = o.userInfo.avatarUrl, t.hasWxtX = !1;

                                  case 7:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    newInfo: function() {
                        var t = this;
                        return x(i.default.mark(function n() {
                            var o, r;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.getNewUserInfo();

                                  case 2:
                                    return o = n.sent, console.log(o), e.setStorageSync("wxinfo", o.userInfo), n.next = 7, 
                                    t.getUnionid(o);

                                  case 7:
                                    r = n.sent, e.setStorageSync("unionId", r.data.unionId), t.getMemberinfo();

                                  case 10:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    getNewUserInfo: function() {
                        return new Promise(function(t, n) {
                            e.getUserProfile({
                                desc: "会员信息",
                                success: function(e) {
                                    console.log(e), t(e);
                                },
                                fail: function(e) {
                                    console.log(e), console.log("拒绝了用户信息授权");
                                }
                            });
                        });
                    },
                    gotoAct: function() {
                        e.redirectTo({
                            url: "../../evaluation/list/index"
                        });
                    },
                    getRecord: function(t) {
                        c.default.saveLoginRecord({
                            unionId: e.getStorageSync("unionId"),
                            openId: e.getStorageSync("openId"),
                            source: t || e.getStorageSync("smsSource")
                        }).then(function(e) {
                            console.log(e);
                        });
                    },
                    getList: function() {
                        var e = this;
                        u.default.getList().then(function(t) {
                            0 == t.code && (e.swiper.imgUrls = t.data.map(function(e) {
                                return S(S({}, e), {}, {
                                    newpicUrl: a.default.assetsRoot + e.picUrl
                                });
                            }));
                        });
                    },
                    prevImg: function() {
                        this.swiper.current = this.swiper.current > 0 ? this.swiper.current - 1 : this.swiper.imgUrls.length - 1;
                    },
                    nextImg: function() {
                        this.swiper.current = this.swiper.current < this.swiper.imgUrls.length - 1 ? this.swiper.current + 1 : 0;
                    },
                    onGetUserInfo: function() {
                        var t = this;
                        return x(i.default.mark(function n() {
                            var o, r;
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.getUserinfo(t.loginRes);

                                  case 2:
                                    return o = n.sent, e.setStorageSync("wxinfo", o.userInfo), n.next = 6, t.getUnionid(o);

                                  case 6:
                                    r = n.sent, e.setStorageSync("unionId", r.data.unionId), t.getMemberinfo();

                                  case 9:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    onGetPhoneNumber: function(t) {
                        var n = this;
                        "getPhoneNumber:fail user deny" == t.detail.errMsg ? console.log("取消授权") : r.default.decrypt({
                            encryptedData: t.detail.encryptedData,
                            openId: e.getStorageSync("openId"),
                            iv: t.detail.iv
                        }).then(function(t) {
                            n.phone = t.data.phoneNumber, e.setStorageSync("userinfoPhone", t.data.phoneNumber), 
                            n.bindQuery();
                        });
                    },
                    doLogin: function() {
                        return new Promise(function(t, n) {
                            e.login({
                                success: function(e) {
                                    console.log(e), t(e);
                                },
                                fail: function(e) {
                                    console.log(e), n(e);
                                }
                            });
                        });
                    },
                    getUserinfo: function(t) {
                        return console.log(t), new Promise(function(n, o) {
                            t.code ? e.getUserInfo({
                                success: function(e) {
                                    console.log(e), n(e);
                                }
                            }) : (o("登录失败！" + t.errMsg), console.log("登录失败！" + t.errMsg));
                        });
                    },
                    getOpenid: function(e) {},
                    getUnionid: function(t) {
                        return r.default.decrypt({
                            encryptedData: t.encryptedData,
                            openId: e.getStorageSync("openId"),
                            iv: t.iv
                        });
                    },
                    bindQuery: function() {
                        var t = this, n = e.getStorageSync("unionId"), o = e.getStorageSync("openId");
                        r.default.bindquery({
                            thirdPartyId: n,
                            openid: o,
                            source: 2,
                            mobilePhone: this.phone
                        }).then(function(i) {
                            console.log("会员绑定查询入参" + JSON.stringify({
                                thirdPartyId: n,
                                openid: o,
                                source: 2,
                                mobilePhone: t.phone
                            })), console.log("会员绑定查询返回" + JSON.stringify(i)), 0 == i.resultCode ? "E000101" == i.resultDesc ? e.navigateTo({
                                url: "/pages/register/register?fromUrl=index"
                            }) : "E000102" == i.resultDesc ? r.default.bind({
                                thirdPartyId: e.getStorageSync("unionId"),
                                thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                openid: e.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: t.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: e.getStorageSync("unionId"),
                                    thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                    openid: e.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: t.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (t.iserror = !1, 
                                e.setStorageSync("socialhubId", n.data.socialhubId), t.getMemberinfo()) : (e.showToast({
                                    title: "访问异常，小哈正在努力恢复，请稍后重试",
                                    icon: "none"
                                }), that.iserror = !0);
                            }) : "E000103" == i.resultDesc ? (e.setStorageSync("socialhubId", i.data.socialhubId), 
                            t.getMemberinfo()) : t.showFlag = !0 : 1 == i.resultCode ? "E000107" == i.resultDesc ? (t.iserror = !1, 
                            r.default.bind({
                                thirdPartyId: e.getStorageSync("unionId"),
                                thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                openid: e.getStorageSync("openId"),
                                source: 2,
                                mobilePhone: t.phone
                            }).then(function(n) {
                                console.log("会员绑定入参" + JSON.stringify({
                                    thirdPartyId: e.getStorageSync("unionId"),
                                    thirdPartyName: e.getStorageSync("wxinfo").nickName,
                                    openid: e.getStorageSync("openId"),
                                    source: 2,
                                    mobilePhone: t.phone
                                })), console.log("会员绑定的出参" + JSON.stringify(n)), 0 == n.resultCode ? (t.iserror = !1, 
                                e.setStorageSync("socialhubId", n.data.socialhubId), t.getMemberinfo()) : (e.showToast({
                                    title: "访问异常，小哈正在努力恢复，请稍后重试",
                                    icon: "none"
                                }), that.iserror = !0);
                            })) : (e.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), that.iserror = !0) : e.showToast({
                                title: "请求异常请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    getMemberinfo: function() {
                        var t = this;
                        r.default.getmember({
                            idType: "2",
                            id: e.getStorageSync("unionId")
                        }).then(function() {
                            var n = x(i.default.mark(function n(o) {
                                return i.default.wrap(function(n) {
                                    for (;;) switch (n.prev = n.next) {
                                      case 0:
                                        if (console.log(o), 0 != o.resultCode) {
                                            n.next = 17;
                                            break;
                                        }
                                        return e.setStorageSync("logininfo", o.data), e.setStorageSync("socialhubId", o.data.socialhubId), 
                                        t.$store.commit("userinfo", o.data), t.typeParamList(), t.getPoint(), n.next = 9, 
                                        t.getCardnum();

                                      case 9:
                                        n.sent, t.getRecord(), t.isLogin = !0, t.pictype && (t.isHasUserInfo = !0, t.getByType()), 
                                        e.showTabBar(), t.cangoNext = !0, n.next = 21;
                                        break;

                                      case 17:
                                        t.isLogin = !1, t.iserror = !1, t.isLogin ? (t.isLogin = !1, e.hideTabBar(), e.showToast({
                                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                                            icon: "none"
                                        }), that.iserror = !0) : t.wxgetPhone = !0, t.pictype && (t.isHasUserInfo = !1, 
                                        t.getByType());

                                      case 21:
                                      case "end":
                                        return n.stop();
                                    }
                                }, n);
                            }));
                            return function(e) {
                                return n.apply(this, arguments);
                            };
                        }()).catch(function(n) {
                            console.log("接口出错了"), t.isLogin = !1, e.hideTabBar(), e.showToast({
                                title: "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), that.iserror = !0;
                        });
                    },
                    plusPoints: function() {
                        r.default.plusPoints(e.getStorageSync("unionId")).then(function(e) {
                            console.log(e);
                        });
                    },
                    getCardnum: function() {
                        var t = this;
                        return new Promise(function(n, o) {
                            s.default.indexCouponList({
                                idType: 1,
                                id: e.getStorageSync("socialhubId"),
                                state: 1e8,
                                pageSize: 100
                            }).then(function(e) {
                                0 == e.resultCode ? (t.cardNum = e.data >= 100 ? "99+" : e.data, n(e)) : o(e);
                            });
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        s.default.getRuledesc({
                            type: 1
                        }).then(function(t) {
                            e.ruleDesc = t.data[0].content, e.showindex = !0;
                        });
                    },
                    tabChange: function(e) {
                        console.log(e);
                    },
                    tabbarClick: function() {
                        this.wxgetPhone ? e.showToast({
                            title: "请点击登录验证",
                            icon: "none"
                        }) : this.showLogin = !0;
                    },
                    navigateTo: function(t) {
                        if (this.iserror) e.showToast({
                            title: "访问异常，小哈正在努力恢复，请稍后重试",
                            icon: "none"
                        }); else {
                            if (!this.isLogin) return this.wxgetPhone ? void e.showToast({
                                title: "请点击登录验证",
                                icon: "none"
                            }) : void (this.showLogin = !0);
                            this.cangoNext && (t.url ? (t.url.includes("/shop/shop") || t.url.includes("/pages/attendance/attendance") || d.default.recordPv(t.url), 
                            t.outAppid && "" != t.outAppid ? e.navigateToMiniProgram({
                                appId: t.outAppid,
                                path: t.url,
                                success: function(e) {}
                            }) : e.navigateTo({
                                url: t.url
                            })) : (t.includes("/shop/shop") || t.includes("/attendance/attendance") || d.default.recordPv(t), 
                            t.includes("/mine/mine") || t.includes("/code/code") ? e.switchTab({
                                url: t
                            }) : t.indexOf("moonActive/rule/index") > 0 ? "success" == e.getStorageSync("isGetMoonRule") ? e.navigateTo({
                                url: "/pages/shop/shop"
                            }) : e.navigateTo({
                                url: t
                            }) : t.indexOf("pages/webView/home_index") > -1 ? e.requestSubscribeMessage({
                                tmplIds: [ "vs2kCdD9yEQ28bUvk2lklAVX8jiO7u5-VoTZjfWzsNk", "_2Xdxp95FeXVwryFbxN6VsVKMFbLwe0HD-FCn9KSyi4" ],
                                complete: function(n) {
                                    e.navigateTo({
                                        url: t
                                    });
                                }
                            }) : "/indexShow" == t ? this.showBannerAct = !0 : e.navigateTo({
                                url: t
                            })));
                        }
                    },
                    switchTab: function(t) {
                        if (console.log("switchTab"), !this.isLogin) return this.wxgetPhone ? void e.showToast({
                            title: "请点击登录验证",
                            icon: "none"
                        }) : void (this.showLogin = !0);
                        e.switchTab({
                            url: t
                        });
                    },
                    gopupop: function() {
                        this.getRuleDesc();
                    }
                })
            };
            n.default = I;
        }).call(this, o("543d").default);
    }
}, [ [ "62ed", "common/runtime", "common/vendor" ] ] ]);