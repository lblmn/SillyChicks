(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/attendance/attendance" ], {
    "00e6": function(n, t, e) {
        var i = e("f076");
        e.n(i).a;
    },
    "273c": function(n, t, e) {
        (function(n) {
            var i = e("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = i(e("9523")), s = i(e("bed4")), a = i(e("0098")), r = i(e("f3d4")), c = i(e("7d43")), h = i(e("5db4")), u = e("26cb");
            function g(n, t) {
                var e = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(n);
                    t && (i = i.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable;
                    })), e.push.apply(e, i);
                }
                return e;
            }
            function l(n) {
                for (var t = 1; t < arguments.length; t++) {
                    var e = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? g(Object(e), !0).forEach(function(t) {
                        (0, o.default)(n, t, e[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : g(Object(e)).forEach(function(t) {
                        Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t));
                    });
                }
                return n;
            }
            var d = [ 0, 3, 6, 9, 17, 19, 20, 25, 32, 33, 34, 35, 36, 36, 41, 48, 49, 50, 51, 52, 53, 58, 63, 64, 65, 66, 67, 68, 69, 71, 77, 81, 81, 82, 82, 82, 83, 83, 83, 83, 84, 84, 84, 84, 85, 85, 85, 85, 85, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 100 ], f = [ 5, 10, 15, "咖啡券×1", 20, 200 ], p = (getApp(), 
            {
                components: {
                    uniIcons: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(e("6093"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    uniCalendar: function() {
                        Promise.all([ e.e("common/vendor"), e.e("pages/attendance/uni-calendar/uni-calendar") ]).then(function() {
                            return resolve(e("16fd"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    loginDialog: function() {
                        Promise.all([ e.e("common/vendor"), e.e("components/loginDialog") ]).then(function() {
                            return resolve(e("d6e5"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    Loading: function() {
                        e.e("components/loading").then(function() {
                            return resolve(e("64ff"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    headerimg: function() {
                        e.e("components/headerimg").then(function() {
                            return resolve(e("09c2"));
                        }.bind(null, e)).catch(e.oe);
                    },
                    hxNavbar: function() {
                        e.e("components/hx-navbar/hx-navbar").then(function() {
                            return resolve(e("614f"));
                        }.bind(null, e)).catch(e.oe);
                    }
                },
                data: function() {
                    return {
                        showFlag: !1,
                        showactive: !1,
                        attendanceList: [],
                        startDate: "",
                        endDate: "",
                        dayLength: 0,
                        canSign: Boolean,
                        isfirst: !1,
                        from: "",
                        imgoss: r.default.ossurl + "/images/attendance/",
                        imgoss_new: r.default.ossurl + "UX/attendance/",
                        fromzwheel: !1,
                        showloginDialog: !1,
                        checked: !1,
                        firstTime: 0,
                        secordTime: 0,
                        lastTime: 0,
                        isHasHeadimg: !1,
                        showPopup: !1,
                        isOpen: !1,
                        signType: "point",
                        width: 0,
                        nextday: 0,
                        resultIndex: "",
                        coffeeIndex: !1,
                        reusltDay: "",
                        config: {
                            statusBarFontColor: "#ffffff",
                            barPlaceholder: !1,
                            backgroundColor: [ 0, "#fff" ]
                        },
                        pointAdd: 3,
                        isShowSetting: !1,
                        isBirth: !1,
                        scence: "",
                        gramRow: 0,
                        nowInfo: {},
                        gameNextDay: "",
                        lastSignInDate: "",
                        nowcanSign: "",
                        isneedSign: !1,
                        fromType: "",
                        activityName: ""
                    };
                },
                onLoad: function(n) {
                    c.default.setSource(n), this.from = n.from, "zwheel" == this.from && (this.fromzwheel = !0), 
                    "blind" == n.type && (this.fromType = "blind"), this.isHeightPhone();
                },
                onShow: function() {
                    this.$refs.Loading.showLoading(), Object.keys(n.getStorageSync("logininfo")).length > 0 ? (this.signInSearch(), 
                    c.default.recordPv(), this.getRecord(), getApp().hxt.identify({
                        openid: n.getStorageSync("openId"),
                        unionid: n.getStorageSync("unionId")
                    }), this.getUserAll_w(), this.$refs.Loading.hideLoading()) : this.showloginDialog = !0;
                },
                computed: l(l({}, (0, u.mapState)([ "isHeightScreen", "points", "navbarHeight_a" ])), {}, {
                    shwidth: function() {
                        var n = this.dayLength;
                        n > 60 && n % 60 != 0 && (n %= 60);
                        var t = d[n];
                        return console.log("result", t), t;
                    },
                    newPoints: function() {
                        return this.$store.state.points;
                    }
                }),
                methods: l(l({
                    monthSwitch: function(n) {
                        console.log(n), this.$refs.Loading.showLoading(), this.signInSearch(n.nowDate), 
                        this.$refs.Loading.hideLoading();
                    },
                    getweekinfo: function(n) {
                        var t;
                        if (console.info("当天数据", n), n) if (this.nowInfo = n, n.lunar.isBirth) this.isBirth = !0; else if (null !== (t = n.lunar.ishasImg) && void 0 !== t && t.isneedSign) {
                            var e;
                            this.isneedSign = !0, null !== (e = n.lunar.ishasImg) && void 0 !== e && e.activityName && (this.activityName = n.lunar.ishasImg.activityName);
                        } else this.isBirth = !1; else this.isBirth = !1;
                    },
                    todayIsBirth: function() {
                        this.nowInfo && this.nowInfo.lunar.isBirth ? this.isBirth = !0 : this.isBirth = !1;
                    },
                    showWidth: function() {}
                }, (0, u.mapActions)([ "getPoint", "isHeightPhone" ])), {}, {
                    switchChange: function(n) {
                        n.detail, getApp().hxt.sendAction("checkin_reminder_clk"), this.getUserAll();
                    },
                    closeShowPopup: function() {
                        this.showPopup = !1;
                    },
                    getUserAll_w: function() {
                        var t = this;
                        n.getSetting({
                            withSubscriptions: !0,
                            success: function(n) {
                                var e = n.subscriptionsSetting;
                                console.log(e), void 0 !== e.itemSettings && "accept" == e.itemSettings.Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00 ? (t.checked = !0, 
                                t.isShowSetting = !0) : void 0 !== e.itemSettings && "reject" == e.itemSettings.Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00 && (t.checked = !1, 
                                t.isShowSetting = !1);
                            }
                        });
                    },
                    getUserAll: function() {
                        var t = this;
                        n.getSetting({
                            withSubscriptions: !0,
                            success: function(e) {
                                console.log(e);
                                var i = e.subscriptionsSetting;
                                void 0 !== i.itemSettings && "accept" == i.itemSettings.Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00 ? (t.isOpen = !0, 
                                t.showPopup = !0) : void 0 !== i.itemSettings && "reject" == i.itemSettings.Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00 ? (t.isOpen = !1, 
                                t.showPopup = !0) : n.requestSubscribeMessage({
                                    tmplIds: [ "Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00" ],
                                    complete: function(n) {
                                        t.warnConfigFun(), t.getUserAll_w();
                                    }
                                });
                            }
                        });
                    },
                    warnConfigFun: function() {
                        s.default.warnConfig({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId")
                        }).then(function(n) {
                            console.log(n);
                        });
                    },
                    userInfoSuccess: function(t) {
                        "all" == t && (this.signInSearch(), this.getUserAll_w(), this.getRecord(), c.default.recordPv(), 
                        n.removeStorageSync("successInfo"), this.$refs.Loading.hideLoading());
                    },
                    getRecord: function() {
                        h.default.saveLoginRecord({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId"),
                            source: n.getStorageSync("smsSource")
                        }).then(function(n) {
                            console.log(n);
                        });
                    },
                    signInSearch: function() {
                        var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                        if (!e) {
                            var o = new Date(), a = o.getFullYear(), r = o.getMonth() + 1;
                            console.log(a, r), r < 10 && (r = "0" + r), e = a + "-" + r + "-10";
                        }
                        s.default.signInSearch({
                            unionId: n.getStorageSync("unionId"),
                            startTime: e,
                            endTime: i
                        }).then(function(e) {
                            if (0 == e.code) {
                                var i = [];
                                if (e.data.signInList.forEach(function(n) {
                                    i.push(l(l({}, n), {}, {
                                        date: n.signInDate
                                    }));
                                }), t.attendanceList = i, t.dayLength = e.data.continuingSignInCount, t.lastSignInDate = e.data.lastSignInDate, 
                                t.nowcanSign = e.data.currentSignIn, t.DayLengthResult(), t.canSign = !e.data.currentSignIn, 
                                0 == t.canSign) {
                                    t.getPoint();
                                    var o = t.dayLength;
                                    o > 60 && o % 60 != 0 && (o %= 60), o % 21 == 0 && o / 21 == 1 && (t.signType = "coupon");
                                }
                            } else n.showToast({
                                title: e.msg ? e.msg : "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            });
                        });
                    },
                    showLastGameTime: function(n) {
                        var t = this.lastSignInDate, e = 0;
                        this.nowcanSign && (e = 60 - this.gramRow);
                        var i = new Date(t);
                        i.setDate(i.getDate() + e), console.log(i);
                        var o = i.getMonth() + 1, s = i.getDate(), a = i.getFullYear() + "-" + (o < 10 ? "0" + o : o) + "-" + (s < 10 ? "0" + s : s);
                        console.log(a), this.gameNextDay = a;
                    },
                    changeDayLength: function() {
                        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                        "dosign" == n && (this.dayLength = this.dayLength + 1, this.DayLengthResult()), 
                        this.showPoint();
                    },
                    showPoint: function() {
                        var n = this.dayLength;
                        n > 60 && n % 60 != 0 ? n %= 60 : n > 60 && n % 60 == 0 && (n = 60), this.pointAdd = 3 == n ? 5 : 7 == n ? 10 : 14 == n ? 15 : 21 == n ? 3 : 30 == n ? 20 : 60 == n ? 200 : 3;
                    },
                    DayLengthResult: function() {
                        var n = this.dayLength;
                        n > 60 && n % 60 != 0 ? n %= 60 : n > 60 && n % 60 == 0 && (n = 60), this.gramRow = n, 
                        this.coffeeIndex = !1, n < 3 ? (this.nextday = 3 - n, this.resultIndex = f[0], this.reusltDay = 3) : n >= 3 && n < 7 ? (this.nextday = 7 - n, 
                        this.resultIndex = f[1], this.reusltDay = 7) : n >= 7 && n < 14 ? (this.nextday = 14 - n, 
                        this.resultIndex = f[2], this.reusltDay = 14) : n >= 14 && n < 21 ? (this.nextday = 21 - n, 
                        this.resultIndex = f[3], this.reusltDay = 21, this.coffeeIndex = !0) : n >= 21 && n < 30 ? (this.nextday = 30 - n, 
                        this.resultIndex = f[4], this.reusltDay = 30) : n >= 30 && n < 60 ? (this.nextday = 60 - n, 
                        this.resultIndex = f[5], this.reusltDay = 60) : 60 == n && (this.nextday = 0, this.resultIndex = 0);
                    },
                    doSign: function() {
                        var t = this;
                        if (!this.canSign) return this.showFlag = !0, void (this.isShowSetting && n.requestSubscribeMessage({
                            tmplIds: [ "Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00" ],
                            complete: function(n) {}
                        }));
                        if (this.isfirst) return !1;
                        this.isfirst = !0, getApp().hxt.sendAction("checkin_now_clk");
                        var e = new Date().getTime();
                        this.$refs.Loading.showLoading(), s.default.signIn({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId"),
                            socialHubid: n.getStorageSync("socialhubId"),
                            mobile: n.getStorageSync("logininfo").mobilePhone,
                            sign: c.default.mdString(e, {
                                openId: n.getStorageSync("openId"),
                                unionId: n.getStorageSync("unionId")
                            }),
                            timestamp: e
                        }).then(function(e) {
                            if (0 == e.code) {
                                if (t.isShowSetting && n.requestSubscribeMessage({
                                    tmplIds: [ "Srz9SiIuGpNSFXFnKCK8JneH9dQN77C7ACnY2vl2M00" ],
                                    complete: function(n) {}
                                }), "birth" != t.signType && (t.signType = e.data.type ? e.data.type : "point"), 
                                "coupon" == e.data.type) t.showFlag = !0, t.isfirst = !1; else var i = t, o = setTimeout(function() {
                                    i.getPoint().then(function(n) {
                                        console.log(n), i.showFlag = !0, i.isfirst = !1, clearTimeout(o);
                                    }).catch(function() {
                                        i.isfirst = !1, clearTimeout(o);
                                    });
                                }, 1e3);
                                t.changeDayLength("dosign"), t.$refs.Loading.hideLoading();
                            } else t.$refs.Loading.hideLoading(), n.showToast({
                                title: e.msg ? e.msg : "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), t.isfirst = !1;
                        }).catch(function() {
                            t.$refs.Loading.hideLoading(), n.showToast({
                                title: res.msg ? res.msg : "访问异常，小哈正在努力恢复，请稍后重试",
                                icon: "none"
                            }), t.isfirst = !1;
                        });
                    },
                    gotoShop: function() {
                        if (getApp().hxt.sendAction("jixincoupon_clk"), "blind" == this.fromType) n.reLaunch({
                            url: "/blindBox/home/index?source=MCYRCJ_Sign&channelLabel=MCYRCJ_Sign"
                        }); else if (this.isBirth) {
                            var t = this.nowInfo.lunar.ishasImg.url;
                            n.navigateTo({
                                url: t
                            });
                        } else if (this.isneedSign) {
                            var e = this.nowInfo.lunar.ishasImg.url;
                            if ("moonActive" == this.activityName) {
                                console.log(this.newPoints);
                                var i;
                                i = !this.newPoints || this.newPoints <= 199 ? "pointA" : this.newPoints > 199 && this.newPoints <= 499 ? "pointB" : this.newPoints > 499 ? "pointC" : "pointA", 
                                n.navigateTo({
                                    url: e + "&tabFrom=" + i
                                });
                            } else n.navigateTo({
                                url: e
                            });
                        } else "coupon" == this.signType ? n.navigateTo({
                            url: "/pages/mine/mycard"
                        }) : "shop" == this.from || "zwheel" == this.from ? n.navigateBack({
                            delta: -1
                        }) : n.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    getPoints: function() {
                        var t = this;
                        a.default.point({
                            idType: "1",
                            id: n.getStorageSync("socialhubId")
                        }).then(function(n) {
                            0 == n.resultCode ? (t.showFlag = !0, t.isfirst = !1) : t.isfirst = !1;
                        }).catch(function() {
                            t.isfirst = !1;
                        });
                    },
                    activeRule: function() {
                        getApp().hxt.sendAction("checkin_rule_clk"), this.showactive = !0;
                    },
                    changeWeek: function(t) {
                        if (console.log(t), t.lunar.ishasImg && t.lunar.ishasImg.url) if (getApp().hxt.sendAction("calendar_icon_clk", {
                            calendar_icon_campaign_name: t.lunar.ishasImg.actName ? t.lunar.ishasImg.actName : "未配置活动名称",
                            calendar_icon_campaign_id: t.lunar.ishasImg.actId ? t.lunar.ishasImg.actId : "暂无"
                        }), t.isDay) (t.lunar.isBirth || t.lunar.ishasImg.isneedSign) && this.doSign(); else if ("moonActive" == t.lunar.ishasImg.activityName) {
                            var e;
                            e = !this.newPoints || this.newPoints <= 199 ? "pointA" : this.newPoints > 199 && this.newPoints <= 499 ? "pointB" : this.newPoints > 499 ? "pointC" : "pointA", 
                            n.navigateTo({
                                url: t.lunar.ishasImg.url + "&tabFrom=" + e
                            });
                        } else n.navigateTo({
                            url: t.lunar.ishasImg.url
                        });
                    },
                    goheart: function() {
                        n.navigateTo({
                            url: "/pages/mine/heart"
                        });
                    },
                    goshop: function() {
                        "shop" == this.from ? n.navigateBack({
                            delta: -1
                        }) : n.navigateTo({
                            url: "/pages/shop/shop"
                        });
                    },
                    leaveAlert: function() {
                        this.canSign && (this.canSign = !1);
                    }
                })
            });
            t.default = p;
        }).call(this, e("543d").default);
    },
    2767: function(n, t, e) {
        e.r(t);
        var i = e("4e7f"), o = e("fb73");
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(s);
        e("00e6");
        var a = e("f0c5"), r = Object(a.a)(o.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = r.exports;
    },
    "4e7f": function(n, t, e) {
        e.d(t, "b", function() {
            return i;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {});
        var i = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(t) {
                n.showFlag = !1;
            }, n.e1 = function(t) {
                n.showFlag = !1;
            }, n.e2 = function(t) {
                n.showactive = !1;
            }, n.e3 = function(t) {
                n.showactive = !1;
            });
        }, o = [];
    },
    bb2c: function(n, t, e) {
        (function(n) {
            var t = e("4ea4");
            e("a1ea"), t(e("66fd"));
            var i = t(e("2767"));
            wx.__webpack_require_UNI_MP_PLUGIN__ = e, n(i.default);
        }).call(this, e("543d").createPage);
    },
    f076: function(n, t, e) {},
    fb73: function(n, t, e) {
        e.r(t);
        var i = e("273c"), o = e.n(i);
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(s);
        t.default = o.a;
    }
}, [ [ "bb2c", "common/runtime", "common/vendor" ] ] ]);