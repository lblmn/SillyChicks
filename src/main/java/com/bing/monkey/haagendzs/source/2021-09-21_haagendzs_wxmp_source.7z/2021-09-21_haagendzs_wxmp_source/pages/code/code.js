(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/code/code" ], {
    "10a8": function(n, e, t) {},
    "50d9": function(n, e, t) {
        t.r(e);
        var o = t("90ac"), a = t.n(o);
        for (var c in o) "default" !== c && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e.default = a.a;
    },
    "6a61": function(n, e, t) {
        var o = t("10a8");
        t.n(o).a;
    },
    "90ac": function(n, e, t) {
        (function(n) {
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = o(t("bdeb")), c = o(t("1d54")), i = o(t("d7df")), u = {
                components: {
                    uniIcons: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(t("349f"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        qrcode: n.getStorageSync("logininfo").cardNumber,
                        points: 0,
                        showFlag: !1,
                        ruleDesc: "",
                        showCanvas: !0,
                        canvasImg: "",
                        timeObj: "",
                        dynamicCode: ""
                    };
                },
                onLoad: function() {
                    this.getRuleDesc();
                },
                onShow: function() {
                    var e = this;
                    this.make(), getApp().globalData.PointAccountResult.length > 0 ? this.points = getApp().globalData.PointAccountResult.filter(function(n) {
                        return n.pointAccountName.indexOf("积心") > -1;
                    })[0].availablePoint : c.default.point({
                        idType: "1",
                        id: n.getStorageSync("socialhubId")
                    }).then(function(t) {
                        0 == t.resultCode ? e.points = t.data.filter(function(n) {
                            return n.pointAccountName.indexOf("积心") > -1;
                        })[0].availablePoint : n.showToast({
                            title: "请求积分异常请稍后重试",
                            icon: "none"
                        });
                    });
                },
                onHide: function() {
                    console.log("关闭"), this.clearGetCode();
                },
                methods: {
                    clearGetCode: function() {
                        console.log("清除"), clearInterval(this.timeObj);
                    },
                    getdynamiccode: function() {
                        var e = this;
                        i.default.getdynamiccode({
                            idType: "2",
                            id: n.getStorageSync("unionId"),
                            flag: 1
                        }).then(function(n) {
                            console.log(n), 0 == n.resultCode && (e.dynamicCode = n.data.dynamicCode, e.showCanvas = !0, 
                            e.canvasImg = "", e.make());
                        });
                    },
                    getCode: function() {
                        var n = this;
                        n.timeObj = setInterval(function() {
                            n.getdynamiccode();
                        }, 31e3);
                    },
                    make: function() {
                        var e = this;
                        a.default.make({
                            canvasId: "qrcode",
                            componentInstance: this,
                            text: this.qrcode,
                            size: n.upx2px(336),
                            margin: 10,
                            backgroundColor: "#ffffff",
                            foregroundColor: "#000000",
                            fileType: "jpg",
                            correctLevel: a.default.defaults.correctLevel,
                            success: function(n) {
                                console.log(n), e.canvasImg = n, e.showCanvas = !1;
                            }
                        });
                    },
                    getRuleDesc: function() {
                        var n = this;
                        c.default.getRuledesc({
                            type: 1
                        }).then(function(e) {
                            n.ruleDesc = e.data[0].content;
                        });
                    },
                    gocode: function() {
                        this.showFlag = !0, this.showCanvas = !1;
                    },
                    navigateTo: function(e) {
                        n.navigateTo({
                            url: e
                        });
                    },
                    switchTab: function(e) {
                        n.switchTab({
                            url: e
                        });
                    }
                }
            };
            e.default = u;
        }).call(this, t("543d").default);
    },
    d5c0: function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(e) {
                n.showFlag = !1;
            }, n.e1 = function(e) {
                n.showFlag = !1;
            });
        }, a = [];
    },
    dc28: function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t("f4aa"), e(t("66fd")), n(e(t("e9ca")).default);
        }).call(this, t("543d").createPage);
    },
    e9ca: function(n, e, t) {
        t.r(e);
        var o = t("d5c0"), a = t("50d9");
        for (var c in a) "default" !== c && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        t("6a61");
        var i = t("f0c5"), u = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = u.exports;
    }
}, [ [ "dc28", "common/runtime", "common/vendor" ] ] ]);