(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/notice/index" ], {
    "40de": function(e, n, t) {
        var o = t("5e1f");
        t.n(o).a;
    },
    "4e61": function(e, n, t) {
        t.r(n);
        var o = t("ba57"), c = t.n(o);
        for (var a in o) "default" !== a && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        n.default = c.a;
    },
    "5e1f": function(e, n, t) {},
    ba57: function(e, n, t) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var c = o(t("1d54")), a = o(t("d7df")), i = o(t("811a")), r = o(t("9607")), u = o(t("1328")), d = {
                data: function() {
                    return {
                        ruleDesc: "",
                        showloginDialog: !1,
                        showRead: !1
                    };
                },
                onLoad: function(e) {
                    i.default.setSource(e), this.getRuleDesc();
                },
                onShow: function() {
                    "all" == e.getStorageSync("successInfo") && (this.showRead = !0);
                },
                components: {
                    loginDialog: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/loginDialog") ]).then(function() {
                            return resolve(t("a81e"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                destroyed: function() {},
                onHide: function() {
                    e.removeStorageSync("successInfo");
                },
                methods: {
                    gotocard: function() {
                        0 == Object.keys(e.getStorageSync("logininfo")).length ? (e.setStorageSync("noticeType", "card"), 
                        this.showloginDialog = !0) : this.gotoCard();
                    },
                    gotoCard: function() {
                        this.getActivityRecord(), e.navigateTo({
                            url: "/pages/mine/mycard"
                        });
                    },
                    getRuleDesc: function() {
                        var e = this;
                        c.default.getRuledesc({
                            type: 5
                        }).then(function(n) {
                            console.log(n), n.data.length <= 0 ? e.ruleDesc = "暂无公告信息" : e.ruleDesc = n.data[0].content;
                        });
                    },
                    backtoMine: function() {
                        0 == Object.keys(e.getStorageSync("logininfo")).length ? (e.setStorageSync("noticeType", "back"), 
                        this.showloginDialog = !0) : this.shareRecord();
                    },
                    readrule: function() {
                        this.showRead = !1, e.removeStorageSync("successInfo"), "card" == e.getStorageSync("noticeType") ? (e.removeStorageSync("noticeType"), 
                        this.gotoCard()) : (e.removeStorageSync("noticeType"), this.shareRecord());
                    },
                    getActivityRecord: function() {
                        r.default.into({
                            aid: "release" == u.default.envVersion ? "29" : "36",
                            unionId: e.getStorageSync("unionId"),
                            openid: e.getStorageSync("openId"),
                            source: e.getStorageSync("smsSource") ? e.getStorageSync("smsSource") : "",
                            channel: e.getStorageSync("channelLabel") ? e.getStorageSync("channelLabel") : ""
                        }, !1).then(function(e) {
                            console.log(e);
                        });
                    },
                    shareRecord: function() {
                        a.default.shareRecord({
                            aid: "",
                            unionId: e.getStorageSync("unionId"),
                            openid: e.getStorageSync("openId"),
                            path: "pages/notice/index",
                            button: "pages/notice/index",
                            invitedOpenid: "",
                            type: "2"
                        }).then(function(e) {
                            console.log(e);
                        }).catch(function(e) {
                            console.log(e);
                        }), this.getActivityRecord();
                        var n = getCurrentPages();
                        console.log(n), n.length - 1 <= 0 ? e.switchTab({
                            url: "../index/index"
                        }) : e.navigateBack({});
                    }
                }
            };
            n.default = d;
        }).call(this, t("543d").default);
    },
    d775: function(e, n, t) {
        t.r(n);
        var o = t("edbf"), c = t("4e61");
        for (var a in c) "default" !== a && function(e) {
            t.d(n, e, function() {
                return c[e];
            });
        }(a);
        t("40de");
        var i = t("f0c5"), r = Object(i.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = r.exports;
    },
    e8b3: function(e, n, t) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            t("f4aa"), n(t("66fd")), e(n(t("d775")).default);
        }).call(this, t("543d").createPage);
    },
    edbf: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {});
        var o = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, c = [];
    }
}, [ [ "e8b3", "common/runtime", "common/vendor" ] ] ]);