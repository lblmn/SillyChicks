// moonActive/rule/index.js
Page({data: {}})