require("../../@babel/runtime/helpers/Arrayincludes"), (global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/mine/exchange" ], {
    5910: function(e, o, n) {
        n.r(o);
        var t = n("9479"), c = n.n(t);
        for (var i in t) "default" !== i && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(i);
        o.default = c.a;
    },
    "609f": function(e, o, n) {
        n.d(o, "b", function() {
            return t;
        }), n.d(o, "c", function() {
            return c;
        }), n.d(o, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    9479: function(e, o, n) {
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var t = u(n("727b")), c = u(n("500b")), i = u(n("c1f6")), a = u(n("ec2e")), d = u(n("f0fd"));
            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function r(e, o) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(e);
                    o && (t = t.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), n.push.apply(n, t);
                }
                return n;
            }
            function s(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var n = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? r(Object(n), !0).forEach(function(o) {
                        l(e, o, n[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(n, o));
                    });
                }
                return e;
            }
            function l(e, o, n) {
                return o in e ? Object.defineProperty(e, o, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[o] = n, e;
            }
            var f = getApp(), p = {
                components: {
                    uniIcons: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/uni-icons/uni-icons") ]).then(function() {
                            return resolve(n("fafe"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        qrcode: "",
                        obj: {},
                        couponRuleId: "",
                        effectEnd: "",
                        getcity: "",
                        isCanvasImg: "",
                        showbtn: !1,
                        typeFrom: !1,
                        isshowTl: !1
                    };
                },
                onLoad: function(e) {
                    console.log(e);
                    var o = JSON.parse(decodeURIComponent(e.obj));
                    console.log(o), this.obj = s(s({}, o), {}, {
                        ruleDesc: o.ruleDesc.replace(/\n/g, "<br>")
                    }), this.qrcode = e.couponCode, this.couponRuleId = e.couponRuleId, this.couponCode = e.couponCode, 
                    this.showbtn = e.showbtn, this.typeFrom = e.typeFrom;
                    this.isshowTl = [ "16YoGt8H00020200", "16YoGrrk0001ff00", "16YoyYkc00003f00", "16YoyYqQ00005503", "16nLwZJZ00005e03", "16nLwZNe00004f00", "16nNBFBe00004f00" ].indexOf(o.couponRuleCode) > -1 ? "yes" : "no", 
                    this.make(), e.effectEnd && (this.effectEnd = this.$util.dateFormat("YYYY年mm月dd日", new Date(e.effectEnd.replace(/-/g, "/")))), 
                    this.getcity = a.default.filter(function(e) {
                        return e.code == o.cityCode;
                    }).length > 0 ? a.default.filter(function(e) {
                        return e.code == o.cityCode;
                    })[0].text : "";
                },
                onShow: function() {
                    this.isCanvasImg || this.make(), this.getPoints();
                },
                onHide: function() {
                    f.globalData.istransfer = !1;
                },
                methods: {
                    cardTl: function() {
                        var o, n = "";
                        if (o = "release" == d.default.envVersion ? "https://hd.rydeen.com.cn/coupon-booking/booking" : "https://hd-uat.rydeen.com.cn/coupon-booking/booking", 
                        this.obj.couponCode) n = o + "?couponNo=" + this.obj.couponCode, e.navigateTo({
                            url: "/pages/webView/indexN?url=" + encodeURIComponent(n)
                        }); else {
                            if (!this.qrcode) return !1;
                            n = o + "?couponNo=" + this.qrcode, e.navigateTo({
                                url: "/pages/webView/indexN?url=" + encodeURIComponent(n)
                            });
                        }
                    },
                    make: function() {
                        var o = this;
                        t.default.make({
                            canvasId: "qrcode",
                            componentInstance: this,
                            text: this.qrcode,
                            size: e.upx2px(292),
                            margin: 10,
                            backgroundColor: "#ffffff",
                            foregroundColor: "#000000",
                            fileType: "jpg",
                            correctLevel: t.default.defaults.correctLevel,
                            success: function(e) {
                                o.isCanvasImg = e;
                            }
                        });
                    },
                    transfer: function() {
                        e.showLoading({
                            mask: !0,
                            title: "加载中..."
                        });
                        var o = this.obj.couponCode ? this.obj.couponCode : this.qrcode, n = this.obj.couponRuleCode;
                        "mooncard" == this.typeFrom && (o = this.couponCode, n = this.couponRuleId), "16HYjDy800006e00" == this.obj.couponBagCode ? e.redirectTo({
                            url: "/pages/calendarActivity/turnIndex?couponCode=" + this.couponCode,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XQs8Ei00011c00" == this.obj.couponBagCode || "16XQs7SQ00001600" == this.obj.couponBagCode || "16XRa7Qr00003800" == this.obj.couponBagCode ? e.redirectTo({
                            url: "/pureFeeling/hdShare/turnIndex?couponCode=" + o,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : [ "16HaQ1eW0000ad00", "16HaQ1eu0000ae00", "16HaQ1fu0000af00", "16Hb25MK00008400", "16Hb25Mg00008500", "16Hb25My00008600" ].indexOf(this.obj.couponBagCode) >= 0 ? e.redirectTo({
                            url: "/pages/makeUpForever/turnIndex?couponCode=" + this.couponCode,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : [ "16XG7Fw20000a000", "16XG7Fub00009e00", "16XG23EQ00004100", "16XG23EA00004000", "16XG7Fw20000a000", "16XG7Fub00009e00", "16HZcEPN00009d00", "16HZsSWt00007800", "16X9Dn7D00009c00", "16HYYpXw00007b00", "16XG23Ch00003e00" ].indexOf(this.obj.couponBagCode) >= 0 ? "16X9Dn7D00009c00" == this.obj.couponBagCode || "16HYYpXw00007b00" == this.obj.couponBagCode || "16XG23Ch00003e00" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + o + "&activityType=newYearType",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XG7Fub00009e00" == this.obj.couponBagCode || "16XG23EA00004000" == this.obj.couponBagCode || "16XG7Fub00009e00" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + o + "&activityType=loveGolden",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16XG7Fw20000a000" == this.obj.couponBagCode || "16XG23EQ00004100" == this.obj.couponBagCode || "16XG7Fw20000a000" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + o + "&activityType=lovePink",
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : e.navigateTo({
                            url: "/pages/CNYactivity/turnIndex?couponCode=" + o,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : [ "16XHhMdG00009200", "16XHhMjT0000ad00", "16XHsckE0000b800", "16XHscoa0000d400", "16XHscs70000d700", "16XHseM60000da00", "16XHseQV0000dd00", "16XQfj9c0000dc00", "16XQfjBL0000df00", "16XQfjCv0000e200", "16XQgbRg0000e500", "16XQgbV40000e800", "16XQgbkL00010400", "16XQgbqV0000d500", "16XQs74E00000a00", "16XRZbF700002900", "16XRZbki00002f00", "16XQs7tW00011000" ].indexOf(n) >= 0 ? e.navigateTo({
                            url: "/pureFeeling/hdShare/turnIndex?couponCode=" + o,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : [ "16HZcE2q00008e00", "16HZcE4H00009100", "16HZcE5h00009400", "16HZcE6R00009700", "16HZcE7x00009a00", "16HaE49q00007900", "16HaE4Pe00007500", "16HaE4Uw00007f00", "16HaE4Uw00007f00", "16HaE4md00007800", "16HaE51V00007b00", "16Hb2EZz00008800", "16Hb2Eey00008700", "16HQ4edg00001d00", "16HQ4ebn00001a00", "16HaE1Vu0000a100", "16Hb2EWZ00008500" ].indexOf(n) >= 0 ? e.navigateTo({
                            url: "/pureFeeling/cameraHome/turnIndex?couponCode=" + o,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : "16X9DnM500002500" == this.obj.couponBagCode || "16XG7cAN0000a200" == this.obj.couponBagCode ? e.navigateTo({
                            url: "/pureFeeling/cameraHome/turnIndex?type=winterGet&couponCode=" + o + "&couponRuleCode=" + n,
                            complete: function() {
                                e.hideLoading();
                            }
                        }) : (console.log(n), n = n.indexOf("_") > 0 ? n.split("_")[0] : n, i.default.findGet({
                            couponRuleId: n,
                            ops: {
                                couponRuleId: "equal"
                            }
                        }).then(function(t) {
                            if (console.log(t), 0 == t.code) {
                                var c = t.data.forwardViewUrl;
                                c.includes("?") ? c += "&couponRuleCode=" + n + "&couponCode=" + o + "&detailinfo=" + encodeURIComponent(JSON.stringify(t.data)) : c += "?couponRuleCode=" + n + "&couponCode=" + o + "&detailinfo=" + encodeURIComponent(JSON.stringify(t.data)), 
                                e.navigateTo({
                                    url: c,
                                    complete: function() {
                                        e.hideLoading();
                                    }
                                });
                            } else e.navigateTo({
                                url: "/unifyExchange/home/turnIndex?couponCode=" + o,
                                complete: function() {
                                    e.hideLoading();
                                }
                            });
                        }).catch(function() {
                            e.navigateTo({
                                url: "/thanksgiving/share/turnIndex?couponCode=" + o,
                                complete: function() {
                                    e.hideLoading();
                                }
                            });
                        }));
                    },
                    findWeixinCard: function() {
                        e.openCard({
                            cardList: [ {
                                cardId: this.obj.wxCardId,
                                code: this.couponCode
                            } ],
                            success: function(e) {}
                        });
                    },
                    getPoints: function() {
                        i.default.point({
                            idType: "1",
                            id: e.getStorageSync("socialhubId")
                        }).then(function(e) {
                            0 == e.resultCode && (getApp().globalData.PointAccount = e.data);
                        });
                    },
                    changeCard: function() {
                        var o = encodeURIComponent("https://www.gmec.top/hgdz_dwz/ticketExchange.html");
                        e.navigateTo({
                            url: "../webView/indexN?url=" + o
                        });
                    },
                    addToWeixinCard: function() {
                        var o = this;
                        c.default.convertWxCardId({
                            couponRuleId: this.couponRuleId
                        }).then(function(n) {
                            c.default.getJsCardSignature({
                                code: o.qrcode,
                                cardId: n.data.wxCardId,
                                openId: e.getStorageSync("openId")
                            }).then(function(e) {
                                console.log("调getjscard签名", e);
                                var o = e.data, n = o.cardId, t = o.cardSign, c = o.openId, i = o.nonceStr, a = o.timestamp, d = {
                                    code: o.code,
                                    cardId: n,
                                    signature: t,
                                    openid: c,
                                    nonce_str: i,
                                    timestamp: a,
                                    outer_str: "miniProgram"
                                };
                                console.log(JSON.stringify(d)), wx.addCard({
                                    cardList: [ {
                                        cardId: n,
                                        cardExt: JSON.stringify(d)
                                    } ],
                                    success: function(e) {
                                        console.log(e);
                                    },
                                    fail: function(e) {
                                        console.log(e);
                                    }
                                });
                            });
                        });
                    }
                }
            };
            o.default = p;
        }).call(this, n("543d").default);
    },
    b6f0: function(e, o, n) {
        n.r(o);
        var t = n("609f"), c = n("5910");
        for (var i in c) "default" !== i && function(e) {
            n.d(o, e, function() {
                return c[e];
            });
        }(i);
        n("c5be");
        var a = n("f0c5"), d = Object(a.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        o.default = d.exports;
    },
    c5be: function(e, o, n) {
        var t = n("ea1e");
        n.n(t).a;
    },
    ea1e: function(e, o, n) {},
    fd06: function(e, o, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("c0e2"), o(n("66fd")), e(o(n("b6f0")).default);
        }).call(this, n("543d").createPage);
    }
}, [ [ "fd06", "common/runtime", "common/vendor" ] ] ]);