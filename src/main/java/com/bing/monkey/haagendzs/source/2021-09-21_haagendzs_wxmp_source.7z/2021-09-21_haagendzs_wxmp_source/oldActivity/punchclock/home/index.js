// oldActivity/punchclock/home/index.js
Page({data: {}})