Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.WHITE = exports.RED = exports.ORANGE = exports.GREEN = exports.GRAY_DARK = exports.GRAY = exports.BLUE = void 0;

exports.RED = "#ee0a24";

exports.BLUE = "#1989fa";

exports.WHITE = "#fff";

exports.GREEN = "#07c160";

exports.ORANGE = "#ff976a";

exports.GRAY = "#323233";

exports.GRAY_DARK = "#969799";