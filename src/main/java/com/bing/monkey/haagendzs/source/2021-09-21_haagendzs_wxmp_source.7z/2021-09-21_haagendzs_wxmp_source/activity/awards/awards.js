// activity/awards/awards.js
Page({data: {}})