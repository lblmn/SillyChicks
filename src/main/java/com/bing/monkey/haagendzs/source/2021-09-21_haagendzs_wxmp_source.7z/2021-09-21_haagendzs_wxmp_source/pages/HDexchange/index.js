(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/HDexchange/index" ], {
    2756: function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return a;
        }), o.d(e, "a", function() {});
        var t = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(e) {
                n.showRule = !1;
            }, n.e1 = function(e) {
                n.showRule = !1;
            });
        }, a = [];
    },
    "2a06": function(n, e, o) {},
    "7d79": function(n, e, o) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function a(n, e, o, t, a, i, r) {
                try {
                    var c = n[i](r), s = c.value;
                } catch (n) {
                    return void o(n);
                }
                c.done ? e(s) : Promise.resolve(s).then(t, a);
            }
            function i(n) {
                return function() {
                    var e = this, o = arguments;
                    return new Promise(function(t, i) {
                        function r(n) {
                            a(s, t, i, r, c, "next", n);
                        }
                        function c(n) {
                            a(s, t, i, r, c, "throw", n);
                        }
                        var s = n.apply(e, o);
                        r(void 0);
                    });
                };
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = t(o("a34a")), c = t(o("9607")), s = t(o("a5d3")), d = t(o("1328")), u = t(o("811a")), l = t(o("57d0")), f = t(o("d7df")), g = {
                name: "breakfast",
                components: {
                    loginDialog: function() {
                        Promise.all([ o.e("common/vendor"), o.e("components/loginDialog") ]).then(function() {
                            return resolve(o("a81e"));
                        }.bind(null, o)).catch(o.oe);
                    },
                    hxNavbar: function() {
                        o.e("components/hx-navbar/hx-navbar").then(function() {
                            return resolve(o("a561"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                data: function() {
                    return {
                        imgUrl: d.default.assetsRoot + "/oss/wxapp/20210127/static/",
                        showloginDialog: !1,
                        showRule: !1,
                        showError: !1,
                        errorInfo: "",
                        ruleinfo: "",
                        showRead: !1,
                        config: {
                            statusBarFontColor: "#ffffff",
                            barPlaceholder: !1,
                            backgroundColor: [ 0, "#fff" ]
                        },
                        isSuccess: !1,
                        isShowCardBtn: !1,
                        isCloseCardBtn: !1,
                        isHeightScreen: !1
                    };
                },
                onLoad: function(e) {
                    var o = this;
                    n.showLoading({
                        mask: !0,
                        title: "图片加载中..."
                    }), e.aid ? n.setStorageSync("hdAid", e.aid) : n.removeStorageSync("hdAid"), this.aid = e.aid ? e.aid : n.getStorageSync("hdAid") ? n.getStorageSync("hdAid") : "31", 
                    u.default.setSource(e), u.default.isHeightPhone().then(function(n) {
                        o.isHeightScreen = n;
                    }).catch(function(n) {
                        o.isHeightScreen = n;
                    });
                },
                onShow: function() {
                    "all" == n.getStorageSync("successInfo") && (this.showRead = !0), n.getStorageSync("logininfo") && n.getStorageSync("unionId") && n.getStorageSync("smsSource") && this.getRecord();
                },
                onHide: function() {
                    console.log("关闭"), this.showError = !1;
                },
                methods: {
                    imageLoad: function(e) {
                        console.log("图片加载完成"), n.hideLoading();
                    },
                    getActivityRecord: function() {
                        c.default.into({
                            aid: this.aid,
                            unionId: n.getStorageSync("unionId"),
                            openid: n.getStorageSync("openId"),
                            source: n.getStorageSync("smsSource") ? n.getStorageSync("smsSource") : "",
                            channel: n.getStorageSync("channelLabel") ? n.getStorageSync("channelLabel") : ""
                        }, !1).then(function(n) {
                            console.log(n);
                        });
                    },
                    getRecord: function() {
                        l.default.saveLoginRecord({
                            unionId: n.getStorageSync("unionId"),
                            openId: n.getStorageSync("openId"),
                            source: n.getStorageSync("smsSource")
                        }, !1).then(function(n) {
                            console.log(n);
                        });
                    },
                    getRule: function() {
                        var e = this;
                        return i(r.default.mark(function o() {
                            return r.default.wrap(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    c.default.activityGet(e.aid, {
                                        unionId: n.getStorageSync("unionId")
                                    }).then(function(n) {
                                        console.log(n), 0 == n.code ? (e.ruleinfo = n.data.activity.ruleDesc.replace(/\n/g, "<br/>"), 
                                        e.showRule = !0) : (e.errorInfo = "当前在线人数太多<br/>请稍后重试", e.showError = !0);
                                    }).catch(function() {
                                        e.errorInfo = "当前在线人数太多<br/>请稍后重试", e.showError = !0;
                                    });

                                  case 1:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    readrule: function() {
                        this.showRead = !1, this.exchangeCard();
                    },
                    exchangeCard: function() {
                        var e = this;
                        Object.keys(n.getStorageSync("logininfo")).length > 0 ? (n.showLoading({
                            mask: !0,
                            title: "正在兑换中..."
                        }), this.getActivityRecord(), n.removeStorageSync("successInfo"), s.default.getExchange({
                            activityId: this.aid ? this.aid : "31",
                            unionId: n.getStorageSync("unionId")
                        }).then(function(o) {
                            console.log(o), e.isSuccess = !1, e.isShowCardBtn = !1, e.isCloseCardBtn = !1, "414" == o.code ? (e.isShowCardBtn = !0, 
                            e.errorInfo = o.msg.replace(/\n/g, "<br/>")) : "0" == o.code ? (e.isSuccess = !0, 
                            e.isShowCardBtn = !0, e.errorInfo = o.msg.replace(/\n/g, "<br/>")) : "410" == o.code || "413" == o.code ? e.errorInfo = o.msg.replace(/\n/g, "<br/>") : (e.isCloseCardBtn = !0, 
                            e.errorInfo = "当前在线人数太多<br/>请稍后重试"), e.showError = !0, n.hideLoading();
                        }).catch(function(o) {
                            console.log(o), e.isSuccess = !1, e.isShowCardBtn = !1, e.isCloseCardBtn = !0, e.errorInfo = "当前在线人数太多<br/>请稍后重试", 
                            e.showError = !0, n.hideLoading();
                        })) : (n.showLoading({
                            mask: !0,
                            title: "加载中..."
                        }), this.showloginDialog = !0);
                    },
                    gotoCard: function() {
                        n.showLoading({
                            title: "跳转中...",
                            mask: !0
                        }), this.isShowCardBtn ? n.redirectTo({
                            url: "/pages/mine/mycard",
                            complete: function() {
                                n.hideLoading();
                            }
                        }) : this.isCloseCardBtn ? (this.showError = !1, n.hideLoading()) : n.navigateTo({
                            url: "/pages/shop/shop",
                            complete: function() {
                                n.hideLoading();
                            }
                        });
                    }
                },
                onShareAppMessage: function(e) {
                    var o = "".concat(d.default.assetsRoot, "/oss/wxapp/20210127/static/hdShare/share.png");
                    return f.default.shareRecord({
                        aid: "",
                        unionId: n.getStorageSync("unionId"),
                        openid: n.getStorageSync("openId"),
                        path: "pages/HDexchange/index",
                        button: "",
                        invitedOpenid: "",
                        type: "1"
                    }).then(function(n) {
                        console.log(n);
                    }).catch(function(n) {
                        console.log(n);
                    }), {
                        title: "会员新品福利，赏味券开抢",
                        path: "pages/HDexchange/index?aid=".concat(this.aid),
                        imageUrl: o
                    };
                }
            };
            e.default = g;
        }).call(this, o("543d").default);
    },
    "9b91": function(n, e, o) {
        o.r(e);
        var t = o("7d79"), a = o.n(t);
        for (var i in t) "default" !== i && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(i);
        e.default = a.a;
    },
    a836: function(n, e, o) {
        o.r(e);
        var t = o("2756"), a = o("9b91");
        for (var i in a) "default" !== i && function(n) {
            o.d(e, n, function() {
                return a[n];
            });
        }(i);
        o("dd25");
        var r = o("f0c5"), c = Object(r.a)(a.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = c.exports;
    },
    dd25: function(n, e, o) {
        var t = o("2a06");
        o.n(t).a;
    },
    f896: function(n, e, o) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("f4aa"), e(o("66fd")), n(e(o("a836")).default);
        }).call(this, o("543d").createPage);
    }
}, [ [ "f896", "common/runtime", "common/vendor" ] ] ]);