// moonActive/ranking/index.js
Page({data: {}})