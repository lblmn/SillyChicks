// ebuyCard/enterprise/index.js
Page({data: {}})