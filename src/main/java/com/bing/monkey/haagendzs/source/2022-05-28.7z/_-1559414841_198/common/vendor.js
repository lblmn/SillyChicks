var t = require("../@babel/runtime/helpers/interopRequireDefault");

require("../@babel/runtime/helpers/Arrayincludes"), require("../@babel/runtime/helpers/Objectentries");

var n = t(require("../@babel/runtime/helpers/typeof"));

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/vendor" ], {
    "0afe": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.System = void 0;
        var r = n("9ab4"), o = n("c6ce"), i = n("6916"), a = function() {
            function e() {
                this.name = e.id;
            }
            return e.prototype.setupOnce = function() {
                (0, o.addGlobalEventProcessor)(function(t) {
                    if ((0, o.getCurrentHub)().getIntegration(e)) try {
                        var n = i.sdk.getSystemInfoSync(), a = n.SDKVersion, u = void 0 === a ? "0.0.0" : a, c = n.batteryLevel, s = n.currentBattery, f = n.battery, l = n.brand, p = n.language, d = n.model, h = n.pixelRatio, v = n.platform, g = n.screenHeight, y = n.screenWidth, b = n.statusBarHeight, m = n.system, _ = n.version, w = n.windowHeight, x = n.windowWidth, O = n.wifiSignal, S = n.app, E = n.appName, k = n.storage, P = n.fontSizeSetting, j = (0, 
                        r.__read)(m.split(" "), 2), A = j[0], C = j[1];
                        return (0, r.__assign)((0, r.__assign)({}, t), {
                            contexts: (0, r.__assign)((0, r.__assign)({}, t.contexts), {
                                device: {
                                    brand: l,
                                    battery_level: c || s || f,
                                    model: d,
                                    screen_dpi: h
                                },
                                os: {
                                    name: A || m,
                                    version: C || m
                                },
                                extra: {
                                    SDKVersion: u,
                                    language: p,
                                    platform: v,
                                    screenHeight: g,
                                    screenWidth: y,
                                    statusBarHeight: b,
                                    version: _,
                                    windowHeight: w,
                                    windowWidth: x,
                                    wifiSignal: O,
                                    fontSizeSetting: P,
                                    storage: k,
                                    app: S || E || i.appName
                                }
                            })
                        });
                    } catch (e) {
                        console.warn("sentry-miniapp get system info fail: " + e);
                    }
                    return t;
                });
            }, e.id = "System", e;
        }();
        t.System = a;
    },
    "0b33": function(e, t, r) {
        function o(e) {
            return null != e;
        }
        function i(e) {
            return /^\d+(\.\d+)?$/.test(e);
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.isDef = o, t.isObj = function(e) {
            var t = (0, n.default)(e);
            return null !== e && ("object" === t || "function" === t);
        }, t.isNumber = i, t.range = function(e, t, n) {
            return Math.min(Math.max(e, t), n);
        }, t.nextTick = function(e) {
            setTimeout(function() {
                e();
            }, 1e3 / 30);
        }, t.getSystemInfoSync = function() {
            return null == a && (a = wx.getSystemInfoSync()), a;
        }, t.addUnit = function(e) {
            if (o(e)) return i(e = String(e)) ? "".concat(e, "px") : e;
        };
        var a = null;
    },
    "0b67": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(n("c1f6")), o = i(n("234f"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var a = {
                getPoint: function(t) {
                    return new Promise(function(n, o) {
                        r.default.point({
                            idType: "1",
                            id: e.getStorageSync("socialhubId")
                        }).then(function(e) {
                            if (0 == e.resultCode) {
                                var r = e.data.filter(function(e) {
                                    return e.pointAccountName.indexOf("积心") > -1;
                                })[0];
                                t.commit("getPoint", r), n(e);
                            } else t.commit("getPoint", "--"), o(e);
                        }).catch(function() {
                            t.commit("getPoint", "--");
                        });
                    });
                },
                isHeightPhone: function(e) {
                    o.default.isHeightPhone().then(function(t) {
                        e.commit("isHeightPhone", t);
                    }).catch(function(t) {
                        e.commit("isHeightPhone", t);
                    });
                },
                existsSignIn: function(t, n) {
                    var o = e.getStorageSync("unionId");
                    r.default.existsSignIn(o).then(function(e) {
                        console.log(e), 0 == e.code ? t.commit("existsSignIn", e.data) : t.commit("existsSignIn", !1);
                    }).catch(function() {
                        t.commit("existsSignIn", !1);
                    });
                }
            };
            t.default = a;
        }).call(this, n("543d").default);
    },
    "0ca3": function(e, t, r) {
        var o = r("a34a");
        function i(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function a(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? i(Object(n), !0).forEach(function(t) {
                    h(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        function u(e) {
            return function(e) {
                if (Array.isArray(e)) return l(e);
            }(e) || function(e) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e);
            }(e) || f(e) || function() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }();
        }
        function c(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        function s(e, t) {
            return function(e) {
                if (Array.isArray(e)) return e;
            }(e) || function(e, t) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                    var n = [], r = !0, o = !1, i = void 0;
                    try {
                        for (var a, u = e[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), 
                        !t || n.length !== t); r = !0) ;
                    } catch (e) {
                        o = !0, i = e;
                    } finally {
                        try {
                            r || null == u.return || u.return();
                        } finally {
                            if (o) throw i;
                        }
                    }
                    return n;
                }
            }(e, t) || f(e, t) || function() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }();
        }
        function f(e, t) {
            if (e) {
                if ("string" == typeof e) return l(e, t);
                var n = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, t) : void 0;
            }
        }
        function l(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r;
        }
        function p(e, t, n, r, o, i, a) {
            try {
                var u = e[i](a), c = u.value;
            } catch (e) {
                return void n(e);
            }
            u.done ? t(c) : Promise.resolve(c).then(r, o);
        }
        function d(e) {
            return function() {
                var t = this, n = arguments;
                return new Promise(function(r, o) {
                    var i = e.apply(t, n);
                    function a(e) {
                        p(i, r, o, a, u, "next", e);
                    }
                    function u(e) {
                        p(i, r, o, a, u, "throw", e);
                    }
                    a(void 0);
                });
            };
        }
        function h(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        var v, g = (v = r("2869")) && "object" == (0, n.default)(v) && "default" in v ? v.default : v;
        Object.entries || (Object.entries = function(e) {
            for (var t = Object.keys(e), n = t.length, r = new Array(n); n; ) r[n -= 1] = [ t[n], e[t[n]] ];
            return r;
        });
        var y = {
            prefix: "_hxt_",
            sdkVersion: "1.8.1",
            userInfoWhiteList: [ "wx_id", "unionid", "cust_id", "alipay_id", "mail", "phone" ],
            utmWhiteList: [ "utm_campaign", "utm_source", "utm_medium", "utm_term", "utm_content" ],
            isAppEnable: !!g.module.basic,
            isPlayerEnable: !!g.module.player,
            appUrl: g.module.basic ? g.module.basic.apiUrl : "",
            playerUrl: g.module.player ? g.module.player.apiUrl : "",
            shortUrlApi: g.module.basic && g.module.basic.shortUrlApi || "https://t.hypers.com.cn/goa",
            appKey: g.module.basic && g.module.basic.appKey,
            playerKey: g.module.player && g.module.player.appKey,
            appName: g.appName,
            appVersion: g.appVersion,
            appCode: g.appCode,
            locationAccessible: ("locationAccessable 选项已被弃用，在后续版本中可能被移除。请使用 locationAccessible 选项代替。", 
            !("locationAccessable" in g) || console.warn("[hxt.config.js] ".concat("locationAccessable 选项已被弃用，在后续版本中可能被移除。请使用 locationAccessible 选项代替。")), 
            "locationAccessible" in g ? g.locationAccessible : g.locationAccessable),
            usingPlugins: g.usingPlugins,
            requireOpenid: g.requireOpenid,
            autoTrackEventsEnabled: g.autoTrackEvents,
            autoTrackEventsList: [ "tap", "longpress", "longtap" ]
        };
        console.log("[hxt] 配置"), ("table" in console ? console.table : console.log)({
            locationAccessible: y.locationAccessible,
            usingPlugins: y.usingPlugins,
            requireOpenid: y.requireOpenid,
            autoTrackEvents: y.autoTrackEventsEnabled
        });
        var b = y.prefix;
        function m(e) {
            return wx.getStorageSync(b + e);
        }
        function _(e, t) {
            return wx.setStorageSync(b + e, t);
        }
        function w() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 ? arguments[1] : void 0;
            t.forEach(function(t) {
                e[t] || 0 === e[t] || console.error("缺少必填字段：".concat(t, "，请检查是否传入。"));
            });
        }
        var x = {
            client_data: "初始化",
            activity: "页面活动",
            act: "自定义事件",
            start: "播放开始",
            heart_beat: "播放中",
            end: "播放停止"
        };
        function O(e, t) {
            var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "GET", o = arguments.length > 3 ? arguments[3] : void 0;
            console.info("[hxt] 数据上报：".concat(x[t.type]), t), wx.request({
                url: e,
                method: r,
                data: function(e) {
                    var t = {}, r = null;
                    return Object.keys(e).forEach(function(o) {
                        var i = e[o];
                        !function(e) {
                            if (!e) return !1;
                            if ("object" != (0, n.default)(e)) return !1;
                            if (!Array.isArray(e)) return !0;
                            for (var t = 0; t < e.length; t++) if (e[t] && "object" == (0, n.default)(e[t])) return !0;
                            return !1;
                        }(i) ? t[o] = i : (t[o] = S(JSON.stringify(i)), r || (r = {}), r[o] = "json");
                    }), r && (t._typed = S(JSON.stringify(r))), t;
                }(t),
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function(e) {
                    o && o(e);
                }
            });
        }
        function S(e) {
            for (var t, n, r, o, i, a, u, c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=", s = "", f = 0, l = function(e) {
                for (var t = e.replace(/\r\n/g, "n"), n = "", r = 0; r < t.length; r++) {
                    var o = t.charCodeAt(r);
                    o < 128 ? n += String.fromCharCode(o) : o > 127 && o < 2048 ? (n += String.fromCharCode(o >> 6 | 192), 
                    n += String.fromCharCode(63 & o | 128)) : (n += String.fromCharCode(o >> 12 | 224), 
                    n += String.fromCharCode(o >> 6 & 63 | 128), n += String.fromCharCode(63 & o | 128));
                }
                return n;
            }(e); f < l.length; ) o = (t = l.charCodeAt(f++)) >> 2, i = (3 & t) << 4 | (n = l.charCodeAt(f++)) >> 4, 
            a = (15 & n) << 2 | (r = l.charCodeAt(f++)) >> 6, u = 63 & r, isNaN(n) ? a = u = 64 : isNaN(r) && (u = 64), 
            s = s + c.charAt(o) + c.charAt(i) + c.charAt(a) + c.charAt(u);
            return s;
        }
        function E(e) {
            var t = {};
            return e && "object" == (0, n.default)(e) ? (Object.keys(e).forEach(function(n) {
                null !== e[n] && (t["p_".concat(n)] = e[n]);
            }), t) : {};
        }
        function k() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "_", r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "";
            return "object" != (0, n.default)(e) ? r ? h({}, r, e) : e : Object.keys(e).reduce(function(o, i) {
                return "object" == (0, n.default)(e[i]) ? Object.assign(o, k(e[i], t, "".concat(r).concat(t).concat(i))) : o["".concat(r).concat(t).concat(i)] = e[i], 
                o;
            }, {});
        }
        function P() {
            var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = {};
            return (e = t) && "object" == (0, n.default)(e) && 0 === Object.keys(e).length || Object.keys(t).forEach(function(e) {
                "weixinadinfo" === e && (r.query_aid = t[e].split(".")[0]), -1 !== y.utmWhiteList.indexOf(e) ? r[e] = t[e] : r["query_".concat(e)] = t[e];
            }), r;
        }
        var j = {};
        function A(e) {
            return C.apply(this, arguments);
        }
        function C() {
            return (C = d(o.mark(function e(t) {
                return o.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.abrupt("return", j[t] ? j[t] : new Promise(function(e, n) {
                            wx.request({
                                url: "".concat(y.shortUrlApi, "/").concat(t),
                                success: function(t) {
                                    t.data && 0 === t.data.c ? e(t.data.s) : n(new Error("decodeShortUrl failed: ".concat(t.data.e)));
                                },
                                fail: n
                            });
                        }));

                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))).apply(this, arguments);
        }
        function T(e) {
            var t = {}, n = s(e.split("?"), 2)[1];
            return n ? (n.split("&").forEach(function(e) {
                var n = s(e.split("="), 2), r = n[0], o = n[1];
                0 === r.indexOf("utm_") && (t[r] = decodeURIComponent(o));
            }), t) : t;
        }
        function D() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = {};
            return Object.entries(e).forEach(function(e) {
                var n = s(e, 2), r = n[0], o = n[1];
                y.userInfoWhiteList.includes(r) ? t[r] = o : t["p_".concat(r)] = o;
            }), t;
        }
        var M = {
            clientData: {
                _z: "m",
                channel_id: "default",
                app_name: y.appName,
                app_code: y.appCode,
                app_version: y.appVersion,
                sv: y.sdkVersion,
                device_id: function() {
                    var e = m("uuid");
                    return e || _("uuid", e = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                        var t = 16 * Math.random() | 0;
                        return ("x" === e ? t : 3 & t | 8).toString(16);
                    })), e;
                }()
            },
            userData: {},
            wxData: {},
            pageData: {},
            refData: {},
            initAppData: function(e, t) {
                var n = this;
                return d(o.mark(function r() {
                    return o.wrap(function(r) {
                        for (;;) switch (r.prev = r.next) {
                          case 0:
                            return r.next = 2, n.initRefData(e);

                          case 2:
                            n.initUserData(), n.initWxData(), n.initClientData(t);

                          case 5:
                          case "end":
                            return r.stop();
                        }
                    }, r);
                }))();
            },
            initRefData: function(e) {
                var t = this;
                return d(o.mark(function r() {
                    var i, a, u, c, s, f, l, p;
                    return o.wrap(function(r) {
                        for (;;) switch (r.prev = r.next) {
                          case 0:
                            if (i = e.path, a = e.query, u = e.scene, c = e.shareTicket, s = e.referrerInfo, 
                            f = {}, l = a || {}, Object.assign(f, P(l)), !l.utm) {
                                r.next = 6;
                                break;
                            }
                            return r.next = 4, A(l.utm);

                          case 4:
                            p = r.sent, Object.assign(f, P(T(p)));

                          case 6:
                            t.refData = Object.assign({
                                path: i,
                                scene: u
                            }, f, c && {
                                shareticket: c
                            }, s && "object" == (0, n.default)(s) && {
                                ref_info: JSON.stringify(s)
                            }, s && s.appId && {
                                ref_appid: s.appId
                            });

                          case 7:
                          case "end":
                            return r.stop();
                        }
                    }, r);
                }))();
            },
            initUserData: function() {
                var e = m("userData");
                this.userData = e ? D(e) : {};
            },
            initWxData: function() {
                this.wxData = m("wxData") || {};
            },
            initClientData: function(e) {
                var t = this, n = wx.getSystemInfoSync(), r = n.brand, o = n.model, i = n.screenWidth, a = n.screenHeight, u = n.windowWidth, c = n.windowHeight, s = n.language, f = n.version, l = n.system, p = n.platform, d = n.SDKVersion, h = n.pixelRatio, v = o, g = v.toLowerCase().includes(r.toLowerCase()) ? v : "".concat(r, " ").concat(v), y = 3;
                if (p.toLowerCase().includes("android")) y = 0; else if (p.toLowerCase().includes("ios")) {
                    y = 1;
                    var b = o.match(/((.*)\(.*\)<(.*)>)|((.*)<(.*)>)|((.*)\(.*\))|.*/);
                    v = b[2] || b[5] || b[8] || b[0], b[3] && (g = b[3].replace(" ", "")), b[6] && (g = b[6].replace(" ", ""));
                }
                var m = l.toLowerCase().split(" ")[1] || "";
                Object.assign(this.clientData, {
                    xcxsv: d,
                    model: v.trim(),
                    device_name: g,
                    os: y,
                    os_version: m,
                    manufacturer: r,
                    sr: i ? "".concat(i * h, "x").concat(a * h) : "".concat(u * h, "x").concat(c * h),
                    lang: s,
                    p_wesv: f
                }), Promise.all([ this.setNetworkType(), this.setLocation() ]).then(function() {
                    e && e(t);
                });
            },
            initPageQuery: function(e) {
                var t = this;
                return d(o.mark(function n() {
                    var r, i;
                    return o.wrap(function(n) {
                        for (;;) switch (n.prev = n.next) {
                          case 0:
                            if (!e) {
                                n.next = 7;
                                break;
                            }
                            if (r = e, t.pageData.query = P(r), !r.utm) {
                                n.next = 7;
                                break;
                            }
                            return n.next = 5, A(r.utm);

                          case 5:
                            i = n.sent, Object.assign(t.pageData.query, P(T(i)));

                          case 7:
                          case "end":
                            return n.stop();
                        }
                    }, n);
                }))();
            },
            initPageData: function(e) {
                var t = getCurrentPages(), n = t[t.length - 1].route;
                this.pageData.depth = t.length, this.pageData.path = n, this.pageData.startTs = Date.now(), 
                e && e(this);
            },
            setLocation: function() {
                var e = this;
                return new Promise(function(t, n) {
                    y.locationAccessible ? wx.getLocation({
                        type: "wgs84",
                        success: function(n) {
                            var r = n.latitude, o = n.longitude;
                            e.clientData.lon = o, e.clientData.lat = r, t();
                        },
                        fail: function(e) {
                            console.error("hxt: 获取位置信息失败", e), t();
                        }
                    }) : t();
                });
            },
            setNetworkType: function() {
                var e = this;
                return wx.onNetworkStatusChange && wx.onNetworkStatusChange(function(t) {
                    var n = t.networkType;
                    e.clientData.network = n;
                }), new Promise(function(t, n) {
                    wx.getNetworkType({
                        success: function(n) {
                            var r = n.networkType;
                            e.clientData.network = r, t();
                        },
                        fail: function(e) {
                            console.error("hxt: 获取网络信息失败", e), t();
                        }
                    });
                });
            },
            setWxData: function(e) {
                if (e) {
                    if ("object" == (0, n.default)(e)) {
                        var t = m("wxData") || {};
                        Object.entries(e).forEach(function(e) {
                            var n = s(e, 2), r = n[0], o = n[1];
                            "string" != typeof o && "number" != typeof o || ("openid" === r.toLowerCase() && (t.wx_id = "".concat(o)), 
                            "unionid" === r.toLowerCase() && (t.unionid = "".concat(o)));
                        }), this.wxData = t, _("wxData", t);
                    }
                } else this.wxData = {}, _("wxData", null);
            },
            setUserData: function(e) {
                if (e) {
                    if ("object" == (0, n.default)(e)) {
                        var t = m("userData"), r = Object.assign({}, t, e);
                        this.userData = D(r), _("userData", r);
                    }
                } else this.userData = {}, _("userData", null);
            }
        }, I = function() {
            function e(t) {
                (function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
                })(this, e), w(t, [ "v_id" ]), this.queuedReports = [], this.data = Object.assign({
                    v_id: t.v_id
                }, (t.len || 0 === t.len) && {
                    len: 1e3 * t.len
                });
            }
            return function(e, t, n) {
                t && c(e.prototype, t), n && c(e, n);
            }(e, [ {
                key: "consumeQueuedReports",
                value: function() {
                    for (;this.queuedReports.length; ) {
                        var e = this.queuedReports.shift(), t = e.type, n = e.param;
                        this.doReport(t, n);
                    }
                }
            }, {
                key: "start",
                value: function(e) {
                    this.report("start", e);
                }
            }, {
                key: "heartbeat",
                value: function(e) {
                    this.report("heart_beat", e);
                }
            }, {
                key: "end",
                value: function(e) {
                    this.report("end", e);
                }
            }, {
                key: "sendAction",
                value: function(e, t) {
                    this.report("act", {
                        name: e,
                        params: t
                    });
                }
            }, {
                key: "report",
                value: function(e, t) {
                    y.requireOpenid && !M.wxData.wx_id || this.queuedReports.length ? this.queuedReports.push({
                        type: e,
                        param: t
                    }) : this.doReport(e, t);
                }
            }, {
                key: "doReport",
                value: function(e, t) {
                    var n = Object.assign({
                        _t: "i",
                        _ua: y.playerKey,
                        url: M.pageData.path,
                        title: M.pageData.path,
                        ts: Date.now(),
                        type: e
                    }, M.clientData, M.userData, M.wxData, this.data, t.upid && {
                        upid: t.upid
                    }, (t.lag_ts || 0 === t.lag_ts) && {
                        lag_ts: 1e3 * t.lag_ts
                    }, E(t.params)), r = {};
                    [ "start", "end", "heart_beat" ].includes(e) ? w(r = Object.assign(n, {
                        spend: 1e3 * t.spend
                    }, (t.progress || 0 === t.progress) && {
                        progress: 1e3 * t.progress
                    }), [ "spend" ]) : "act" === e && (r = Object.assign(n, {
                        act_name: t.name
                    })), r.wx_id && (r.device_id = r.wx_id), O(y.playerUrl, r);
                }
            } ]), e;
        }(), L = {
            queuedReports: [],
            attemptConsumeQueuedReports: function() {
                this.isReadyToSendReports() && (this.consumeQueuedReports(), this.player && this.player.consumeQueuedReports());
            },
            consumeQueuedReports: function() {
                for (;this.queuedReports.length; ) {
                    var e = this.queuedReports.shift(), t = e.type, n = e.param, r = e.meta;
                    this.doReport(t, n, r);
                }
            },
            initApp: function(e, t) {
                var n = this;
                t.hxt = Object.assign(t.hxt || {}, {
                    sendAction: this.sendAction.bind(this),
                    identify: this.identify.bind(this),
                    setUserInfo: this.setUserInfo.bind(this),
                    onWebviewMessage: this.onWebviewMessage.bind(this),
                    disableTrackType: this.disableTrackType.bind(this),
                    disableAllTrackTypes: this.disableAllTrackTypes.bind(this),
                    enableTrackType: this.enableTrackType.bind(this),
                    enableAllTrackTypes: this.enableAllTrackTypes.bind(this),
                    disableTrackShare: this.disableTrackShare.bind(this),
                    enableTrackShare: this.enableTrackShare.bind(this),
                    disableTrackQuery: this.disableTrackQuery.bind(this),
                    enableTrackQuery: this.enableTrackQuery.bind(this)
                }, y.isPlayerEnable && {
                    createPlayer: this.createPlayer
                }), y.isAppEnable && this.report("client_data"), M.initAppData(e, function() {
                    n._initAppReady = !0, n.attemptConsumeQueuedReports();
                });
            },
            initPageQuery: function(e) {
                return d(o.mark(function t() {
                    return o.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return t.next = 2, M.initPageQuery(e);

                          case 2:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }))();
            },
            initPage: function() {
                M.initPageData();
            },
            endPage: function() {
                var e = getCurrentPages();
                if (e.length === M.pageData.depth) {
                    var t = e[e.length - 1];
                    this._currentPageview && (this.report("webview_pageview", this._currentPageview.params, this._currentPageview.meta), 
                    this._currentPageview = null), t && t.route === M.pageData.path && y.isAppEnable && this.report("activity");
                }
            },
            setPageProps: function(e) {
                getCurrentPages().length === M.pageData.depth && (M.pageData.props = e);
            },
            _initAppReady: !1,
            isReadyToSendReports: function() {
                return !(!this._initAppReady || y.requireOpenid && !M.wxData.wx_id);
            },
            _trackTypeFlags: {
                client_data: !0,
                act: !0,
                activity: !0
            },
            _trackActionFlags: {
                share: !0
            },
            _trackQueryFlag: !0,
            report: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, r = getCurrentPages();
                if (r.length === M.pageData.depth) {
                    var o = r[r.length - 1];
                    n.pageProps = Object.assign({}, o.hxtPageProps, M.pageData.props);
                }
                this.isReadyToSendReports() ? this.queuedReports.length ? this.queuedReports.push({
                    type: e,
                    param: t,
                    meta: n
                }) : this.doReport(e, t, n) : this.queuedReports.push({
                    type: e,
                    param: t,
                    meta: n
                });
            },
            doReport: function(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, r = Object.assign({}, M.clientData, M.userData, M.wxData, {
                    _ua: y.appKey,
                    ts: n.ts || Date.now(),
                    type: e,
                    source: n.source,
                    url: n.url
                }), o = {};
                if ("client_data" === e) o = Object.assign(r, E(M.refData)); else if ("activity" === e) {
                    var i = Date.now();
                    o = Object.assign(r, this._trackQueryFlag ? E(M.pageData.query) : {}, E(n.pageProps), {
                        activity: M.pageData.path,
                        start_ts: M.pageData.startTs,
                        end_ts: i,
                        duration: i - M.pageData.startTs
                    });
                } else if ("webview_pageview" === e) {
                    var a = n.end_ts || Date.now();
                    o = Object.assign(r, this._trackQueryFlag ? E(M.pageData.query) : {}, {
                        type: "activity",
                        activity: M.pageData.path,
                        start_ts: n.ts,
                        end_ts: a,
                        duration: a - n.ts
                    }, E(t));
                } else "act" === e && (o = Object.assign(r, {
                    activity: function() {
                        var e = getCurrentPages();
                        return e[e.length - 1].route;
                    }(),
                    act_name: t.name
                }, E(n.pageProps), E(t.props)));
                y.requireOpenid && (o.device_id = o.wx_id), this._trackTypeFlags[o.type] && ("act" === o.type && !1 === this._trackActionFlags[o.act_name] || O("".concat(y.appUrl, "?_ua=").concat(encodeURIComponent(o._ua), "&_t=i&_z=m"), o, "POST"));
            },
            shareApp: function(e) {
                this.report("act", {
                    name: "share",
                    props: {
                        share_title: e.title,
                        share_path: e.path
                    }
                });
            },
            sendAction: function(e, t, n) {
                this.report("act", {
                    name: e,
                    props: t
                }, n);
            },
            identify: function(e) {
                M.setWxData(e), this.attemptConsumeQueuedReports();
            },
            setUserInfo: function(e) {
                M.setUserData(e);
            },
            createPlayer: function(e) {
                return this.player = new I(e), this.player;
            },
            onWebviewMessage: function(e) {
                var t = this, n = e.detail.data;
                (void 0 === n ? [] : n).filter(function(e) {
                    return "invokeHxt" === e.type;
                }).forEach(function(e) {
                    var n = e.method, r = e.args, o = e.timestamp, i = e.url;
                    t.handleInvokeHxt(n, {
                        timestamp: o,
                        args: r,
                        url: i
                    });
                });
            },
            handleInvokeHxt: function(e, t) {
                var n = t.timestamp, r = t.args, o = void 0 === r ? [] : r, i = t.url;
                this[e] && this[e].apply(this, u(o).concat([ {
                    ts: n,
                    source: "webview",
                    url: i
                } ]));
            },
            _currentPageview: null,
            webviewPageview: function(e, t) {
                this._currentPageview && this.report("webview_pageview", this._currentPageview.params, a(a({}, this._currentPageview.meta), {}, {
                    end_ts: t.ts
                })), this._currentPageview = {
                    params: e,
                    meta: a(a({}, t), {}, {
                        url: e && e.url || t.url
                    })
                };
            },
            isEvent: function(e) {
                return !!e && "object" == (0, n.default)(e) && "type" in e && "currentTarget" in e && "detail" in e;
            },
            isAutoTrackEvent: function(e) {
                return this.isEvent(e) && -1 !== y.autoTrackEventsList.indexOf(e.type);
            },
            trackEventCallback: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 ? arguments[1] : void 0, n = t.type, r = t.currentTarget, o = t.detail;
                return this.sendAction(this.getSafeCallbackName(e, t), a(a({
                    event: n,
                    target_id: r.id
                }, k(this.getEventTargetDataset(t, e), "_", "target_data")), k(o, "_", "detail")), {
                    source: "auto_track"
                });
            },
            getSafeCallbackName: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 ? arguments[1] : void 0;
                return this.isUniappEventProxy(t, e) && (e = this.extractUniappProxiedCallbackName(e, t)), 
                "cb_".concat(e).replace(/[^A-Za-z0-9]+/g, "_").split(/(?=[A-Z0-9])/).join("_").toLowerCase().replace(/_+/g, "_");
            },
            getEventTargetDataset: function(e, t) {
                var n = e.currentTarget.dataset;
                return this.isUniappEventProxy(e, t) ? Object.keys(n).reduce(function(e, t) {
                    return "eventOpts" !== t && "event-opts" !== t && (e[t] = n[t]), e;
                }, {}) : n;
            },
            isUniappEventProxy: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return "__e" === t && (e.currentTarget.dataset.eventOpts || e.currentTarget.dataset["event-opts"]);
            },
            extractUniappProxiedCallbackName: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 ? arguments[1] : void 0, n = (t.currentTarget.dataset.eventOpts || t.currentTarget.dataset["event-opts"]).filter(function(e) {
                    return e[0] === t.type;
                })[0];
                return n ? n[1][0][0] : e;
            },
            disableTrackType: function(e) {
                var t = this;
                e && Array.isArray(e) ? e.forEach(function(e) {
                    e in t._trackTypeFlags && (t._trackTypeFlags[e] = !1);
                }) : this.disableTrackType([ e ]);
            },
            disableAllTrackTypes: function() {
                this.disableTrackType(Object.getOwnPropertyNames(this._trackTypeFlags));
            },
            enableTrackType: function(e) {
                var t = this;
                e && Array.isArray(e) ? e.forEach(function(e) {
                    e in t._trackTypeFlags && (t._trackTypeFlags[e] = !0);
                }) : this.enableTrackType([ e ]);
            },
            enableAllTrackTypes: function() {
                this.enableTrackType(Object.getOwnPropertyNames(this._trackTypeFlags));
            },
            disableTrackShare: function() {
                this._trackActionFlags.share = !1;
            },
            enableTrackShare: function() {
                this._trackActionFlags.share = !0;
            },
            disableTrackQuery: function() {
                this._trackQueryFlag = !1;
            },
            enableTrackQuery: function() {
                this._trackQueryFlag = !0;
            }
        };
        function $(e, t, n) {
            return function() {
                var r, o = n[t] && (r = n[t]).call.apply(r, [ this ].concat(Array.prototype.slice.call(arguments)));
                if (e.call.apply(e, [ this, o ].concat(Array.prototype.slice.call(arguments))), 
                o) return o;
            };
        }
        function N(e, t) {
            L.initApp(t, this);
        }
        function R(e, t) {
            L.initPageQuery(t);
        }
        function B() {
            L.initPage();
        }
        function H() {
            L.endPage();
        }
        function F() {
            L.endPage();
        }
        function U(e) {
            L.shareApp(e);
        }
        function G(e, t) {
            return function(n) {
                return L.isAutoTrackEvent(n) && L.trackEventCallback(e, n), t.apply(this, arguments);
            };
        }
        function V(e) {
            var t = [ "onLoad", "onShow", "onReady", "onHide", "onUnload", "onPullDownRefresh", "onReachBottom", "onShareAppMessage", "onPageScroll", "onResize", "onTabItemTap" ];
            return Object.assign({}, e, {
                onLoad: $(R, "onLoad", e),
                onShow: $(B, "onShow", e),
                onHide: $(H, "onHide", e),
                onUnload: $(F, "onUnload", e)
            }, e.onShareAppMessage ? {
                onShareAppMessage: $(U, "onShareAppMessage", e)
            } : {}, y.autoTrackEventsEnabled ? Object.keys(e).reduce(function(n, r) {
                return "function" == typeof e[r] && -1 === t.indexOf(r) && (n[r] = G(r, e[r])), 
                n;
            }, {}) : {});
        }
        var W = Page, z = function(e) {
            var t = V(e);
            W(t);
        }, q = Component, Y = function(e) {
            var t = Object.assign(e, {
                methods: V(e.methods || {})
            });
            q(t);
        }, K = App, J = function(e) {
            var t = function(e) {
                var t = [ "onLaunch", "onShow", "onHide", "onError", "onPageNotFound", "onUnhandledRejection" ];
                return Object.assign({}, e, {
                    onLaunch: $(N, "onLaunch", e)
                }, y.autoTrackEventsEnabled ? Object.keys(e).reduce(function(n, r) {
                    return "function" == typeof e[r] && -1 === t.indexOf(r) && (n[r] = G(r, e[r])), 
                    n;
                }, {}) : {});
            }(e);
            if (K(t), y.usingPlugins) {
                var n = getApp();
                n.hxt ? (n.hxt.Page = z, n.hxt.Component = Y) : n.hxt = {
                    Page: z,
                    Component: Y
                };
            }
        };
        if (e.exports = {
            App: J,
            Page: z,
            useApp: function(e) {
                K = e;
            },
            usePage: function(e) {
                W = e;
            }
        }, !y.usingPlugins) try {
            App = J, Page = z, Component = Y;
        } catch (v) {
            console.error("hxt: 如果小程序使用了插件，请设置 usingPlugins: true", v);
        }
    },
    "0d25a": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.NoopTransport = void 0;
        var r = n("507c"), o = n("32f1"), i = function() {
            function e() {}
            return e.prototype.sendEvent = function(e) {
                return o.SyncPromise.resolve({
                    reason: "NoopTransport: Event has been skipped because no Dsn is configured.",
                    status: r.Status.Skipped
                });
            }, e.prototype.close = function(e) {
                return o.SyncPromise.resolve(!0);
            }, e;
        }();
        t.NoopTransport = i;
    },
    1096: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.TryCatch = void 0;
        var r = n("32f1"), o = n("413f"), i = function() {
            function e() {
                this._ignoreOnError = 0, this.name = e.id;
            }
            return e.prototype._wrapTimeFunction = function(e) {
                return function() {
                    for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                    var r = t[0];
                    return t[0] = (0, o.wrap)(r, {
                        mechanism: {
                            data: {
                                function: a(e)
                            },
                            handled: !0,
                            type: "instrument"
                        }
                    }), e.apply(this, t);
                };
            }, e.prototype._wrapRAF = function(e) {
                return function(t) {
                    return e((0, o.wrap)(t, {
                        mechanism: {
                            data: {
                                function: "requestAnimationFrame",
                                handler: a(e)
                            },
                            handled: !0,
                            type: "instrument"
                        }
                    }));
                };
            }, e.prototype._wrapEventTarget = function(e) {
                var t = (0, r.getGlobalObject)(), n = t[e] && t[e].prototype;
                n && n.hasOwnProperty && n.hasOwnProperty("addEventListener") && ((0, r.fill)(n, "addEventListener", function(t) {
                    return function(n, r, i) {
                        try {
                            "function" == typeof r.handleEvent && (r.handleEvent = (0, o.wrap)(r.handleEvent.bind(r), {
                                mechanism: {
                                    data: {
                                        function: "handleEvent",
                                        handler: a(r),
                                        target: e
                                    },
                                    handled: !0,
                                    type: "instrument"
                                }
                            }));
                        } catch (e) {}
                        return t.call(this, n, (0, o.wrap)(r, {
                            mechanism: {
                                data: {
                                    function: "addEventListener",
                                    handler: a(r),
                                    target: e
                                },
                                handled: !0,
                                type: "instrument"
                            }
                        }), i);
                    };
                }), (0, r.fill)(n, "removeEventListener", function(e) {
                    return function(t, n, r) {
                        var o = n;
                        try {
                            o = o && (o.__sentry_wrapped__ || o);
                        } catch (e) {}
                        return e.call(this, t, o, r);
                    };
                }));
            }, e.prototype.setupOnce = function() {
                this._ignoreOnError = this._ignoreOnError;
                var e = (0, r.getGlobalObject)();
                (0, r.fill)(e, "setTimeout", this._wrapTimeFunction.bind(this)), (0, r.fill)(e, "setInterval", this._wrapTimeFunction.bind(this)), 
                (0, r.fill)(e, "requestAnimationFrame", this._wrapRAF.bind(this)), [ "EventTarget", "Window", "Node", "ApplicationCache", "AudioTrackList", "ChannelMergerNode", "CryptoOperation", "EventSource", "FileReader", "HTMLUnknownElement", "IDBDatabase", "IDBRequest", "IDBTransaction", "KeyOperation", "MediaController", "MessagePort", "ModalWindow", "Notification", "SVGElementInstance", "Screen", "TextTrack", "TextTrackCue", "TextTrackList", "WebSocket", "WebSocketWorker", "Worker", "XMLHttpRequest", "XMLHttpRequestEventTarget", "XMLHttpRequestUpload" ].forEach(this._wrapEventTarget.bind(this));
            }, e.id = "TryCatch", e;
        }();
        function a(e) {
            try {
                return e && e.name || "<anonymous>";
            } catch (e) {
                return "<anonymous>";
            }
        }
        t.TryCatch = i;
    },
    "11b6": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), Object.defineProperty(t, "BaseTransport", {
            enumerable: !0,
            get: function() {
                return r.BaseTransport;
            }
        }), Object.defineProperty(t, "XHRTransport", {
            enumerable: !0,
            get: function() {
                return o.XHRTransport;
            }
        });
        var r = n("7b45"), o = n("94a1");
    },
    1246: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        t.default = {
            province: [ [ "1", "北京市" ], [ "2", "上海市" ], [ "3", "湖北省" ], [ "4", "湖南省" ], [ "5", "吉林省" ], [ "6", "辽宁省" ], [ "7", "天津市" ], [ "8", "山西省" ], [ "9", "河北省" ], [ "10", "新疆维吾尔自治区" ], [ "11", "河南省" ], [ "12", "安徽省" ], [ "13", "山东省" ], [ "14", "江苏省" ], [ "15", "甘肃省" ], [ "16", "宁夏回族自治区" ], [ "17", "云南省" ], [ "18", "浙江省" ], [ "19", "福建省" ], [ "20", "贵州省" ], [ "21", "江西省" ], [ "22", "广西壮族自治区" ], [ "23", "西藏自治区" ], [ "24", "广东省" ], [ "25", "重庆市" ], [ "26", "海南省" ], [ "27", "内蒙古自治区" ], [ "28", "陕西省" ], [ "29", "青海省" ], [ "30", "四川省" ], [ "31", "黑龙江省" ] ],
            city: [ [ "32", "阿坝藏族羌族自治州" ], [ "33", "甘孜藏族自治州" ], [ "34", "凉山彝族自治州" ], [ "35", "哈尔滨市" ], [ "36", "齐齐哈尔市" ], [ "37", "牡丹江市" ], [ "38", "佳木斯市" ], [ "39", "大庆市" ], [ "40", "鸡西市" ], [ "41", "鹤岗市" ], [ "42", "双鸭山市" ], [ "43", "伊春市" ], [ "44", "七台河市" ], [ "45", "黑河市" ], [ "46", "绥化市" ], [ "47", "大兴安岭地区" ], [ "48", "武汉市" ], [ "49", "襄樊市" ], [ "50", "宜昌市" ], [ "51", "神农架林区" ], [ "52", "黄石市" ], [ "53", "十堰市" ], [ "54", "鄂州市" ], [ "55", "荆门市" ], [ "56", "孝感市" ], [ "57", "荆州市" ], [ "58", "黄冈市" ], [ "59", "咸宁市" ], [ "60", "随州市" ], [ "61", "恩施土家族苗族自治州" ], [ "62", "仙桃市" ], [ "63", "潜江市" ], [ "64", "天门市" ], [ "65", "长沙市" ], [ "66", "岳阳市" ], [ "67", "株洲市" ], [ "68", "衡阳市" ], [ "69", "怀化市" ], [ "70", "湘潭市" ], [ "71", "邵阳市" ], [ "72", "常德市" ], [ "73", "张家界市" ], [ "74", "益阳市" ], [ "75", "郴州市" ], [ "76", "永州市" ], [ "77", "娄底市" ], [ "78", "湘西土家族苗族自治州" ], [ "79", "长春市" ], [ "80", "通化市" ], [ "81", "白城市" ], [ "82", "吉林市" ], [ "83", "四平市" ], [ "84", "辽源市" ], [ "85", "白山市" ], [ "86", "松原市" ], [ "87", "延边朝鲜族自治州" ], [ "88", "大连市" ], [ "89", "沈阳市" ], [ "90", "鞍山市" ], [ "91", "抚顺市" ], [ "92", "本溪市" ], [ "93", "锦州市" ], [ "94", "辽阳市" ], [ "95", "朝阳市" ], [ "96", "丹东市" ], [ "97", "营口市" ], [ "98", "阜新市" ], [ "99", "盘锦市" ], [ "100", "铁岭市" ], [ "101", "葫芦岛市" ], [ "102", "天津市" ], [ "103", "太原市" ], [ "104", "大同市" ], [ "105", "晋中市" ], [ "106", "临汾市" ], [ "107", "运城市" ], [ "108", "忻州市" ], [ "109", "朔州市" ], [ "110", "阳泉市" ], [ "111", "晋城市" ], [ "112", "长治市" ], [ "113", "吕梁市" ], [ "114", "石家庄市" ], [ "115", "邯郸市" ], [ "116", "保定市" ], [ "117", "张家口市" ], [ "118", "承德市" ], [ "119", "唐山市" ], [ "120", "沧州市" ], [ "121", "秦皇岛市" ], [ "122", "廊坊市" ], [ "123", "衡水市" ], [ "124", "邢台市" ], [ "125", "乌鲁木齐市" ], [ "126", "克拉玛依市" ], [ "127", "喀什地区" ], [ "128", "吐鲁番地区" ], [ "129", "哈密地区" ], [ "130", "石河子市" ], [ "131", "阿克苏地区" ], [ "132", "昌吉回族自治州" ], [ "133", "博尔塔拉蒙古自治州" ], [ "134", "巴音郭楞蒙古自治州" ], [ "135", "克孜勒苏柯尔克孜自治州" ], [ "136", "和田地区" ], [ "137", "伊犁哈萨克自治州" ], [ "138", "塔城地区" ], [ "139", "阿勒泰地区" ], [ "140", "阿拉尔市" ], [ "141", "图木舒克市" ], [ "142", "五家渠市" ], [ "143", "郑州市" ], [ "144", "安阳市" ], [ "145", "商丘市" ], [ "146", "新乡市" ], [ "147", "许昌市" ], [ "148", "信阳市" ], [ "149", "南阳市" ], [ "150", "开封市" ], [ "151", "洛阳市" ], [ "152", "焦作市" ], [ "153", "漯河市" ], [ "154", "濮阳市" ], [ "155", "平顶山市" ], [ "156", "鹤壁市" ], [ "157", "三门峡市" ], [ "158", "周口市" ], [ "159", "驻马店市" ], [ "160", "济源市" ], [ "161", "合肥市" ], [ "162", "蚌埠市" ], [ "163", "芜湖市" ], [ "164", "淮南市" ], [ "165", "马鞍山市" ], [ "166", "阜阳市" ], [ "167", "铜陵市" ], [ "168", "安庆市" ], [ "169", "黄山市" ], [ "170", "滁州市" ], [ "171", "宿州市" ], [ "172", "巢湖市" ], [ "173", "六安市" ], [ "174", "亳州市" ], [ "175", "池州市" ], [ "176", "宣城市" ], [ "177", "淮北市" ], [ "178", "南京市" ], [ "179", "苏州市" ], [ "180", "无锡市" ], [ "181", "南通市" ], [ "182", "常州市" ], [ "183", "镇江市" ], [ "184", "扬州市" ], [ "185", "淮安市" ], [ "186", "连云港市" ], [ "187", "泰州市" ], [ "188", "徐州市" ], [ "189", "盐城市" ], [ "190", "宿迁市" ], [ "191", "兰州市" ], [ "192", "嘉峪关市" ], [ "193", "天水市" ], [ "194", "白银市" ], [ "195", "武威市" ], [ "196", "张掖市" ], [ "197", "平凉市" ], [ "198", "酒泉市" ], [ "199", "庆阳市" ], [ "200", "定西市" ], [ "201", "陇南市" ], [ "202", "临夏回族自治州" ], [ "203", "甘南藏族自治州" ], [ "204", "金昌市" ], [ "205", "银川市" ], [ "206", "石嘴山市" ], [ "207", "吴忠市" ], [ "208", "固原市" ], [ "209", "中卫市" ], [ "210", "昆明市" ], [ "211", "昭通市" ], [ "212", "大理白族自治州" ], [ "213", "临沧市" ], [ "214", "保山市" ], [ "215", "丽江市" ], [ "216", "普洱市" ], [ "217", "文山壮族苗族自治州" ], [ "218", "红河哈尼族彝族自治州" ], [ "219", "西双版纳傣族自治州" ], [ "220", "楚雄彝族自治州" ], [ "221", "德宏傣族景颇族自治州" ], [ "222", "怒江傈僳族自治州" ], [ "223", "迪庆藏族自治州" ], [ "224", "杭州市" ], [ "225", "温州市" ], [ "226", "绍兴市" ], [ "227", "宁波市" ], [ "228", "金华市" ], [ "229", "嘉兴市" ], [ "230", "舟山市" ], [ "231", "湖州市" ], [ "232", "衢州市" ], [ "233", "丽水市" ], [ "234", "台州市" ], [ "235", "福州市" ], [ "236", "厦门市" ], [ "237", "泉州市" ], [ "238", "漳州市" ], [ "239", "莆田市" ], [ "240", "龙岩市" ], [ "241", "三明市" ], [ "242", "南平市" ], [ "243", "宁德市" ], [ "244", "贵阳市" ], [ "245", "遵义市" ], [ "246", "六盘水市" ], [ "247", "黔西南布依族苗族自治州" ], [ "248", "安顺市" ], [ "249", "铜仁地区" ], [ "250", "毕节地区" ], [ "251", "黔东南苗族侗族自治州" ], [ "252", "黔南布依族苗族自治州" ], [ "253", "南昌市" ], [ "254", "九江市" ], [ "255", "上饶市" ], [ "256", "宜春市" ], [ "257", "吉安市" ], [ "258", "赣州市" ], [ "259", "景德镇市" ], [ "260", "萍乡市" ], [ "261", "新余市" ], [ "262", "鹰潭市" ], [ "263", "抚州市" ], [ "264", "南宁市" ], [ "265", "柳州市" ], [ "266", "桂林市" ], [ "267", "北海市" ], [ "268", "玉林市" ], [ "269", "梧州市" ], [ "270", "防城港市" ], [ "271", "钦州市" ], [ "272", "贵港市" ], [ "273", "百色市" ], [ "274", "贺州市" ], [ "275", "河池市" ], [ "276", "来宾市" ], [ "277", "崇左市" ], [ "278", "拉萨市" ], [ "279", "日喀则地区" ], [ "280", "山南地区" ], [ "281", "昌都地区" ], [ "282", "那曲地区" ], [ "283", "阿里地区" ], [ "284", "林芝地区" ], [ "285", "重庆市" ], [ "286", "曲靖市" ], [ "287", "玉溪市" ], [ "288", "北京市" ], [ "289", "上海市" ], [ "290", "济南市" ], [ "291", "青岛市" ], [ "292", "淄博市" ], [ "293", "烟台市" ], [ "294", "泰安市" ], [ "295", "济宁市" ], [ "296", "威海市" ], [ "297", "潍坊市" ], [ "298", "聊城市" ], [ "299", "德州市" ], [ "300", "菏泽市" ], [ "301", "滨州市" ], [ "302", "日照市" ], [ "303", "枣庄市" ], [ "304", "东营市" ], [ "305", "临沂市" ], [ "306", "莱芜市" ], [ "307", "广州市" ], [ "308", "深圳市" ], [ "309", "珠海市" ], [ "310", "中山市" ], [ "311", "佛山市" ], [ "312", "东莞市" ], [ "313", "惠州市" ], [ "314", "江门市" ], [ "315", "肇庆市" ], [ "316", "汕头市" ], [ "317", "湛江市" ], [ "318", "潮州市" ], [ "319", "云浮市" ], [ "320", "茂名市" ], [ "321", "阳江市" ], [ "322", "汕尾市" ], [ "323", "揭阳市" ], [ "324", "梅州市" ], [ "325", "河源市" ], [ "326", "韶关市" ], [ "327", "清远市" ], [ "328", "海口市" ], [ "329", "三亚市" ], [ "330", "琼海市" ], [ "331", "儋州市" ], [ "332", "文昌市" ], [ "333", "东方市" ], [ "334", "澄迈县" ], [ "335", "定安县" ], [ "336", "临高县" ], [ "337", "琼中黎族苗族自治县" ], [ "338", "万宁市" ], [ "339", "屯昌县" ], [ "340", "保亭黎族苗族自治县" ], [ "341", "白沙黎族自治县" ], [ "342", "陵水黎族自治县" ], [ "343", "乐东黎族自治县" ], [ "344", "昌江黎族自治县" ], [ "345", "五指山市" ], [ "346", "西南中沙群岛办事处" ], [ "347", "呼和浩特市" ], [ "348", "包头市" ], [ "349", "鄂尔多斯市" ], [ "350", "乌海市" ], [ "351", "赤峰市" ], [ "352", "通辽市" ], [ "353", "呼伦贝尔市" ], [ "354", "巴彦淖尔市" ], [ "355", "乌兰察布市" ], [ "356", "兴安盟" ], [ "357", "锡林郭勒盟" ], [ "358", "阿拉善盟" ], [ "359", "西安市" ], [ "360", "咸阳市" ], [ "361", "汉中市" ], [ "362", "渭南市" ], [ "363", "宝鸡市" ], [ "364", "榆林市" ], [ "365", "铜川市" ], [ "366", "延安市" ], [ "367", "安康市" ], [ "368", "商洛市" ], [ "369", "西宁市" ], [ "370", "海东地区" ], [ "371", "海北藏族自治州" ], [ "372", "黄南藏族自治州" ], [ "373", "海南藏族自治州" ], [ "374", "果洛藏族自治州" ], [ "375", "玉树藏族自治州" ], [ "376", "海西蒙古族藏族自治州" ], [ "377", "成都市" ], [ "378", "攀枝花市" ], [ "379", "绵阳市" ], [ "380", "宜宾市" ], [ "381", "泸州市" ], [ "382", "乐山市" ], [ "383", "雅安市" ], [ "384", "广元市" ], [ "385", "德阳市" ], [ "386", "南充市" ], [ "387", "自贡市" ], [ "388", "遂宁市" ], [ "389", "内江市" ], [ "390", "眉山市" ], [ "391", "广安市" ], [ "392", "达州市" ], [ "393", "巴中市" ], [ "394", "资阳市" ], [ "396", "丰镇市" ], [ "401", "九台市" ], [ "402", "榆树市" ], [ "403", "德惠市" ], [ "410", "梅河口市" ], [ "411", "集安市" ], [ "415", "洮南市" ], [ "416", "大安市" ], [ "423", "蛟河市" ], [ "424", "桦甸市" ], [ "425", "舒兰市" ], [ "426", "磐石市" ], [ "432", "公主岭市" ], [ "433", "双辽市" ], [ "444", "临江市" ], [ "450", "延吉市" ], [ "451", "图们市" ], [ "452", "敦化市" ], [ "454", "珲春市" ], [ "455", "龙井市" ], [ "456", "和龙市" ], [ "467", "瓦房店市" ], [ "468", "普兰店市" ], [ "469", "庄河市" ], [ "481", "卫辉市" ], [ "482", "如皋市" ], [ "483", "通州市" ], [ "484", "海门市" ], [ "491", "溧阳市" ], [ "492", "金坛市" ], [ "496", "丹阳市" ], [ "498", "扬中市" ], [ "499", "句容市" ], [ "506", "仪征市" ], [ "507", "高邮市" ], [ "510", "江都市" ], [ "530", "兴化市" ], [ "532", "靖江市" ], [ "533", "泰兴市" ], [ "534", "姜堰市" ], [ "545", "新沂市" ], [ "546", "邳州市" ], [ "555", "东台市" ], [ "556", "大丰市" ], [ "611", "玉门市" ], [ "612", "敦煌市" ], [ "643", "个旧市" ], [ "644", "开远市" ], [ "657", "景洪市" ], [ "660", "楚雄市" ], [ "671", "瑞丽市" ], [ "672", "潞西市" ], [ "695", "建德市" ], [ "696", "富阳市" ], [ "698", "临安市" ], [ "709", "瑞安市" ], [ "710", "乐清市" ], [ "714", "诸暨市" ], [ "715", "上虞市" ], [ "716", "嵊州市" ], [ "726", "余姚市" ], [ "727", "慈溪市" ], [ "728", "奉化市" ], [ "736", "兰溪市" ], [ "737", "义乌市" ], [ "738", "东阳市" ], [ "739", "永康市" ], [ "745", "海宁市" ], [ "746", "平湖市" ], [ "747", "桐乡市" ], [ "763", "江山市" ], [ "773", "龙泉市" ], [ "782", "温岭市" ], [ "783", "临海市" ], [ "786", "大冶市" ], [ "798", "福清市" ], [ "799", "长乐市" ], [ "810", "晋江市" ], [ "811", "石狮市" ], [ "812", "南安市" ], [ "822", "龙海市" ], [ "845", "漳平市" ], [ "858", "永安市" ], [ "866", "邵武市" ], [ "867", "武夷山市" ], [ "868", "建瓯市" ], [ "869", "建阳市" ], [ "875", "丹江口市" ], [ "878", "福安市" ], [ "879", "福鼎市" ], [ "890", "清镇市" ], [ "893", "赤水市" ], [ "894", "仁怀市" ], [ "911", "兴义市" ], [ "926", "铜仁市" ], [ "937", "毕节市" ], [ "946", "凯里市" ], [ "964", "钟祥市" ], [ "965", "都匀市" ], [ "966", "福泉市" ], [ "1003", "瑞昌市" ], [ "1016", "德兴市" ], [ "1019", "应城市" ], [ "1025", "丰城市" ], [ "1026", "樟树市" ], [ "1027", "高安市" ], [ "1030", "安陆市" ], [ "1041", "汉川市" ], [ "1042", "井冈山市" ], [ "1060", "瑞金市" ], [ "1061", "南康市" ], [ "1067", "乐平市" ], [ "1078", "贵溪市" ], [ "1108", "石首市" ], [ "1119", "洪湖市" ], [ "1130", "松滋市" ], [ "1140", "北流市" ], [ "1153", "岑溪市" ], [ "1157", "东兴市" ], [ "1167", "桂平市" ], [ "1198", "宜州市" ], [ "1204", "合山市" ], [ "1212", "凭祥市" ], [ "1222", "日喀则市" ], [ "1230", "麻城市" ], [ "1241", "武穴市" ], [ "1308", "赤壁市" ], [ "1312", "江津市" ], [ "1313", "合川市" ], [ "1314", "永川市" ], [ "1315", "南川市" ], [ "1330", "广水市" ], [ "1341", "恩施市" ], [ "1352", "利川市" ], [ "1353", "临夏市" ], [ "1361", "合作市" ], [ "1378", "灵武市" ], [ "1386", "青铜峡市" ], [ "1411", "安宁市" ], [ "1424", "大理市" ], [ "1446", "宣威市" ], [ "1483", "辉县市" ], [ "1489", "禹州市" ], [ "1490", "长葛市" ], [ "1507", "乌兰浩特市" ], [ "1517", "邓州市" ], [ "1545", "偃师市" ], [ "1553", "浏阳市" ], [ "1555", "沁阳市" ], [ "1556", "孟州市" ], [ "1578", "舞钢市" ], [ "1579", "汝州市" ], [ "1590", "义马市" ], [ "1591", "灵宝市" ], [ "1602", "项城市" ], [ "1641", "侯马市" ], [ "1642", "汨罗市" ], [ "1643", "霍州市" ], [ "1644", "永济市" ], [ "1645", "河津市" ], [ "1653", "临湘市" ], [ "1672", "原平市" ], [ "1691", "高平市" ], [ "1694", "潞城市" ], [ "1706", "孝义市" ], [ "1707", "汾阳市" ], [ "1727", "鹿泉市" ], [ "1743", "辛集市" ], [ "1744", "藁城市" ], [ "1745", "晋州市" ], [ "1746", "新乐市" ], [ "1753", "醴陵市" ], [ "1767", "武安市" ], [ "1796", "滕州市" ], [ "1824", "增城市" ], [ "1825", "从化市" ], [ "1859", "台山市" ], [ "1860", "开平市" ], [ "1861", "鹤山市" ], [ "1862", "恩平市" ], [ "1865", "四会市" ], [ "1866", "高要市" ], [ "1875", "耒阳市" ], [ "1885", "雷州市" ], [ "1886", "常宁市" ], [ "1888", "廉江市" ], [ "1890", "吴川市" ], [ "1896", "罗定市" ], [ "1903", "高州市" ], [ "1904", "化州市" ], [ "1905", "信宜市" ], [ "1909", "阳春市" ], [ "1913", "陆丰市" ], [ "1918", "普宁市" ], [ "1925", "兴宁市" ], [ "1928", "绥芬河市" ], [ "1929", "海林市" ], [ "1931", "宁安市" ], [ "1932", "穆棱市" ], [ "1942", "同江市" ], [ "1943", "富锦市" ], [ "1962", "虎林市" ], [ "1963", "密山市" ], [ "2000", "铁力市" ], [ "2010", "北安市" ], [ "2011", "五大连池市" ], [ "2019", "洪江市" ], [ "2020", "安达市" ], [ "2021", "肇东市" ], [ "2022", "海伦市" ], [ "2051", "老河口市" ], [ "2053", "枣阳市" ], [ "2054", "宜城市" ], [ "2064", "湘乡市" ], [ "2068", "宜都市" ], [ "2069", "当阳市" ], [ "2070", "枝江市" ], [ "2075", "韶山市" ], [ "2085", "涿州市" ], [ "2087", "定州市" ], [ "2088", "安国市" ], [ "2089", "高碑店市" ], [ "2134", "遵化市" ], [ "2135", "迁安市" ], [ "2139", "河间市" ], [ "2150", "泊头市" ], [ "2151", "任丘市" ], [ "2153", "黄骅市" ], [ "2171", "霸州市" ], [ "2172", "三河市" ], [ "2173", "深州市" ], [ "2185", "冀州市" ], [ "2205", "南宫市" ], [ "2206", "沙河市" ], [ "2208", "武冈市" ], [ "2223", "喀什市" ], [ "2254", "界首市" ], [ "2270", "桐城市" ], [ "2287", "天长市" ], [ "2288", "明光市" ], [ "2323", "宁国市" ], [ "2351", "常熟市" ], [ "2353", "张家港市" ], [ "2354", "昆山市" ], [ "2355", "吴江市" ], [ "2356", "太仓市" ], [ "2364", "江阴市" ], [ "2365", "宜兴市" ], [ "2383", "乐昌市" ], [ "2384", "南雄市" ], [ "2385", "吐鲁番市" ], [ "2393", "英德市" ], [ "2394", "连州市" ], [ "2419", "哈密市" ], [ "2463", "阿克苏市" ], [ "2479", "霍林郭勒市" ], [ "2489", "满洲里市" ], [ "2490", "牙克石市" ], [ "2491", "扎兰屯市" ], [ "2492", "额尔古纳市" ], [ "2493", "根河市" ], [ "2517", "昌吉市" ], [ "2518", "阜康市" ], [ "2522", "阿尔山市" ], [ "2526", "博乐市" ], [ "2529", "库尔勒市" ], [ "2539", "阿图什市" ], [ "2543", "和田市" ], [ "2552", "伊宁市" ], [ "2553", "奎屯市" ], [ "2563", "塔城市" ], [ "2564", "乌苏市" ], [ "2571", "阿勒泰市" ], [ "2593", "巩义市" ], [ "2594", "荥阳市" ], [ "2595", "新密市" ], [ "2596", "新郑市" ], [ "2597", "登封市" ], [ "2607", "林州市" ], [ "2617", "永城市" ], [ "2645", "兴平市" ], [ "2665", "章丘市" ], [ "2674", "胶州市" ], [ "2675", "即墨市" ], [ "2676", "平度市" ], [ "2677", "胶南市" ], [ "2679", "莱西市" ], [ "2696", "龙口市" ], [ "2697", "莱阳市" ], [ "2698", "莱州市" ], [ "2699", "蓬莱市" ], [ "2701", "招远市" ], [ "2702", "栖霞市" ], [ "2703", "海阳市" ], [ "2708", "新泰市" ], [ "2709", "肥城市" ], [ "2720", "曲阜市" ], [ "2721", "兖州市" ], [ "2723", "邹城市" ], [ "2727", "文登市" ], [ "2728", "荣成市" ], [ "2729", "乳山市" ], [ "2738", "青州市" ], [ "2739", "诸城市" ], [ "2740", "寿光市" ], [ "2741", "安丘市" ], [ "2742", "高密市" ], [ "2743", "昌邑市" ], [ "2746", "临清市" ], [ "2764", "乐陵市" ], [ "2765", "禹城市" ], [ "2780", "阆中市" ], [ "2810", "华蓥市" ], [ "2818", "万源市" ], [ "2827", "简阳市" ], [ "2863", "西昌市" ], [ "2897", "阿城市" ], [ "2898", "双城市" ], [ "2899", "尚志市" ], [ "2901", "五常市" ], [ "2918", "讷河市" ], [ "2927", "新民市" ], [ "2935", "海城市" ], [ "2950", "凌海市" ], [ "2951", "北宁市" ], [ "2964", "灯塔市" ], [ "2967", "韩城市" ], [ "2972", "北票市" ], [ "2973", "凌源市" ], [ "2978", "华阴市" ], [ "2979", "东港市" ], [ "2980", "凤城市" ], [ "2985", "盖州市" ], [ "2986", "大石桥市" ], [ "3005", "调兵山市" ], [ "3006", "开原市" ], [ "3013", "兴城市" ], [ "3034", "古交市" ], [ "3057", "介休市" ], [ "3071", "启东市" ], [ "3077", "二连浩特市" ], [ "3128", "格尔木市" ], [ "3129", "德令哈市" ], [ "3142", "都江堰市" ], [ "3143", "彭州市" ], [ "3145", "邛崃市" ], [ "3151", "崇州市" ], [ "3173", "江油市" ], [ "3188", "锡林浩特市" ], [ "3205", "峨眉山市" ], [ "3224", "绵竹市" ], [ "3228", "广汉市" ], [ "3229", "什邡市" ], [ "3243", "津市市" ], [ "3254", "沅江市" ], [ "3267", "资兴市" ], [ "3283", "冷水江市" ], [ "3284", "涟源市" ], [ "3285", "吉首市" ] ],
            area: [ [ "395", "四子王旗" ], [ "397", "阿巴嘎旗" ], [ "398", "宝塔区" ], [ "399", "双阳区" ], [ "400", "农安县" ], [ "404", "东昌区" ], [ "405", "二道江区" ], [ "406", "通化县" ], [ "407", "辉南县" ], [ "408", "柳河县" ], [ "409", "延长县" ], [ "412", "洮北区" ], [ "413", "镇赉县" ], [ "414", "通榆县" ], [ "417", "船营区" ], [ "418", "昌邑区" ], [ "419", "龙潭区" ], [ "420", "延川县" ], [ "421", "丰满区" ], [ "422", "永吉县" ], [ "427", "铁西区" ], [ "428", "铁东区" ], [ "429", "梨树县" ], [ "430", "伊通满族自治县" ], [ "431", "子长县" ], [ "434", "龙山区" ], [ "435", "西安区" ], [ "436", "东丰县" ], [ "437", "东辽县" ], [ "438", "八道江区" ], [ "439", "抚松县" ], [ "440", "靖宇县" ], [ "441", "长白朝鲜族自治县" ], [ "442", "安塞县" ], [ "443", "江源县" ], [ "445", "宁江区" ], [ "446", "前郭尔罗斯蒙古族自治县" ], [ "447", "长岭县" ], [ "448", "乾安县" ], [ "449", "扶余县" ], [ "453", "志丹县" ], [ "457", "汪清县" ], [ "458", "安图县" ], [ "459", "中山区" ], [ "460", "西岗区" ], [ "461", "沙河口区" ], [ "462", "甘井子区" ], [ "463", "旅顺口区" ], [ "464", "吴旗县" ], [ "465", "金州区" ], [ "466", "长海县" ], [ "470", "和平区" ], [ "471", "沈河区" ], [ "472", "大东区" ], [ "473", "皇姑区" ], [ "474", "铁西区" ], [ "475", "甘泉县" ], [ "476", "苏家屯区" ], [ "477", "东陵区" ], [ "478", "新城子区" ], [ "479", "于洪区" ], [ "480", "古县" ], [ "485", "天宁区" ], [ "486", "富县" ], [ "487", "钟楼区" ], [ "488", "戚墅堰区" ], [ "489", "新北区" ], [ "490", "武进区" ], [ "493", "京口区" ], [ "494", "润州区" ], [ "495", "丹徒区" ], [ "497", "洛川县" ], [ "500", "大港开发区" ], [ "501", "丁卯开发区" ], [ "502", "广陵区" ], [ "503", "维扬区" ], [ "504", "邗江区" ], [ "505", "宝应县" ], [ "508", "苏尼特左旗" ], [ "509", "宜川县" ], [ "511", "开发区" ], [ "512", "清河区" ], [ "513", "楚州区" ], [ "514", "淮阴区" ], [ "515", "清浦区" ], [ "516", "涟水县" ], [ "517", "洪泽县" ], [ "518", "盱眙县" ], [ "519", "金湖县" ], [ "520", "黄龙县" ], [ "521", "连云区" ], [ "522", "新浦区" ], [ "523", "海州区" ], [ "524", "赣榆县" ], [ "525", "东海县" ], [ "526", "灌云县" ], [ "527", "灌南县" ], [ "528", "海陵区" ], [ "529", "高港区" ], [ "531", "黄陵县" ], [ "535", "云龙区" ], [ "536", "鼓楼区" ], [ "537", "九里区" ], [ "538", "泉山区" ], [ "539", "铜山县" ], [ "540", "贾汪区" ], [ "541", "丰县" ], [ "542", "汉滨区" ], [ "543", "沛县" ], [ "544", "睢宁县" ], [ "547", "铜山新区" ], [ "548", "盐都区" ], [ "549", "响水县" ], [ "550", "滨海县" ], [ "551", "阜宁县" ], [ "552", "射阳县" ], [ "553", "汉阴县" ], [ "554", "建湖县" ], [ "557", "亭湖区" ], [ "558", "宿城区" ], [ "559", "宿豫区" ], [ "560", "沭阳县" ], [ "561", "泗阳县" ], [ "562", "泗洪县" ], [ "563", "城关区" ], [ "564", "石泉县" ], [ "565", "七里河区" ], [ "566", "安宁区" ], [ "567", "红古区" ], [ "568", "西固区" ], [ "569", "永登县" ], [ "570", "皋兰县" ], [ "571", "榆中县" ], [ "572", "嘉峪关市" ], [ "573", "秦城区" ], [ "574", "北道区" ], [ "575", "宁陕县" ], [ "576", "清水县" ], [ "577", "秦安县" ], [ "578", "甘谷县" ], [ "579", "武山县" ], [ "580", "张家川回族自治县" ], [ "581", "白银区" ], [ "582", "平川区" ], [ "583", "靖远县" ], [ "584", "会宁县" ], [ "585", "景泰县" ], [ "586", "紫阳县" ], [ "587", "凉州区" ], [ "588", "民勤县" ], [ "589", "古浪县" ], [ "590", "天祝藏族自治县" ], [ "591", "甘州区" ], [ "592", "肃南裕固族自治县" ], [ "593", "民乐县" ], [ "594", "临泽县" ], [ "595", "高台县" ], [ "596", "山丹县" ], [ "597", "岚皋县" ], [ "598", "崆峒区" ], [ "599", "泾川县" ], [ "600", "灵台县" ], [ "601", "崇信县" ], [ "602", "华亭县" ], [ "603", "庄浪县" ], [ "604", "静宁县" ], [ "605", "肃州区" ], [ "606", "金塔县" ], [ "607", "安西县" ], [ "608", "平利县" ], [ "609", "肃北蒙古族自治县" ], [ "610", "阿克塞哈萨克族自治县" ], [ "613", "西峰区" ], [ "614", "庆城县" ], [ "615", "环县" ], [ "616", "华池县" ], [ "617", "合水县" ], [ "618", "正宁县" ], [ "619", "苏尼特右旗" ], [ "620", "镇坪县" ], [ "621", "宁县" ], [ "622", "镇原县" ], [ "623", "安定区" ], [ "624", "通渭县" ], [ "625", "陇西县" ], [ "626", "渭源县" ], [ "627", "成县" ], [ "628", "镇沅彝族哈尼族拉祜族自治县" ], [ "629", "江城哈尼族彝族自治县" ], [ "630", "孟连傣族拉祜族佤族自治县" ], [ "631", "旬阳县" ], [ "632", "澜沧拉祜族自治县" ], [ "633", "西盟佤族自治县" ], [ "634", "文山县" ], [ "635", "砚山县" ], [ "636", "西畴县" ], [ "637", "麻栗坡县" ], [ "638", "马关县" ], [ "639", "丘北县" ], [ "640", "广南县" ], [ "641", "富宁县" ], [ "642", "白河县" ], [ "645", "蒙自县" ], [ "646", "屏边苗族自治县" ], [ "647", "建水县" ], [ "648", "石屏县" ], [ "649", "弥勒县" ], [ "650", "泸西县" ], [ "651", "元阳县" ], [ "652", "红河县" ], [ "653", "商州区" ], [ "654", "金平苗族瑶族傣族自治县" ], [ "655", "绿春县" ], [ "656", "河口瑶族自治县" ], [ "658", "勐海县" ], [ "659", "勐腊县" ], [ "661", "双柏县" ], [ "662", "牟定县" ], [ "663", "南华县" ], [ "664", "洛南县" ], [ "665", "姚安县" ], [ "666", "大姚县" ], [ "667", "永仁县" ], [ "668", "元谋县" ], [ "669", "武定县" ], [ "670", "禄丰县" ], [ "673", "梁河县" ], [ "674", "盈江县" ], [ "675", "丹凤县" ], [ "676", "陇川县" ], [ "677", "泸水县" ], [ "678", "福贡县" ], [ "679", "贡山独龙族怒族自治县" ], [ "680", "兰坪白族普米族自治县" ], [ "681", "香格里拉县" ], [ "682", "德钦县" ], [ "683", "维西傈僳族自治县" ], [ "684", "上城区" ], [ "685", "下城区" ], [ "686", "商南县" ], [ "687", "江干区" ], [ "688", "拱墅区" ], [ "689", "西湖区" ], [ "690", "滨江区" ], [ "691", "萧山区" ], [ "692", "余杭区" ], [ "693", "桐庐县" ], [ "694", "淳安县" ], [ "697", "山阳县" ], [ "699", "鹿城区" ], [ "700", "龙湾区" ], [ "701", "瓯海区" ], [ "702", "洞头县" ], [ "703", "永嘉县" ], [ "704", "平阳县" ], [ "705", "苍南县" ], [ "706", "文成县" ], [ "707", "泰顺县" ], [ "708", "镇安县" ], [ "711", "越城区" ], [ "712", "绍兴县" ], [ "713", "新昌县" ], [ "717", "海曙区" ], [ "718", "江东区" ], [ "719", "柞水县" ], [ "720", "江北区" ], [ "721", "北仑区" ], [ "722", "镇海区" ], [ "723", "鄞州区" ], [ "724", "象山县" ], [ "725", "宁海县" ], [ "729", "金东区" ], [ "730", "东乌珠穆沁旗" ], [ "731", "城东区" ], [ "732", "婺城区" ], [ "733", "武义县" ], [ "734", "浦江县" ], [ "735", "磐安县" ], [ "740", "秀洲区" ], [ "741", "南湖区" ], [ "742", "城北区" ], [ "743", "嘉善县" ], [ "744", "海盐县" ], [ "748", "定海区" ], [ "749", "普陀区" ], [ "750", "岱山县" ], [ "751", "嵊泗县" ], [ "752", "吴兴区" ], [ "753", "城中区" ], [ "754", "南浔区" ], [ "755", "德清县" ], [ "756", "长兴县" ], [ "757", "安吉县" ], [ "758", "柯城区" ], [ "759", "衢江区" ], [ "760", "常山县" ], [ "761", "开化县" ], [ "762", "龙游县" ], [ "764", "铁山区" ], [ "765", "莲都区" ], [ "766", "青田县" ], [ "767", "缙云县" ], [ "768", "遂昌县" ], [ "769", "松阳县" ], [ "770", "云和县" ], [ "771", "庆元县" ], [ "772", "景宁畲族自治县" ], [ "774", "椒江区" ], [ "775", "阳新县" ], [ "776", "路桥区" ], [ "777", "黄岩区" ], [ "778", "玉环县" ], [ "779", "三门县" ], [ "780", "天台县" ], [ "781", "仙居县" ], [ "784", "鼓楼区" ], [ "785", "台江区" ], [ "787", "仓山区" ], [ "788", "晋安区" ], [ "789", "金山开发区" ], [ "790", "马尾区" ], [ "791", "闽侯县" ], [ "792", "连江县" ], [ "793", "罗源县" ], [ "794", "闽清县" ], [ "795", "永泰县" ], [ "796", "平潭县" ], [ "797", "张湾区" ], [ "800", "思明区" ], [ "801", "湖里区" ], [ "802", "同安区" ], [ "803", "海沧区" ], [ "804", "集美区" ], [ "805", "翔安区" ], [ "806", "鲤城区" ], [ "807", "泉港区" ], [ "808", "茅箭区" ], [ "809", "丰泽区" ], [ "813", "德化县" ], [ "814", "永春县" ], [ "815", "安溪县" ], [ "816", "洛江区" ], [ "817", "惠安县" ], [ "818", "金门县" ], [ "819", "郧县" ], [ "820", "芗城区" ], [ "821", "龙文区" ], [ "823", "漳浦县" ], [ "824", "东山县" ], [ "825", "诏安县" ], [ "826", "平和县" ], [ "827", "华安县" ], [ "828", "长泰县" ], [ "829", "南靖县" ], [ "830", "郧西县" ], [ "831", "云霄县" ], [ "832", "城厢区" ], [ "833", "荔城区" ], [ "834", "涵江区" ], [ "835", "秀屿区" ], [ "836", "仙游县" ], [ "837", "新罗区" ], [ "838", "长汀县" ], [ "839", "永定县" ], [ "840", "上杭县" ], [ "841", "西乌珠穆沁旗" ], [ "842", "竹山县" ], [ "843", "武平县" ], [ "844", "连城县" ], [ "846", "梅列区" ], [ "847", "三元区" ], [ "848", "明溪县" ], [ "849", "清流县" ], [ "850", "宁化县" ], [ "851", "大田县" ], [ "852", "尤溪县" ], [ "853", "竹溪县" ], [ "854", "沙县" ], [ "855", "将乐县" ], [ "856", "泰宁县" ], [ "857", "建宁县" ], [ "859", "延平区" ], [ "860", "顺昌县" ], [ "861", "浦城县" ], [ "862", "光泽县" ], [ "863", "松溪县" ], [ "864", "房县" ], [ "865", "政和县" ], [ "870", "蕉城区" ], [ "871", "霞浦县" ], [ "872", "古田县" ], [ "873", "屏南县" ], [ "874", "寿宁县" ], [ "876", "周宁县" ], [ "877", "柘荣县" ], [ "880", "云岩区" ], [ "881", "南明区" ], [ "882", "乌当区" ], [ "883", "花溪区" ], [ "884", "白云区" ], [ "885", "小河区" ], [ "886", "梁子湖区" ], [ "887", "开阳县" ], [ "888", "息烽县" ], [ "889", "修文县" ], [ "891", "红花岗区" ], [ "892", "汇川区" ], [ "895", "遵义县" ], [ "896", "绥阳县" ], [ "897", "华容区" ], [ "898", "桐梓县" ], [ "899", "习水县" ], [ "900", "正安县" ], [ "901", "余庆县" ], [ "902", "湄潭县" ], [ "903", "道真仡佬族苗族自治县" ], [ "904", "务川仡佬族苗族自治县" ], [ "905", "凤冈县" ], [ "906", "钟山区" ], [ "907", "六枝特区" ], [ "908", "鄂城区" ], [ "909", "水城县" ], [ "910", "盘县" ], [ "912", "兴仁县" ], [ "913", "普安县" ], [ "914", "晴隆县" ], [ "915", "贞丰县" ], [ "916", "望谟县" ], [ "917", "册亨县" ], [ "918", "安龙县" ], [ "919", "东宝区" ], [ "920", "西秀区" ], [ "921", "普定县" ], [ "922", "平坝县" ], [ "923", "镇宁布依族苗族自治县" ], [ "924", "紫云苗族布依族自治县" ], [ "925", "关岭布依族苗族自治县" ], [ "927", "江口县" ], [ "928", "玉屏侗族自治县" ], [ "929", "石阡县" ], [ "930", "掇刀区" ], [ "931", "思南县" ], [ "932", "印江土家族苗族自治县" ], [ "933", "德江县" ], [ "934", "沿河土家族自治县" ], [ "935", "松桃苗族自治县" ], [ "936", "万山特区" ], [ "938", "大方县" ], [ "939", "黔西县" ], [ "940", "金沙县" ], [ "941", "京山县" ], [ "942", "织金县" ], [ "943", "纳雍县" ], [ "944", "威宁彝族回族苗族自治县" ], [ "945", "赫章县" ], [ "947", "黄平县" ], [ "948", "施秉县" ], [ "949", "三穗县" ], [ "950", "镇远县" ], [ "951", "岑巩县" ], [ "952", "太仆寺旗" ], [ "953", "沙洋县" ], [ "954", "天柱县" ], [ "955", "锦屏县" ], [ "956", "剑河县" ], [ "957", "台江县" ], [ "958", "黎平县" ], [ "959", "榕江县" ], [ "960", "从江县" ], [ "961", "雷山县" ], [ "962", "麻江县" ], [ "963", "丹寨县" ], [ "967", "荔波县" ], [ "968", "贵定县" ], [ "969", "瓮安县" ], [ "970", "独山县" ], [ "971", "平塘县" ], [ "972", "罗甸县" ], [ "973", "长顺县" ], [ "974", "龙里县" ], [ "975", "孝南区" ], [ "976", "惠水县" ], [ "977", "三都水族自治县" ], [ "978", "西湖区" ], [ "979", "东湖区" ], [ "980", "青山湖区" ], [ "981", "青云谱区" ], [ "982", "高新区" ], [ "983", "昌北经济开发区" ], [ "984", "红谷滩新区" ], [ "985", "湾里区" ], [ "986", "孝昌县" ], [ "987", "南昌县" ], [ "988", "新建县" ], [ "989", "安义县" ], [ "990", "进贤县" ], [ "991", "庐山区" ], [ "992", "浔阳区" ], [ "993", "九江县" ], [ "994", "武宁县" ], [ "995", "修水县" ], [ "996", "永修县" ], [ "997", "大悟县" ], [ "998", "德安县" ], [ "999", "星子县" ], [ "1000", "都昌县" ], [ "1001", "湖口县" ], [ "1002", "彭泽县" ], [ "1004", "信州区" ], [ "1005", "上饶县" ], [ "1006", "广丰县" ], [ "1007", "玉山县" ], [ "1008", "云梦县" ], [ "1009", "铅山县" ], [ "1010", "横峰县" ], [ "1011", "弋阳县" ], [ "1012", "余干县" ], [ "1013", "鄱阳县" ], [ "1014", "万年县" ], [ "1015", "婺源县" ], [ "1017", "袁州区" ], [ "1018", "奉新县" ], [ "1020", "万载县" ], [ "1021", "上高县" ], [ "1022", "宜丰县" ], [ "1023", "靖安县" ], [ "1024", "铜鼓县" ], [ "1028", "吉州区" ], [ "1029", "青原区" ], [ "1031", "吉安县" ], [ "1032", "吉水县" ], [ "1033", "峡江县" ], [ "1034", "新干县" ], [ "1035", "永丰县" ], [ "1036", "泰和县" ], [ "1037", "遂川县" ], [ "1038", "万安县" ], [ "1039", "安福县" ], [ "1040", "永新县" ], [ "1043", "章贡区" ], [ "1044", "赣县" ], [ "1045", "信丰县" ], [ "1046", "大余县" ], [ "1047", "上犹县" ], [ "1048", "崇义县" ], [ "1049", "安远县" ], [ "1050", "龙南县" ], [ "1051", "定南县" ], [ "1052", "沙市区" ], [ "1053", "全南县" ], [ "1054", "宁都县" ], [ "1055", "于都县" ], [ "1056", "兴国县" ], [ "1057", "会昌县" ], [ "1058", "寻乌县" ], [ "1059", "石城县" ], [ "1062", "珠山区" ], [ "1063", "镶黄旗" ], [ "1064", "荆州区" ], [ "1065", "昌江区" ], [ "1066", "浮梁县" ], [ "1068", "安源区" ], [ "1069", "湘东区" ], [ "1070", "莲花县" ], [ "1071", "上栗县" ], [ "1072", "芦溪县" ], [ "1073", "渝水区" ], [ "1074", "分宜县" ], [ "1075", "公安县" ], [ "1076", "月湖区" ], [ "1077", "余江县" ], [ "1079", "临川区" ], [ "1080", "南城县" ], [ "1081", "黎川县" ], [ "1082", "南丰县" ], [ "1083", "崇仁县" ], [ "1084", "乐安县" ], [ "1085", "宜黄县" ], [ "1086", "监利县" ], [ "1087", "金溪县" ], [ "1088", "资溪县" ], [ "1089", "东乡县" ], [ "1090", "广昌县" ], [ "1091", "青秀区" ], [ "1092", "兴宁区" ], [ "1093", "西乡塘区" ], [ "1094", "江南区" ], [ "1095", "良庆区" ], [ "1096", "邕宁区" ], [ "1097", "江陵县" ], [ "1098", "武鸣县" ], [ "1099", "隆安县" ], [ "1100", "马山县" ], [ "1101", "上林县" ], [ "1102", "宾阳县" ], [ "1103", "横县" ], [ "1104", "柳北区" ], [ "1105", "柳南区" ], [ "1106", "鱼峰区" ], [ "1107", "高新区" ], [ "1109", "城中区" ], [ "1110", "柳江县" ], [ "1111", "柳城县" ], [ "1112", "鹿寨县" ], [ "1113", "融安县" ], [ "1114", "融水苗族自治县" ], [ "1115", "三江侗族自治县" ], [ "1116", "秀峰区" ], [ "1117", "叠彩区" ], [ "1118", "象山区" ], [ "1120", "七星区" ], [ "1121", "雁山区" ], [ "1122", "阳朔县" ], [ "1123", "临桂县" ], [ "1124", "灵川县" ], [ "1125", "全州县" ], [ "1126", "兴安县" ], [ "1127", "灌阳县" ], [ "1128", "荔浦县" ], [ "1129", "资源县" ], [ "1131", "平乐县" ], [ "1132", "永福县" ], [ "1133", "龙胜各族自治县" ], [ "1134", "恭城瑶族自治县" ], [ "1135", "海城区" ], [ "1136", "银海区" ], [ "1137", "铁山港区" ], [ "1138", "合浦县" ], [ "1139", "玉州区" ], [ "1141", "黄州区" ], [ "1142", "容县" ], [ "1143", "陆川县" ], [ "1144", "博白县" ], [ "1145", "兴业县" ], [ "1146", "万秀区" ], [ "1147", "蝶山区" ], [ "1148", "长洲区" ], [ "1149", "苍梧县" ], [ "1150", "藤县" ], [ "1151", "蒙山县" ], [ "1152", "团风县" ], [ "1154", "港口区" ], [ "1155", "防城区" ], [ "1156", "上思县" ], [ "1158", "钦南区" ], [ "1159", "钦北区" ], [ "1160", "灵山县" ], [ "1161", "浦北县" ], [ "1162", "港北区" ], [ "1163", "红安县" ], [ "1164", "港南区" ], [ "1165", "覃塘区" ], [ "1166", "平南县" ], [ "1168", "右江区" ], [ "1169", "田阳县" ], [ "1170", "田东县" ], [ "1171", "平果县" ], [ "1172", "德保县" ], [ "1173", "靖西县" ], [ "1174", "正镶白旗" ], [ "1175", "罗田县" ], [ "1176", "那坡县" ], [ "1177", "凌云县" ], [ "1178", "乐业县" ], [ "1179", "田林县" ], [ "1180", "西林县" ], [ "1181", "隆林各族自治县" ], [ "1182", "八步区" ], [ "1183", "昭平县" ], [ "1184", "钟山县" ], [ "1185", "富川瑶族自治县" ], [ "1186", "英山县" ], [ "1187", "金城江区" ], [ "1188", "南丹县" ], [ "1189", "天峨县" ], [ "1190", "凤山县" ], [ "1191", "东兰县" ], [ "1192", "罗城仫佬族自治县" ], [ "1193", "环江毛南族自治县" ], [ "1194", "巴马瑶族自治县" ], [ "1195", "都安瑶族自治县" ], [ "1196", "大化瑶族自治县" ], [ "1197", "浠水县" ], [ "1199", "兴宾区" ], [ "1200", "忻城县" ], [ "1201", "象州县" ], [ "1202", "武宣县" ], [ "1203", "金秀瑶族自治县" ], [ "1205", "江洲区" ], [ "1206", "扶绥县" ], [ "1207", "宁明县" ], [ "1208", "蕲春县" ], [ "1209", "龙州县" ], [ "1210", "大新县" ], [ "1211", "天等县" ], [ "1213", "城关区" ], [ "1214", "林周县" ], [ "1215", "当雄县" ], [ "1216", "尼木县" ], [ "1217", "曲水县" ], [ "1218", "堆龙德庆县" ], [ "1219", "黄梅县" ], [ "1220", "达孜县" ], [ "1221", "墨竹工卡县" ], [ "1223", "南木林县" ], [ "1224", "江孜县" ], [ "1225", "定日县" ], [ "1226", "萨迦县" ], [ "1227", "拉孜县" ], [ "1228", "昂仁县" ], [ "1229", "谢通门县" ], [ "1231", "白朗县" ], [ "1232", "仁布县" ], [ "1233", "康马县" ], [ "1234", "定结县" ], [ "1235", "仲巴县" ], [ "1236", "亚东县" ], [ "1237", "吉隆县" ], [ "1238", "聂拉木县" ], [ "1239", "萨嘎县" ], [ "1240", "岗巴县" ], [ "1242", "乃东县" ], [ "1243", "扎囊县" ], [ "1244", "贡嘎县" ], [ "1245", "桑日县" ], [ "1246", "琼结县" ], [ "1247", "曲松县" ], [ "1248", "措美县" ], [ "1249", "洛扎县" ], [ "1250", "加查县" ], [ "1251", "隆子县" ], [ "1252", "咸安区" ], [ "1253", "错那县" ], [ "1254", "浪卡子县" ], [ "1255", "普兰县" ], [ "1256", "札达县" ], [ "1257", "噶尔县" ], [ "1258", "日土县" ], [ "1259", "革吉县" ], [ "1260", "改则县" ], [ "1261", "措勤县" ], [ "1262", "昌都县" ], [ "1263", "嘉鱼县" ], [ "1264", "江达县" ], [ "1265", "贡觉县" ], [ "1266", "类乌齐县" ], [ "1267", "丁青县" ], [ "1268", "察雅县" ], [ "1269", "八宿县" ], [ "1270", "左贡县" ], [ "1271", "芒康县" ], [ "1272", "洛隆县" ], [ "1273", "边坝县" ], [ "1274", "通城县" ], [ "1275", "那曲县" ], [ "1276", "嘉黎县" ], [ "1277", "比如县" ], [ "1278", "聂荣县" ], [ "1279", "安多县" ], [ "1280", "申扎县" ], [ "1281", "索县" ], [ "1282", "班戈县" ], [ "1283", "巴青县" ], [ "1284", "尼玛县" ], [ "1285", "正蓝旗" ], [ "1286", "崇阳县" ], [ "1287", "林芝县" ], [ "1288", "工布江达县" ], [ "1289", "米林县" ], [ "1290", "墨脱县" ], [ "1291", "波密县" ], [ "1292", "察隅县" ], [ "1293", "朗县" ], [ "1294", "渝中区" ], [ "1295", "沙坪坝区" ], [ "1296", "九龙坡区" ], [ "1297", "通山县" ], [ "1298", "江北区" ], [ "1299", "南岸区" ], [ "1300", "大渡口区" ], [ "1301", "高新区" ], [ "1302", "渝北区" ], [ "1303", "巴南区" ], [ "1304", "北碚区" ], [ "1305", "万盛区" ], [ "1306", "双桥区" ], [ "1307", "万州区" ], [ "1309", "涪陵区" ], [ "1310", "黔江区" ], [ "1311", "长寿区" ], [ "1316", "綦江县" ], [ "1317", "潼南县" ], [ "1318", "铜梁县" ], [ "1319", "曾都区" ], [ "1320", "大足县" ], [ "1321", "荣昌县" ], [ "1322", "璧山县" ], [ "1323", "梁平县" ], [ "1324", "城口县" ], [ "1325", "丰都县" ], [ "1326", "垫江县" ], [ "1327", "武隆县" ], [ "1328", "忠县" ], [ "1329", "开县" ], [ "1331", "云阳县" ], [ "1332", "奉节县" ], [ "1333", "巫山县" ], [ "1334", "巫溪县" ], [ "1335", "石柱土家族自治县" ], [ "1336", "秀山土家族苗族自治县" ], [ "1337", "酉阳土家族苗族自治县" ], [ "1338", "彭水苗族土家族自治县" ], [ "1339", "下陆区" ], [ "1340", "高新区" ], [ "1342", "如东县" ], [ "1343", "临洮县" ], [ "1344", "岷县" ], [ "1345", "文县" ], [ "1346", "宕昌县" ], [ "1347", "康县" ], [ "1348", "西和县" ], [ "1349", "礼县" ], [ "1350", "徽县" ], [ "1351", "两当县" ], [ "1354", "临夏县" ], [ "1355", "康乐县" ], [ "1356", "永靖县" ], [ "1357", "广河县" ], [ "1358", "和政县" ], [ "1359", "东乡族自治县" ], [ "1360", "积石山保安族东乡族撒拉族自治县" ], [ "1362", "临潭县" ], [ "1363", "建始县" ], [ "1364", "卓尼县" ], [ "1365", "舟曲县" ], [ "1366", "迭部县" ], [ "1367", "玛曲县" ], [ "1368", "碌曲县" ], [ "1369", "夏河县" ], [ "1370", "金川区" ], [ "1371", "永昌县" ], [ "1372", "兴庆区" ], [ "1373", "金凤区" ], [ "1374", "巴东县" ], [ "1375", "西夏区" ], [ "1376", "永宁县" ], [ "1377", "贺兰县" ], [ "1379", "大武口区" ], [ "1380", "惠农区" ], [ "1381", "平罗县" ], [ "1382", "利通区" ], [ "1383", "盐池县" ], [ "1384", "同心县" ], [ "1385", "宣恩县" ], [ "1387", "原州区" ], [ "1388", "西吉县" ], [ "1389", "隆德县" ], [ "1390", "泾源县" ], [ "1391", "彭阳县" ], [ "1392", "沙坡头区" ], [ "1393", "中宁县" ], [ "1394", "海原县" ], [ "1395", "五华区" ], [ "1396", "多伦县" ], [ "1397", "咸丰县" ], [ "1398", "盘龙区" ], [ "1399", "西山区" ], [ "1400", "官渡区" ], [ "1401", "东川区" ], [ "1402", "呈贡县" ], [ "1403", "晋宁县" ], [ "1404", "富民县" ], [ "1405", "宜良县" ], [ "1406", "石林彝族自治县" ], [ "1407", "嵩明县" ], [ "1408", "来凤县" ], [ "1409", "禄劝彝族苗族自治县" ], [ "1410", "寻甸回族彝族自治县" ], [ "1412", "昭阳区" ], [ "1413", "鲁甸县" ], [ "1414", "巧家县" ], [ "1415", "盐津县" ], [ "1416", "大关县" ], [ "1417", "永善县" ], [ "1418", "绥江县" ], [ "1419", "鹤峰县" ], [ "1420", "镇雄县" ], [ "1421", "彝良县" ], [ "1422", "威信县" ], [ "1423", "水富县" ], [ "1425", "漾濞彝族自治县" ], [ "1426", "祥云县" ], [ "1427", "宾川县" ], [ "1428", "弥渡县" ], [ "1429", "南涧彝族自治县" ], [ "1430", "仙桃市" ], [ "1431", "巍山彝族回族自治县" ], [ "1432", "永平县" ], [ "1433", "云龙县" ], [ "1434", "洱源县" ], [ "1435", "剑川县" ], [ "1436", "鹤庆县" ], [ "1437", "临翔区" ], [ "1438", "凤庆县" ], [ "1439", "云县" ], [ "1440", "永德县" ], [ "1441", "潜江市" ], [ "1442", "镇康县" ], [ "1443", "双江拉祜族佤族布朗族傣族自治县" ], [ "1444", "耿马傣族佤族自治县" ], [ "1445", "沧源佤族自治县" ], [ "1447", "马龙县" ], [ "1448", "陆良县" ], [ "1449", "师宗县" ], [ "1450", "罗平县" ], [ "1451", "富源县" ], [ "1452", "天门市" ], [ "1453", "会泽县" ], [ "1454", "沾益县" ], [ "1455", "麒麟区" ], [ "1456", "江川县" ], [ "1457", "澄江县" ], [ "1458", "通海县" ], [ "1459", "华宁县" ], [ "1460", "易门县" ], [ "1461", "峨山彝族自治县" ], [ "1462", "新平彝族傣族自治县" ], [ "1463", "芙蓉区" ], [ "1464", "元江哈尼族彝族傣族自治县" ], [ "1465", "红塔区" ], [ "1466", "隆阳区" ], [ "1467", "施甸县" ], [ "1468", "腾冲县" ], [ "1469", "龙陵县" ], [ "1470", "昌宁县" ], [ "1471", "古城区" ], [ "1472", "玉龙纳西族自治县" ], [ "1473", "永胜县" ], [ "1474", "开福区" ], [ "1475", "华坪县" ], [ "1476", "宁蒗彝族自治县" ], [ "1477", "思茅区" ], [ "1478", "宁洱哈尼族彝族自治县" ], [ "1479", "墨江哈尼族自治县" ], [ "1480", "景东彝族自治县" ], [ "1481", "景谷傣族彝族自治县" ], [ "1482", "容城县" ], [ "1484", "魏都区" ], [ "1485", "天心区" ], [ "1486", "许昌县" ], [ "1487", "鄢陵县" ], [ "1488", "襄城县" ], [ "1491", "平桥区" ], [ "1492", "浉河区" ], [ "1493", "罗山县" ], [ "1494", "光山县" ], [ "1495", "新县" ], [ "1496", "雨花区" ], [ "1497", "商城县" ], [ "1498", "固始县" ], [ "1499", "潢川县" ], [ "1500", "淮滨县" ], [ "1501", "息县" ], [ "1502", "卧龙区" ], [ "1503", "宛城区" ], [ "1504", "南召县" ], [ "1505", "方城县" ], [ "1506", "西峡县" ], [ "1508", "阿拉善左旗" ], [ "1509", "岳麓区" ], [ "1510", "镇平县" ], [ "1511", "内乡县" ], [ "1512", "淅川县" ], [ "1513", "社旗县" ], [ "1514", "唐河县" ], [ "1515", "新野县" ], [ "1516", "桐柏县" ], [ "1518", "鼓楼区" ], [ "1519", "龙亭区" ], [ "1520", "长沙县" ], [ "1521", "顺河回族区" ], [ "1522", "禹王台区" ], [ "1523", "金明区" ], [ "1524", "杞县" ], [ "1525", "通许县" ], [ "1526", "尉氏县" ], [ "1527", "开封县" ], [ "1528", "兰考县" ], [ "1529", "西工区" ], [ "1530", "老城区" ], [ "1531", "望城县" ], [ "1532", "涧西区" ], [ "1533", "瀍河回族区" ], [ "1534", "洛龙区" ], [ "1535", "吉利区" ], [ "1536", "孟津县" ], [ "1537", "新安县" ], [ "1538", "栾川县" ], [ "1539", "嵩县" ], [ "1540", "汝阳县" ], [ "1541", "宜阳县" ], [ "1542", "宁乡县" ], [ "1543", "洛宁县" ], [ "1544", "伊川县" ], [ "1546", "马村区" ], [ "1547", "山阳区" ], [ "1548", "解放区" ], [ "1549", "中站区" ], [ "1550", "修武县" ], [ "1551", "博爱县" ], [ "1552", "武陟县" ], [ "1554", "温县" ], [ "1557", "召陵区" ], [ "1558", "源汇区" ], [ "1559", "郾城区" ], [ "1560", "舞阳县" ], [ "1561", "临颍县" ], [ "1562", "华龙区" ], [ "1563", "清丰县" ], [ "1564", "岳阳楼区" ], [ "1565", "南乐县" ], [ "1566", "范县" ], [ "1567", "台前县" ], [ "1568", "濮阳县" ], [ "1569", "新华区" ], [ "1570", "卫东区" ], [ "1571", "石龙区" ], [ "1572", "湛河区" ], [ "1573", "宝丰县" ], [ "1574", "叶县" ], [ "1575", "君山区" ], [ "1576", "鲁山县" ], [ "1577", "郏县" ], [ "1580", "鹤山区" ], [ "1581", "山城区" ], [ "1582", "淇滨区" ], [ "1583", "浚县" ], [ "1584", "淇县" ], [ "1585", "湖滨区" ], [ "1586", "云溪区" ], [ "1587", "渑池县" ], [ "1588", "陕县" ], [ "1589", "卢氏县" ], [ "1592", "川汇区" ], [ "1593", "扶沟县" ], [ "1594", "西华县" ], [ "1595", "商水县" ], [ "1596", "沈丘县" ], [ "1597", "岳阳县" ], [ "1598", "郸城县" ], [ "1599", "淮阳县" ], [ "1600", "太康县" ], [ "1601", "鹿邑县" ], [ "1603", "驿城区" ], [ "1604", "西平县" ], [ "1605", "上蔡县" ], [ "1606", "平舆县" ], [ "1607", "正阳县" ], [ "1608", "华容县" ], [ "1609", "确山县" ], [ "1610", "泌阳县" ], [ "1611", "汝南县" ], [ "1612", "遂平县" ], [ "1613", "新蔡县" ], [ "1614", "济源市" ], [ "1615", "瑶海区" ], [ "1616", "庐阳区" ], [ "1617", "蜀山区" ], [ "1618", "包河区" ], [ "1619", "阿拉善右旗" ], [ "1620", "湘阴县" ], [ "1621", "长丰县" ], [ "1622", "肥东县" ], [ "1623", "肥西县" ], [ "1624", "龙子湖区" ], [ "1625", "蚌山区" ], [ "1626", "禹会区" ], [ "1627", "淮上区" ], [ "1628", "怀远县" ], [ "1629", "五河县" ], [ "1630", "固镇县" ], [ "1631", "平江县" ], [ "1632", "安泽县" ], [ "1633", "浮山县" ], [ "1634", "吉县" ], [ "1635", "乡宁县" ], [ "1636", "大宁县" ], [ "1637", "隰县" ], [ "1638", "永和县" ], [ "1639", "蒲县" ], [ "1640", "汾西县" ], [ "1646", "临猗县" ], [ "1647", "万荣县" ], [ "1648", "闻喜县" ], [ "1649", "稷山县" ], [ "1650", "新绛县" ], [ "1651", "绛县" ], [ "1652", "垣曲县" ], [ "1654", "夏县" ], [ "1655", "平陆县" ], [ "1656", "芮城县" ], [ "1657", "盐湖区" ], [ "1658", "忻府区" ], [ "1659", "定襄县" ], [ "1660", "五台县" ], [ "1661", "代县" ], [ "1662", "繁峙县" ], [ "1663", "宁武县" ], [ "1664", "天元区" ], [ "1665", "静乐县" ], [ "1666", "神池县" ], [ "1667", "五寨县" ], [ "1668", "岢岚县" ], [ "1669", "河曲县" ], [ "1670", "保德县" ], [ "1671", "偏关县" ], [ "1673", "朔城区" ], [ "1674", "平鲁区" ], [ "1675", "荷塘区" ], [ "1676", "山阴县" ], [ "1677", "应县" ], [ "1678", "右玉县" ], [ "1679", "怀仁县" ], [ "1680", "城区" ], [ "1681", "矿区" ], [ "1682", "郊区" ], [ "1683", "平定县" ], [ "1684", "盂县" ], [ "1685", "城区" ], [ "1686", "芦淞区" ], [ "1687", "沁水县" ], [ "1688", "阳城县" ], [ "1689", "陵川县" ], [ "1690", "泽州县" ], [ "1692", "城区" ], [ "1693", "长治县" ], [ "1695", "郊区" ], [ "1696", "襄垣县" ], [ "1697", "石峰区" ], [ "1698", "屯留县" ], [ "1699", "平顺县" ], [ "1700", "黎城县" ], [ "1701", "壶关县" ], [ "1702", "长子县" ], [ "1703", "武乡县" ], [ "1704", "沁县" ], [ "1705", "沁源县" ], [ "1708", "株洲县" ], [ "1709", "文水县" ], [ "1710", "交城县" ], [ "1711", "兴县" ], [ "1712", "临县" ], [ "1713", "柳林县" ], [ "1714", "石楼县" ], [ "1715", "岚县" ], [ "1716", "方山县" ], [ "1717", "中阳县" ], [ "1718", "交口县" ], [ "1719", "攸县" ], [ "1720", "离石区" ], [ "1721", "长安区" ], [ "1722", "桥西区" ], [ "1723", "新华区" ], [ "1724", "裕华区" ], [ "1725", "桥东区" ], [ "1726", "正定县" ], [ "1728", "井陉矿区" ], [ "1729", "井陉县" ], [ "1730", "额济纳旗" ], [ "1731", "茶陵县" ], [ "1732", "栾城县" ], [ "1733", "行唐县" ], [ "1734", "灵寿县" ], [ "1735", "高邑县" ], [ "1736", "深泽县" ], [ "1737", "赞皇县" ], [ "1738", "无极县" ], [ "1739", "平山县" ], [ "1740", "元氏县" ], [ "1741", "赵县" ], [ "1742", "炎陵县" ], [ "1747", "邯山区" ], [ "1748", "丛台区" ], [ "1749", "复兴区" ], [ "1750", "峰峰矿区" ], [ "1751", "邯郸县" ], [ "1752", "临漳县" ], [ "1754", "成安县" ], [ "1755", "大名县" ], [ "1756", "涉县" ], [ "1757", "磁县" ], [ "1758", "肥乡县" ], [ "1759", "永年县" ], [ "1760", "邱县" ], [ "1761", "鸡泽县" ], [ "1762", "广平县" ], [ "1763", "馆陶县" ], [ "1764", "雁峰区" ], [ "1765", "魏县" ], [ "1766", "曲周县" ], [ "1768", "新市区" ], [ "1769", "南市区" ], [ "1770", "北市区" ], [ "1771", "满城县" ], [ "1772", "徐水县" ], [ "1773", "清苑县" ], [ "1774", "涞水县" ], [ "1775", "珠晖区" ], [ "1776", "阜平县" ], [ "1777", "定兴县" ], [ "1778", "唐县" ], [ "1779", "高阳县" ], [ "1780", "惠民县" ], [ "1781", "阳信县" ], [ "1782", "无棣县" ], [ "1783", "沾化县" ], [ "1784", "博兴县" ], [ "1785", "邹平县" ], [ "1786", "石鼓区" ], [ "1787", "东港区" ], [ "1788", "岚山区" ], [ "1789", "五莲县" ], [ "1790", "莒县" ], [ "1791", "市中区" ], [ "1792", "薛城区" ], [ "1793", "峄城区" ], [ "1794", "台儿庄区" ], [ "1795", "山亭区" ], [ "1797", "蒸湘区" ], [ "1798", "东营区" ], [ "1799", "河口区" ], [ "1800", "垦利县" ], [ "1801", "利津县" ], [ "1802", "广饶县" ], [ "1803", "兰山区" ], [ "1804", "罗庄区" ], [ "1805", "河东区" ], [ "1806", "沂南县" ], [ "1807", "郯城县" ], [ "1808", "南岳区" ], [ "1809", "沂水县" ], [ "1810", "苍山县" ], [ "1811", "费县" ], [ "1812", "平邑县" ], [ "1813", "莒南县" ], [ "1814", "蒙阴县" ], [ "1815", "临沭县" ], [ "1816", "莱城区" ], [ "1817", "钢城区" ], [ "1818", "白云区" ], [ "1819", "衡阳县" ], [ "1820", "广州大学城" ], [ "1821", "黄埔区" ], [ "1822", "萝岗区" ], [ "1823", "南沙区" ], [ "1826", "花都区" ], [ "1827", "番禺区" ], [ "1828", "荔湾区" ], [ "1829", "天河区" ], [ "1830", "衡南县" ], [ "1831", "越秀区" ], [ "1832", "海珠区" ], [ "1833", "罗湖区" ], [ "1834", "南山区" ], [ "1835", "福田区" ], [ "1836", "宝安区" ], [ "1837", "龙岗区" ], [ "1838", "盐田区" ], [ "1839", "香洲区" ], [ "1840", "金湾区" ], [ "1841", "莲湖区" ], [ "1842", "衡山县" ], [ "1843", "斗门区" ], [ "1844", "中山市" ], [ "1845", "禅城区" ], [ "1846", "南海区" ], [ "1847", "顺德区" ], [ "1848", "三水区" ], [ "1849", "高明区" ], [ "1850", "东莞市" ], [ "1851", "惠城区" ], [ "1852", "惠阳区" ], [ "1853", "衡东县" ], [ "1854", "博罗县" ], [ "1855", "惠东县" ], [ "1856", "龙门县" ], [ "1857", "江海区" ], [ "1858", "新会区" ], [ "1863", "蓬江区" ], [ "1864", "祁东县" ], [ "1867", "广宁县" ], [ "1868", "德庆县" ], [ "1869", "封开县" ], [ "1870", "怀集县" ], [ "1871", "端州区" ], [ "1872", "鼎湖区" ], [ "1873", "龙湖区" ], [ "1874", "金平区" ], [ "1876", "澄海区" ], [ "1877", "潮阳区" ], [ "1878", "濠江区" ], [ "1879", "潮南区" ], [ "1880", "南澳县" ], [ "1881", "霞山区" ], [ "1882", "赤坎区" ], [ "1883", "开发区" ], [ "1884", "麻章区" ], [ "1887", "徐闻县" ], [ "1889", "遂溪县" ], [ "1891", "坡头区" ], [ "1892", "湘桥区" ], [ "1893", "潮安县" ], [ "1894", "饶平县" ], [ "1895", "云城区" ], [ "1897", "鹤城区" ], [ "1898", "新兴县" ], [ "1899", "云安县" ], [ "1900", "郁南县" ], [ "1901", "茂南区" ], [ "1902", "茂港区" ], [ "1906", "电白县" ], [ "1907", "江城区" ], [ "1908", "中方县" ], [ "1910", "阳西县" ], [ "1911", "阳东县" ], [ "1912", "城区" ], [ "1914", "海丰县" ], [ "1915", "陆河县" ], [ "1916", "榕城区" ], [ "1917", "东山区" ], [ "1919", "沅陵县" ], [ "1920", "揭东县" ], [ "1921", "揭西县" ], [ "1922", "惠来县" ], [ "1923", "梅江区" ], [ "1924", "梅县" ], [ "1926", "蕉岭县" ], [ "1927", "林口县" ], [ "1930", "辰溪县" ], [ "1933", "向阳区" ], [ "1934", "前进区" ], [ "1935", "东风区" ], [ "1936", "郊区" ], [ "1937", "桦南县" ], [ "1938", "桦川县" ], [ "1939", "汤原县" ], [ "1940", "抚远县" ], [ "1941", "溆浦县" ], [ "1944", "萨尔图区" ], [ "1945", "龙凤区" ], [ "1946", "让胡路区" ], [ "1947", "红岗区" ], [ "1948", "大同区" ], [ "1949", "肇州县" ], [ "1950", "肇源县" ], [ "1951", "林甸县" ], [ "1952", "新城区" ], [ "1953", "会同县" ], [ "1954", "杜尔伯特蒙古族自治县" ], [ "1955", "鸡冠区" ], [ "1956", "恒山区" ], [ "1957", "滴道区" ], [ "1958", "梨树区" ], [ "1959", "城子河区" ], [ "1960", "麻山区" ], [ "1961", "鸡东县" ], [ "1964", "麻阳苗族自治县" ], [ "1965", "向阳区" ], [ "1966", "工农区" ], [ "1967", "南山区" ], [ "1968", "兴安区" ], [ "1969", "东山区" ], [ "1970", "兴山区" ], [ "1971", "萝北县" ], [ "1972", "绥滨县" ], [ "1973", "尖山区" ], [ "1974", "岭东区" ], [ "1975", "新晃侗族自治县" ], [ "1976", "四方台区" ], [ "1977", "宝山区" ], [ "1978", "集贤县" ], [ "1979", "友谊县" ], [ "1980", "宝清县" ], [ "1981", "饶河县" ], [ "1982", "伊春区" ], [ "1983", "南岔区" ], [ "1984", "友好区" ], [ "1985", "西林区" ], [ "1986", "芷江侗族自治县" ], [ "1987", "翠峦区" ], [ "1988", "新青区" ], [ "1989", "美溪区" ], [ "1990", "金山屯区" ], [ "1991", "五营区" ], [ "1992", "乌马河区" ], [ "1993", "汤旺河区" ], [ "1994", "带岭区" ], [ "1995", "乌伊岭区" ], [ "1996", "红星区" ], [ "1997", "靖州苗族侗族自治县" ], [ "1998", "上甘岭区" ], [ "1999", "嘉荫县" ], [ "2001", "新兴区" ], [ "2002", "桃山区" ], [ "2003", "茄子河区" ], [ "2004", "勃利县" ], [ "2005", "爱辉区" ], [ "2006", "嫩江县" ], [ "2007", "逊克县" ], [ "2008", "通道侗族自治县" ], [ "2009", "孙吴县" ], [ "2012", "北林区" ], [ "2013", "望奎县" ], [ "2014", "兰西县" ], [ "2015", "青冈县" ], [ "2016", "庆安县" ], [ "2017", "明水县" ], [ "2018", "绥棱县" ], [ "2023", "呼玛县" ], [ "2024", "塔河县" ], [ "2025", "漠河县" ], [ "2026", "加格达奇区" ], [ "2027", "松岭区" ], [ "2028", "新林区" ], [ "2029", "呼中区" ], [ "2030", "雨湖区" ], [ "2031", "江岸区" ], [ "2032", "江汉区" ], [ "2033", "硚口区" ], [ "2034", "汉阳区" ], [ "2035", "武昌区" ], [ "2036", "青山区" ], [ "2037", "洪山区" ], [ "2038", "东西湖区" ], [ "2039", "汉南区" ], [ "2040", "蔡甸区" ], [ "2041", "岳塘区" ], [ "2042", "江夏区" ], [ "2043", "黄陂区" ], [ "2044", "新洲区" ], [ "2045", "襄城区" ], [ "2046", "樊城区" ], [ "2047", "襄阳区" ], [ "2048", "南漳县" ], [ "2049", "谷城县" ], [ "2050", "保康县" ], [ "2052", "湘潭县" ], [ "2055", "西陵区" ], [ "2056", "伍家岗区" ], [ "2057", "东山开发区" ], [ "2058", "点军区" ], [ "2059", "虢亭区" ], [ "2060", "夷陵区" ], [ "2061", "远安县" ], [ "2062", "兴山县" ], [ "2063", "碑林区" ], [ "2065", "秭归县" ], [ "2066", "长阳土家族自治县" ], [ "2067", "五峰土家族自治县" ], [ "2071", "神农架林区" ], [ "2072", "黄石港区" ], [ "2073", "西塞山区" ], [ "2074", "翼城县" ], [ "2076", "涞源县" ], [ "2077", "望都县" ], [ "2078", "安新县" ], [ "2079", "易县" ], [ "2080", "曲阳县" ], [ "2081", "蠡县" ], [ "2082", "顺平县" ], [ "2083", "博野县" ], [ "2084", "雄县" ], [ "2086", "双清区" ], [ "2090", "桥东区" ], [ "2091", "桥西区" ], [ "2092", "宣化区" ], [ "2093", "下花园区" ], [ "2094", "宣化县" ], [ "2095", "张北县" ], [ "2096", "康保县" ], [ "2097", "大祥区" ], [ "2098", "沽源县" ], [ "2099", "尚义县" ], [ "2100", "蔚县" ], [ "2101", "阳原县" ], [ "2102", "怀安县" ], [ "2103", "万全县" ], [ "2104", "怀来县" ], [ "2105", "涿鹿县" ], [ "2106", "赤城县" ], [ "2107", "崇礼县" ], [ "2108", "北塔区" ], [ "2109", "双桥区" ], [ "2110", "双滦区" ], [ "2111", "鹰手营子矿区" ], [ "2112", "承德县" ], [ "2113", "兴隆县" ], [ "2114", "平泉县" ], [ "2115", "滦平县" ], [ "2116", "隆化县" ], [ "2117", "丰宁满族自治县" ], [ "2118", "宽城满族自治县" ], [ "2119", "邵东县" ], [ "2120", "围场满族蒙古族自治县" ], [ "2121", "路北区" ], [ "2122", "路南区" ], [ "2123", "开平区" ], [ "2124", "丰南区" ], [ "2125", "古冶区" ], [ "2126", "丰润区" ], [ "2127", "滦县" ], [ "2128", "滦南县" ], [ "2129", "乐亭县" ], [ "2130", "新邵县" ], [ "2131", "迁西县" ], [ "2132", "玉田县" ], [ "2133", "唐海县" ], [ "2136", "运河区" ], [ "2137", "新华区" ], [ "2138", "沧县" ], [ "2140", "肃宁县" ], [ "2141", "邵阳县" ], [ "2142", "青县" ], [ "2143", "东光县" ], [ "2144", "海兴县" ], [ "2145", "盐山县" ], [ "2146", "南皮县" ], [ "2147", "吴桥县" ], [ "2148", "献县" ], [ "2149", "孟村回族自治县" ], [ "2152", "隆回县" ], [ "2154", "海港区" ], [ "2155", "山海关区" ], [ "2156", "北戴河区" ], [ "2157", "青龙满族自治县" ], [ "2158", "昌黎县" ], [ "2159", "抚宁县" ], [ "2160", "卢龙县" ], [ "2161", "开发区" ], [ "2162", "安次区" ], [ "2163", "洞口县" ], [ "2164", "广阳区" ], [ "2165", "固安县" ], [ "2166", "永清县" ], [ "2167", "香河县" ], [ "2168", "大城县" ], [ "2169", "文安县" ], [ "2170", "大厂回族自治县" ], [ "2174", "雁塔区" ], [ "2175", "绥宁县" ], [ "2176", "桃城区" ], [ "2177", "枣强县" ], [ "2178", "武邑县" ], [ "2179", "武强县" ], [ "2180", "饶阳县" ], [ "2181", "安平县" ], [ "2182", "故城县" ], [ "2183", "景县" ], [ "2184", "阜城县" ], [ "2186", "新宁县" ], [ "2187", "桥东区" ], [ "2188", "桥西区" ], [ "2189", "邢台县" ], [ "2190", "临城县" ], [ "2191", "内丘县" ], [ "2192", "柏乡县" ], [ "2193", "隆尧县" ], [ "2194", "任县" ], [ "2195", "南和县" ], [ "2196", "宁晋县" ], [ "2197", "城步苗族自治县" ], [ "2198", "巨鹿县" ], [ "2199", "新河县" ], [ "2200", "广宗县" ], [ "2201", "平乡县" ], [ "2202", "威县" ], [ "2203", "清河县" ], [ "2204", "临西县" ], [ "2207", "天山区" ], [ "2209", "沙依巴克区" ], [ "2210", "新市区" ], [ "2211", "水磨沟区" ], [ "2212", "头屯河区" ], [ "2213", "达坂城区" ], [ "2214", "米东区" ], [ "2215", "乌鲁木齐县" ], [ "2216", "独山子区" ], [ "2217", "克拉玛依区" ], [ "2218", "白碱滩区" ], [ "2219", "鼎城区" ], [ "2220", "乌尔禾区" ], [ "2221", "高新区" ], [ "2222", "漳县" ], [ "2224", "经济开发区" ], [ "2225", "镜湖区" ], [ "2226", "鸠江区" ], [ "2227", "芜湖县" ], [ "2228", "繁昌县" ], [ "2229", "南陵县" ], [ "2230", "辽中县" ], [ "2231", "弋江区" ], [ "2232", "三山区" ], [ "2233", "大通区" ], [ "2234", "田家庵区" ], [ "2235", "谢家集区" ], [ "2236", "八公山区" ], [ "2237", "潘集区" ], [ "2238", "凤台县" ], [ "2239", "雨山区" ], [ "2240", "花山区" ], [ "2241", "襄汾县" ], [ "2242", "金家庄区" ], [ "2243", "当涂县" ], [ "2244", "经济开发区" ], [ "2245", "经济开发区" ], [ "2246", "颍州区" ], [ "2247", "颍东区" ], [ "2248", "颍泉区" ], [ "2249", "临泉县" ], [ "2250", "太和县" ], [ "2251", "阜南县" ], [ "2252", "洪洞县" ], [ "2253", "颍上县" ], [ "2255", "铜官山区" ], [ "2256", "狮子山区" ], [ "2257", "郊区" ], [ "2258", "铜陵县" ], [ "2259", "迎江区" ], [ "2260", "大观区" ], [ "2261", "宜秀区" ], [ "2262", "怀宁县" ], [ "2263", "疏附县" ], [ "2264", "枞阳县" ], [ "2265", "潜山县" ], [ "2266", "太湖县" ], [ "2267", "宿松县" ], [ "2268", "望江县" ], [ "2269", "岳西县" ], [ "2271", "屯溪区" ], [ "2272", "黄山区" ], [ "2273", "徽州区" ], [ "2274", "疏勒县" ], [ "2275", "歙县" ], [ "2276", "休宁县" ], [ "2277", "黟县" ], [ "2278", "祁门县" ], [ "2279", "琅琊区" ], [ "2280", "南谯区" ], [ "2281", "来安县" ], [ "2282", "全椒县" ], [ "2283", "定远县" ], [ "2284", "凤阳县" ], [ "2285", "灞桥区" ], [ "2286", "英吉沙县" ], [ "2289", "埇桥区" ], [ "2290", "砀山县" ], [ "2291", "萧县" ], [ "2292", "灵璧县" ], [ "2293", "泗县" ], [ "2294", "居巢区" ], [ "2295", "庐江县" ], [ "2296", "无为县" ], [ "2297", "泽普县" ], [ "2298", "含山县" ], [ "2299", "和县" ], [ "2300", "金安区" ], [ "2301", "裕安区" ], [ "2302", "寿县" ], [ "2303", "霍邱县" ], [ "2304", "舒城县" ], [ "2305", "金寨县" ], [ "2306", "霍山县" ], [ "2307", "谯城区" ], [ "2308", "莎车县" ], [ "2309", "涡阳县" ], [ "2310", "蒙城县" ], [ "2311", "利辛县" ], [ "2312", "贵池区" ], [ "2313", "东至县" ], [ "2314", "石台县" ], [ "2315", "青阳县" ], [ "2316", "宣州区" ], [ "2317", "郎溪县" ], [ "2318", "广德县" ], [ "2319", "叶城县" ], [ "2320", "泾县" ], [ "2321", "绩溪县" ], [ "2322", "旌德县" ], [ "2324", "杜集区" ], [ "2325", "相山区" ], [ "2326", "烈山区" ], [ "2327", "濉溪县" ], [ "2328", "玄武区" ], [ "2329", "白下区" ], [ "2330", "麦盖提县" ], [ "2331", "秦淮区" ], [ "2332", "建邺区" ], [ "2333", "鼓楼区" ], [ "2334", "下关区" ], [ "2335", "浦口区" ], [ "2336", "栖霞区" ], [ "2337", "雨花台区" ], [ "2338", "江宁区" ], [ "2339", "六合区" ], [ "2340", "溧水县" ], [ "2341", "岳普湖县" ], [ "2342", "高淳县" ], [ "2343", "平江区" ], [ "2344", "金阊区" ], [ "2345", "吴中区" ], [ "2346", "高新区" ], [ "2347", "工业园区" ], [ "2348", "沧浪区" ], [ "2349", "虎丘区" ], [ "2350", "相城区" ], [ "2352", "伽师县" ], [ "2357", "崇安区" ], [ "2358", "南长区" ], [ "2359", "北塘区" ], [ "2360", "锡山区" ], [ "2361", "惠山区" ], [ "2362", "滨湖区" ], [ "2363", "巴楚县" ], [ "2366", "崇川区" ], [ "2367", "港闸区" ], [ "2368", "经济开发区" ], [ "2369", "海安县" ], [ "2370", "大埔县" ], [ "2371", "丰顺县" ], [ "2372", "五华县" ], [ "2373", "平远县" ], [ "2374", "塔什库尔干塔吉克自治县" ], [ "2375", "源城区" ], [ "2376", "紫金县" ], [ "2377", "龙川县" ], [ "2378", "连平县" ], [ "2379", "和平县" ], [ "2380", "东源县" ], [ "2381", "浈江区" ], [ "2382", "武江区" ], [ "2386", "仁化县" ], [ "2387", "始兴县" ], [ "2388", "翁源县" ], [ "2389", "曲江区" ], [ "2390", "新丰县" ], [ "2391", "乳源瑶族自治县" ], [ "2392", "清城区" ], [ "2395", "佛冈县" ], [ "2396", "未央区" ], [ "2397", "鄯善县" ], [ "2398", "阳山县" ], [ "2399", "清新县" ], [ "2400", "连山壮族瑶族自治县" ], [ "2401", "连南瑶族自治县" ], [ "2402", "龙华区" ], [ "2403", "秀英区" ], [ "2404", "琼山区" ], [ "2405", "美兰区" ], [ "2406", "三亚市" ], [ "2407", "琼海市" ], [ "2408", "托克逊县" ], [ "2409", "儋州市" ], [ "2410", "文昌市" ], [ "2411", "东方市" ], [ "2412", "澄迈县" ], [ "2413", "定安县" ], [ "2414", "临高县" ], [ "2415", "琼中黎族苗族自治县" ], [ "2416", "万宁市" ], [ "2417", "屯昌县" ], [ "2418", "保亭黎族苗族自治县" ], [ "2420", "白沙黎族自治县" ], [ "2421", "陵水黎族自治县" ], [ "2422", "乐东黎族自治县" ], [ "2423", "昌江黎族自治县" ], [ "2424", "五指山市" ], [ "2425", "西南中沙群岛办事处" ], [ "2426", "回民区" ], [ "2427", "玉泉区" ], [ "2428", "新城区" ], [ "2429", "赛罕区" ], [ "2430", "巴里坤哈萨克自治县" ], [ "2431", "土默特左旗" ], [ "2432", "托克托县" ], [ "2433", "和林格尔县" ], [ "2434", "清水河县" ], [ "2435", "武川县" ], [ "2436", "东河区" ], [ "2437", "昆都仑区" ], [ "2438", "青山区" ], [ "2439", "石拐区" ], [ "2440", "白云矿区" ], [ "2441", "伊吾县" ], [ "2442", "九原区" ], [ "2443", "土默特右旗" ], [ "2444", "固阳县" ], [ "2445", "达尔罕茂明安联合旗" ], [ "2446", "东胜区" ], [ "2447", "达拉特旗" ], [ "2448", "准格尔旗" ], [ "2449", "鄂托克前旗" ], [ "2450", "鄂托克旗" ], [ "2451", "杭锦旗" ], [ "2452", "石河子市" ], [ "2453", "乌审旗" ], [ "2454", "伊金霍洛旗" ], [ "2455", "海勃湾区" ], [ "2456", "海南区" ], [ "2457", "乌达区" ], [ "2458", "红山区" ], [ "2459", "元宝山区" ], [ "2460", "松山区" ], [ "2461", "阿鲁科尔沁旗" ], [ "2462", "巴林左旗" ], [ "2464", "巴林右旗" ], [ "2465", "林西县" ], [ "2466", "克什克腾旗" ], [ "2467", "翁牛特旗" ], [ "2468", "喀喇沁旗" ], [ "2469", "宁城县" ], [ "2470", "敖汉旗" ], [ "2471", "科尔沁区" ], [ "2472", "科尔沁左翼中旗" ], [ "2473", "科尔沁左翼后旗" ], [ "2474", "温宿县" ], [ "2475", "开鲁县" ], [ "2476", "库伦旗" ], [ "2477", "奈曼旗" ], [ "2478", "扎鲁特旗" ], [ "2480", "海拉尔区" ], [ "2481", "阿荣旗" ], [ "2482", "莫力达瓦达斡尔族自治旗" ], [ "2483", "鄂伦春自治旗" ], [ "2484", "鄂温克族自治旗" ], [ "2485", "库车县" ], [ "2486", "陈巴尔虎旗" ], [ "2487", "新巴尔虎左旗" ], [ "2488", "新巴尔虎右旗" ], [ "2494", "临河区" ], [ "2495", "五原县" ], [ "2496", "沙雅县" ], [ "2497", "磴口县" ], [ "2498", "乌拉特前旗" ], [ "2499", "乌拉特中旗" ], [ "2500", "乌拉特后旗" ], [ "2501", "杭锦后旗" ], [ "2502", "集宁区" ], [ "2503", "卓资县" ], [ "2504", "化德县" ], [ "2505", "商都县" ], [ "2506", "兴和县" ], [ "2507", "长安区" ], [ "2508", "新和县" ], [ "2509", "凉城县" ], [ "2510", "察哈尔右翼前旗" ], [ "2511", "察哈尔右翼中旗" ], [ "2512", "察哈尔右翼后旗" ], [ "2513", "拜城县" ], [ "2514", "乌什县" ], [ "2515", "阿瓦提县" ], [ "2516", "柯坪县" ], [ "2519", "呼图壁县" ], [ "2520", "玛纳斯县" ], [ "2521", "奇台县" ], [ "2523", "阎良区" ], [ "2524", "吉木萨尔县" ], [ "2525", "木垒哈萨克自治县" ], [ "2527", "精河县" ], [ "2528", "温泉县" ], [ "2530", "轮台县" ], [ "2531", "尉犁县" ], [ "2532", "若羌县" ], [ "2533", "且末县" ], [ "2534", "临潼区" ], [ "2535", "焉耆回族自治县" ], [ "2536", "和静县" ], [ "2537", "和硕县" ], [ "2538", "博湖县" ], [ "2540", "阿克陶县" ], [ "2541", "阿合奇县" ], [ "2542", "乌恰县" ], [ "2544", "和田县" ], [ "2545", "蓝田县" ], [ "2546", "墨玉县" ], [ "2547", "皮山县" ], [ "2548", "洛浦县" ], [ "2549", "策勒县" ], [ "2550", "于田县" ], [ "2551", "民丰县" ], [ "2554", "伊宁县" ], [ "2555", "察布查尔锡伯自治县" ], [ "2556", "周至县" ], [ "2557", "霍城县" ], [ "2558", "巩留县" ], [ "2559", "新源县" ], [ "2560", "昭苏县" ], [ "2561", "特克斯县" ], [ "2562", "尼勒克县" ], [ "2565", "额敏县" ], [ "2566", "沙湾县" ], [ "2567", "户县" ], [ "2568", "托里县" ], [ "2569", "裕民县" ], [ "2570", "和布克赛尔蒙古自治县" ], [ "2572", "布尔津县" ], [ "2573", "富蕴县" ], [ "2574", "福海县" ], [ "2575", "哈巴河县" ], [ "2576", "青河县" ], [ "2577", "吉木乃县" ], [ "2578", "高陵县" ], [ "2579", "阿拉尔市" ], [ "2580", "图木舒克市" ], [ "2581", "五家渠市" ], [ "2582", "中原区" ], [ "2583", "二七区" ], [ "2584", "管城回族区" ], [ "2585", "金水区" ], [ "2586", "西北高新区" ], [ "2587", "东南经济区" ], [ "2588", "郑东新区" ], [ "2589", "秦都区" ], [ "2590", "上街区" ], [ "2591", "惠济区" ], [ "2592", "中牟县" ], [ "2598", "文峰区" ], [ "2599", "北关区" ], [ "2600", "渭城区" ], [ "2601", "殷都区" ], [ "2602", "龙安区" ], [ "2603", "安阳县" ], [ "2604", "汤阴县" ], [ "2605", "滑县" ], [ "2606", "内黄县" ], [ "2608", "梁园区" ], [ "2609", "睢阳区" ], [ "2610", "民权县" ], [ "2611", "杨陵区" ], [ "2612", "睢县" ], [ "2613", "宁陵县" ], [ "2614", "柘城县" ], [ "2615", "虞城县" ], [ "2616", "夏邑县" ], [ "2618", "红旗区" ], [ "2619", "卫滨区" ], [ "2620", "凤泉区" ], [ "2621", "牧野区" ], [ "2622", "三原县" ], [ "2623", "新乡县" ], [ "2624", "获嘉县" ], [ "2625", "原阳县" ], [ "2626", "延津县" ], [ "2627", "封丘县" ], [ "2628", "长垣县" ], [ "2629", "顺义区" ], [ "2630", "昌平区" ], [ "2631", "通州区" ], [ "2632", "房山区" ], [ "2633", "科尔沁右翼前旗" ], [ "2634", "泾阳县" ], [ "2635", "静安区" ], [ "2636", "长宁区" ], [ "2637", "普陀区" ], [ "2638", "徐汇区" ], [ "2639", "卢湾区" ], [ "2640", "虹口区" ], [ "2641", "杨浦区" ], [ "2642", "闸北区" ], [ "2643", "宝山区" ], [ "2644", "黄浦区" ], [ "2646", "闵行区" ], [ "2647", "浦东新区" ], [ "2648", "嘉定区" ], [ "2649", "青浦区" ], [ "2650", "松江区" ], [ "2651", "奉贤区" ], [ "2652", "金山区" ], [ "2653", "南汇区" ], [ "2654", "崇明县" ], [ "2655", "市中区" ], [ "2656", "乾县" ], [ "2657", "槐荫区" ], [ "2658", "历城区" ], [ "2659", "历下区" ], [ "2660", "天桥区" ], [ "2661", "长清区" ], [ "2662", "平阴县" ], [ "2663", "济阳县" ], [ "2664", "商河县" ], [ "2666", "市南区" ], [ "2667", "礼泉县" ], [ "2668", "市北区" ], [ "2669", "四方区" ], [ "2670", "黄岛区" ], [ "2671", "崂山区" ], [ "2672", "李沧区" ], [ "2673", "城阳区" ], [ "2678", "永寿县" ], [ "2680", "张店区" ], [ "2681", "高新区" ], [ "2682", "淄川区" ], [ "2683", "博山区" ], [ "2684", "临淄区" ], [ "2685", "周村区" ], [ "2686", "桓台县" ], [ "2687", "高青县" ], [ "2688", "沂源县" ], [ "2689", "彬县" ], [ "2690", "芝罘区" ], [ "2691", "福山区" ], [ "2692", "牟平区" ], [ "2693", "莱山区" ], [ "2694", "开发区" ], [ "2695", "长岛县" ], [ "2700", "长武县" ], [ "2704", "泰山区" ], [ "2705", "岱岳区" ], [ "2706", "宁阳县" ], [ "2707", "东平县" ], [ "2710", "市中区" ], [ "2711", "旬邑县" ], [ "2712", "任城区" ], [ "2713", "微山县" ], [ "2714", "鱼台县" ], [ "2715", "金乡县" ], [ "2716", "嘉祥县" ], [ "2717", "汶上县" ], [ "2718", "泗水县" ], [ "2719", "梁山县" ], [ "2722", "淳化县" ], [ "2724", "环翠区" ], [ "2725", "经济技术开发区" ], [ "2726", "高新技术开发区" ], [ "2730", "潍城区" ], [ "2731", "奎文区" ], [ "2732", "开发区" ], [ "2733", "武功县" ], [ "2734", "寒亭区" ], [ "2735", "坊子区" ], [ "2736", "临朐县" ], [ "2737", "昌乐县" ], [ "2744", "科尔沁右翼中旗" ], [ "2745", "汉台区" ], [ "2747", "东昌府区" ], [ "2748", "阳谷县" ], [ "2749", "莘县" ], [ "2750", "茌平县" ], [ "2751", "东阿县" ], [ "2752", "冠县" ], [ "2753", "高唐县" ], [ "2754", "德城区" ], [ "2755", "陵县" ], [ "2756", "南郑县" ], [ "2757", "宁津县" ], [ "2758", "庆云县" ], [ "2759", "临邑县" ], [ "2760", "齐河县" ], [ "2761", "平原县" ], [ "2762", "夏津县" ], [ "2763", "武城县" ], [ "2766", "牡丹区" ], [ "2767", "城固县" ], [ "2768", "曹县" ], [ "2769", "单县" ], [ "2770", "成武县" ], [ "2771", "巨野县" ], [ "2772", "郓城县" ], [ "2773", "鄄城县" ], [ "2774", "定陶县" ], [ "2775", "东明县" ], [ "2776", "滨城区" ], [ "2777", "仪陇县" ], [ "2778", "洋县" ], [ "2779", "西充县" ], [ "2781", "顺庆区" ], [ "2782", "自流井区" ], [ "2783", "贡井区" ], [ "2784", "大安区" ], [ "2785", "沿滩区" ], [ "2786", "荣县" ], [ "2787", "富顺县" ], [ "2788", "船山区" ], [ "2789", "西乡县" ], [ "2790", "安居区" ], [ "2791", "蓬溪县" ], [ "2792", "射洪县" ], [ "2793", "大英县" ], [ "2794", "市中区" ], [ "2795", "东兴区" ], [ "2796", "威远县" ], [ "2797", "资中县" ], [ "2798", "隆昌县" ], [ "2799", "东坡区" ], [ "2800", "勉县" ], [ "2801", "仁寿县" ], [ "2802", "彭山县" ], [ "2803", "洪雅县" ], [ "2804", "丹棱县" ], [ "2805", "青神县" ], [ "2806", "广安区" ], [ "2807", "岳池县" ], [ "2808", "武胜县" ], [ "2809", "邻水县" ], [ "2811", "宁强县" ], [ "2812", "通川区" ], [ "2813", "达县" ], [ "2814", "宣汉县" ], [ "2815", "开江县" ], [ "2816", "大竹县" ], [ "2817", "渠县" ], [ "2819", "巴州区" ], [ "2820", "通江县" ], [ "2821", "南江县" ], [ "2822", "略阳县" ], [ "2823", "平昌县" ], [ "2824", "雁江区" ], [ "2825", "安岳县" ], [ "2826", "乐至县" ], [ "2828", "汶川县" ], [ "2829", "理县" ], [ "2830", "茂县" ], [ "2831", "松潘县" ], [ "2832", "九寨沟县" ], [ "2833", "镇巴县" ], [ "2834", "金川县" ], [ "2835", "小金县" ], [ "2836", "黑水县" ], [ "2837", "马尔康县" ], [ "2838", "壤塘县" ], [ "2839", "阿坝县" ], [ "2840", "若尔盖县" ], [ "2841", "红原县" ], [ "2842", "康定县" ], [ "2843", "泸定县" ], [ "2844", "留坝县" ], [ "2845", "丹巴县" ], [ "2846", "九龙县" ], [ "2847", "雅江县" ], [ "2848", "道孚县" ], [ "2849", "炉霍县" ], [ "2850", "甘孜县" ], [ "2851", "新龙县" ], [ "2852", "德格县" ], [ "2853", "白玉县" ], [ "2854", "石渠县" ], [ "2855", "扎赉特旗" ], [ "2856", "佛坪县" ], [ "2857", "色达县" ], [ "2858", "理塘县" ], [ "2859", "巴塘县" ], [ "2860", "乡城县" ], [ "2861", "稻城县" ], [ "2862", "得荣县" ], [ "2864", "木里藏族自治县" ], [ "2865", "盐源县" ], [ "2866", "德昌县" ], [ "2867", "临渭区" ], [ "2868", "会理县" ], [ "2869", "会东县" ], [ "2870", "宁南县" ], [ "2871", "普格县" ], [ "2872", "布拖县" ], [ "2873", "金阳县" ], [ "2874", "昭觉县" ], [ "2875", "喜德县" ], [ "2876", "冕宁县" ], [ "2877", "越西县" ], [ "2878", "华县" ], [ "2879", "甘洛县" ], [ "2880", "美姑县" ], [ "2881", "雷波县" ], [ "2882", "道里区" ], [ "2883", "南岗区" ], [ "2884", "道外区" ], [ "2885", "香坊区" ], [ "2886", "松北新区" ], [ "2887", "平房区" ], [ "2888", "呼兰区" ], [ "2889", "潼关县" ], [ "2890", "依兰县" ], [ "2891", "方正县" ], [ "2892", "宾县" ], [ "2893", "巴彦县" ], [ "2894", "木兰县" ], [ "2895", "通河县" ], [ "2896", "延寿县" ], [ "2900", "大荔县" ], [ "2902", "龙沙区" ], [ "2903", "建华区" ], [ "2904", "铁锋区" ], [ "2905", "昂昂溪区" ], [ "2906", "富拉尔基区" ], [ "2907", "碾子山区" ], [ "2908", "梅里斯达斡尔族区" ], [ "2909", "龙江县" ], [ "2910", "依安县" ], [ "2911", "合阳县" ], [ "2912", "泰来县" ], [ "2913", "甘南县" ], [ "2914", "富裕县" ], [ "2915", "克山县" ], [ "2916", "克东县" ], [ "2917", "拜泉县" ], [ "2919", "爱民区" ], [ "2920", "东安区" ], [ "2921", "阳明区" ], [ "2922", "澄城县" ], [ "2923", "西安区" ], [ "2924", "东宁县" ], [ "2925", "康平县" ], [ "2926", "法库县" ], [ "2928", "铁东区" ], [ "2929", "铁西区" ], [ "2930", "立山区" ], [ "2931", "千山区" ], [ "2932", "台安县" ], [ "2933", "蒲城县" ], [ "2934", "岫岩满族自治县" ], [ "2936", "新抚区" ], [ "2937", "东洲区" ], [ "2938", "望花区" ], [ "2939", "顺城区" ], [ "2940", "抚顺县" ], [ "2941", "新宾满族自治县" ], [ "2942", "清原满族自治县" ], [ "2943", "平山区" ], [ "2944", "白水县" ], [ "2945", "明山区" ], [ "2946", "溪湖区" ], [ "2947", "南芬区" ], [ "2948", "本溪满族自治县" ], [ "2949", "桓仁满族自治县" ], [ "2952", "义县" ], [ "2953", "太和区" ], [ "2954", "古塔区" ], [ "2955", "富平县" ], [ "2956", "凌河区" ], [ "2957", "黑山县" ], [ "2958", "白塔区" ], [ "2959", "文圣区" ], [ "2960", "宏伟区" ], [ "2961", "弓长岭区" ], [ "2962", "太子河区" ], [ "2963", "辽阳县" ], [ "2965", "双塔区" ], [ "2966", "突泉县" ], [ "2968", "龙城区" ], [ "2969", "朝阳县" ], [ "2970", "建平县" ], [ "2971", "喀喇沁左翼蒙古族自治县" ], [ "2974", "振兴区" ], [ "2975", "元宝区" ], [ "2976", "振安区" ], [ "2977", "宽甸满族自治县" ], [ "2981", "站前区" ], [ "2982", "西市区" ], [ "2983", "鲅鱼圈区" ], [ "2984", "老边区" ], [ "2987", "海州区" ], [ "2988", "新邱区" ], [ "2989", "渭滨区" ], [ "2990", "太平区" ], [ "2991", "清河门区" ], [ "2992", "细河区" ], [ "2993", "阜新蒙古族自治县" ], [ "2994", "彰武县" ], [ "2995", "双台子区" ], [ "2996", "兴隆台区" ], [ "2997", "大洼县" ], [ "2998", "盘山县" ], [ "2999", "银州区" ], [ "3000", "金台区" ], [ "3001", "清河区" ], [ "3002", "铁岭县" ], [ "3003", "西丰县" ], [ "3004", "昌图县" ], [ "3007", "连山区" ], [ "3008", "龙港区" ], [ "3009", "南票区" ], [ "3010", "绥中县" ], [ "3011", "陈仓区" ], [ "3012", "建昌县" ], [ "3014", "和平区" ], [ "3015", "河北区" ], [ "3016", "河东区" ], [ "3017", "河西区" ], [ "3018", "南开区" ], [ "3019", "红桥区" ], [ "3020", "塘沽区" ], [ "3021", "西青区" ], [ "3022", "凤翔县" ], [ "3023", "北辰区" ], [ "3024", "东丽区" ], [ "3025", "津南区" ], [ "3026", "武清区" ], [ "3027", "宝坻区" ], [ "3028", "蓟县" ], [ "3029", "宁河县" ], [ "3030", "汉沽区" ], [ "3031", "大港区" ], [ "3032", "静海县" ], [ "3033", "岐山县" ], [ "3035", "清徐县" ], [ "3036", "阳曲县" ], [ "3037", "小店区" ], [ "3038", "迎泽区" ], [ "3039", "杏花岭区" ], [ "3040", "尖草坪区" ], [ "3041", "万柏林区" ], [ "3042", "晋源区" ], [ "3043", "娄烦县" ], [ "3044", "扶风县" ], [ "3045", "城区" ], [ "3046", "矿区" ], [ "3047", "南郊区" ], [ "3048", "新荣区" ], [ "3049", "阳高县" ], [ "3050", "天镇县" ], [ "3051", "广灵县" ], [ "3052", "灵丘县" ], [ "3053", "浑源县" ], [ "3054", "左云县" ], [ "3055", "眉县" ], [ "3056", "大同县" ], [ "3058", "平遥县" ], [ "3059", "太谷县" ], [ "3060", "祁县" ], [ "3061", "榆次区" ], [ "3062", "榆社县" ], [ "3063", "左权县" ], [ "3064", "和顺县" ], [ "3065", "昔阳县" ], [ "3066", "陇县" ], [ "3067", "寿阳县" ], [ "3068", "灵石县" ], [ "3069", "尧都区" ], [ "3070", "曲沃县" ], [ "3072", "武都区" ], [ "3073", "东城区" ], [ "3074", "西城区" ], [ "3075", "宣武区" ], [ "3076", "崇文区" ], [ "3078", "千阳县" ], [ "3079", "海淀区" ], [ "3080", "石景山区" ], [ "3081", "丰台区" ], [ "3082", "怀柔区" ], [ "3083", "朝阳区" ], [ "3084", "延庆县" ], [ "3085", "密云县" ], [ "3086", "平谷区" ], [ "3087", "门头沟区" ], [ "3088", "大兴区" ], [ "3089", "麟游县" ], [ "3090", "城西区" ], [ "3091", "大通回族土族自治县" ], [ "3092", "湟中县" ], [ "3093", "湟源县" ], [ "3094", "平安县" ], [ "3095", "乐都县" ], [ "3096", "民和回族土族自治县" ], [ "3097", "互助土族自治县" ], [ "3098", "化隆回族自治县" ], [ "3099", "循化撒拉族自治县" ], [ "3100", "凤县" ], [ "3101", "门源回族自治县" ], [ "3102", "祁连县" ], [ "3103", "海晏县" ], [ "3104", "刚察县" ], [ "3105", "同仁县" ], [ "3106", "尖扎县" ], [ "3107", "泽库县" ], [ "3108", "河南蒙古族自治县" ], [ "3109", "共和县" ], [ "3110", "同德县" ], [ "3111", "太白县" ], [ "3112", "贵德县" ], [ "3113", "兴海县" ], [ "3114", "贵南县" ], [ "3115", "玛沁县" ], [ "3116", "班玛县" ], [ "3117", "甘德县" ], [ "3118", "达日县" ], [ "3119", "久治县" ], [ "3120", "玛多县" ], [ "3121", "玉树县" ], [ "3122", "榆阳区" ], [ "3123", "杂多县" ], [ "3124", "称多县" ], [ "3125", "治多县" ], [ "3126", "囊谦县" ], [ "3127", "曲麻莱县" ], [ "3130", "乌兰县" ], [ "3131", "都兰县" ], [ "3132", "天峻县" ], [ "3133", "神木县" ], [ "3134", "青羊区" ], [ "3135", "成华区" ], [ "3136", "武侯区" ], [ "3137", "锦江区" ], [ "3138", "金牛区" ], [ "3139", "高新区" ], [ "3140", "青白江区" ], [ "3141", "新都区" ], [ "3144", "府谷县" ], [ "3146", "金堂县" ], [ "3147", "新津县" ], [ "3148", "双流县" ], [ "3149", "蒲江县" ], [ "3150", "大邑县" ], [ "3152", "温江区" ], [ "3153", "龙泉驿区" ], [ "3154", "郫县" ], [ "3155", "横山县" ], [ "3156", "东区" ], [ "3157", "西区" ], [ "3158", "仁和区" ], [ "3159", "米易县" ], [ "3160", "盐边县" ], [ "3161", "涪城区" ], [ "3162", "游仙区" ], [ "3163", "高新区" ], [ "3164", "科学城区" ], [ "3165", "西南科技大学" ], [ "3166", "靖边县" ], [ "3167", "三台县" ], [ "3168", "盐亭县" ], [ "3169", "安县" ], [ "3170", "梓潼县" ], [ "3171", "北川羌族自治县" ], [ "3172", "平武县" ], [ "3174", "翠屏区" ], [ "3175", "宜宾县" ], [ "3176", "南溪县" ], [ "3177", "定边县" ], [ "3178", "江安县" ], [ "3179", "长宁县" ], [ "3180", "高县" ], [ "3181", "珙县" ], [ "3182", "筠连县" ], [ "3183", "兴文县" ], [ "3184", "屏山县" ], [ "3185", "江阳区" ], [ "3186", "纳溪区" ], [ "3187", "龙马潭区" ], [ "3189", "绥德县" ], [ "3190", "泸县" ], [ "3191", "合江县" ], [ "3192", "叙永县" ], [ "3193", "古蔺县" ], [ "3194", "市中区" ], [ "3195", "沙湾区" ], [ "3196", "五通桥区" ], [ "3197", "金口河区" ], [ "3198", "犍为县" ], [ "3199", "井研县" ], [ "3200", "米脂县" ], [ "3201", "夹江县" ], [ "3202", "沐川县" ], [ "3203", "峨边彝族自治县" ], [ "3204", "马边彝族自治县" ], [ "3206", "名山县" ], [ "3207", "荥经县" ], [ "3208", "汉源县" ], [ "3209", "石棉县" ], [ "3210", "天全县" ], [ "3211", "佳县" ], [ "3212", "芦山县" ], [ "3213", "宝兴县" ], [ "3214", "雨城区" ], [ "3215", "市中区" ], [ "3216", "元坝区" ], [ "3217", "朝天区" ], [ "3218", "旺苍县" ], [ "3219", "青川县" ], [ "3220", "剑阁县" ], [ "3221", "苍溪县" ], [ "3222", "吴堡县" ], [ "3223", "旌阳区" ], [ "3225", "高新区" ], [ "3226", "中江县" ], [ "3227", "罗江县" ], [ "3230", "高坪区" ], [ "3231", "嘉陵区" ], [ "3232", "南部县" ], [ "3233", "清涧县" ], [ "3234", "营山县" ], [ "3235", "蓬安县" ], [ "3236", "武陵区" ], [ "3237", "安乡县" ], [ "3238", "汉寿县" ], [ "3239", "澧县" ], [ "3240", "临澧县" ], [ "3241", "桃源县" ], [ "3242", "石门县" ], [ "3244", "子洲县" ], [ "3245", "永定区" ], [ "3246", "武陵源区" ], [ "3247", "慈利县" ], [ "3248", "桑植县" ], [ "3249", "赫山区" ], [ "3250", "资阳区" ], [ "3251", "南县" ], [ "3252", "桃江县" ], [ "3253", "安化县" ], [ "3255", "王益区" ], [ "3256", "苏仙区" ], [ "3257", "北湖区" ], [ "3258", "桂阳县" ], [ "3259", "宜章县" ], [ "3260", "永兴县" ], [ "3261", "嘉禾县" ], [ "3262", "临武县" ], [ "3263", "汝城县" ], [ "3264", "桂东县" ], [ "3265", "安仁县" ], [ "3266", "印台区" ], [ "3268", "芝山区" ], [ "3269", "冷水滩区" ], [ "3270", "祁阳县" ], [ "3271", "东安县" ], [ "3272", "双牌县" ], [ "3273", "道县" ], [ "3274", "江永县" ], [ "3275", "宁远县" ], [ "3276", "蓝山县" ], [ "3277", "耀州区" ], [ "3278", "新田县" ], [ "3279", "江华瑶族自治县" ], [ "3280", "娄星区" ], [ "3281", "双峰县" ], [ "3282", "新化县" ], [ "3286", "泸溪县" ], [ "3287", "凤凰县" ], [ "3288", "宜君县" ], [ "3289", "花垣县" ], [ "3290", "保靖县" ], [ "3291", "古丈县" ], [ "3292", "永顺县" ], [ "3293", "龙山县" ], [ "3294", "宽城区" ], [ "3295", "南关区" ], [ "3296", "朝阳区" ], [ "3297", "绿园区" ], [ "3298", "二道区" ] ]
        };
    },
    1819: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SyncPromise = void 0;
        var r, o = n("670e");
        !function(e) {
            e.PENDING = "PENDING", e.RESOLVED = "RESOLVED", e.REJECTED = "REJECTED";
        }(r || (r = {}));
        var i = function() {
            function e(e) {
                var t = this;
                this._state = r.PENDING, this._handlers = [], this._resolve = function(e) {
                    t._setResult(r.RESOLVED, e);
                }, this._reject = function(e) {
                    t._setResult(r.REJECTED, e);
                }, this._setResult = function(e, n) {
                    t._state === r.PENDING && ((0, o.isThenable)(n) ? n.then(t._resolve, t._reject) : (t._state = e, 
                    t._value = n, t._executeHandlers()));
                }, this._attachHandler = function(e) {
                    t._handlers = t._handlers.concat(e), t._executeHandlers();
                }, this._executeHandlers = function() {
                    if (t._state !== r.PENDING) {
                        var e = t._handlers.slice();
                        t._handlers = [], e.forEach(function(e) {
                            e.done || (t._state === r.RESOLVED && e.onfulfilled && e.onfulfilled(t._value), 
                            t._state === r.REJECTED && e.onrejected && e.onrejected(t._value), e.done = !0);
                        });
                    }
                };
                try {
                    e(this._resolve, this._reject);
                } catch (e) {
                    this._reject(e);
                }
            }
            return e.prototype.toString = function() {
                return "[object SyncPromise]";
            }, e.resolve = function(t) {
                return new e(function(e) {
                    e(t);
                });
            }, e.reject = function(t) {
                return new e(function(e, n) {
                    n(t);
                });
            }, e.all = function(t) {
                return new e(function(n, r) {
                    if (Array.isArray(t)) if (0 !== t.length) {
                        var o = t.length, i = [];
                        t.forEach(function(t, a) {
                            e.resolve(t).then(function(e) {
                                i[a] = e, 0 === (o -= 1) && n(i);
                            }).then(null, r);
                        });
                    } else n([]); else r(new TypeError("Promise.all requires an array as input."));
                });
            }, e.prototype.then = function(t, n) {
                var r = this;
                return new e(function(e, o) {
                    r._attachHandler({
                        done: !1,
                        onfulfilled: function(n) {
                            if (t) try {
                                return void e(t(n));
                            } catch (e) {
                                return void o(e);
                            } else e(n);
                        },
                        onrejected: function(t) {
                            if (n) try {
                                return void e(n(t));
                            } catch (e) {
                                return void o(e);
                            } else o(t);
                        }
                    });
                });
            }, e.prototype.catch = function(e) {
                return this.then(function(e) {
                    return e;
                }, e);
            }, e.prototype.finally = function(t) {
                var n = this;
                return new e(function(e, r) {
                    var o, i;
                    return n.then(function(e) {
                        i = !1, o = e, t && t();
                    }, function(e) {
                        i = !0, o = e, t && t();
                    }).then(function() {
                        i ? r(o) : e(o);
                    });
                });
            }, e;
        }();
        t.SyncPromise = i;
    },
    18425: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            publish: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/publish", e, !1);
            },
            detail: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/detail", e, !1);
            },
            pagingView: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/pagingView", e, !1);
            },
            isClick: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/isClick", e, !1);
            },
            clickFun: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/click", e, !1);
            },
            shareFun: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/share", e, !1);
            },
            taskInfo: function(e) {
                return (0, r.default)("get", "/api/wxapp/evaluate/taskInfo/".concat(e));
            },
            invite: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/invite", e, !1);
            },
            top100: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/top100", e);
            }
        };
        t.default = o;
    },
    "19b2": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = [];
        var o = function e(t) {
            return t = Object.assign(Object.assign({}, e.currentOptions), t), new Promise(function(e, n) {
                var o = (t.context || function() {
                    var e = getCurrentPages();
                    return e[e.length - 1];
                }()).selectComponent(t.selector);
                delete t.context, delete t.selector, o ? (o.setData(Object.assign({
                    onCancel: n,
                    onConfirm: e
                }, t)), r.push(o)) : console.warn("未找到 van-dialog 节点，请确认 selector 及 context 是否正确");
            });
        };
        o.defaultOptions = {
            show: !0,
            title: "",
            width: null,
            message: "",
            zIndex: 100,
            overlay: !0,
            selector: "#van-dialog",
            className: "",
            asyncClose: !1,
            transition: "scale",
            customStyle: "",
            messageAlign: "",
            overlayStyle: "",
            confirmButtonText: "确认",
            cancelButtonText: "取消",
            showConfirmButton: !0,
            showCancelButton: !1,
            closeOnClickOverlay: !1,
            confirmButtonOpenType: ""
        }, o.alert = o, o.confirm = function(e) {
            return o(Object.assign({
                showCancelButton: !0
            }, e));
        }, o.close = function() {
            r.forEach(function(e) {
                e.close();
            }), r = [];
        }, o.stopLoading = function() {
            r.forEach(function(e) {
                e.stopLoading();
            });
        }, o.setDefaultOptions = function(e) {
            Object.assign(o.currentOptions, e);
        }, o.resetDefaultOptions = function() {
            o.currentOptions = Object.assign({}, o.defaultOptions);
        }, o.resetDefaultOptions();
        var i = o;
        t.default = i;
    },
    "1a85": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            register: function(e) {
                return (0, r.default)("post", "/api/wxapp/member/register", e, !1);
            }
        };
        t.default = o;
    },
    "1f13": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.LinkedErrors = void 0;
        var r = n("9ab4"), o = n("c6ce"), i = n("ff36"), a = n("938b"), u = function() {
            function e(t) {
                void 0 === t && (t = {}), this.name = e.id, this._key = t.key || "cause", this._limit = t.limit || 5;
            }
            return e.prototype.setupOnce = function() {
                (0, o.addGlobalEventProcessor)(function(t, n) {
                    var r = (0, o.getCurrentHub)().getIntegration(e);
                    return r ? r._handler(t, n) : t;
                });
            }, e.prototype._handler = function(e, t) {
                if (!(e.exception && e.exception.values && t && t.originalException instanceof Error)) return e;
                var n = this._walkErrorTree(t.originalException, this._key);
                return e.exception.values = (0, r.__spread)(n, e.exception.values), e;
            }, e.prototype._walkErrorTree = function(e, t, n) {
                if (void 0 === n && (n = []), !(e[t] instanceof Error) || n.length + 1 >= this._limit) return n;
                var o = (0, a.computeStackTrace)(e[t]), u = (0, i.exceptionFromStacktrace)(o);
                return this._walkErrorTree(e[t], t, (0, r.__spread)([ u ], n));
            }, e.id = "LinkedErrors", e;
        }();
        t.LinkedErrors = u;
    },
    "1f9b": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SDK_VERSION = t.SDK_NAME = void 0;
        t.SDK_NAME = "sentry.javascript.miniapp";
        t.SDK_VERSION = "0.11.1";
    },
    "234f": function(e, t, r) {
        (function(t) {
            var o = u(r("a34a")), i = u(r("6bd2")), a = u(r("717a"));
            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function c(e, t, n, r, o, i, a) {
                try {
                    var u = e[i](a), c = u.value;
                } catch (e) {
                    return void n(e);
                }
                u.done ? t(c) : Promise.resolve(c).then(r, o);
            }
            function s(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(r, o) {
                        var i = e.apply(t, n);
                        function a(e) {
                            c(i, r, o, a, u, "next", e);
                        }
                        function u(e) {
                            c(i, r, o, a, u, "throw", e);
                        }
                        a(void 0);
                    });
                };
            }
            function f(e) {
                return parseInt(e) < 10 && (e = "0" + e), e;
            }
            function l(e, t) {
                return new Promise(function(n, r) {
                    wx.getFileInfo({
                        filePath: e,
                        success: function(r) {
                            console.log("压缩前图片大小", r.size / 1024, "kb"), r.size > 1024 * t ? n({
                                code: 1,
                                imagePath: e
                            }) : n({
                                code: 0,
                                imagePath: e
                            });
                        }
                    });
                });
            }
            function p(e, n, r, o) {
                return new Promise(function(i, a) {
                    var u = t.createCanvasContext(e);
                    u.drawImage(n, 0, 0, r, o), u.draw(!1, setTimeout(function() {
                        t.canvasToTempFilePath({
                            canvasId: e,
                            x: 0,
                            y: 0,
                            width: r,
                            height: o,
                            quality: .65,
                            success: function(e) {
                                console.log(e), i(e.tempFilePath);
                            }
                        });
                    }, 200));
                });
            }
            var d = {
                UNITS: {
                    "年": 315576e5,
                    "月": 26298e5,
                    "天": 864e5,
                    "小时": 36e5,
                    "分钟": 6e4,
                    "秒": 1e3
                },
                humanize: function(e) {
                    var t = "";
                    for (var n in this.UNITS) if (e >= this.UNITS[n]) {
                        t = Math.floor(e / this.UNITS[n]) + n + "前";
                        break;
                    }
                    return t || "刚刚";
                },
                format: function(e) {
                    var t = this.parse(e), n = Date.now() - t.getTime();
                    if (n < this.UNITS["天"]) return this.humanize(n);
                    var r = function(e) {
                        return e < 10 ? "0" + e : e;
                    };
                    return t.getFullYear() + "/" + r(t.getMonth() + 1) + "/" + r(t.getDate()) + "-" + r(t.getHours()) + ":" + r(t.getMinutes());
                },
                parse: function(e) {
                    var t = e.split(/[^0-9]/);
                    return new Date(t[0], t[1] - 1, t[2], t[3], t[4], t[5]);
                }
            };
            e.exports = {
                formatTime: function(e) {
                    if ("number" != typeof e || e < 0) return e;
                    var t = parseInt(e / 3600);
                    return e %= 3600, [ t, parseInt(e / 60), e %= 60 ].map(function(e) {
                        return (e = e.toString())[1] ? e : "0" + e;
                    }).join(":");
                },
                dateFormat: function(e, t) {
                    var n, r = {
                        "Y+": t.getFullYear().toString(),
                        "m+": (t.getMonth() + 1).toString(),
                        "d+": t.getDate().toString(),
                        "H+": t.getHours().toString(),
                        "M+": t.getMinutes().toString(),
                        "S+": t.getSeconds().toString()
                    };
                    for (var o in r) (n = new RegExp("(" + o + ")").exec(e)) && (e = e.replace(n[1], 1 == n[1].length ? r[o] : r[o].padStart(n[1].length, "0")));
                    return e;
                },
                formatLocation: function(e, t) {
                    return "string" == typeof e && "string" == typeof t && (e = parseFloat(e), t = parseFloat(t)), 
                    e = e.toFixed(2), t = t.toFixed(2), {
                        longitude: e.toString().split("."),
                        latitude: t.toString().split(".")
                    };
                },
                dateUtils: d,
                setSource: function(e) {
                    console.log(e);
                    var n = "undefined" == decodeURIComponent(e.scene) ? "" : decodeURIComponent(e.scene);
                    n ? (console.log("进入1", n), t.setStorageSync("smsSource", n.split("&")[0]), t.setStorageSync("channelLabel", n.split("&")[1])) : (console.log("进入2", n), 
                    t.setStorageSync("smsSource", e.source), console.log("进入3", n), t.setStorageSync("shopCode", e.shop_code), 
                    t.setStorageSync("shopCode", e.shopCode), t.setStorageSync("channelLabel", e.channel_label), 
                    t.setStorageSync("channelLabel", e.channelLabel), e.scence && (t.setStorageSync("smsSource", e.scence), 
                    t.setStorageSync("channelLabel", e.scence)));
                },
                isHeightPhone: function() {
                    return new Promise(function(e, n) {
                        var r = 750 / t.getSystemInfoSync().windowWidth;
                        t.getSystemInfoSync().windowHeight * r > 1334 ? e(!0) : n(!1);
                    });
                },
                getLessLimitSizeImage: function e(n, r) {
                    var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1024, a = arguments.length > 3 ? arguments[3] : void 0;
                    return new Promise(function() {
                        var u = s(o.default.mark(function u(c, f) {
                            var d;
                            return o.default.wrap(function(u) {
                                for (;;) switch (u.prev = u.next) {
                                  case 0:
                                    return u.next = 2, l(r, i);

                                  case 2:
                                    d = u.sent, console.log(d), 1 == d.code ? t.getImageInfo({
                                        src: d.imagePath,
                                        success: function() {
                                            var t = s(o.default.mark(function t(u) {
                                                var s, f, l, d, h, v;
                                                return o.default.wrap(function(t) {
                                                    for (;;) switch (t.prev = t.next) {
                                                      case 0:
                                                        return console.log(u), s = Math.max(u.width, u.height), l = 1, s > (f = a) && (l = f / s), 
                                                        d = Math.trunc(u.width * l), h = Math.trunc(u.height * l), console.log("调用压缩", d, h), 
                                                        t.next = 10, p(n, r, d, h);

                                                      case 10:
                                                        v = t.sent, e(n, v, i = 1024, .95 * a).then(function(e) {
                                                            c(e);
                                                        });

                                                      case 12:
                                                      case "end":
                                                        return t.stop();
                                                    }
                                                }, t);
                                            }));
                                            return function(e) {
                                                return t.apply(this, arguments);
                                            };
                                        }()
                                    }) : c(d);

                                  case 5:
                                  case "end":
                                    return u.stop();
                                }
                            }, u);
                        }));
                        return function(e, t) {
                            return u.apply(this, arguments);
                        };
                    }());
                },
                isMidPadding: function() {
                    return new Promise(function(e, n) {
                        var r = 750 / t.getSystemInfoSync().windowWidth;
                        e((t.getSystemInfoSync().windowWidth * r / (t.getSystemInfoSync().windowHeight * r - 320 - 230)).toFixed(2));
                    });
                },
                formatFun: function(e) {
                    var t = e.split(" ").join(""), n = "";
                    if (t.length <= 8) {
                        for (var r = 0; r < t.length; r++) 4 == r ? n = n + " " + t[r] : n += t[r];
                        return n;
                    }
                    return e;
                },
                setNavBarInfo: function() {
                    var e = t.getSystemInfoSync(), n = t.getMenuButtonBoundingClientRect();
                    if (n) {
                        this.navBarHeight = 2 * (n.top - e.statusBarHeight) + n.height + e.statusBarHeight, 
                        this.menuBotton = n.top - e.statusBarHeight, this.menuRight = e.screenWidth - n.right, 
                        this.menuHeight = n.height, getApp().globalData.navBarHeight = 2 * (n.top - e.statusBarHeight) + n.height + e.statusBarHeight, 
                        getApp().globalData.menuBotton = this.menuBotton, getApp().globalData.menuHeight = this.menuHeight;
                        var r = e.statusBarHeight, o = n.top, i = n.height + 2 * (o - r), a = r + i;
                        console.log(i, a);
                    } else this.setNavBarInfo();
                },
                recordPv: function(e) {
                    var t = e || function() {
                        var e = getCurrentPages(), t = e[e.length - 1].route, n = e[e.length - 1].options, r = "";
                        if ("" == Object.keys(n)) r = "/" + t; else if (Object.keys(n).length > 0) {
                            var o = "";
                            for (var i in n) o += ("" == o ? "" : "&") + i + "=" + n[i];
                            r = "/" + t + "?" + o;
                        } else r = "/" + t;
                        return [ t, n, r ];
                    }()[2];
                    console.log(t), i.default.savePv({
                        url: t
                    });
                },
                imageUtil: function(e) {
                    var n = {}, r = e.width, o = e.height, i = o / r;
                    return console.log("原始宽: " + r), console.log("原始高: " + o), console.log("宽高比" + i), 
                    t.getSystemInfo({
                        success: function(e) {
                            var t = 2 * e.windowWidth, a = 2 * e.windowHeight, u = a / t;
                            r > e.windowWidth || o > e.windowHeight ? i < u ? (n.imageWidth = t, n.imageHeight = t * o / r) : (n.imageHeight = a, 
                            n.imageWidth = a * r / o) : (n.imageHeight = o, n.imageWidth = r);
                        }
                    }), console.log("缩放后的宽: " + n.imageWidth), console.log("缩放后的高: " + n.imageHeight), 
                    n;
                },
                getRecord: function(e) {
                    i.default.saveLoginRecord({
                        unionId: t.getStorageSync("unionId"),
                        openId: t.getStorageSync("openId"),
                        source: e || t.getStorageSync("smsSource")
                    });
                },
                timeDiff: function(e, t) {
                    var n = new Date(e), r = new Date(t);
                    return n.getTime() >= r.getTime() ? (console.log("第一个大"), !0) : (console.log("第二个大"), 
                    !1);
                },
                timeDiffAll: function(e, t, n) {
                    console.log(e, t, n);
                    var r = new Date(t.replace(/\-/g, "/")), o = new Date(n.replace(/\-/g, "/"));
                    return e = new Date(e.replace(/\-/g, "/")), console.log(e, r, o), e.getTime() >= r.getTime() && e.getTime() <= o.getTime() ? (console.log("在范围内"), 
                    !0) : (console.log("不在范围内"), !1);
                },
                mdString: function(e, r) {
                    var o, i = e, u = "";
                    if ("object" != (0, n.default)(r) || r instanceof Array) if (r && r.length > 0) {
                        for (var c in r) {
                            console.log(c), console.log(t.getStorageSync(r[c])), u += "".concat(r[c], "=").concat(t.getStorageSync(r[c])).concat(r.length > 1 ? "&" : "");
                        }
                        u += "&timestamp=".concat(i);
                    } else {
                        var s = t.getStorageSync("unionId"), f = t.getStorageSync("openId");
                        u = "unionId=".concat(s, "&openid=").concat(f, "&timestamp=").concat(i);
                    } else {
                        console.log(r);
                        for (var l = 0, p = Object.keys(r); l < p.length; l++) {
                            var d = p[l];
                            console.log(d), u += "".concat(d, "=").concat(r[d], "&");
                        }
                        u += "timestamp=".concat(i);
                    }
                    console.log("原来", u);
                    var h = Array.from(u).sort().join("");
                    return console.log("排序", h), console.log("排序md5", a.default.hexMD5(h)), o = a.default.hexMD5(a.default.hexMD5(h) + ",key=HE8@EqkD7GN4"), 
                    console.log("加key后加密", o), o;
                },
                getMyDate: function(e) {
                    var t = new Date(e), n = t.getFullYear(), r = t.getMonth() + 1, o = t.getDate(), i = t.getHours(), a = t.getMinutes(), u = t.getSeconds();
                    return n + "-" + f(r) + "-" + f(o) + " " + f(i) + ":" + f(a) + ":" + f(u);
                }
            };
        }).call(this, r("543d").default);
    },
    "236e": function(e) {
        function t(t, n, r) {
            return e.apply(this, arguments);
        }
        return t.toString = function() {
            return e.toString();
        }, t;
    }(function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        t.default = {
            pulldown: "",
            refreshempty: "",
            back: "",
            forward: "",
            more: "",
            "more-filled": "",
            scan: "",
            qq: "",
            weibo: "",
            weixin: "",
            pengyouquan: "",
            loop: "",
            refresh: "",
            "refresh-filled": "",
            arrowthindown: "",
            arrowthinleft: "",
            arrowthinright: "",
            arrowthinup: "",
            "undo-filled": "",
            undo: "",
            redo: "",
            "redo-filled": "",
            bars: "",
            chatboxes: "",
            camera: "",
            "chatboxes-filled": "",
            "camera-filled": "",
            "cart-filled": "",
            cart: "",
            "checkbox-filled": "",
            checkbox: "",
            arrowleft: "",
            arrowdown: "",
            arrowright: "",
            "smallcircle-filled": "",
            arrowup: "",
            circle: "",
            "eye-filled": "",
            "eye-slash-filled": "",
            "eye-slash": "",
            eye: "",
            "flag-filled": "",
            flag: "",
            "gear-filled": "",
            reload: "",
            gear: "",
            "hand-thumbsdown-filled": "",
            "hand-thumbsdown": "",
            "hand-thumbsup-filled": "",
            "heart-filled": "",
            "hand-thumbsup": "",
            heart: "",
            home: "",
            info: "",
            "home-filled": "",
            "info-filled": "",
            "circle-filled": "",
            "chat-filled": "",
            chat: "",
            "mail-open-filled": "",
            "email-filled": "",
            "mail-open": "",
            email: "",
            checkmarkempty: "",
            list: "",
            "locked-filled": "",
            locked: "",
            "map-filled": "",
            "map-pin": "",
            "map-pin-ellipse": "",
            map: "",
            "minus-filled": "",
            "mic-filled": "",
            minus: "",
            micoff: "",
            mic: "",
            clear: "",
            smallcircle: "",
            close: "",
            closeempty: "",
            paperclip: "",
            paperplane: "",
            "paperplane-filled": "",
            "person-filled": "",
            "contact-filled": "",
            person: "",
            contact: "",
            "images-filled": "",
            phone: "",
            images: "",
            image: "",
            "image-filled": "",
            "location-filled": "",
            location: "",
            "plus-filled": "",
            plus: "",
            plusempty: "",
            "help-filled": "",
            help: "",
            "navigate-filled": "",
            navigate: "",
            "mic-slash-filled": "",
            search: "",
            settings: "",
            sound: "",
            "sound-filled": "",
            "spinner-cycle": "",
            "download-filled": "",
            "personadd-filled": "",
            "videocam-filled": "",
            personadd: "",
            upload: "",
            "upload-filled": "",
            starhalf: "",
            "star-filled": "",
            star: "",
            trash: "",
            "phone-filled": "",
            compose: "",
            videocam: "",
            "trash-filled": "",
            download: "",
            "chatbubble-filled": "",
            chatbubble: "",
            "cloud-download": "",
            "cloud-upload-filled": "",
            "cloud-upload": "",
            "cloud-download-filled": "",
            headphones: "",
            shop: ""
        };
    }),
    "24db": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.forget = function(e) {
            e.then(null, function(e) {
                console.error(e);
            });
        };
    },
    "26cb": function(e, t, r) {
        (function(t) {
            var r = ("undefined" != typeof window ? window : void 0 !== t ? t : {}).__VUE_DEVTOOLS_GLOBAL_HOOK__;
            function o(e) {
                r && (e._devtoolHook = r, r.emit("vuex:init", e), r.on("vuex:travel-to-state", function(t) {
                    e.replaceState(t);
                }), e.subscribe(function(e, t) {
                    r.emit("vuex:mutation", e, t);
                }, {
                    prepend: !0
                }), e.subscribeAction(function(e, t) {
                    r.emit("vuex:action", e, t);
                }, {
                    prepend: !0
                }));
            }
            function i(e, t) {
                if (void 0 === t && (t = []), null === e || "object" !== (0, n.default)(e)) return e;
                var r = function(e, t) {
                    return e.filter(t)[0];
                }(t, function(t) {
                    return t.original === e;
                });
                if (r) return r.copy;
                var o = Array.isArray(e) ? [] : {};
                return t.push({
                    original: e,
                    copy: o
                }), Object.keys(e).forEach(function(n) {
                    o[n] = i(e[n], t);
                }), o;
            }
            function a(e, t) {
                Object.keys(e).forEach(function(n) {
                    return t(e[n], n);
                });
            }
            function u(e) {
                return null !== e && "object" === (0, n.default)(e);
            }
            var c = function(e, t) {
                this.runtime = t, this._children = Object.create(null), this._rawModule = e;
                var n = e.state;
                this.state = ("function" == typeof n ? n() : n) || {};
            }, s = {
                namespaced: {
                    configurable: !0
                }
            };
            s.namespaced.get = function() {
                return !!this._rawModule.namespaced;
            }, c.prototype.addChild = function(e, t) {
                this._children[e] = t;
            }, c.prototype.removeChild = function(e) {
                delete this._children[e];
            }, c.prototype.getChild = function(e) {
                return this._children[e];
            }, c.prototype.hasChild = function(e) {
                return e in this._children;
            }, c.prototype.update = function(e) {
                this._rawModule.namespaced = e.namespaced, e.actions && (this._rawModule.actions = e.actions), 
                e.mutations && (this._rawModule.mutations = e.mutations), e.getters && (this._rawModule.getters = e.getters);
            }, c.prototype.forEachChild = function(e) {
                a(this._children, e);
            }, c.prototype.forEachGetter = function(e) {
                this._rawModule.getters && a(this._rawModule.getters, e);
            }, c.prototype.forEachAction = function(e) {
                this._rawModule.actions && a(this._rawModule.actions, e);
            }, c.prototype.forEachMutation = function(e) {
                this._rawModule.mutations && a(this._rawModule.mutations, e);
            }, Object.defineProperties(c.prototype, s);
            var f, l = function(e) {
                this.register([], e, !1);
            };
            l.prototype.get = function(e) {
                return e.reduce(function(e, t) {
                    return e.getChild(t);
                }, this.root);
            }, l.prototype.getNamespace = function(e) {
                var t = this.root;
                return e.reduce(function(e, n) {
                    return e + ((t = t.getChild(n)).namespaced ? n + "/" : "");
                }, "");
            }, l.prototype.update = function(e) {
                !function e(t, n, r) {
                    if (n.update(r), r.modules) for (var o in r.modules) {
                        if (!n.getChild(o)) return;
                        e(t.concat(o), n.getChild(o), r.modules[o]);
                    }
                }([], this.root, e);
            }, l.prototype.register = function(e, t, n) {
                var r = this;
                void 0 === n && (n = !0);
                var o = new c(t, n);
                0 === e.length ? this.root = o : this.get(e.slice(0, -1)).addChild(e[e.length - 1], o);
                t.modules && a(t.modules, function(t, o) {
                    r.register(e.concat(o), t, n);
                });
            }, l.prototype.unregister = function(e) {
                var t = this.get(e.slice(0, -1)), n = e[e.length - 1], r = t.getChild(n);
                r && r.runtime && t.removeChild(n);
            }, l.prototype.isRegistered = function(e) {
                var t = this.get(e.slice(0, -1)), n = e[e.length - 1];
                return !!t && t.hasChild(n);
            };
            var p = function(e) {
                var t = this;
                void 0 === e && (e = {}), !f && "undefined" != typeof window && window.Vue && _(window.Vue);
                var n = e.plugins;
                void 0 === n && (n = []);
                var r = e.strict;
                void 0 === r && (r = !1), this._committing = !1, this._actions = Object.create(null), 
                this._actionSubscribers = [], this._mutations = Object.create(null), this._wrappedGetters = Object.create(null), 
                this._modules = new l(e), this._modulesNamespaceMap = Object.create(null), this._subscribers = [], 
                this._watcherVM = new f(), this._makeLocalGettersCache = Object.create(null);
                var i = this, a = this.dispatch, u = this.commit;
                this.dispatch = function(e, t) {
                    return a.call(i, e, t);
                }, this.commit = function(e, t, n) {
                    return u.call(i, e, t, n);
                }, this.strict = r;
                var c = this._modules.root.state;
                y(this, c, [], this._modules.root), g(this, c), n.forEach(function(e) {
                    return e(t);
                }), (void 0 !== e.devtools ? e.devtools : f.config.devtools) && o(this);
            }, d = {
                state: {
                    configurable: !0
                }
            };
            function h(e, t, n) {
                return t.indexOf(e) < 0 && (n && n.prepend ? t.unshift(e) : t.push(e)), function() {
                    var n = t.indexOf(e);
                    n > -1 && t.splice(n, 1);
                };
            }
            function v(e, t) {
                e._actions = Object.create(null), e._mutations = Object.create(null), e._wrappedGetters = Object.create(null), 
                e._modulesNamespaceMap = Object.create(null);
                var n = e.state;
                y(e, n, [], e._modules.root, !0), g(e, n, t);
            }
            function g(e, t, n) {
                var r = e._vm;
                e.getters = {}, e._makeLocalGettersCache = Object.create(null);
                var o = e._wrappedGetters, i = {};
                a(o, function(t, n) {
                    i[n] = function(e, t) {
                        return function() {
                            return e(t);
                        };
                    }(t, e), Object.defineProperty(e.getters, n, {
                        get: function() {
                            return e._vm[n];
                        },
                        enumerable: !0
                    });
                });
                var u = f.config.silent;
                f.config.silent = !0, e._vm = new f({
                    data: {
                        $$state: t
                    },
                    computed: i
                }), f.config.silent = u, e.strict && function(e) {
                    e._vm.$watch(function() {
                        return this._data.$$state;
                    }, function() {}, {
                        deep: !0,
                        sync: !0
                    });
                }(e), r && (n && e._withCommit(function() {
                    r._data.$$state = null;
                }), f.nextTick(function() {
                    return r.$destroy();
                }));
            }
            function y(e, t, n, r, o) {
                var i = !n.length, a = e._modules.getNamespace(n);
                if (r.namespaced && (e._modulesNamespaceMap[a], e._modulesNamespaceMap[a] = r), 
                !i && !o) {
                    var u = b(t, n.slice(0, -1)), c = n[n.length - 1];
                    e._withCommit(function() {
                        f.set(u, c, r.state);
                    });
                }
                var s = r.context = function(e, t, n) {
                    var r = "" === t, o = {
                        dispatch: r ? e.dispatch : function(n, r, o) {
                            var i = m(n, r, o), a = i.payload, u = i.options, c = i.type;
                            return u && u.root || (c = t + c), e.dispatch(c, a);
                        },
                        commit: r ? e.commit : function(n, r, o) {
                            var i = m(n, r, o), a = i.payload, u = i.options, c = i.type;
                            u && u.root || (c = t + c), e.commit(c, a, u);
                        }
                    };
                    return Object.defineProperties(o, {
                        getters: {
                            get: r ? function() {
                                return e.getters;
                            } : function() {
                                return function(e, t) {
                                    if (!e._makeLocalGettersCache[t]) {
                                        var n = {}, r = t.length;
                                        Object.keys(e.getters).forEach(function(o) {
                                            if (o.slice(0, r) === t) {
                                                var i = o.slice(r);
                                                Object.defineProperty(n, i, {
                                                    get: function() {
                                                        return e.getters[o];
                                                    },
                                                    enumerable: !0
                                                });
                                            }
                                        }), e._makeLocalGettersCache[t] = n;
                                    }
                                    return e._makeLocalGettersCache[t];
                                }(e, t);
                            }
                        },
                        state: {
                            get: function() {
                                return b(e.state, n);
                            }
                        }
                    }), o;
                }(e, a, n);
                r.forEachMutation(function(t, n) {
                    !function(e, t, n, r) {
                        (e._mutations[t] || (e._mutations[t] = [])).push(function(t) {
                            n.call(e, r.state, t);
                        });
                    }(e, a + n, t, s);
                }), r.forEachAction(function(t, n) {
                    var r = t.root ? n : a + n, o = t.handler || t;
                    !function(e, t, n, r) {
                        (e._actions[t] || (e._actions[t] = [])).push(function(t) {
                            var o = n.call(e, {
                                dispatch: r.dispatch,
                                commit: r.commit,
                                getters: r.getters,
                                state: r.state,
                                rootGetters: e.getters,
                                rootState: e.state
                            }, t);
                            return function(e) {
                                return e && "function" == typeof e.then;
                            }(o) || (o = Promise.resolve(o)), e._devtoolHook ? o.catch(function(t) {
                                throw e._devtoolHook.emit("vuex:error", t), t;
                            }) : o;
                        });
                    }(e, r, o, s);
                }), r.forEachGetter(function(t, n) {
                    !function(e, t, n, r) {
                        e._wrappedGetters[t] || (e._wrappedGetters[t] = function(e) {
                            return n(r.state, r.getters, e.state, e.getters);
                        });
                    }(e, a + n, t, s);
                }), r.forEachChild(function(r, i) {
                    y(e, t, n.concat(i), r, o);
                });
            }
            function b(e, t) {
                return t.reduce(function(e, t) {
                    return e[t];
                }, e);
            }
            function m(e, t, n) {
                return u(e) && e.type && (n = t, t = e, e = e.type), {
                    type: e,
                    payload: t,
                    options: n
                };
            }
            function _(e) {
                f && e === f || 
                /*!
       * vuex v3.6.2
       * (c) 2021 Evan You
       * @license MIT
       */
                function(e) {
                    if (Number(e.version.split(".")[0]) >= 2) e.mixin({
                        beforeCreate: n
                    }); else {
                        var t = e.prototype._init;
                        e.prototype._init = function(e) {
                            void 0 === e && (e = {}), e.init = e.init ? [ n ].concat(e.init) : n, t.call(this, e);
                        };
                    }
                    function n() {
                        var e = this.$options;
                        e.store ? this.$store = "function" == typeof e.store ? e.store() : e.store : e.parent && e.parent.$store && (this.$store = e.parent.$store);
                    }
                }(f = e);
            }
            d.state.get = function() {
                return this._vm._data.$$state;
            }, d.state.set = function(e) {}, p.prototype.commit = function(e, t, n) {
                var r = this, o = m(e, t, n), i = o.type, a = o.payload, u = (o.options, {
                    type: i,
                    payload: a
                }), c = this._mutations[i];
                c && (this._withCommit(function() {
                    c.forEach(function(e) {
                        e(a);
                    });
                }), this._subscribers.slice().forEach(function(e) {
                    return e(u, r.state);
                }));
            }, p.prototype.dispatch = function(e, t) {
                var n = this, r = m(e, t), o = r.type, i = r.payload, a = {
                    type: o,
                    payload: i
                }, u = this._actions[o];
                if (u) {
                    try {
                        this._actionSubscribers.slice().filter(function(e) {
                            return e.before;
                        }).forEach(function(e) {
                            return e.before(a, n.state);
                        });
                    } catch (e) {}
                    var c = u.length > 1 ? Promise.all(u.map(function(e) {
                        return e(i);
                    })) : u[0](i);
                    return new Promise(function(e, t) {
                        c.then(function(t) {
                            try {
                                n._actionSubscribers.filter(function(e) {
                                    return e.after;
                                }).forEach(function(e) {
                                    return e.after(a, n.state);
                                });
                            } catch (e) {}
                            e(t);
                        }, function(e) {
                            try {
                                n._actionSubscribers.filter(function(e) {
                                    return e.error;
                                }).forEach(function(t) {
                                    return t.error(a, n.state, e);
                                });
                            } catch (e) {}
                            t(e);
                        });
                    });
                }
            }, p.prototype.subscribe = function(e, t) {
                return h(e, this._subscribers, t);
            }, p.prototype.subscribeAction = function(e, t) {
                return h("function" == typeof e ? {
                    before: e
                } : e, this._actionSubscribers, t);
            }, p.prototype.watch = function(e, t, n) {
                var r = this;
                return this._watcherVM.$watch(function() {
                    return e(r.state, r.getters);
                }, t, n);
            }, p.prototype.replaceState = function(e) {
                var t = this;
                this._withCommit(function() {
                    t._vm._data.$$state = e;
                });
            }, p.prototype.registerModule = function(e, t, n) {
                void 0 === n && (n = {}), "string" == typeof e && (e = [ e ]), this._modules.register(e, t), 
                y(this, this.state, e, this._modules.get(e), n.preserveState), g(this, this.state);
            }, p.prototype.unregisterModule = function(e) {
                var t = this;
                "string" == typeof e && (e = [ e ]), this._modules.unregister(e), this._withCommit(function() {
                    var n = b(t.state, e.slice(0, -1));
                    f.delete(n, e[e.length - 1]);
                }), v(this);
            }, p.prototype.hasModule = function(e) {
                return "string" == typeof e && (e = [ e ]), this._modules.isRegistered(e);
            }, p.prototype[[ 104, 111, 116, 85, 112, 100, 97, 116, 101 ].map(function(e) {
                return String.fromCharCode(e);
            }).join("")] = function(e) {
                this._modules.update(e), v(this, !0);
            }, p.prototype._withCommit = function(e) {
                var t = this._committing;
                this._committing = !0, e(), this._committing = t;
            }, Object.defineProperties(p.prototype, d);
            var w = k(function(e, t) {
                var n = {};
                return E(t).forEach(function(t) {
                    var r = t.key, o = t.val;
                    n[r] = function() {
                        var t = this.$store.state, n = this.$store.getters;
                        if (e) {
                            var r = P(this.$store, "mapState", e);
                            if (!r) return;
                            t = r.context.state, n = r.context.getters;
                        }
                        return "function" == typeof o ? o.call(this, t, n) : t[o];
                    }, n[r].vuex = !0;
                }), n;
            }), x = k(function(e, t) {
                var n = {};
                return E(t).forEach(function(t) {
                    var r = t.key, o = t.val;
                    n[r] = function() {
                        for (var t = [], n = arguments.length; n--; ) t[n] = arguments[n];
                        var r = this.$store.commit;
                        if (e) {
                            var i = P(this.$store, "mapMutations", e);
                            if (!i) return;
                            r = i.context.commit;
                        }
                        return "function" == typeof o ? o.apply(this, [ r ].concat(t)) : r.apply(this.$store, [ o ].concat(t));
                    };
                }), n;
            }), O = k(function(e, t) {
                var n = {};
                return E(t).forEach(function(t) {
                    var r = t.key, o = t.val;
                    o = e + o, n[r] = function() {
                        if (!e || P(this.$store, "mapGetters", e)) return this.$store.getters[o];
                    }, n[r].vuex = !0;
                }), n;
            }), S = k(function(e, t) {
                var n = {};
                return E(t).forEach(function(t) {
                    var r = t.key, o = t.val;
                    n[r] = function() {
                        for (var t = [], n = arguments.length; n--; ) t[n] = arguments[n];
                        var r = this.$store.dispatch;
                        if (e) {
                            var i = P(this.$store, "mapActions", e);
                            if (!i) return;
                            r = i.context.dispatch;
                        }
                        return "function" == typeof o ? o.apply(this, [ r ].concat(t)) : r.apply(this.$store, [ o ].concat(t));
                    };
                }), n;
            });
            function E(e) {
                return function(e) {
                    return Array.isArray(e) || u(e);
                }(e) ? Array.isArray(e) ? e.map(function(e) {
                    return {
                        key: e,
                        val: e
                    };
                }) : Object.keys(e).map(function(t) {
                    return {
                        key: t,
                        val: e[t]
                    };
                }) : [];
            }
            function k(e) {
                return function(t, n) {
                    return "string" != typeof t ? (n = t, t = "") : "/" !== t.charAt(t.length - 1) && (t += "/"), 
                    e(t, n);
                };
            }
            function P(e, t, n) {
                return e._modulesNamespaceMap[n];
            }
            function j(e, t, n) {
                var r = n ? e.groupCollapsed : e.group;
                try {
                    r.call(e, t);
                } catch (n) {
                    e.log(t);
                }
            }
            function A(e) {
                try {
                    e.groupEnd();
                } catch (t) {
                    e.log("—— log end ——");
                }
            }
            function C() {
                var e = new Date();
                return " @ " + T(e.getHours(), 2) + ":" + T(e.getMinutes(), 2) + ":" + T(e.getSeconds(), 2) + "." + T(e.getMilliseconds(), 3);
            }
            function T(e, t) {
                return function(e, t) {
                    return new Array(t + 1).join(e);
                }("0", t - e.toString().length) + e;
            }
            var D = {
                Store: p,
                install: _,
                version: "3.6.2",
                mapState: w,
                mapMutations: x,
                mapGetters: O,
                mapActions: S,
                createNamespacedHelpers: function(e) {
                    return {
                        mapState: w.bind(null, e),
                        mapGetters: O.bind(null, e),
                        mapMutations: x.bind(null, e),
                        mapActions: S.bind(null, e)
                    };
                },
                createLogger: function(e) {
                    void 0 === e && (e = {});
                    var t = e.collapsed;
                    void 0 === t && (t = !0);
                    var n = e.filter;
                    void 0 === n && (n = function(e, t, n) {
                        return !0;
                    });
                    var r = e.transformer;
                    void 0 === r && (r = function(e) {
                        return e;
                    });
                    var o = e.mutationTransformer;
                    void 0 === o && (o = function(e) {
                        return e;
                    });
                    var a = e.actionFilter;
                    void 0 === a && (a = function(e, t) {
                        return !0;
                    });
                    var u = e.actionTransformer;
                    void 0 === u && (u = function(e) {
                        return e;
                    });
                    var c = e.logMutations;
                    void 0 === c && (c = !0);
                    var s = e.logActions;
                    void 0 === s && (s = !0);
                    var f = e.logger;
                    return void 0 === f && (f = console), function(e) {
                        var l = i(e.state);
                        void 0 !== f && (c && e.subscribe(function(e, a) {
                            var u = i(a);
                            if (n(e, l, u)) {
                                var c = C(), s = o(e), p = "mutation " + e.type + c;
                                j(f, p, t), f.log("%c prev state", "color: #9E9E9E; font-weight: bold", r(l)), f.log("%c mutation", "color: #03A9F4; font-weight: bold", s), 
                                f.log("%c next state", "color: #4CAF50; font-weight: bold", r(u)), A(f);
                            }
                            l = u;
                        }), s && e.subscribeAction(function(e, n) {
                            if (a(e, n)) {
                                var r = C(), o = u(e), i = "action " + e.type + r;
                                j(f, i, t), f.log("%c action", "color: #03A9F4; font-weight: bold", o), A(f);
                            }
                        }));
                    };
                }
            };
            e.exports = D;
        }).call(this, r("c8ba"));
    },
    2869: function(e, t, n) {
        e.exports = {
            appName: "",
            appVersion: "",
            appCode: "wx3656c2a2353eb377",
            locationAccessible: !1,
            usingPlugins: !1,
            requireOpenid: !0,
            autoTrackEvents: !1,
            module: {
                basic: {
                    apiUrl: "https://tracker.gmicdp.com.cn/hxt",
                    appKey: "hmt_1ETETQ0I"
                }
            }
        };
    },
    "290d": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MiniappBackend = void 0;
        var r = n("9ab4"), o = n("c6ce"), i = n("507c"), a = n("32f1"), u = n("3e83"), c = n("11b6"), s = function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this;
            }
            return (0, r.__extends)(t, e), t.prototype._setupTransport = function() {
                if (!this._options.dsn) return e.prototype._setupTransport.call(this);
                var t = (0, r.__assign)((0, r.__assign)({}, this._options.transportOptions), {
                    dsn: this._options.dsn
                });
                return this._options.transport ? new this._options.transport(t) : new c.XHRTransport(t);
            }, t.prototype.eventFromException = function(e, t) {
                var n = t && t.syntheticException || void 0, r = (0, u.eventFromUnknownInput)(e, n, {
                    attachStacktrace: this._options.attachStacktrace
                });
                return (0, a.addExceptionMechanism)(r, {
                    handled: !0,
                    type: "generic"
                }), r.level = i.Severity.Error, t && t.event_id && (r.event_id = t.event_id), a.SyncPromise.resolve(r);
            }, t.prototype.eventFromMessage = function(e, t, n) {
                void 0 === t && (t = i.Severity.Info);
                var r = n && n.syntheticException || void 0, o = (0, u.eventFromString)(e, r, {
                    attachStacktrace: this._options.attachStacktrace
                });
                return o.level = t, n && n.event_id && (o.event_id = n.event_id), a.SyncPromise.resolve(o);
            }, t;
        }(o.BaseBackend);
        t.MiniappBackend = s;
    },
    "2a13": function(e, t, r) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.fill = function(e, t, n) {
                if (t in e) {
                    var r = e[t], o = n(r);
                    if ("function" == typeof o) try {
                        o.prototype = o.prototype || {}, Object.defineProperties(o, {
                            __sentry_original__: {
                                enumerable: !1,
                                value: r
                            }
                        });
                    } catch (e) {}
                    e[t] = o;
                }
            }, t.urlEncode = function(e) {
                return Object.keys(e).map(function(t) {
                    return encodeURIComponent(t) + "=" + encodeURIComponent(e[t]);
                }).join("&");
            }, t.normalizeToSize = function e(t, n, r) {
                void 0 === n && (n = 3), void 0 === r && (r = 102400);
                var o = d(t, n);
                return function(e) {
                    return function(e) {
                        return ~-encodeURI(e).split(/%..|./).length;
                    }(JSON.stringify(e));
                }(o) > r ? e(t, n - 1, r) : o;
            }, t.walk = p, t.normalize = d, t.extractExceptionKeysForMessage = function(e, t) {
                void 0 === t && (t = 40);
                var n = Object.keys(f(e));
                if (n.sort(), !n.length) return "[object has no keys]";
                if (n[0].length >= t) return (0, c.truncate)(n[0], t);
                for (var r = n.length; r > 0; r--) {
                    var o = n.slice(0, r).join(", ");
                    if (!(o.length > t)) return r === n.length ? o : (0, c.truncate)(o, t);
                }
                return "";
            }, t.dropUndefinedKeys = function e(t) {
                var n, r;
                if ((0, i.isPlainObject)(t)) {
                    var a = t, u = {};
                    try {
                        for (var c = o.__values(Object.keys(a)), s = c.next(); !s.done; s = c.next()) {
                            var f = s.value;
                            void 0 !== a[f] && (u[f] = e(a[f]));
                        }
                    } catch (e) {
                        n = {
                            error: e
                        };
                    } finally {
                        try {
                            s && !s.done && (r = c.return) && r.call(c);
                        } finally {
                            if (n) throw n.error;
                        }
                    }
                    return u;
                }
                return Array.isArray(t) ? t.map(e) : t;
            };
            var o = function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                    default: e
                };
                var t = s();
                if (t && t.has(e)) return t.get(e);
                var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                    var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                    a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
                }
                return r.default = e, t && t.set(e, r), r;
            }(r("9ab4")), i = r("670e"), a = r("648e"), u = r("f658"), c = r("d34a");
            function s() {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap();
                return s = function() {
                    return e;
                }, e;
            }
            function f(e) {
                if ((0, i.isError)(e)) {
                    var t = e, n = {
                        message: t.message,
                        name: t.name,
                        stack: t.stack
                    };
                    for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (n[r] = t[r]);
                    return n;
                }
                if ((0, i.isEvent)(e)) {
                    var o = e, a = {};
                    a.type = o.type;
                    try {
                        a.target = (0, i.isElement)(o.target) ? (0, u.htmlTreeAsString)(o.target) : Object.prototype.toString.call(o.target);
                    } catch (e) {
                        a.target = "<unknown>";
                    }
                    try {
                        a.currentTarget = (0, i.isElement)(o.currentTarget) ? (0, u.htmlTreeAsString)(o.currentTarget) : Object.prototype.toString.call(o.currentTarget);
                    } catch (e) {
                        a.currentTarget = "<unknown>";
                    }
                    for (var r in "undefined" != typeof CustomEvent && (0, i.isInstanceOf)(e, CustomEvent) && (a.detail = o.detail), 
                    o) Object.prototype.hasOwnProperty.call(o, r) && (a[r] = o);
                    return a;
                }
                return e;
            }
            function l(t, r) {
                return "domain" === r && t && "object" === (0, n.default)(t) && t._events ? "[Domain]" : "domainEmitter" === r ? "[DomainEmitter]" : void 0 !== e && t === e ? "[Global]" : "undefined" != typeof window && t === window ? "[Window]" : "undefined" != typeof document && t === document ? "[Document]" : (0, 
                i.isSyntheticEvent)(t) ? "[SyntheticEvent]" : "number" == typeof t && t != t ? "[NaN]" : void 0 === t ? "[undefined]" : "function" == typeof t ? "[Function: " + (0, 
                u.getFunctionName)(t) + "]" : t;
            }
            function p(e, t, n, r) {
                if (void 0 === n && (n = 1 / 0), void 0 === r && (r = new a.Memo()), 0 === n) return function(e) {
                    var t = Object.prototype.toString.call(e);
                    if ("string" == typeof e) return e;
                    if ("[object Object]" === t) return "[Object]";
                    if ("[object Array]" === t) return "[Array]";
                    var n = l(e);
                    return (0, i.isPrimitive)(n) ? n : t;
                }(t);
                if (null != t && "function" == typeof t.toJSON) return t.toJSON();
                var o = l(t, e);
                if ((0, i.isPrimitive)(o)) return o;
                var u = f(t), c = Array.isArray(t) ? [] : {};
                if (r.memoize(t)) return "[Circular ~]";
                for (var s in u) Object.prototype.hasOwnProperty.call(u, s) && (c[s] = p(s, u[s], n - 1, r));
                return r.unmemoize(t), c;
            }
            function d(e, t) {
                try {
                    return JSON.parse(JSON.stringify(e, function(e, n) {
                        return p(e, n, t);
                    }));
                } catch (e) {
                    return "**non-serializable**";
                }
            }
        }).call(this, r("c8ba"));
    },
    "2ed3": function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.addGlobalEventProcessor = function(e) {
            c().push(e);
        }, t.Scope = void 0;
        var o = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = a();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var u = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                u && (u.get || u.set) ? Object.defineProperty(r, i, u) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("9ab4")), i = r("32f1");
        function a() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return a = function() {
                return e;
            }, e;
        }
        var u = function() {
            function e() {
                this._notifyingListeners = !1, this._scopeListeners = [], this._eventProcessors = [], 
                this._breadcrumbs = [], this._user = {}, this._tags = {}, this._extra = {}, this._context = {};
            }
            return e.prototype.addScopeListener = function(e) {
                this._scopeListeners.push(e);
            }, e.prototype.addEventProcessor = function(e) {
                return this._eventProcessors.push(e), this;
            }, e.prototype._notifyScopeListeners = function() {
                var e = this;
                this._notifyingListeners || (this._notifyingListeners = !0, setTimeout(function() {
                    e._scopeListeners.forEach(function(t) {
                        t(e);
                    }), e._notifyingListeners = !1;
                }));
            }, e.prototype._notifyEventProcessors = function(e, t, n, r) {
                var a = this;
                return void 0 === r && (r = 0), new i.SyncPromise(function(u, c) {
                    var s = e[r];
                    if (null === t || "function" != typeof s) u(t); else {
                        var f = s(o.__assign({}, t), n);
                        (0, i.isThenable)(f) ? f.then(function(t) {
                            return a._notifyEventProcessors(e, t, n, r + 1).then(u);
                        }).then(null, c) : a._notifyEventProcessors(e, f, n, r + 1).then(u).then(null, c);
                    }
                });
            }, e.prototype.setUser = function(e) {
                return this._user = e || {}, this._notifyScopeListeners(), this;
            }, e.prototype.setTags = function(e) {
                return this._tags = o.__assign({}, this._tags, e), this._notifyScopeListeners(), 
                this;
            }, e.prototype.setTag = function(e, t) {
                var n;
                return this._tags = o.__assign({}, this._tags, ((n = {})[e] = t, n)), this._notifyScopeListeners(), 
                this;
            }, e.prototype.setExtras = function(e) {
                return this._extra = o.__assign({}, this._extra, e), this._notifyScopeListeners(), 
                this;
            }, e.prototype.setExtra = function(e, t) {
                var n;
                return this._extra = o.__assign({}, this._extra, ((n = {})[e] = t, n)), this._notifyScopeListeners(), 
                this;
            }, e.prototype.setFingerprint = function(e) {
                return this._fingerprint = e, this._notifyScopeListeners(), this;
            }, e.prototype.setLevel = function(e) {
                return this._level = e, this._notifyScopeListeners(), this;
            }, e.prototype.setTransaction = function(e) {
                return this._transaction = e, this._span && (this._span.transaction = e), this._notifyScopeListeners(), 
                this;
            }, e.prototype.setContext = function(e, t) {
                var n;
                return this._context = o.__assign({}, this._context, ((n = {})[e] = t, n)), this._notifyScopeListeners(), 
                this;
            }, e.prototype.setSpan = function(e) {
                return this._span = e, this._notifyScopeListeners(), this;
            }, e.prototype.getSpan = function() {
                return this._span;
            }, e.clone = function(t) {
                var n = new e();
                return t && (n._breadcrumbs = o.__spread(t._breadcrumbs), n._tags = o.__assign({}, t._tags), 
                n._extra = o.__assign({}, t._extra), n._context = o.__assign({}, t._context), n._user = t._user, 
                n._level = t._level, n._span = t._span, n._transaction = t._transaction, n._fingerprint = t._fingerprint, 
                n._eventProcessors = o.__spread(t._eventProcessors)), n;
            }, e.prototype.clear = function() {
                return this._breadcrumbs = [], this._tags = {}, this._extra = {}, this._user = {}, 
                this._context = {}, this._level = void 0, this._transaction = void 0, this._fingerprint = void 0, 
                this._span = void 0, this._notifyScopeListeners(), this;
            }, e.prototype.addBreadcrumb = function(e, t) {
                var n = o.__assign({
                    timestamp: (0, i.timestampWithMs)()
                }, e);
                return this._breadcrumbs = void 0 !== t && t >= 0 ? o.__spread(this._breadcrumbs, [ n ]).slice(-t) : o.__spread(this._breadcrumbs, [ n ]), 
                this._notifyScopeListeners(), this;
            }, e.prototype.clearBreadcrumbs = function() {
                return this._breadcrumbs = [], this._notifyScopeListeners(), this;
            }, e.prototype._applyFingerprint = function(e) {
                e.fingerprint = e.fingerprint ? Array.isArray(e.fingerprint) ? e.fingerprint : [ e.fingerprint ] : [], 
                this._fingerprint && (e.fingerprint = e.fingerprint.concat(this._fingerprint)), 
                e.fingerprint && !e.fingerprint.length && delete e.fingerprint;
            }, e.prototype.applyToEvent = function(e, t) {
                return this._extra && Object.keys(this._extra).length && (e.extra = o.__assign({}, this._extra, e.extra)), 
                this._tags && Object.keys(this._tags).length && (e.tags = o.__assign({}, this._tags, e.tags)), 
                this._user && Object.keys(this._user).length && (e.user = o.__assign({}, this._user, e.user)), 
                this._context && Object.keys(this._context).length && (e.contexts = o.__assign({}, this._context, e.contexts)), 
                this._level && (e.level = this._level), this._transaction && (e.transaction = this._transaction), 
                this._span && (e.contexts = o.__assign({
                    trace: this._span.getTraceContext()
                }, e.contexts)), this._applyFingerprint(e), e.breadcrumbs = o.__spread(e.breadcrumbs || [], this._breadcrumbs), 
                e.breadcrumbs = e.breadcrumbs.length > 0 ? e.breadcrumbs : void 0, this._notifyEventProcessors(o.__spread(c(), this._eventProcessors), e, t);
            }, e;
        }();
        function c() {
            var e = (0, i.getGlobalObject)();
            return e.__SENTRY__ = e.__SENTRY__ || {}, e.__SENTRY__.globalEventProcessors = e.__SENTRY__.globalEventProcessors || [], 
            e.__SENTRY__.globalEventProcessors;
        }
        t.Scope = u;
    },
    "2fa1": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            checkCode: function(e, t) {
                return (0, r.default)("post", "/api/wxapp/activity/checkCode/".concat(e), t);
            },
            transfer: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/transfer", e);
            },
            coupontransferlist: function(e) {
                return (0, r.default)("get", "/api/wxapp/coupon/coupontransferlist", e, !1);
            },
            transferGet: function(e) {
                return (0, r.default)("get", "/api/wxapp/coupon/transfer/get/".concat(e));
            },
            luckyBag: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/luckyBag", e);
            },
            sendLuckyBagTemp: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/sendLuckyBagTemp", e, !1);
            },
            isExchangeluckyBag: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/isExchangeluckyBag", e, !1);
            },
            dimooAct: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/dimoo", e, !1);
            },
            sendDimooTemp: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/sendDimooTemp", e, !1);
            },
            isExchangeDimoo: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/isExchangeDimoo", e, !1);
            },
            queryAid: function(e, t) {
                return (0, r.default)("get", "/api/wxapp/activity/queryAid/".concat(e), t, !1);
            },
            getOnlineCode: function(e) {
                return (0, r.default)("post", "/api/wxapp/lyxActivity/getOnlineCode", e, !1);
            },
            queryCode: function(e) {
                return (0, r.default)("post", "/api/wxapp/lyxActivity/queryCode", e, !1);
            },
            checkCodeF: function(e) {
                return (0, r.default)("post", "/api/wxapp/lyxActivity/checkCode", e, !1);
            },
            getofflineCode: function(e) {
                return (0, r.default)("post", "/api/wxapp/lyxActivity/getofflineCode", e, !1);
            },
            sendCvd: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/sendCvd", e, !1);
            },
            pyqCoupon: function(e) {
                return (0, r.default)("post", "/api/wxapp/gratitudeRecord/pyqCoupon", e, !1);
            },
            ebuyLuckyBag: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/ebuyLuckyBag", e, !1);
            },
            ebuyDeliverTransfer: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/ebuyDeliverTransfer", e);
            },
            ebuyGetTransferRecord: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/ebuyGetTransferRecord", e, !1);
            },
            ebuyCancelTransfer: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/ebuyCancelTransfer", e, !1);
            },
            ebuyTransferDetail: function(e) {
                return (0, r.default)("get", "/api/wxapp/coupon/ebuyTransferDetail/".concat(e));
            },
            ebuyReceiveTransfer: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/ebuyReceiveTransfer", e, !1);
            }
        };
        t.default = o;
    },
    "2fce": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.IgnoreMpcrawlerErrors = void 0;
        var r = n("c6ce"), o = n("6916"), i = function() {
            function e() {
                this.name = e.id;
            }
            return e.prototype.setupOnce = function() {
                (0, r.addGlobalEventProcessor)(function(t) {
                    if ((0, r.getCurrentHub)().getIntegration(e) && "wechat" === o.appName && o.sdk.getLaunchOptionsSync && 1129 === o.sdk.getLaunchOptionsSync().scene) return null;
                    return t;
                });
            }, e.id = "IgnoreMpcrawlerErrors", e;
        }();
        t.IgnoreMpcrawlerErrors = i;
    },
    "30c4": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        t.default = {
            province_list: {
                110000: "北京市",
                120000: "天津市",
                130000: "河北省",
                140000: "山西省",
                150000: "内蒙古自治区",
                210000: "辽宁省",
                220000: "吉林省",
                230000: "黑龙江省",
                310000: "上海市",
                320000: "江苏省",
                330000: "浙江省",
                340000: "安徽省",
                350000: "福建省",
                360000: "江西省",
                370000: "山东省",
                410000: "河南省",
                420000: "湖北省",
                430000: "湖南省",
                440000: "广东省",
                450000: "广西壮族自治区",
                460000: "海南省",
                500000: "重庆市",
                510000: "四川省",
                520000: "贵州省",
                530000: "云南省",
                540000: "西藏自治区",
                610000: "陕西省",
                620000: "甘肃省",
                630000: "青海省",
                640000: "宁夏回族自治区",
                650000: "新疆维吾尔自治区",
                710000: "台湾省",
                810000: "香港特别行政区",
                820000: "澳门特别行政区"
            },
            city_list: {
                110100: "北京市",
                120100: "天津市",
                130100: "石家庄市",
                130200: "唐山市",
                130300: "秦皇岛市",
                130400: "邯郸市",
                130500: "邢台市",
                130600: "保定市",
                130700: "张家口市",
                130800: "承德市",
                130900: "沧州市",
                131000: "廊坊市",
                131100: "衡水市",
                140100: "太原市",
                140200: "大同市",
                140300: "阳泉市",
                140400: "长治市",
                140500: "晋城市",
                140600: "朔州市",
                140700: "晋中市",
                140800: "运城市",
                140900: "忻州市",
                141000: "临汾市",
                141100: "吕梁市",
                150100: "呼和浩特市",
                150200: "包头市",
                150300: "乌海市",
                150400: "赤峰市",
                150500: "通辽市",
                150600: "鄂尔多斯市",
                150700: "呼伦贝尔市",
                150800: "巴彦淖尔市",
                150900: "乌兰察布市",
                152200: "兴安盟",
                152500: "锡林郭勒盟",
                152900: "阿拉善盟",
                210100: "沈阳市",
                210200: "大连市",
                210300: "鞍山市",
                210400: "抚顺市",
                210500: "本溪市",
                210600: "丹东市",
                210700: "锦州市",
                210800: "营口市",
                210900: "阜新市",
                211000: "辽阳市",
                211100: "盘锦市",
                211200: "铁岭市",
                211300: "朝阳市",
                211400: "葫芦岛市",
                220100: "长春市",
                220200: "吉林市",
                220300: "四平市",
                220400: "辽源市",
                220500: "通化市",
                220600: "白山市",
                220700: "松原市",
                220800: "白城市",
                222400: "延边朝鲜族自治州",
                230100: "哈尔滨市",
                230200: "齐齐哈尔市",
                230300: "鸡西市",
                230400: "鹤岗市",
                230500: "双鸭山市",
                230600: "大庆市",
                230700: "伊春市",
                230800: "佳木斯市",
                230900: "七台河市",
                231000: "牡丹江市",
                231100: "黑河市",
                231200: "绥化市",
                232700: "大兴安岭地区",
                310100: "上海市",
                320100: "南京市",
                320200: "无锡市",
                320300: "徐州市",
                320400: "常州市",
                320500: "苏州市",
                320600: "南通市",
                320700: "连云港市",
                320800: "淮安市",
                320900: "盐城市",
                321000: "扬州市",
                321100: "镇江市",
                321200: "泰州市",
                321300: "宿迁市",
                330100: "杭州市",
                330200: "宁波市",
                330300: "温州市",
                330400: "嘉兴市",
                330500: "湖州市",
                330600: "绍兴市",
                330700: "金华市",
                330800: "衢州市",
                330900: "舟山市",
                331000: "台州市",
                331100: "丽水市",
                340100: "合肥市",
                340200: "芜湖市",
                340300: "蚌埠市",
                340400: "淮南市",
                340500: "马鞍山市",
                340600: "淮北市",
                340700: "铜陵市",
                340800: "安庆市",
                341000: "黄山市",
                341100: "滁州市",
                341200: "阜阳市",
                341300: "宿州市",
                341500: "六安市",
                341600: "亳州市",
                341700: "池州市",
                341800: "宣城市",
                350100: "福州市",
                350200: "厦门市",
                350300: "莆田市",
                350400: "三明市",
                350500: "泉州市",
                350600: "漳州市",
                350700: "南平市",
                350800: "龙岩市",
                350900: "宁德市",
                360100: "南昌市",
                360200: "景德镇市",
                360300: "萍乡市",
                360400: "九江市",
                360500: "新余市",
                360600: "鹰潭市",
                360700: "赣州市",
                360800: "吉安市",
                360900: "宜春市",
                361000: "抚州市",
                361100: "上饶市",
                370100: "济南市",
                370200: "青岛市",
                370300: "淄博市",
                370400: "枣庄市",
                370500: "东营市",
                370600: "烟台市",
                370700: "潍坊市",
                370800: "济宁市",
                370900: "泰安市",
                371000: "威海市",
                371100: "日照市",
                371300: "临沂市",
                371400: "德州市",
                371500: "聊城市",
                371600: "滨州市",
                371700: "菏泽市",
                410100: "郑州市",
                410200: "开封市",
                410300: "洛阳市",
                410400: "平顶山市",
                410500: "安阳市",
                410600: "鹤壁市",
                410700: "新乡市",
                410800: "焦作市",
                410900: "濮阳市",
                411000: "许昌市",
                411100: "漯河市",
                411200: "三门峡市",
                411300: "南阳市",
                411400: "商丘市",
                411500: "信阳市",
                411600: "周口市",
                411700: "驻马店市",
                419000: "省直辖县",
                420100: "武汉市",
                420200: "黄石市",
                420300: "十堰市",
                420500: "宜昌市",
                420600: "襄阳市",
                420700: "鄂州市",
                420800: "荆门市",
                420900: "孝感市",
                421000: "荆州市",
                421100: "黄冈市",
                421200: "咸宁市",
                421300: "随州市",
                422800: "恩施土家族苗族自治州",
                429000: "省直辖县",
                430100: "长沙市",
                430200: "株洲市",
                430300: "湘潭市",
                430400: "衡阳市",
                430500: "邵阳市",
                430600: "岳阳市",
                430700: "常德市",
                430800: "张家界市",
                430900: "益阳市",
                431000: "郴州市",
                431100: "永州市",
                431200: "怀化市",
                431300: "娄底市",
                433100: "湘西土家族苗族自治州",
                440100: "广州市",
                440200: "韶关市",
                440300: "深圳市",
                440400: "珠海市",
                440500: "汕头市",
                440600: "佛山市",
                440700: "江门市",
                440800: "湛江市",
                440900: "茂名市",
                441200: "肇庆市",
                441300: "惠州市",
                441400: "梅州市",
                441500: "汕尾市",
                441600: "河源市",
                441700: "阳江市",
                441800: "清远市",
                441900: "东莞市",
                442000: "中山市",
                445100: "潮州市",
                445200: "揭阳市",
                445300: "云浮市",
                450100: "南宁市",
                450200: "柳州市",
                450300: "桂林市",
                450400: "梧州市",
                450500: "北海市",
                450600: "防城港市",
                450700: "钦州市",
                450800: "贵港市",
                450900: "玉林市",
                451000: "百色市",
                451100: "贺州市",
                451200: "河池市",
                451300: "来宾市",
                451400: "崇左市",
                460100: "海口市",
                460200: "三亚市",
                460300: "三沙市",
                460400: "儋州市",
                469000: "省直辖县",
                500100: "重庆市",
                500200: "县",
                510100: "成都市",
                510300: "自贡市",
                510400: "攀枝花市",
                510500: "泸州市",
                510600: "德阳市",
                510700: "绵阳市",
                510800: "广元市",
                510900: "遂宁市",
                511000: "内江市",
                511100: "乐山市",
                511300: "南充市",
                511400: "眉山市",
                511500: "宜宾市",
                511600: "广安市",
                511700: "达州市",
                511800: "雅安市",
                511900: "巴中市",
                512000: "资阳市",
                513200: "阿坝藏族羌族自治州",
                513300: "甘孜藏族自治州",
                513400: "凉山彝族自治州",
                520100: "贵阳市",
                520200: "六盘水市",
                520300: "遵义市",
                520400: "安顺市",
                520500: "毕节市",
                520600: "铜仁市",
                522300: "黔西南布依族苗族自治州",
                522600: "黔东南苗族侗族自治州",
                522700: "黔南布依族苗族自治州",
                530100: "昆明市",
                530300: "曲靖市",
                530400: "玉溪市",
                530500: "保山市",
                530600: "昭通市",
                530700: "丽江市",
                530800: "普洱市",
                530900: "临沧市",
                532300: "楚雄彝族自治州",
                532500: "红河哈尼族彝族自治州",
                532600: "文山壮族苗族自治州",
                532800: "西双版纳傣族自治州",
                532900: "大理白族自治州",
                533100: "德宏傣族景颇族自治州",
                533300: "怒江傈僳族自治州",
                533400: "迪庆藏族自治州",
                540100: "拉萨市",
                540200: "日喀则市",
                540300: "昌都市",
                540400: "林芝市",
                540500: "山南市",
                540600: "那曲市",
                542500: "阿里地区",
                610100: "西安市",
                610200: "铜川市",
                610300: "宝鸡市",
                610400: "咸阳市",
                610500: "渭南市",
                610600: "延安市",
                610700: "汉中市",
                610800: "榆林市",
                610900: "安康市",
                611000: "商洛市",
                620100: "兰州市",
                620200: "嘉峪关市",
                620300: "金昌市",
                620400: "白银市",
                620500: "天水市",
                620600: "武威市",
                620700: "张掖市",
                620800: "平凉市",
                620900: "酒泉市",
                621000: "庆阳市",
                621100: "定西市",
                621200: "陇南市",
                622900: "临夏回族自治州",
                623000: "甘南藏族自治州",
                630100: "西宁市",
                630200: "海东市",
                632200: "海北藏族自治州",
                632300: "黄南藏族自治州",
                632500: "海南藏族自治州",
                632600: "果洛藏族自治州",
                632700: "玉树藏族自治州",
                632800: "海西蒙古族藏族自治州",
                640100: "银川市",
                640200: "石嘴山市",
                640300: "吴忠市",
                640400: "固原市",
                640500: "中卫市",
                650100: "乌鲁木齐市",
                650200: "克拉玛依市",
                650400: "吐鲁番市",
                650500: "哈密市",
                652300: "昌吉回族自治州",
                652700: "博尔塔拉蒙古自治州",
                652800: "巴音郭楞蒙古自治州",
                652900: "阿克苏地区",
                653000: "克孜勒苏柯尔克孜自治州",
                653100: "喀什地区",
                653200: "和田地区",
                654000: "伊犁哈萨克自治州",
                654200: "塔城地区",
                654300: "阿勒泰地区",
                659000: "自治区直辖县级行政区划",
                710100: "台北市",
                710200: "高雄市",
                710300: "台南市",
                710400: "台中市",
                710500: "金门县",
                710600: "南投县",
                710700: "基隆市",
                710800: "新竹市",
                710900: "嘉义市",
                711100: "新北市",
                711200: "宜兰县",
                711300: "新竹县",
                711400: "桃园县",
                711500: "苗栗县",
                711700: "彰化县",
                711900: "嘉义县",
                712100: "云林县",
                712400: "屏东县",
                712500: "台东县",
                712600: "花莲县",
                712700: "澎湖县",
                712800: "连江县",
                810100: "香港岛",
                810200: "九龙",
                810300: "新界",
                820100: "澳门半岛",
                820200: "离岛"
            },
            county_list: {
                110101: "东城区",
                110102: "西城区",
                110105: "朝阳区",
                110106: "丰台区",
                110107: "石景山区",
                110108: "海淀区",
                110109: "门头沟区",
                110111: "房山区",
                110112: "通州区",
                110113: "顺义区",
                110114: "昌平区",
                110115: "大兴区",
                110116: "怀柔区",
                110117: "平谷区",
                110118: "密云区",
                110119: "延庆区",
                120101: "和平区",
                120102: "河东区",
                120103: "河西区",
                120104: "南开区",
                120105: "河北区",
                120106: "红桥区",
                120110: "东丽区",
                120111: "西青区",
                120112: "津南区",
                120113: "北辰区",
                120114: "武清区",
                120115: "宝坻区",
                120116: "滨海新区",
                120117: "宁河区",
                120118: "静海区",
                120119: "蓟州区",
                130102: "长安区",
                130104: "桥西区",
                130105: "新华区",
                130107: "井陉矿区",
                130108: "裕华区",
                130109: "藁城区",
                130110: "鹿泉区",
                130111: "栾城区",
                130121: "井陉县",
                130123: "正定县",
                130125: "行唐县",
                130126: "灵寿县",
                130127: "高邑县",
                130128: "深泽县",
                130129: "赞皇县",
                130130: "无极县",
                130131: "平山县",
                130132: "元氏县",
                130133: "赵县",
                130171: "石家庄高新技术产业开发区",
                130172: "石家庄循环化工园区",
                130181: "辛集市",
                130183: "晋州市",
                130184: "新乐市",
                130202: "路南区",
                130203: "路北区",
                130204: "古冶区",
                130205: "开平区",
                130207: "丰南区",
                130208: "丰润区",
                130209: "曹妃甸区",
                130224: "滦南县",
                130225: "乐亭县",
                130227: "迁西县",
                130229: "玉田县",
                130273: "唐山高新技术产业开发区",
                130274: "河北唐山海港经济开发区",
                130281: "遵化市",
                130283: "迁安市",
                130284: "滦州市",
                130302: "海港区",
                130303: "山海关区",
                130304: "北戴河区",
                130306: "抚宁区",
                130321: "青龙满族自治县",
                130322: "昌黎县",
                130324: "卢龙县",
                130371: "秦皇岛市经济技术开发区",
                130372: "北戴河新区",
                130390: "经济技术开发区",
                130402: "邯山区",
                130403: "丛台区",
                130404: "复兴区",
                130406: "峰峰矿区",
                130407: "肥乡区",
                130408: "永年区",
                130423: "临漳县",
                130424: "成安县",
                130425: "大名县",
                130426: "涉县",
                130427: "磁县",
                130430: "邱县",
                130431: "鸡泽县",
                130432: "广平县",
                130433: "馆陶县",
                130434: "魏县",
                130435: "曲周县",
                130471: "邯郸经济技术开发区",
                130473: "邯郸冀南新区",
                130481: "武安市",
                130502: "桥东区",
                130503: "桥西区",
                130521: "邢台县",
                130522: "临城县",
                130523: "内丘县",
                130524: "柏乡县",
                130525: "隆尧县",
                130526: "任县",
                130527: "南和县",
                130528: "宁晋县",
                130529: "巨鹿县",
                130530: "新河县",
                130531: "广宗县",
                130532: "平乡县",
                130533: "威县",
                130534: "清河县",
                130535: "临西县",
                130571: "河北邢台经济开发区",
                130581: "南宫市",
                130582: "沙河市",
                130602: "竞秀区",
                130606: "莲池区",
                130607: "满城区",
                130608: "清苑区",
                130609: "徐水区",
                130623: "涞水县",
                130624: "阜平县",
                130626: "定兴县",
                130627: "唐县",
                130628: "高阳县",
                130629: "容城县",
                130630: "涞源县",
                130631: "望都县",
                130632: "安新县",
                130633: "易县",
                130634: "曲阳县",
                130635: "蠡县",
                130636: "顺平县",
                130637: "博野县",
                130638: "雄县",
                130671: "保定高新技术产业开发区",
                130672: "保定白沟新城",
                130681: "涿州市",
                130682: "定州市",
                130683: "安国市",
                130684: "高碑店市",
                130702: "桥东区",
                130703: "桥西区",
                130705: "宣化区",
                130706: "下花园区",
                130708: "万全区",
                130709: "崇礼区",
                130722: "张北县",
                130723: "康保县",
                130724: "沽源县",
                130725: "尚义县",
                130726: "蔚县",
                130727: "阳原县",
                130728: "怀安县",
                130730: "怀来县",
                130731: "涿鹿县",
                130732: "赤城县",
                130772: "张家口市察北管理区",
                130802: "双桥区",
                130803: "双滦区",
                130804: "鹰手营子矿区",
                130821: "承德县",
                130822: "兴隆县",
                130824: "滦平县",
                130825: "隆化县",
                130826: "丰宁满族自治县",
                130827: "宽城满族自治县",
                130828: "围场满族蒙古族自治县",
                130871: "承德高新技术产业开发区",
                130881: "平泉市",
                130902: "新华区",
                130903: "运河区",
                130921: "沧县",
                130922: "青县",
                130923: "东光县",
                130924: "海兴县",
                130925: "盐山县",
                130926: "肃宁县",
                130927: "南皮县",
                130928: "吴桥县",
                130929: "献县",
                130930: "孟村回族自治县",
                130971: "河北沧州经济开发区",
                130972: "沧州高新技术产业开发区",
                130973: "沧州渤海新区",
                130981: "泊头市",
                130982: "任丘市",
                130983: "黄骅市",
                130984: "河间市",
                131002: "安次区",
                131003: "广阳区",
                131022: "固安县",
                131023: "永清县",
                131024: "香河县",
                131025: "大城县",
                131026: "文安县",
                131028: "大厂回族自治县",
                131071: "廊坊经济技术开发区",
                131081: "霸州市",
                131082: "三河市",
                131090: "开发区",
                131102: "桃城区",
                131103: "冀州区",
                131121: "枣强县",
                131122: "武邑县",
                131123: "武强县",
                131124: "饶阳县",
                131125: "安平县",
                131126: "故城县",
                131127: "景县",
                131128: "阜城县",
                131171: "河北衡水经济开发区",
                131172: "衡水滨湖新区",
                131182: "深州市",
                140105: "小店区",
                140106: "迎泽区",
                140107: "杏花岭区",
                140108: "尖草坪区",
                140109: "万柏林区",
                140110: "晋源区",
                140121: "清徐县",
                140122: "阳曲县",
                140123: "娄烦县",
                140181: "古交市",
                140212: "新荣区",
                140213: "平城区",
                140214: "云冈区",
                140215: "云州区",
                140221: "阳高县",
                140222: "天镇县",
                140223: "广灵县",
                140224: "灵丘县",
                140225: "浑源县",
                140226: "左云县",
                140271: "山西大同经济开发区",
                140302: "城区",
                140303: "矿区",
                140311: "郊区",
                140321: "平定县",
                140322: "盂县",
                140403: "潞州区",
                140404: "上党区",
                140405: "屯留区",
                140406: "潞城区",
                140423: "襄垣县",
                140425: "平顺县",
                140426: "黎城县",
                140427: "壶关县",
                140428: "长子县",
                140429: "武乡县",
                140430: "沁县",
                140431: "沁源县",
                140471: "山西长治高新技术产业园区",
                140502: "城区",
                140521: "沁水县",
                140522: "阳城县",
                140524: "陵川县",
                140525: "泽州县",
                140581: "高平市",
                140602: "朔城区",
                140603: "平鲁区",
                140621: "山阴县",
                140622: "应县",
                140623: "右玉县",
                140671: "山西朔州经济开发区",
                140681: "怀仁市",
                140702: "榆次区",
                140703: "太谷区",
                140721: "榆社县",
                140722: "左权县",
                140723: "和顺县",
                140724: "昔阳县",
                140725: "寿阳县",
                140727: "祁县",
                140728: "平遥县",
                140729: "灵石县",
                140781: "介休市",
                140802: "盐湖区",
                140821: "临猗县",
                140822: "万荣县",
                140823: "闻喜县",
                140824: "稷山县",
                140825: "新绛县",
                140826: "绛县",
                140827: "垣曲县",
                140828: "夏县",
                140829: "平陆县",
                140830: "芮城县",
                140881: "永济市",
                140882: "河津市",
                140902: "忻府区",
                140921: "定襄县",
                140922: "五台县",
                140923: "代县",
                140924: "繁峙县",
                140925: "宁武县",
                140926: "静乐县",
                140927: "神池县",
                140928: "五寨县",
                140929: "岢岚县",
                140930: "河曲县",
                140931: "保德县",
                140932: "偏关县",
                140971: "五台山风景名胜区",
                140981: "原平市",
                141002: "尧都区",
                141021: "曲沃县",
                141022: "翼城县",
                141023: "襄汾县",
                141024: "洪洞县",
                141025: "古县",
                141026: "安泽县",
                141027: "浮山县",
                141028: "吉县",
                141029: "乡宁县",
                141030: "大宁县",
                141031: "隰县",
                141032: "永和县",
                141033: "蒲县",
                141034: "汾西县",
                141081: "侯马市",
                141082: "霍州市",
                141102: "离石区",
                141121: "文水县",
                141122: "交城县",
                141123: "兴县",
                141124: "临县",
                141125: "柳林县",
                141126: "石楼县",
                141127: "岚县",
                141128: "方山县",
                141129: "中阳县",
                141130: "交口县",
                141181: "孝义市",
                141182: "汾阳市",
                150102: "新城区",
                150103: "回民区",
                150104: "玉泉区",
                150105: "赛罕区",
                150121: "土默特左旗",
                150122: "托克托县",
                150123: "和林格尔县",
                150124: "清水河县",
                150125: "武川县",
                150172: "呼和浩特经济技术开发区",
                150202: "东河区",
                150203: "昆都仑区",
                150204: "青山区",
                150205: "石拐区",
                150206: "白云鄂博矿区",
                150207: "九原区",
                150221: "土默特右旗",
                150222: "固阳县",
                150223: "达尔罕茂明安联合旗",
                150271: "包头稀土高新技术产业开发区",
                150302: "海勃湾区",
                150303: "海南区",
                150304: "乌达区",
                150402: "红山区",
                150403: "元宝山区",
                150404: "松山区",
                150421: "阿鲁科尔沁旗",
                150422: "巴林左旗",
                150423: "巴林右旗",
                150424: "林西县",
                150425: "克什克腾旗",
                150426: "翁牛特旗",
                150428: "喀喇沁旗",
                150429: "宁城县",
                150430: "敖汉旗",
                150502: "科尔沁区",
                150521: "科尔沁左翼中旗",
                150522: "科尔沁左翼后旗",
                150523: "开鲁县",
                150524: "库伦旗",
                150525: "奈曼旗",
                150526: "扎鲁特旗",
                150571: "通辽经济技术开发区",
                150581: "霍林郭勒市",
                150602: "东胜区",
                150603: "康巴什区",
                150621: "达拉特旗",
                150622: "准格尔旗",
                150623: "鄂托克前旗",
                150624: "鄂托克旗",
                150625: "杭锦旗",
                150626: "乌审旗",
                150627: "伊金霍洛旗",
                150702: "海拉尔区",
                150703: "扎赉诺尔区",
                150721: "阿荣旗",
                150722: "莫力达瓦达斡尔族自治旗",
                150723: "鄂伦春自治旗",
                150724: "鄂温克族自治旗",
                150725: "陈巴尔虎旗",
                150726: "新巴尔虎左旗",
                150727: "新巴尔虎右旗",
                150781: "满洲里市",
                150782: "牙克石市",
                150783: "扎兰屯市",
                150784: "额尔古纳市",
                150785: "根河市",
                150802: "临河区",
                150821: "五原县",
                150822: "磴口县",
                150823: "乌拉特前旗",
                150824: "乌拉特中旗",
                150825: "乌拉特后旗",
                150826: "杭锦后旗",
                150902: "集宁区",
                150921: "卓资县",
                150922: "化德县",
                150923: "商都县",
                150924: "兴和县",
                150925: "凉城县",
                150926: "察哈尔右翼前旗",
                150927: "察哈尔右翼中旗",
                150928: "察哈尔右翼后旗",
                150929: "四子王旗",
                150981: "丰镇市",
                152201: "乌兰浩特市",
                152202: "阿尔山市",
                152221: "科尔沁右翼前旗",
                152222: "科尔沁右翼中旗",
                152223: "扎赉特旗",
                152224: "突泉县",
                152501: "二连浩特市",
                152502: "锡林浩特市",
                152522: "阿巴嘎旗",
                152523: "苏尼特左旗",
                152524: "苏尼特右旗",
                152525: "东乌珠穆沁旗",
                152526: "西乌珠穆沁旗",
                152527: "太仆寺旗",
                152528: "镶黄旗",
                152529: "正镶白旗",
                152530: "正蓝旗",
                152531: "多伦县",
                152571: "乌拉盖管委会",
                152921: "阿拉善左旗",
                152922: "阿拉善右旗",
                152923: "额济纳旗",
                152971: "内蒙古阿拉善经济开发区",
                210102: "和平区",
                210103: "沈河区",
                210104: "大东区",
                210105: "皇姑区",
                210106: "铁西区",
                210111: "苏家屯区",
                210112: "浑南区",
                210113: "沈北新区",
                210114: "于洪区",
                210115: "辽中区",
                210123: "康平县",
                210124: "法库县",
                210181: "新民市",
                210190: "经济技术开发区",
                210202: "中山区",
                210203: "西岗区",
                210204: "沙河口区",
                210211: "甘井子区",
                210212: "旅顺口区",
                210213: "金州区",
                210214: "普兰店区",
                210224: "长海县",
                210281: "瓦房店市",
                210283: "庄河市",
                210302: "铁东区",
                210303: "铁西区",
                210304: "立山区",
                210311: "千山区",
                210321: "台安县",
                210323: "岫岩满族自治县",
                210381: "海城市",
                210390: "高新区",
                210402: "新抚区",
                210403: "东洲区",
                210404: "望花区",
                210411: "顺城区",
                210421: "抚顺县",
                210422: "新宾满族自治县",
                210423: "清原满族自治县",
                210502: "平山区",
                210503: "溪湖区",
                210504: "明山区",
                210505: "南芬区",
                210521: "本溪满族自治县",
                210522: "桓仁满族自治县",
                210602: "元宝区",
                210603: "振兴区",
                210604: "振安区",
                210624: "宽甸满族自治县",
                210681: "东港市",
                210682: "凤城市",
                210702: "古塔区",
                210703: "凌河区",
                210711: "太和区",
                210726: "黑山县",
                210727: "义县",
                210781: "凌海市",
                210782: "北镇市",
                210793: "经济技术开发区",
                210802: "站前区",
                210803: "西市区",
                210804: "鲅鱼圈区",
                210811: "老边区",
                210881: "盖州市",
                210882: "大石桥市",
                210902: "海州区",
                210903: "新邱区",
                210904: "太平区",
                210905: "清河门区",
                210911: "细河区",
                210921: "阜新蒙古族自治县",
                210922: "彰武县",
                211002: "白塔区",
                211003: "文圣区",
                211004: "宏伟区",
                211005: "弓长岭区",
                211011: "太子河区",
                211021: "辽阳县",
                211081: "灯塔市",
                211102: "双台子区",
                211103: "兴隆台区",
                211104: "大洼区",
                211122: "盘山县",
                211202: "银州区",
                211204: "清河区",
                211221: "铁岭县",
                211223: "西丰县",
                211224: "昌图县",
                211281: "调兵山市",
                211282: "开原市",
                211302: "双塔区",
                211303: "龙城区",
                211321: "朝阳县",
                211322: "建平县",
                211324: "喀喇沁左翼蒙古族自治县",
                211381: "北票市",
                211382: "凌源市",
                211402: "连山区",
                211403: "龙港区",
                211404: "南票区",
                211421: "绥中县",
                211422: "建昌县",
                211481: "兴城市",
                220102: "南关区",
                220103: "宽城区",
                220104: "朝阳区",
                220105: "二道区",
                220106: "绿园区",
                220112: "双阳区",
                220113: "九台区",
                220122: "农安县",
                220171: "长春经济技术开发区",
                220172: "长春净月高新技术产业开发区",
                220173: "长春高新技术产业开发区",
                220174: "长春汽车经济技术开发区",
                220182: "榆树市",
                220183: "德惠市",
                220192: "经济技术开发区",
                220202: "昌邑区",
                220203: "龙潭区",
                220204: "船营区",
                220211: "丰满区",
                220221: "永吉县",
                220271: "吉林经济开发区",
                220272: "吉林高新技术产业开发区",
                220281: "蛟河市",
                220282: "桦甸市",
                220283: "舒兰市",
                220284: "磐石市",
                220302: "铁西区",
                220303: "铁东区",
                220322: "梨树县",
                220323: "伊通满族自治县",
                220381: "公主岭市",
                220382: "双辽市",
                220402: "龙山区",
                220403: "西安区",
                220421: "东丰县",
                220422: "东辽县",
                220502: "东昌区",
                220503: "二道江区",
                220521: "通化县",
                220523: "辉南县",
                220524: "柳河县",
                220581: "梅河口市",
                220582: "集安市",
                220602: "浑江区",
                220605: "江源区",
                220621: "抚松县",
                220622: "靖宇县",
                220623: "长白朝鲜族自治县",
                220681: "临江市",
                220702: "宁江区",
                220721: "前郭尔罗斯蒙古族自治县",
                220722: "长岭县",
                220723: "乾安县",
                220771: "吉林松原经济开发区",
                220781: "扶余市",
                220802: "洮北区",
                220821: "镇赉县",
                220822: "通榆县",
                220871: "吉林白城经济开发区",
                220881: "洮南市",
                220882: "大安市",
                222401: "延吉市",
                222402: "图们市",
                222403: "敦化市",
                222404: "珲春市",
                222405: "龙井市",
                222406: "和龙市",
                222424: "汪清县",
                222426: "安图县",
                230102: "道里区",
                230103: "南岗区",
                230104: "道外区",
                230108: "平房区",
                230109: "松北区",
                230110: "香坊区",
                230111: "呼兰区",
                230112: "阿城区",
                230113: "双城区",
                230123: "依兰县",
                230124: "方正县",
                230125: "宾县",
                230126: "巴彦县",
                230127: "木兰县",
                230128: "通河县",
                230129: "延寿县",
                230183: "尚志市",
                230184: "五常市",
                230202: "龙沙区",
                230203: "建华区",
                230204: "铁锋区",
                230205: "昂昂溪区",
                230206: "富拉尔基区",
                230207: "碾子山区",
                230208: "梅里斯达斡尔族区",
                230221: "龙江县",
                230223: "依安县",
                230224: "泰来县",
                230225: "甘南县",
                230227: "富裕县",
                230229: "克山县",
                230230: "克东县",
                230231: "拜泉县",
                230281: "讷河市",
                230302: "鸡冠区",
                230303: "恒山区",
                230304: "滴道区",
                230305: "梨树区",
                230306: "城子河区",
                230307: "麻山区",
                230321: "鸡东县",
                230381: "虎林市",
                230382: "密山市",
                230402: "向阳区",
                230403: "工农区",
                230404: "南山区",
                230405: "兴安区",
                230406: "东山区",
                230407: "兴山区",
                230421: "萝北县",
                230422: "绥滨县",
                230502: "尖山区",
                230503: "岭东区",
                230505: "四方台区",
                230506: "宝山区",
                230521: "集贤县",
                230522: "友谊县",
                230523: "宝清县",
                230524: "饶河县",
                230602: "萨尔图区",
                230603: "龙凤区",
                230604: "让胡路区",
                230605: "红岗区",
                230606: "大同区",
                230621: "肇州县",
                230622: "肇源县",
                230623: "林甸县",
                230624: "杜尔伯特蒙古族自治县",
                230671: "大庆高新技术产业开发区",
                230717: "伊美区",
                230718: "乌翠区",
                230719: "友好区",
                230722: "嘉荫县",
                230723: "汤旺县",
                230724: "丰林县",
                230725: "大箐山县",
                230726: "南岔县",
                230751: "金林区",
                230781: "铁力市",
                230803: "向阳区",
                230804: "前进区",
                230805: "东风区",
                230811: "郊区",
                230822: "桦南县",
                230826: "桦川县",
                230828: "汤原县",
                230881: "同江市",
                230882: "富锦市",
                230883: "抚远市",
                230902: "新兴区",
                230903: "桃山区",
                230904: "茄子河区",
                230921: "勃利县",
                231002: "东安区",
                231003: "阳明区",
                231004: "爱民区",
                231005: "西安区",
                231025: "林口县",
                231081: "绥芬河市",
                231083: "海林市",
                231084: "宁安市",
                231085: "穆棱市",
                231086: "东宁市",
                231102: "爱辉区",
                231123: "逊克县",
                231124: "孙吴县",
                231181: "北安市",
                231182: "五大连池市",
                231183: "嫩江市",
                231202: "北林区",
                231221: "望奎县",
                231222: "兰西县",
                231223: "青冈县",
                231224: "庆安县",
                231225: "明水县",
                231226: "绥棱县",
                231281: "安达市",
                231282: "肇东市",
                231283: "海伦市",
                232701: "漠河市",
                232721: "呼玛县",
                232722: "塔河县",
                232790: "松岭区",
                232791: "呼中区",
                232792: "加格达奇区",
                232793: "新林区",
                310101: "黄浦区",
                310104: "徐汇区",
                310105: "长宁区",
                310106: "静安区",
                310107: "普陀区",
                310109: "虹口区",
                310110: "杨浦区",
                310112: "闵行区",
                310113: "宝山区",
                310114: "嘉定区",
                310115: "浦东新区",
                310116: "金山区",
                310117: "松江区",
                310118: "青浦区",
                310120: "奉贤区",
                310151: "崇明区",
                320102: "玄武区",
                320104: "秦淮区",
                320105: "建邺区",
                320106: "鼓楼区",
                320111: "浦口区",
                320113: "栖霞区",
                320114: "雨花台区",
                320115: "江宁区",
                320116: "六合区",
                320117: "溧水区",
                320118: "高淳区",
                320205: "锡山区",
                320206: "惠山区",
                320211: "滨湖区",
                320213: "梁溪区",
                320214: "新吴区",
                320281: "江阴市",
                320282: "宜兴市",
                320302: "鼓楼区",
                320303: "云龙区",
                320305: "贾汪区",
                320311: "泉山区",
                320312: "铜山区",
                320321: "丰县",
                320322: "沛县",
                320324: "睢宁县",
                320371: "徐州经济技术开发区",
                320381: "新沂市",
                320382: "邳州市",
                320391: "工业园区",
                320402: "天宁区",
                320404: "钟楼区",
                320411: "新北区",
                320412: "武进区",
                320413: "金坛区",
                320481: "溧阳市",
                320505: "虎丘区",
                320506: "吴中区",
                320507: "相城区",
                320508: "姑苏区",
                320509: "吴江区",
                320571: "苏州工业园区",
                320581: "常熟市",
                320582: "张家港市",
                320583: "昆山市",
                320585: "太仓市",
                320590: "工业园区",
                320591: "高新区",
                320602: "崇川区",
                320611: "港闸区",
                320612: "通州区",
                320623: "如东县",
                320681: "启东市",
                320682: "如皋市",
                320684: "海门市",
                320685: "海安市",
                320691: "高新区",
                320703: "连云区",
                320706: "海州区",
                320707: "赣榆区",
                320722: "东海县",
                320723: "灌云县",
                320724: "灌南县",
                320771: "连云港经济技术开发区",
                320803: "淮安区",
                320804: "淮阴区",
                320812: "清江浦区",
                320813: "洪泽区",
                320826: "涟水县",
                320830: "盱眙县",
                320831: "金湖县",
                320871: "淮安经济技术开发区",
                320890: "经济开发区",
                320902: "亭湖区",
                320903: "盐都区",
                320904: "大丰区",
                320921: "响水县",
                320922: "滨海县",
                320923: "阜宁县",
                320924: "射阳县",
                320925: "建湖县",
                320971: "盐城经济技术开发区",
                320981: "东台市",
                321002: "广陵区",
                321003: "邗江区",
                321012: "江都区",
                321023: "宝应县",
                321071: "扬州经济技术开发区",
                321081: "仪征市",
                321084: "高邮市",
                321090: "经济开发区",
                321102: "京口区",
                321111: "润州区",
                321112: "丹徒区",
                321150: "镇江新区",
                321181: "丹阳市",
                321182: "扬中市",
                321183: "句容市",
                321202: "海陵区",
                321203: "高港区",
                321204: "姜堰区",
                321271: "泰州医药高新技术产业开发区",
                321281: "兴化市",
                321282: "靖江市",
                321283: "泰兴市",
                321302: "宿城区",
                321311: "宿豫区",
                321322: "沭阳县",
                321323: "泗阳县",
                321324: "泗洪县",
                321371: "宿迁经济技术开发区",
                330102: "上城区",
                330105: "拱墅区",
                330106: "西湖区",
                330108: "滨江区",
                330109: "萧山区",
                330110: "余杭区",
                330111: "富阳区",
                330112: "临安区",
                330113: "钱塘区",
                330114: "临平区",
                330122: "桐庐县",
                330127: "淳安县",
                330182: "建德市",
                330203: "海曙区",
                330205: "江北区",
                330206: "北仑区",
                330211: "镇海区",
                330212: "鄞州区",
                330213: "奉化区",
                330225: "象山县",
                330226: "宁海县",
                330281: "余姚市",
                330282: "慈溪市",
                330302: "鹿城区",
                330303: "龙湾区",
                330304: "瓯海区",
                330305: "洞头区",
                330324: "永嘉县",
                330326: "平阳县",
                330327: "苍南县",
                330328: "文成县",
                330329: "泰顺县",
                330381: "瑞安市",
                330382: "乐清市",
                330383: "龙港市",
                330402: "南湖区",
                330411: "秀洲区",
                330421: "嘉善县",
                330424: "海盐县",
                330481: "海宁市",
                330482: "平湖市",
                330483: "桐乡市",
                330502: "吴兴区",
                330503: "南浔区",
                330521: "德清县",
                330522: "长兴县",
                330523: "安吉县",
                330602: "越城区",
                330603: "柯桥区",
                330604: "上虞区",
                330624: "新昌县",
                330681: "诸暨市",
                330683: "嵊州市",
                330702: "婺城区",
                330703: "金东区",
                330723: "武义县",
                330726: "浦江县",
                330727: "磐安县",
                330781: "兰溪市",
                330782: "义乌市",
                330783: "东阳市",
                330784: "永康市",
                330802: "柯城区",
                330803: "衢江区",
                330822: "常山县",
                330824: "开化县",
                330825: "龙游县",
                330881: "江山市",
                330902: "定海区",
                330903: "普陀区",
                330921: "岱山县",
                330922: "嵊泗县",
                331002: "椒江区",
                331003: "黄岩区",
                331004: "路桥区",
                331022: "三门县",
                331023: "天台县",
                331024: "仙居县",
                331081: "温岭市",
                331082: "临海市",
                331083: "玉环市",
                331102: "莲都区",
                331121: "青田县",
                331122: "缙云县",
                331123: "遂昌县",
                331124: "松阳县",
                331125: "云和县",
                331126: "庆元县",
                331127: "景宁畲族自治县",
                331181: "龙泉市",
                340102: "瑶海区",
                340103: "庐阳区",
                340104: "蜀山区",
                340111: "包河区",
                340121: "长丰县",
                340122: "肥东县",
                340123: "肥西县",
                340124: "庐江县",
                340171: "合肥高新技术产业开发区",
                340172: "合肥经济技术开发区",
                340173: "合肥新站高新技术产业开发区",
                340181: "巢湖市",
                340190: "高新技术开发区",
                340191: "经济技术开发区",
                340202: "镜湖区",
                340203: "弋江区",
                340207: "鸠江区",
                340208: "三山区",
                340221: "芜湖县",
                340222: "繁昌县",
                340223: "南陵县",
                340281: "无为市",
                340302: "龙子湖区",
                340303: "蚌山区",
                340304: "禹会区",
                340311: "淮上区",
                340321: "怀远县",
                340322: "五河县",
                340323: "固镇县",
                340371: "蚌埠市高新技术开发区",
                340372: "蚌埠市经济开发区",
                340402: "大通区",
                340403: "田家庵区",
                340404: "谢家集区",
                340405: "八公山区",
                340406: "潘集区",
                340421: "凤台县",
                340422: "寿县",
                340503: "花山区",
                340504: "雨山区",
                340506: "博望区",
                340521: "当涂县",
                340522: "含山县",
                340523: "和县",
                340602: "杜集区",
                340603: "相山区",
                340604: "烈山区",
                340621: "濉溪县",
                340705: "铜官区",
                340706: "义安区",
                340711: "郊区",
                340722: "枞阳县",
                340802: "迎江区",
                340803: "大观区",
                340811: "宜秀区",
                340822: "怀宁县",
                340825: "太湖县",
                340826: "宿松县",
                340827: "望江县",
                340828: "岳西县",
                340881: "桐城市",
                340882: "潜山市",
                341002: "屯溪区",
                341003: "黄山区",
                341004: "徽州区",
                341021: "歙县",
                341022: "休宁县",
                341023: "黟县",
                341024: "祁门县",
                341102: "琅琊区",
                341103: "南谯区",
                341122: "来安县",
                341124: "全椒县",
                341125: "定远县",
                341126: "凤阳县",
                341181: "天长市",
                341182: "明光市",
                341202: "颍州区",
                341203: "颍东区",
                341204: "颍泉区",
                341221: "临泉县",
                341222: "太和县",
                341225: "阜南县",
                341226: "颍上县",
                341271: "阜阳合肥现代产业园区",
                341282: "界首市",
                341302: "埇桥区",
                341321: "砀山县",
                341322: "萧县",
                341323: "灵璧县",
                341324: "泗县",
                341371: "宿州马鞍山现代产业园区",
                341372: "宿州经济技术开发区",
                341390: "经济开发区",
                341502: "金安区",
                341503: "裕安区",
                341504: "叶集区",
                341522: "霍邱县",
                341523: "舒城县",
                341524: "金寨县",
                341525: "霍山县",
                341602: "谯城区",
                341621: "涡阳县",
                341622: "蒙城县",
                341623: "利辛县",
                341702: "贵池区",
                341721: "东至县",
                341722: "石台县",
                341723: "青阳县",
                341802: "宣州区",
                341821: "郎溪县",
                341823: "泾县",
                341824: "绩溪县",
                341825: "旌德县",
                341871: "宣城市经济开发区",
                341881: "宁国市",
                341882: "广德市",
                350102: "鼓楼区",
                350103: "台江区",
                350104: "仓山区",
                350105: "马尾区",
                350111: "晋安区",
                350112: "长乐区",
                350121: "闽侯县",
                350122: "连江县",
                350123: "罗源县",
                350124: "闽清县",
                350125: "永泰县",
                350128: "平潭县",
                350181: "福清市",
                350203: "思明区",
                350205: "海沧区",
                350206: "湖里区",
                350211: "集美区",
                350212: "同安区",
                350213: "翔安区",
                350302: "城厢区",
                350303: "涵江区",
                350304: "荔城区",
                350305: "秀屿区",
                350322: "仙游县",
                350402: "梅列区",
                350403: "三元区",
                350421: "明溪县",
                350423: "清流县",
                350424: "宁化县",
                350425: "大田县",
                350426: "尤溪县",
                350427: "沙县",
                350428: "将乐县",
                350429: "泰宁县",
                350430: "建宁县",
                350481: "永安市",
                350502: "鲤城区",
                350503: "丰泽区",
                350504: "洛江区",
                350505: "泉港区",
                350521: "惠安县",
                350524: "安溪县",
                350525: "永春县",
                350526: "德化县",
                350527: "金门县",
                350581: "石狮市",
                350582: "晋江市",
                350583: "南安市",
                350602: "芗城区",
                350603: "龙文区",
                350622: "云霄县",
                350623: "漳浦县",
                350624: "诏安县",
                350625: "长泰县",
                350626: "东山县",
                350627: "南靖县",
                350628: "平和县",
                350629: "华安县",
                350681: "龙海市",
                350702: "延平区",
                350703: "建阳区",
                350721: "顺昌县",
                350722: "浦城县",
                350723: "光泽县",
                350724: "松溪县",
                350725: "政和县",
                350781: "邵武市",
                350782: "武夷山市",
                350783: "建瓯市",
                350802: "新罗区",
                350803: "永定区",
                350821: "长汀县",
                350823: "上杭县",
                350824: "武平县",
                350825: "连城县",
                350881: "漳平市",
                350902: "蕉城区",
                350921: "霞浦县",
                350922: "古田县",
                350923: "屏南县",
                350924: "寿宁县",
                350925: "周宁县",
                350926: "柘荣县",
                350981: "福安市",
                350982: "福鼎市",
                360102: "东湖区",
                360103: "西湖区",
                360104: "青云谱区",
                360111: "青山湖区",
                360112: "新建区",
                360113: "红谷滩区",
                360121: "南昌县",
                360123: "安义县",
                360124: "进贤县",
                360190: "经济技术开发区",
                360192: "高新区",
                360202: "昌江区",
                360203: "珠山区",
                360222: "浮梁县",
                360281: "乐平市",
                360302: "安源区",
                360313: "湘东区",
                360321: "莲花县",
                360322: "上栗县",
                360323: "芦溪县",
                360402: "濂溪区",
                360403: "浔阳区",
                360404: "柴桑区",
                360423: "武宁县",
                360424: "修水县",
                360425: "永修县",
                360426: "德安县",
                360428: "都昌县",
                360429: "湖口县",
                360430: "彭泽县",
                360481: "瑞昌市",
                360482: "共青城市",
                360483: "庐山市",
                360490: "经济技术开发区",
                360502: "渝水区",
                360521: "分宜县",
                360602: "月湖区",
                360603: "余江区",
                360681: "贵溪市",
                360702: "章贡区",
                360703: "南康区",
                360704: "赣县区",
                360722: "信丰县",
                360723: "大余县",
                360724: "上犹县",
                360725: "崇义县",
                360726: "安远县",
                360727: "龙南县",
                360728: "定南县",
                360729: "全南县",
                360730: "宁都县",
                360731: "于都县",
                360732: "兴国县",
                360733: "会昌县",
                360734: "寻乌县",
                360735: "石城县",
                360781: "瑞金市",
                360802: "吉州区",
                360803: "青原区",
                360821: "吉安县",
                360822: "吉水县",
                360823: "峡江县",
                360824: "新干县",
                360825: "永丰县",
                360826: "泰和县",
                360827: "遂川县",
                360828: "万安县",
                360829: "安福县",
                360830: "永新县",
                360881: "井冈山市",
                360902: "袁州区",
                360921: "奉新县",
                360922: "万载县",
                360923: "上高县",
                360924: "宜丰县",
                360925: "靖安县",
                360926: "铜鼓县",
                360981: "丰城市",
                360982: "樟树市",
                360983: "高安市",
                361002: "临川区",
                361003: "东乡区",
                361021: "南城县",
                361022: "黎川县",
                361023: "南丰县",
                361024: "崇仁县",
                361025: "乐安县",
                361026: "宜黄县",
                361027: "金溪县",
                361028: "资溪县",
                361030: "广昌县",
                361102: "信州区",
                361103: "广丰区",
                361104: "广信区",
                361123: "玉山县",
                361124: "铅山县",
                361125: "横峰县",
                361126: "弋阳县",
                361127: "余干县",
                361128: "鄱阳县",
                361129: "万年县",
                361130: "婺源县",
                361181: "德兴市",
                370102: "历下区",
                370103: "市中区",
                370104: "槐荫区",
                370105: "天桥区",
                370112: "历城区",
                370113: "长清区",
                370114: "章丘区",
                370115: "济阳区",
                370116: "莱芜区",
                370117: "钢城区",
                370124: "平阴县",
                370126: "商河县",
                370171: "济南高新技术产业开发区",
                370190: "高新区",
                370202: "市南区",
                370203: "市北区",
                370211: "黄岛区",
                370212: "崂山区",
                370213: "李沧区",
                370214: "城阳区",
                370215: "即墨区",
                370271: "青岛高新技术产业开发区",
                370281: "胶州市",
                370283: "平度市",
                370285: "莱西市",
                370290: "开发区",
                370302: "淄川区",
                370303: "张店区",
                370304: "博山区",
                370305: "临淄区",
                370306: "周村区",
                370321: "桓台县",
                370322: "高青县",
                370323: "沂源县",
                370402: "市中区",
                370403: "薛城区",
                370404: "峄城区",
                370405: "台儿庄区",
                370406: "山亭区",
                370481: "滕州市",
                370502: "东营区",
                370503: "河口区",
                370505: "垦利区",
                370522: "利津县",
                370523: "广饶县",
                370571: "东营经济技术开发区",
                370572: "东营港经济开发区",
                370602: "芝罘区",
                370611: "福山区",
                370612: "牟平区",
                370613: "莱山区",
                370634: "长岛县",
                370671: "烟台高新技术产业开发区",
                370672: "烟台经济技术开发区",
                370681: "龙口市",
                370682: "莱阳市",
                370683: "莱州市",
                370684: "蓬莱市",
                370685: "招远市",
                370686: "栖霞市",
                370687: "海阳市",
                370690: "开发区",
                370702: "潍城区",
                370703: "寒亭区",
                370704: "坊子区",
                370705: "奎文区",
                370724: "临朐县",
                370725: "昌乐县",
                370772: "潍坊滨海经济技术开发区",
                370781: "青州市",
                370782: "诸城市",
                370783: "寿光市",
                370784: "安丘市",
                370785: "高密市",
                370786: "昌邑市",
                370790: "开发区",
                370791: "高新区",
                370811: "任城区",
                370812: "兖州区",
                370826: "微山县",
                370827: "鱼台县",
                370828: "金乡县",
                370829: "嘉祥县",
                370830: "汶上县",
                370831: "泗水县",
                370832: "梁山县",
                370871: "济宁高新技术产业开发区",
                370881: "曲阜市",
                370883: "邹城市",
                370890: "高新区",
                370902: "泰山区",
                370911: "岱岳区",
                370921: "宁阳县",
                370923: "东平县",
                370982: "新泰市",
                370983: "肥城市",
                371002: "环翠区",
                371003: "文登区",
                371071: "威海火炬高技术产业开发区",
                371072: "威海经济技术开发区",
                371082: "荣成市",
                371083: "乳山市",
                371091: "经济技术开发区",
                371102: "东港区",
                371103: "岚山区",
                371121: "五莲县",
                371122: "莒县",
                371171: "日照经济技术开发区",
                371302: "兰山区",
                371311: "罗庄区",
                371312: "河东区",
                371321: "沂南县",
                371322: "郯城县",
                371323: "沂水县",
                371324: "兰陵县",
                371325: "费县",
                371326: "平邑县",
                371327: "莒南县",
                371328: "蒙阴县",
                371329: "临沭县",
                371371: "临沂高新技术产业开发区",
                371402: "德城区",
                371403: "陵城区",
                371422: "宁津县",
                371423: "庆云县",
                371424: "临邑县",
                371425: "齐河县",
                371426: "平原县",
                371427: "夏津县",
                371428: "武城县",
                371472: "德州运河经济开发区",
                371481: "乐陵市",
                371482: "禹城市",
                371502: "东昌府区",
                371503: "茌平区",
                371521: "阳谷县",
                371522: "莘县",
                371524: "东阿县",
                371525: "冠县",
                371526: "高唐县",
                371581: "临清市",
                371602: "滨城区",
                371603: "沾化区",
                371621: "惠民县",
                371622: "阳信县",
                371623: "无棣县",
                371625: "博兴县",
                371681: "邹平市",
                371702: "牡丹区",
                371703: "定陶区",
                371721: "曹县",
                371722: "单县",
                371723: "成武县",
                371724: "巨野县",
                371725: "郓城县",
                371726: "鄄城县",
                371728: "东明县",
                371771: "菏泽经济技术开发区",
                371772: "菏泽高新技术开发区",
                410102: "中原区",
                410103: "二七区",
                410104: "管城回族区",
                410105: "金水区",
                410106: "上街区",
                410108: "惠济区",
                410122: "中牟县",
                410171: "郑州经济技术开发区",
                410172: "郑州高新技术产业开发区",
                410173: "郑州航空港经济综合实验区",
                410181: "巩义市",
                410182: "荥阳市",
                410183: "新密市",
                410184: "新郑市",
                410185: "登封市",
                410190: "高新技术开发区",
                410191: "经济技术开发区",
                410202: "龙亭区",
                410203: "顺河回族区",
                410204: "鼓楼区",
                410205: "禹王台区",
                410212: "祥符区",
                410221: "杞县",
                410222: "通许县",
                410223: "尉氏县",
                410225: "兰考县",
                410302: "老城区",
                410303: "西工区",
                410304: "瀍河回族区",
                410305: "涧西区",
                410306: "吉利区",
                410311: "洛龙区",
                410322: "孟津县",
                410323: "新安县",
                410324: "栾川县",
                410325: "嵩县",
                410326: "汝阳县",
                410327: "宜阳县",
                410328: "洛宁县",
                410329: "伊川县",
                410381: "偃师市",
                410402: "新华区",
                410403: "卫东区",
                410404: "石龙区",
                410411: "湛河区",
                410421: "宝丰县",
                410422: "叶县",
                410423: "鲁山县",
                410425: "郏县",
                410471: "平顶山高新技术产业开发区",
                410481: "舞钢市",
                410482: "汝州市",
                410502: "文峰区",
                410503: "北关区",
                410505: "殷都区",
                410506: "龙安区",
                410522: "安阳县",
                410523: "汤阴县",
                410526: "滑县",
                410527: "内黄县",
                410581: "林州市",
                410590: "开发区",
                410602: "鹤山区",
                410603: "山城区",
                410611: "淇滨区",
                410621: "浚县",
                410622: "淇县",
                410702: "红旗区",
                410703: "卫滨区",
                410704: "凤泉区",
                410711: "牧野区",
                410721: "新乡县",
                410724: "获嘉县",
                410725: "原阳县",
                410726: "延津县",
                410727: "封丘县",
                410771: "新乡高新技术产业开发区",
                410772: "新乡经济技术开发区",
                410781: "卫辉市",
                410782: "辉县市",
                410783: "长垣市",
                410802: "解放区",
                410803: "中站区",
                410804: "马村区",
                410811: "山阳区",
                410821: "修武县",
                410822: "博爱县",
                410823: "武陟县",
                410825: "温县",
                410871: "焦作城乡一体化示范区",
                410882: "沁阳市",
                410883: "孟州市",
                410902: "华龙区",
                410922: "清丰县",
                410923: "南乐县",
                410926: "范县",
                410927: "台前县",
                410928: "濮阳县",
                410971: "河南濮阳工业园区",
                411002: "魏都区",
                411003: "建安区",
                411024: "鄢陵县",
                411025: "襄城县",
                411071: "许昌经济技术开发区",
                411081: "禹州市",
                411082: "长葛市",
                411102: "源汇区",
                411103: "郾城区",
                411104: "召陵区",
                411121: "舞阳县",
                411122: "临颍县",
                411171: "漯河经济技术开发区",
                411202: "湖滨区",
                411203: "陕州区",
                411221: "渑池县",
                411224: "卢氏县",
                411271: "河南三门峡经济开发区",
                411281: "义马市",
                411282: "灵宝市",
                411302: "宛城区",
                411303: "卧龙区",
                411321: "南召县",
                411322: "方城县",
                411323: "西峡县",
                411324: "镇平县",
                411325: "内乡县",
                411326: "淅川县",
                411327: "社旗县",
                411328: "唐河县",
                411329: "新野县",
                411330: "桐柏县",
                411372: "南阳市城乡一体化示范区",
                411381: "邓州市",
                411402: "梁园区",
                411403: "睢阳区",
                411421: "民权县",
                411422: "睢县",
                411423: "宁陵县",
                411424: "柘城县",
                411425: "虞城县",
                411426: "夏邑县",
                411481: "永城市",
                411502: "浉河区",
                411503: "平桥区",
                411521: "罗山县",
                411522: "光山县",
                411523: "新县",
                411524: "商城县",
                411525: "固始县",
                411526: "潢川县",
                411527: "淮滨县",
                411528: "息县",
                411602: "川汇区",
                411603: "淮阳区",
                411621: "扶沟县",
                411622: "西华县",
                411623: "商水县",
                411624: "沈丘县",
                411625: "郸城县",
                411627: "太康县",
                411628: "鹿邑县",
                411671: "河南周口经济开发区",
                411681: "项城市",
                411690: "经济开发区",
                411702: "驿城区",
                411721: "西平县",
                411722: "上蔡县",
                411723: "平舆县",
                411724: "正阳县",
                411725: "确山县",
                411726: "泌阳县",
                411727: "汝南县",
                411728: "遂平县",
                411729: "新蔡县",
                419001: "济源市",
                420102: "江岸区",
                420103: "江汉区",
                420104: "硚口区",
                420105: "汉阳区",
                420106: "武昌区",
                420107: "青山区",
                420111: "洪山区",
                420112: "东西湖区",
                420113: "汉南区",
                420114: "蔡甸区",
                420115: "江夏区",
                420116: "黄陂区",
                420117: "新洲区",
                420202: "黄石港区",
                420203: "西塞山区",
                420204: "下陆区",
                420205: "铁山区",
                420222: "阳新县",
                420281: "大冶市",
                420302: "茅箭区",
                420303: "张湾区",
                420304: "郧阳区",
                420322: "郧西县",
                420323: "竹山县",
                420324: "竹溪县",
                420325: "房县",
                420381: "丹江口市",
                420502: "西陵区",
                420503: "伍家岗区",
                420504: "点军区",
                420505: "猇亭区",
                420506: "夷陵区",
                420525: "远安县",
                420526: "兴山县",
                420527: "秭归县",
                420528: "长阳土家族自治县",
                420529: "五峰土家族自治县",
                420581: "宜都市",
                420582: "当阳市",
                420583: "枝江市",
                420590: "经济开发区",
                420602: "襄城区",
                420606: "樊城区",
                420607: "襄州区",
                420624: "南漳县",
                420625: "谷城县",
                420626: "保康县",
                420682: "老河口市",
                420683: "枣阳市",
                420684: "宜城市",
                420702: "梁子湖区",
                420703: "华容区",
                420704: "鄂城区",
                420802: "东宝区",
                420804: "掇刀区",
                420822: "沙洋县",
                420881: "钟祥市",
                420882: "京山市",
                420902: "孝南区",
                420921: "孝昌县",
                420922: "大悟县",
                420923: "云梦县",
                420981: "应城市",
                420982: "安陆市",
                420984: "汉川市",
                421002: "沙市区",
                421003: "荆州区",
                421022: "公安县",
                421023: "监利县",
                421024: "江陵县",
                421081: "石首市",
                421083: "洪湖市",
                421087: "松滋市",
                421102: "黄州区",
                421121: "团风县",
                421122: "红安县",
                421123: "罗田县",
                421124: "英山县",
                421125: "浠水县",
                421126: "蕲春县",
                421127: "黄梅县",
                421171: "龙感湖管理区",
                421181: "麻城市",
                421182: "武穴市",
                421202: "咸安区",
                421221: "嘉鱼县",
                421222: "通城县",
                421223: "崇阳县",
                421224: "通山县",
                421281: "赤壁市",
                421303: "曾都区",
                421321: "随县",
                421381: "广水市",
                422801: "恩施市",
                422802: "利川市",
                422822: "建始县",
                422823: "巴东县",
                422825: "宣恩县",
                422826: "咸丰县",
                422827: "来凤县",
                422828: "鹤峰县",
                429004: "仙桃市",
                429005: "潜江市",
                429006: "天门市",
                429021: "神农架林区",
                430102: "芙蓉区",
                430103: "天心区",
                430104: "岳麓区",
                430105: "开福区",
                430111: "雨花区",
                430112: "望城区",
                430121: "长沙县",
                430181: "浏阳市",
                430182: "宁乡市",
                430202: "荷塘区",
                430203: "芦淞区",
                430204: "石峰区",
                430211: "天元区",
                430212: "渌口区",
                430223: "攸县",
                430224: "茶陵县",
                430225: "炎陵县",
                430271: "云龙示范区",
                430281: "醴陵市",
                430302: "雨湖区",
                430304: "岳塘区",
                430321: "湘潭县",
                430373: "湘潭九华示范区",
                430381: "湘乡市",
                430382: "韶山市",
                430405: "珠晖区",
                430406: "雁峰区",
                430407: "石鼓区",
                430408: "蒸湘区",
                430412: "南岳区",
                430421: "衡阳县",
                430422: "衡南县",
                430423: "衡山县",
                430424: "衡东县",
                430426: "祁东县",
                430481: "耒阳市",
                430482: "常宁市",
                430502: "双清区",
                430503: "大祥区",
                430511: "北塔区",
                430522: "新邵县",
                430523: "邵阳县",
                430524: "隆回县",
                430525: "洞口县",
                430527: "绥宁县",
                430528: "新宁县",
                430529: "城步苗族自治县",
                430581: "武冈市",
                430582: "邵东市",
                430602: "岳阳楼区",
                430603: "云溪区",
                430611: "君山区",
                430621: "岳阳县",
                430623: "华容县",
                430624: "湘阴县",
                430626: "平江县",
                430681: "汨罗市",
                430682: "临湘市",
                430702: "武陵区",
                430703: "鼎城区",
                430721: "安乡县",
                430722: "汉寿县",
                430723: "澧县",
                430724: "临澧县",
                430725: "桃源县",
                430726: "石门县",
                430781: "津市市",
                430802: "永定区",
                430811: "武陵源区",
                430821: "慈利县",
                430822: "桑植县",
                430902: "资阳区",
                430903: "赫山区",
                430921: "南县",
                430922: "桃江县",
                430923: "安化县",
                430971: "益阳市大通湖管理区",
                430981: "沅江市",
                431002: "北湖区",
                431003: "苏仙区",
                431021: "桂阳县",
                431022: "宜章县",
                431023: "永兴县",
                431024: "嘉禾县",
                431025: "临武县",
                431026: "汝城县",
                431027: "桂东县",
                431028: "安仁县",
                431081: "资兴市",
                431102: "零陵区",
                431103: "冷水滩区",
                431121: "祁阳县",
                431122: "东安县",
                431123: "双牌县",
                431124: "道县",
                431125: "江永县",
                431126: "宁远县",
                431127: "蓝山县",
                431128: "新田县",
                431129: "江华瑶族自治县",
                431202: "鹤城区",
                431221: "中方县",
                431222: "沅陵县",
                431223: "辰溪县",
                431224: "溆浦县",
                431225: "会同县",
                431226: "麻阳苗族自治县",
                431227: "新晃侗族自治县",
                431228: "芷江侗族自治县",
                431229: "靖州苗族侗族自治县",
                431230: "通道侗族自治县",
                431271: "怀化市洪江管理区",
                431281: "洪江市",
                431302: "娄星区",
                431321: "双峰县",
                431322: "新化县",
                431381: "冷水江市",
                431382: "涟源市",
                433101: "吉首市",
                433122: "泸溪县",
                433123: "凤凰县",
                433124: "花垣县",
                433125: "保靖县",
                433126: "古丈县",
                433127: "永顺县",
                433130: "龙山县",
                440103: "荔湾区",
                440104: "越秀区",
                440105: "海珠区",
                440106: "天河区",
                440111: "白云区",
                440112: "黄埔区",
                440113: "番禺区",
                440114: "花都区",
                440115: "南沙区",
                440117: "从化区",
                440118: "增城区",
                440203: "武江区",
                440204: "浈江区",
                440205: "曲江区",
                440222: "始兴县",
                440224: "仁化县",
                440229: "翁源县",
                440232: "乳源瑶族自治县",
                440233: "新丰县",
                440281: "乐昌市",
                440282: "南雄市",
                440303: "罗湖区",
                440304: "福田区",
                440305: "南山区",
                440306: "宝安区",
                440307: "龙岗区",
                440308: "盐田区",
                440309: "龙华区",
                440310: "坪山区",
                440311: "光明区",
                440402: "香洲区",
                440403: "斗门区",
                440404: "金湾区",
                440507: "龙湖区",
                440511: "金平区",
                440512: "濠江区",
                440513: "潮阳区",
                440514: "潮南区",
                440515: "澄海区",
                440523: "南澳县",
                440604: "禅城区",
                440605: "南海区",
                440606: "顺德区",
                440607: "三水区",
                440608: "高明区",
                440703: "蓬江区",
                440704: "江海区",
                440705: "新会区",
                440781: "台山市",
                440783: "开平市",
                440784: "鹤山市",
                440785: "恩平市",
                440802: "赤坎区",
                440803: "霞山区",
                440804: "坡头区",
                440811: "麻章区",
                440823: "遂溪县",
                440825: "徐闻县",
                440881: "廉江市",
                440882: "雷州市",
                440883: "吴川市",
                440890: "经济技术开发区",
                440902: "茂南区",
                440904: "电白区",
                440981: "高州市",
                440982: "化州市",
                440983: "信宜市",
                441202: "端州区",
                441203: "鼎湖区",
                441204: "高要区",
                441223: "广宁县",
                441224: "怀集县",
                441225: "封开县",
                441226: "德庆县",
                441284: "四会市",
                441302: "惠城区",
                441303: "惠阳区",
                441322: "博罗县",
                441323: "惠东县",
                441324: "龙门县",
                441402: "梅江区",
                441403: "梅县区",
                441422: "大埔县",
                441423: "丰顺县",
                441424: "五华县",
                441426: "平远县",
                441427: "蕉岭县",
                441481: "兴宁市",
                441502: "城区",
                441521: "海丰县",
                441523: "陆河县",
                441581: "陆丰市",
                441602: "源城区",
                441621: "紫金县",
                441622: "龙川县",
                441623: "连平县",
                441624: "和平县",
                441625: "东源县",
                441702: "江城区",
                441704: "阳东区",
                441721: "阳西县",
                441781: "阳春市",
                441802: "清城区",
                441803: "清新区",
                441821: "佛冈县",
                441823: "阳山县",
                441825: "连山壮族瑶族自治县",
                441826: "连南瑶族自治县",
                441881: "英德市",
                441882: "连州市",
                441901: "中堂镇",
                441903: "南城街道",
                441904: "长安镇",
                441905: "东坑镇",
                441906: "樟木头镇",
                441907: "莞城街道",
                441908: "石龙镇",
                441909: "桥头镇",
                441910: "万江街道",
                441911: "麻涌镇",
                441912: "虎门镇",
                441913: "谢岗镇",
                441914: "石碣镇",
                441915: "茶山镇",
                441916: "东城街道",
                441917: "洪梅镇",
                441918: "道滘镇",
                441919: "高埗镇",
                441920: "企石镇",
                441921: "凤岗镇",
                441922: "大岭山镇",
                441923: "松山湖",
                441924: "清溪镇",
                441925: "望牛墩镇",
                441926: "厚街镇",
                441927: "常平镇",
                441928: "寮步镇",
                441929: "石排镇",
                441930: "横沥镇",
                441931: "塘厦镇",
                441932: "黄江镇",
                441933: "大朗镇",
                441934: "东莞港",
                441935: "东莞生态园",
                441990: "沙田镇",
                442001: "南头镇",
                442002: "神湾镇",
                442003: "东凤镇",
                442004: "五桂山街道",
                442005: "黄圃镇",
                442006: "小榄镇",
                442007: "石岐街道",
                442008: "横栏镇",
                442009: "三角镇",
                442010: "三乡镇",
                442011: "港口镇",
                442012: "沙溪镇",
                442013: "板芙镇",
                442015: "东升镇",
                442016: "阜沙镇",
                442017: "民众镇",
                442018: "东区街道",
                442019: "火炬开发区街道办事处",
                442020: "西区街道",
                442021: "南区街道",
                442022: "古镇镇",
                442023: "坦洲镇",
                442024: "大涌镇",
                442025: "南朗镇",
                445102: "湘桥区",
                445103: "潮安区",
                445122: "饶平县",
                445202: "榕城区",
                445203: "揭东区",
                445222: "揭西县",
                445224: "惠来县",
                445281: "普宁市",
                445302: "云城区",
                445303: "云安区",
                445321: "新兴县",
                445322: "郁南县",
                445381: "罗定市",
                450102: "兴宁区",
                450103: "青秀区",
                450105: "江南区",
                450107: "西乡塘区",
                450108: "良庆区",
                450109: "邕宁区",
                450110: "武鸣区",
                450123: "隆安县",
                450124: "马山县",
                450125: "上林县",
                450126: "宾阳县",
                450127: "横县",
                450202: "城中区",
                450203: "鱼峰区",
                450204: "柳南区",
                450205: "柳北区",
                450206: "柳江区",
                450222: "柳城县",
                450223: "鹿寨县",
                450224: "融安县",
                450225: "融水苗族自治县",
                450226: "三江侗族自治县",
                450302: "秀峰区",
                450303: "叠彩区",
                450304: "象山区",
                450305: "七星区",
                450311: "雁山区",
                450312: "临桂区",
                450321: "阳朔县",
                450323: "灵川县",
                450324: "全州县",
                450325: "兴安县",
                450326: "永福县",
                450327: "灌阳县",
                450328: "龙胜各族自治县",
                450329: "资源县",
                450330: "平乐县",
                450332: "恭城瑶族自治县",
                450381: "荔浦市",
                450403: "万秀区",
                450405: "长洲区",
                450406: "龙圩区",
                450421: "苍梧县",
                450422: "藤县",
                450423: "蒙山县",
                450481: "岑溪市",
                450502: "海城区",
                450503: "银海区",
                450512: "铁山港区",
                450521: "合浦县",
                450602: "港口区",
                450603: "防城区",
                450621: "上思县",
                450681: "东兴市",
                450702: "钦南区",
                450703: "钦北区",
                450721: "灵山县",
                450722: "浦北县",
                450802: "港北区",
                450803: "港南区",
                450804: "覃塘区",
                450821: "平南县",
                450881: "桂平市",
                450902: "玉州区",
                450903: "福绵区",
                450921: "容县",
                450922: "陆川县",
                450923: "博白县",
                450924: "兴业县",
                450981: "北流市",
                451002: "右江区",
                451003: "田阳区",
                451022: "田东县",
                451024: "德保县",
                451026: "那坡县",
                451027: "凌云县",
                451028: "乐业县",
                451029: "田林县",
                451030: "西林县",
                451031: "隆林各族自治县",
                451081: "靖西市",
                451082: "平果市",
                451102: "八步区",
                451103: "平桂区",
                451121: "昭平县",
                451122: "钟山县",
                451123: "富川瑶族自治县",
                451202: "金城江区",
                451203: "宜州区",
                451221: "南丹县",
                451222: "天峨县",
                451223: "凤山县",
                451224: "东兰县",
                451225: "罗城仫佬族自治县",
                451226: "环江毛南族自治县",
                451227: "巴马瑶族自治县",
                451228: "都安瑶族自治县",
                451229: "大化瑶族自治县",
                451302: "兴宾区",
                451321: "忻城县",
                451322: "象州县",
                451323: "武宣县",
                451324: "金秀瑶族自治县",
                451381: "合山市",
                451402: "江州区",
                451421: "扶绥县",
                451422: "宁明县",
                451423: "龙州县",
                451424: "大新县",
                451425: "天等县",
                451481: "凭祥市",
                460105: "秀英区",
                460106: "龙华区",
                460107: "琼山区",
                460108: "美兰区",
                460202: "海棠区",
                460203: "吉阳区",
                460204: "天涯区",
                460205: "崖州区",
                460321: "西沙区",
                460322: "南沙区",
                460401: "那大镇",
                460402: "和庆镇",
                460403: "南丰镇",
                460404: "大成镇",
                460405: "雅星镇",
                460406: "兰洋镇",
                460407: "光村镇",
                460408: "木棠镇",
                460409: "海头镇",
                460410: "峨蔓镇",
                460411: "王五镇",
                460412: "白马井镇",
                460413: "中和镇",
                460414: "排浦镇",
                460415: "东成镇",
                460416: "新州镇",
                460417: "洋浦经济开发区",
                460418: "华南热作学院",
                469001: "五指山市",
                469002: "琼海市",
                469005: "文昌市",
                469006: "万宁市",
                469007: "东方市",
                469021: "定安县",
                469022: "屯昌县",
                469023: "澄迈县",
                469024: "临高县",
                469025: "白沙黎族自治县",
                469026: "昌江黎族自治县",
                469027: "乐东黎族自治县",
                469028: "陵水黎族自治县",
                469029: "保亭黎族苗族自治县",
                469030: "琼中黎族苗族自治县",
                500101: "万州区",
                500102: "涪陵区",
                500103: "渝中区",
                500104: "大渡口区",
                500105: "江北区",
                500106: "沙坪坝区",
                500107: "九龙坡区",
                500108: "南岸区",
                500109: "北碚区",
                500110: "綦江区",
                500111: "大足区",
                500112: "渝北区",
                500113: "巴南区",
                500114: "黔江区",
                500115: "长寿区",
                500116: "江津区",
                500117: "合川区",
                500118: "永川区",
                500119: "南川区",
                500120: "璧山区",
                500151: "铜梁区",
                500152: "潼南区",
                500153: "荣昌区",
                500154: "开州区",
                500155: "梁平区",
                500156: "武隆区",
                500229: "城口县",
                500230: "丰都县",
                500231: "垫江县",
                500233: "忠县",
                500235: "云阳县",
                500236: "奉节县",
                500237: "巫山县",
                500238: "巫溪县",
                500240: "石柱土家族自治县",
                500241: "秀山土家族苗族自治县",
                500242: "酉阳土家族苗族自治县",
                500243: "彭水苗族土家族自治县",
                510104: "锦江区",
                510105: "青羊区",
                510106: "金牛区",
                510107: "武侯区",
                510108: "成华区",
                510112: "龙泉驿区",
                510113: "青白江区",
                510114: "新都区",
                510115: "温江区",
                510116: "双流区",
                510117: "郫都区",
                510121: "金堂县",
                510129: "大邑县",
                510131: "蒲江县",
                510132: "新津县",
                510181: "都江堰市",
                510182: "彭州市",
                510183: "邛崃市",
                510184: "崇州市",
                510185: "简阳市",
                510191: "高新区",
                510302: "自流井区",
                510303: "贡井区",
                510304: "大安区",
                510311: "沿滩区",
                510321: "荣县",
                510322: "富顺县",
                510402: "东区",
                510403: "西区",
                510411: "仁和区",
                510421: "米易县",
                510422: "盐边县",
                510502: "江阳区",
                510503: "纳溪区",
                510504: "龙马潭区",
                510521: "泸县",
                510522: "合江县",
                510524: "叙永县",
                510525: "古蔺县",
                510603: "旌阳区",
                510604: "罗江区",
                510623: "中江县",
                510681: "广汉市",
                510682: "什邡市",
                510683: "绵竹市",
                510703: "涪城区",
                510704: "游仙区",
                510705: "安州区",
                510722: "三台县",
                510723: "盐亭县",
                510725: "梓潼县",
                510726: "北川羌族自治县",
                510727: "平武县",
                510781: "江油市",
                510791: "高新区",
                510802: "利州区",
                510811: "昭化区",
                510812: "朝天区",
                510821: "旺苍县",
                510822: "青川县",
                510823: "剑阁县",
                510824: "苍溪县",
                510903: "船山区",
                510904: "安居区",
                510921: "蓬溪县",
                510923: "大英县",
                510981: "射洪市",
                511002: "市中区",
                511011: "东兴区",
                511024: "威远县",
                511025: "资中县",
                511083: "隆昌市",
                511102: "市中区",
                511111: "沙湾区",
                511112: "五通桥区",
                511113: "金口河区",
                511123: "犍为县",
                511124: "井研县",
                511126: "夹江县",
                511129: "沐川县",
                511132: "峨边彝族自治县",
                511133: "马边彝族自治县",
                511181: "峨眉山市",
                511302: "顺庆区",
                511303: "高坪区",
                511304: "嘉陵区",
                511321: "南部县",
                511322: "营山县",
                511323: "蓬安县",
                511324: "仪陇县",
                511325: "西充县",
                511381: "阆中市",
                511402: "东坡区",
                511403: "彭山区",
                511421: "仁寿县",
                511423: "洪雅县",
                511424: "丹棱县",
                511425: "青神县",
                511502: "翠屏区",
                511503: "南溪区",
                511504: "叙州区",
                511523: "江安县",
                511524: "长宁县",
                511525: "高县",
                511526: "珙县",
                511527: "筠连县",
                511528: "兴文县",
                511529: "屏山县",
                511602: "广安区",
                511603: "前锋区",
                511621: "岳池县",
                511622: "武胜县",
                511623: "邻水县",
                511681: "华蓥市",
                511702: "通川区",
                511703: "达川区",
                511722: "宣汉县",
                511723: "开江县",
                511724: "大竹县",
                511725: "渠县",
                511781: "万源市",
                511802: "雨城区",
                511803: "名山区",
                511822: "荥经县",
                511823: "汉源县",
                511824: "石棉县",
                511825: "天全县",
                511826: "芦山县",
                511827: "宝兴县",
                511902: "巴州区",
                511903: "恩阳区",
                511921: "通江县",
                511922: "南江县",
                511923: "平昌县",
                511971: "巴中经济开发区",
                512002: "雁江区",
                512021: "安岳县",
                512022: "乐至县",
                513201: "马尔康市",
                513221: "汶川县",
                513222: "理县",
                513223: "茂县",
                513224: "松潘县",
                513225: "九寨沟县",
                513226: "金川县",
                513227: "小金县",
                513228: "黑水县",
                513230: "壤塘县",
                513231: "阿坝县",
                513232: "若尔盖县",
                513233: "红原县",
                513301: "康定市",
                513322: "泸定县",
                513323: "丹巴县",
                513324: "九龙县",
                513325: "雅江县",
                513326: "道孚县",
                513327: "炉霍县",
                513328: "甘孜县",
                513329: "新龙县",
                513330: "德格县",
                513331: "白玉县",
                513332: "石渠县",
                513333: "色达县",
                513334: "理塘县",
                513335: "巴塘县",
                513336: "乡城县",
                513337: "稻城县",
                513338: "得荣县",
                513401: "西昌市",
                513422: "木里藏族自治县",
                513423: "盐源县",
                513424: "德昌县",
                513425: "会理县",
                513426: "会东县",
                513427: "宁南县",
                513428: "普格县",
                513429: "布拖县",
                513430: "金阳县",
                513431: "昭觉县",
                513432: "喜德县",
                513433: "冕宁县",
                513434: "越西县",
                513435: "甘洛县",
                513436: "美姑县",
                513437: "雷波县",
                520102: "南明区",
                520103: "云岩区",
                520111: "花溪区",
                520112: "乌当区",
                520113: "白云区",
                520115: "观山湖区",
                520121: "开阳县",
                520122: "息烽县",
                520123: "修文县",
                520181: "清镇市",
                520201: "钟山区",
                520203: "六枝特区",
                520221: "水城县",
                520281: "盘州市",
                520302: "红花岗区",
                520303: "汇川区",
                520304: "播州区",
                520322: "桐梓县",
                520323: "绥阳县",
                520324: "正安县",
                520325: "道真仡佬族苗族自治县",
                520326: "务川仡佬族苗族自治县",
                520327: "凤冈县",
                520328: "湄潭县",
                520329: "余庆县",
                520330: "习水县",
                520381: "赤水市",
                520382: "仁怀市",
                520402: "西秀区",
                520403: "平坝区",
                520422: "普定县",
                520423: "镇宁布依族苗族自治县",
                520424: "关岭布依族苗族自治县",
                520425: "紫云苗族布依族自治县",
                520502: "七星关区",
                520521: "大方县",
                520522: "黔西县",
                520523: "金沙县",
                520524: "织金县",
                520525: "纳雍县",
                520526: "威宁彝族回族苗族自治县",
                520527: "赫章县",
                520602: "碧江区",
                520603: "万山区",
                520621: "江口县",
                520622: "玉屏侗族自治县",
                520623: "石阡县",
                520624: "思南县",
                520625: "印江土家族苗族自治县",
                520626: "德江县",
                520627: "沿河土家族自治县",
                520628: "松桃苗族自治县",
                522301: "兴义市",
                522302: "兴仁市",
                522323: "普安县",
                522324: "晴隆县",
                522325: "贞丰县",
                522326: "望谟县",
                522327: "册亨县",
                522328: "安龙县",
                522601: "凯里市",
                522622: "黄平县",
                522623: "施秉县",
                522624: "三穗县",
                522625: "镇远县",
                522626: "岑巩县",
                522627: "天柱县",
                522628: "锦屏县",
                522629: "剑河县",
                522630: "台江县",
                522631: "黎平县",
                522632: "榕江县",
                522633: "从江县",
                522634: "雷山县",
                522635: "麻江县",
                522636: "丹寨县",
                522701: "都匀市",
                522702: "福泉市",
                522722: "荔波县",
                522723: "贵定县",
                522725: "瓮安县",
                522726: "独山县",
                522727: "平塘县",
                522728: "罗甸县",
                522729: "长顺县",
                522730: "龙里县",
                522731: "惠水县",
                522732: "三都水族自治县",
                530102: "五华区",
                530103: "盘龙区",
                530111: "官渡区",
                530112: "西山区",
                530113: "东川区",
                530114: "呈贡区",
                530115: "晋宁区",
                530124: "富民县",
                530125: "宜良县",
                530126: "石林彝族自治县",
                530127: "嵩明县",
                530128: "禄劝彝族苗族自治县",
                530129: "寻甸回族彝族自治县",
                530181: "安宁市",
                530302: "麒麟区",
                530303: "沾益区",
                530304: "马龙区",
                530322: "陆良县",
                530323: "师宗县",
                530324: "罗平县",
                530325: "富源县",
                530326: "会泽县",
                530381: "宣威市",
                530402: "红塔区",
                530403: "江川区",
                530423: "通海县",
                530424: "华宁县",
                530425: "易门县",
                530426: "峨山彝族自治县",
                530427: "新平彝族傣族自治县",
                530428: "元江哈尼族彝族傣族自治县",
                530481: "澄江市",
                530502: "隆阳区",
                530521: "施甸县",
                530523: "龙陵县",
                530524: "昌宁县",
                530581: "腾冲市",
                530602: "昭阳区",
                530621: "鲁甸县",
                530622: "巧家县",
                530623: "盐津县",
                530624: "大关县",
                530625: "永善县",
                530626: "绥江县",
                530627: "镇雄县",
                530628: "彝良县",
                530629: "威信县",
                530681: "水富市",
                530702: "古城区",
                530721: "玉龙纳西族自治县",
                530722: "永胜县",
                530723: "华坪县",
                530724: "宁蒗彝族自治县",
                530802: "思茅区",
                530821: "宁洱哈尼族彝族自治县",
                530822: "墨江哈尼族自治县",
                530823: "景东彝族自治县",
                530824: "景谷傣族彝族自治县",
                530825: "镇沅彝族哈尼族拉祜族自治县",
                530826: "江城哈尼族彝族自治县",
                530827: "孟连傣族拉祜族佤族自治县",
                530828: "澜沧拉祜族自治县",
                530829: "西盟佤族自治县",
                530902: "临翔区",
                530921: "凤庆县",
                530922: "云县",
                530923: "永德县",
                530924: "镇康县",
                530925: "双江拉祜族佤族布朗族傣族自治县",
                530926: "耿马傣族佤族自治县",
                530927: "沧源佤族自治县",
                532301: "楚雄市",
                532322: "双柏县",
                532323: "牟定县",
                532324: "南华县",
                532325: "姚安县",
                532326: "大姚县",
                532327: "永仁县",
                532328: "元谋县",
                532329: "武定县",
                532331: "禄丰县",
                532501: "个旧市",
                532502: "开远市",
                532503: "蒙自市",
                532504: "弥勒市",
                532523: "屏边苗族自治县",
                532524: "建水县",
                532525: "石屏县",
                532527: "泸西县",
                532528: "元阳县",
                532529: "红河县",
                532530: "金平苗族瑶族傣族自治县",
                532531: "绿春县",
                532532: "河口瑶族自治县",
                532601: "文山市",
                532622: "砚山县",
                532623: "西畴县",
                532624: "麻栗坡县",
                532625: "马关县",
                532626: "丘北县",
                532627: "广南县",
                532628: "富宁县",
                532801: "景洪市",
                532822: "勐海县",
                532823: "勐腊县",
                532901: "大理市",
                532922: "漾濞彝族自治县",
                532923: "祥云县",
                532924: "宾川县",
                532925: "弥渡县",
                532926: "南涧彝族自治县",
                532927: "巍山彝族回族自治县",
                532928: "永平县",
                532929: "云龙县",
                532930: "洱源县",
                532931: "剑川县",
                532932: "鹤庆县",
                533102: "瑞丽市",
                533103: "芒市",
                533122: "梁河县",
                533123: "盈江县",
                533124: "陇川县",
                533301: "泸水市",
                533323: "福贡县",
                533324: "贡山独龙族怒族自治县",
                533325: "兰坪白族普米族自治县",
                533401: "香格里拉市",
                533422: "德钦县",
                533423: "维西傈僳族自治县",
                540102: "城关区",
                540103: "堆龙德庆区",
                540104: "达孜区",
                540121: "林周县",
                540122: "当雄县",
                540123: "尼木县",
                540124: "曲水县",
                540127: "墨竹工卡县",
                540202: "桑珠孜区",
                540221: "南木林县",
                540222: "江孜县",
                540223: "定日县",
                540224: "萨迦县",
                540225: "拉孜县",
                540226: "昂仁县",
                540227: "谢通门县",
                540228: "白朗县",
                540229: "仁布县",
                540230: "康马县",
                540231: "定结县",
                540232: "仲巴县",
                540233: "亚东县",
                540234: "吉隆县",
                540235: "聂拉木县",
                540236: "萨嘎县",
                540237: "岗巴县",
                540302: "卡若区",
                540321: "江达县",
                540322: "贡觉县",
                540323: "类乌齐县",
                540324: "丁青县",
                540325: "察雅县",
                540326: "八宿县",
                540327: "左贡县",
                540328: "芒康县",
                540329: "洛隆县",
                540330: "边坝县",
                540402: "巴宜区",
                540421: "工布江达县",
                540422: "米林县",
                540423: "墨脱县",
                540424: "波密县",
                540425: "察隅县",
                540426: "朗县",
                540502: "乃东区",
                540521: "扎囊县",
                540522: "贡嘎县",
                540523: "桑日县",
                540524: "琼结县",
                540525: "曲松县",
                540526: "措美县",
                540527: "洛扎县",
                540528: "加查县",
                540529: "隆子县",
                540530: "错那县",
                540531: "浪卡子县",
                540602: "色尼区",
                540621: "嘉黎县",
                540622: "比如县",
                540623: "聂荣县",
                540624: "安多县",
                540625: "申扎县",
                540626: "索县",
                540627: "班戈县",
                540628: "巴青县",
                540629: "尼玛县",
                540630: "双湖县",
                542521: "普兰县",
                542522: "札达县",
                542523: "噶尔县",
                542524: "日土县",
                542525: "革吉县",
                542526: "改则县",
                542527: "措勤县",
                610102: "新城区",
                610103: "碑林区",
                610104: "莲湖区",
                610111: "灞桥区",
                610112: "未央区",
                610113: "雁塔区",
                610114: "阎良区",
                610115: "临潼区",
                610116: "长安区",
                610117: "高陵区",
                610118: "鄠邑区",
                610122: "蓝田县",
                610124: "周至县",
                610202: "王益区",
                610203: "印台区",
                610204: "耀州区",
                610222: "宜君县",
                610302: "渭滨区",
                610303: "金台区",
                610304: "陈仓区",
                610322: "凤翔县",
                610323: "岐山县",
                610324: "扶风县",
                610326: "眉县",
                610327: "陇县",
                610328: "千阳县",
                610329: "麟游县",
                610330: "凤县",
                610331: "太白县",
                610402: "秦都区",
                610403: "杨陵区",
                610404: "渭城区",
                610422: "三原县",
                610423: "泾阳县",
                610424: "乾县",
                610425: "礼泉县",
                610426: "永寿县",
                610428: "长武县",
                610429: "旬邑县",
                610430: "淳化县",
                610431: "武功县",
                610481: "兴平市",
                610482: "彬州市",
                610502: "临渭区",
                610503: "华州区",
                610522: "潼关县",
                610523: "大荔县",
                610524: "合阳县",
                610525: "澄城县",
                610526: "蒲城县",
                610527: "白水县",
                610528: "富平县",
                610581: "韩城市",
                610582: "华阴市",
                610602: "宝塔区",
                610603: "安塞区",
                610621: "延长县",
                610622: "延川县",
                610625: "志丹县",
                610626: "吴起县",
                610627: "甘泉县",
                610628: "富县",
                610629: "洛川县",
                610630: "宜川县",
                610631: "黄龙县",
                610632: "黄陵县",
                610681: "子长市",
                610702: "汉台区",
                610703: "南郑区",
                610722: "城固县",
                610723: "洋县",
                610724: "西乡县",
                610725: "勉县",
                610726: "宁强县",
                610727: "略阳县",
                610728: "镇巴县",
                610729: "留坝县",
                610730: "佛坪县",
                610802: "榆阳区",
                610803: "横山区",
                610822: "府谷县",
                610824: "靖边县",
                610825: "定边县",
                610826: "绥德县",
                610827: "米脂县",
                610828: "佳县",
                610829: "吴堡县",
                610830: "清涧县",
                610831: "子洲县",
                610881: "神木市",
                610902: "汉滨区",
                610921: "汉阴县",
                610922: "石泉县",
                610923: "宁陕县",
                610924: "紫阳县",
                610925: "岚皋县",
                610926: "平利县",
                610927: "镇坪县",
                610928: "旬阳县",
                610929: "白河县",
                611002: "商州区",
                611021: "洛南县",
                611022: "丹凤县",
                611023: "商南县",
                611024: "山阳县",
                611025: "镇安县",
                611026: "柞水县",
                620102: "城关区",
                620103: "七里河区",
                620104: "西固区",
                620105: "安宁区",
                620111: "红古区",
                620121: "永登县",
                620122: "皋兰县",
                620123: "榆中县",
                620171: "兰州新区",
                620201: "市辖区",
                620290: "雄关区",
                620291: "长城区",
                620292: "镜铁区",
                620293: "新城镇",
                620294: "峪泉镇",
                620295: "文殊镇",
                620302: "金川区",
                620321: "永昌县",
                620402: "白银区",
                620403: "平川区",
                620421: "靖远县",
                620422: "会宁县",
                620423: "景泰县",
                620502: "秦州区",
                620503: "麦积区",
                620521: "清水县",
                620522: "秦安县",
                620523: "甘谷县",
                620524: "武山县",
                620525: "张家川回族自治县",
                620602: "凉州区",
                620621: "民勤县",
                620622: "古浪县",
                620623: "天祝藏族自治县",
                620702: "甘州区",
                620721: "肃南裕固族自治县",
                620722: "民乐县",
                620723: "临泽县",
                620724: "高台县",
                620725: "山丹县",
                620802: "崆峒区",
                620821: "泾川县",
                620822: "灵台县",
                620823: "崇信县",
                620825: "庄浪县",
                620826: "静宁县",
                620881: "华亭市",
                620902: "肃州区",
                620921: "金塔县",
                620922: "瓜州县",
                620923: "肃北蒙古族自治县",
                620924: "阿克塞哈萨克族自治县",
                620981: "玉门市",
                620982: "敦煌市",
                621002: "西峰区",
                621021: "庆城县",
                621022: "环县",
                621023: "华池县",
                621024: "合水县",
                621025: "正宁县",
                621026: "宁县",
                621027: "镇原县",
                621102: "安定区",
                621121: "通渭县",
                621122: "陇西县",
                621123: "渭源县",
                621124: "临洮县",
                621125: "漳县",
                621126: "岷县",
                621202: "武都区",
                621221: "成县",
                621222: "文县",
                621223: "宕昌县",
                621224: "康县",
                621225: "西和县",
                621226: "礼县",
                621227: "徽县",
                621228: "两当县",
                622901: "临夏市",
                622921: "临夏县",
                622922: "康乐县",
                622923: "永靖县",
                622924: "广河县",
                622925: "和政县",
                622926: "东乡族自治县",
                622927: "积石山保安族东乡族撒拉族自治县",
                623001: "合作市",
                623021: "临潭县",
                623022: "卓尼县",
                623023: "舟曲县",
                623024: "迭部县",
                623025: "玛曲县",
                623026: "碌曲县",
                623027: "夏河县",
                630102: "城东区",
                630103: "城中区",
                630104: "城西区",
                630105: "城北区",
                630106: "湟中区",
                630121: "大通回族土族自治县",
                630123: "湟源县",
                630202: "乐都区",
                630203: "平安区",
                630222: "民和回族土族自治县",
                630223: "互助土族自治县",
                630224: "化隆回族自治县",
                630225: "循化撒拉族自治县",
                632221: "门源回族自治县",
                632222: "祁连县",
                632223: "海晏县",
                632224: "刚察县",
                632321: "同仁县",
                632322: "尖扎县",
                632323: "泽库县",
                632324: "河南蒙古族自治县",
                632521: "共和县",
                632522: "同德县",
                632523: "贵德县",
                632524: "兴海县",
                632525: "贵南县",
                632621: "玛沁县",
                632622: "班玛县",
                632623: "甘德县",
                632624: "达日县",
                632625: "久治县",
                632626: "玛多县",
                632701: "玉树市",
                632722: "杂多县",
                632723: "称多县",
                632724: "治多县",
                632725: "囊谦县",
                632726: "曲麻莱县",
                632801: "格尔木市",
                632802: "德令哈市",
                632803: "茫崖市",
                632821: "乌兰县",
                632822: "都兰县",
                632823: "天峻县",
                632857: "大柴旦行政委员会",
                640104: "兴庆区",
                640105: "西夏区",
                640106: "金凤区",
                640121: "永宁县",
                640122: "贺兰县",
                640181: "灵武市",
                640202: "大武口区",
                640205: "惠农区",
                640221: "平罗县",
                640302: "利通区",
                640303: "红寺堡区",
                640323: "盐池县",
                640324: "同心县",
                640381: "青铜峡市",
                640402: "原州区",
                640422: "西吉县",
                640423: "隆德县",
                640424: "泾源县",
                640425: "彭阳县",
                640502: "沙坡头区",
                640521: "中宁县",
                640522: "海原县",
                650102: "天山区",
                650103: "沙依巴克区",
                650104: "新市区",
                650105: "水磨沟区",
                650106: "头屯河区",
                650107: "达坂城区",
                650109: "米东区",
                650121: "乌鲁木齐县",
                650202: "独山子区",
                650203: "克拉玛依区",
                650204: "白碱滩区",
                650205: "乌尔禾区",
                650402: "高昌区",
                650421: "鄯善县",
                650422: "托克逊县",
                650502: "伊州区",
                650521: "巴里坤哈萨克自治县",
                650522: "伊吾县",
                652301: "昌吉市",
                652302: "阜康市",
                652323: "呼图壁县",
                652324: "玛纳斯县",
                652325: "奇台县",
                652327: "吉木萨尔县",
                652328: "木垒哈萨克自治县",
                652701: "博乐市",
                652702: "阿拉山口市",
                652722: "精河县",
                652723: "温泉县",
                652801: "库尔勒市",
                652822: "轮台县",
                652823: "尉犁县",
                652824: "若羌县",
                652825: "且末县",
                652826: "焉耆回族自治县",
                652827: "和静县",
                652828: "和硕县",
                652829: "博湖县",
                652901: "阿克苏市",
                652902: "库车市",
                652922: "温宿县",
                652924: "沙雅县",
                652925: "新和县",
                652926: "拜城县",
                652927: "乌什县",
                652928: "阿瓦提县",
                652929: "柯坪县",
                653001: "阿图什市",
                653022: "阿克陶县",
                653023: "阿合奇县",
                653024: "乌恰县",
                653101: "喀什市",
                653121: "疏附县",
                653122: "疏勒县",
                653123: "英吉沙县",
                653124: "泽普县",
                653125: "莎车县",
                653126: "叶城县",
                653127: "麦盖提县",
                653128: "岳普湖县",
                653129: "伽师县",
                653130: "巴楚县",
                653131: "塔什库尔干塔吉克自治县",
                653201: "和田市",
                653221: "和田县",
                653222: "墨玉县",
                653223: "皮山县",
                653224: "洛浦县",
                653225: "策勒县",
                653226: "于田县",
                653227: "民丰县",
                654002: "伊宁市",
                654003: "奎屯市",
                654004: "霍尔果斯市",
                654021: "伊宁县",
                654022: "察布查尔锡伯自治县",
                654023: "霍城县",
                654024: "巩留县",
                654025: "新源县",
                654026: "昭苏县",
                654027: "特克斯县",
                654028: "尼勒克县",
                654201: "塔城市",
                654202: "乌苏市",
                654221: "额敏县",
                654223: "沙湾县",
                654224: "托里县",
                654225: "裕民县",
                654226: "和布克赛尔蒙古自治县",
                654301: "阿勒泰市",
                654321: "布尔津县",
                654322: "富蕴县",
                654323: "福海县",
                654324: "哈巴河县",
                654325: "青河县",
                654326: "吉木乃县",
                659001: "石河子市",
                659002: "阿拉尔市",
                659003: "图木舒克市",
                659004: "五家渠市",
                659005: "北屯市",
                659006: "铁门关市",
                659007: "双河市",
                659008: "可克达拉市",
                659009: "昆玉市",
                659010: "胡杨河市",
                710101: "中正区",
                710102: "大同区",
                710103: "中山区",
                710104: "松山区",
                710105: "大安区",
                710106: "万华区",
                710107: "信义区",
                710108: "士林区",
                710109: "北投区",
                710110: "内湖区",
                710111: "南港区",
                710112: "文山区",
                710199: "其它区",
                710201: "新兴区",
                710202: "前金区",
                710203: "芩雅区",
                710204: "盐埕区",
                710205: "鼓山区",
                710206: "旗津区",
                710207: "前镇区",
                710208: "三民区",
                710209: "左营区",
                710210: "楠梓区",
                710211: "小港区",
                710241: "苓雅区",
                710242: "仁武区",
                710243: "大社区",
                710244: "冈山区",
                710245: "路竹区",
                710246: "阿莲区",
                710247: "田寮区",
                710248: "燕巢区",
                710249: "桥头区",
                710250: "梓官区",
                710251: "弥陀区",
                710252: "永安区",
                710253: "湖内区",
                710254: "凤山区",
                710255: "大寮区",
                710256: "林园区",
                710257: "鸟松区",
                710258: "大树区",
                710259: "旗山区",
                710260: "美浓区",
                710261: "六龟区",
                710262: "内门区",
                710263: "杉林区",
                710264: "甲仙区",
                710265: "桃源区",
                710266: "那玛夏区",
                710267: "茂林区",
                710268: "茄萣区",
                710299: "其它区",
                710301: "中西区",
                710302: "东区",
                710303: "南区",
                710304: "北区",
                710305: "安平区",
                710306: "安南区",
                710339: "永康区",
                710340: "归仁区",
                710341: "新化区",
                710342: "左镇区",
                710343: "玉井区",
                710344: "楠西区",
                710345: "南化区",
                710346: "仁德区",
                710347: "关庙区",
                710348: "龙崎区",
                710349: "官田区",
                710350: "麻豆区",
                710351: "佳里区",
                710352: "西港区",
                710353: "七股区",
                710354: "将军区",
                710355: "学甲区",
                710356: "北门区",
                710357: "新营区",
                710358: "后壁区",
                710359: "白河区",
                710360: "东山区",
                710361: "六甲区",
                710362: "下营区",
                710363: "柳营区",
                710364: "盐水区",
                710365: "善化区",
                710366: "大内区",
                710367: "山上区",
                710368: "新市区",
                710369: "安定区",
                710399: "其它区",
                710401: "中区",
                710402: "东区",
                710403: "南区",
                710404: "西区",
                710405: "北区",
                710406: "北屯区",
                710407: "西屯区",
                710408: "南屯区",
                710431: "太平区",
                710432: "大里区",
                710433: "雾峰区",
                710434: "乌日区",
                710435: "丰原区",
                710436: "后里区",
                710437: "石冈区",
                710438: "东势区",
                710439: "和平区",
                710440: "新社区",
                710441: "潭子区",
                710442: "大雅区",
                710443: "神冈区",
                710444: "大肚区",
                710445: "沙鹿区",
                710446: "龙井区",
                710447: "梧栖区",
                710448: "清水区",
                710449: "大甲区",
                710450: "外埔区",
                710451: "大安区",
                710499: "其它区",
                710507: "金沙镇",
                710508: "金湖镇",
                710509: "金宁乡",
                710510: "金城镇",
                710511: "烈屿乡",
                710512: "乌坵乡",
                710614: "南投市",
                710615: "中寮乡",
                710616: "草屯镇",
                710617: "国姓乡",
                710618: "埔里镇",
                710619: "仁爱乡",
                710620: "名间乡",
                710621: "集集镇",
                710622: "水里乡",
                710623: "鱼池乡",
                710624: "信义乡",
                710625: "竹山镇",
                710626: "鹿谷乡",
                710701: "仁爱区",
                710702: "信义区",
                710703: "中正区",
                710704: "中山区",
                710705: "安乐区",
                710706: "暖暖区",
                710707: "七堵区",
                710799: "其它区",
                710801: "东区",
                710802: "北区",
                710803: "香山区",
                710899: "其它区",
                710901: "东区",
                710902: "西区",
                710999: "其它区",
                711130: "万里区",
                711132: "板桥区",
                711133: "汐止区",
                711134: "深坑区",
                711135: "石碇区",
                711136: "瑞芳区",
                711137: "平溪区",
                711138: "双溪区",
                711139: "贡寮区",
                711140: "新店区",
                711141: "坪林区",
                711142: "乌来区",
                711143: "永和区",
                711144: "中和区",
                711145: "土城区",
                711146: "三峡区",
                711147: "树林区",
                711148: "莺歌区",
                711149: "三重区",
                711150: "新庄区",
                711151: "泰山区",
                711152: "林口区",
                711153: "芦洲区",
                711154: "五股区",
                711155: "八里区",
                711156: "淡水区",
                711157: "三芝区",
                711158: "石门区",
                711287: "宜兰市",
                711288: "头城镇",
                711289: "礁溪乡",
                711290: "壮围乡",
                711291: "员山乡",
                711292: "罗东镇",
                711293: "三星乡",
                711294: "大同乡",
                711295: "五结乡",
                711296: "冬山乡",
                711297: "苏澳镇",
                711298: "南澳乡",
                711299: "钓鱼台",
                711387: "竹北市",
                711388: "湖口乡",
                711389: "新丰乡",
                711390: "新埔镇",
                711391: "关西镇",
                711392: "芎林乡",
                711393: "宝山乡",
                711394: "竹东镇",
                711395: "五峰乡",
                711396: "横山乡",
                711397: "尖石乡",
                711398: "北埔乡",
                711399: "峨眉乡",
                711414: "中坜区",
                711415: "平镇区",
                711417: "杨梅区",
                711418: "新屋区",
                711419: "观音区",
                711420: "桃园区",
                711421: "龟山区",
                711422: "八德区",
                711423: "大溪区",
                711425: "大园区",
                711426: "芦竹区",
                711487: "中坜市",
                711488: "平镇市",
                711489: "龙潭乡",
                711490: "杨梅市",
                711491: "新屋乡",
                711492: "观音乡",
                711493: "桃园市",
                711494: "龟山乡",
                711495: "八德市",
                711496: "大溪镇",
                711497: "复兴乡",
                711498: "大园乡",
                711499: "芦竹乡",
                711520: "头份市",
                711582: "竹南镇",
                711583: "头份镇",
                711584: "三湾乡",
                711585: "南庄乡",
                711586: "狮潭乡",
                711587: "后龙镇",
                711588: "通霄镇",
                711589: "苑里镇",
                711590: "苗栗市",
                711591: "造桥乡",
                711592: "头屋乡",
                711593: "公馆乡",
                711594: "大湖乡",
                711595: "泰安乡",
                711596: "铜锣乡",
                711597: "三义乡",
                711598: "西湖乡",
                711599: "卓兰镇",
                711736: "员林市",
                711774: "彰化市",
                711775: "芬园乡",
                711776: "花坛乡",
                711777: "秀水乡",
                711778: "鹿港镇",
                711779: "福兴乡",
                711780: "线西乡",
                711781: "和美镇",
                711782: "伸港乡",
                711783: "员林镇",
                711784: "社头乡",
                711785: "永靖乡",
                711786: "埔心乡",
                711787: "溪湖镇",
                711788: "大村乡",
                711789: "埔盐乡",
                711790: "田中镇",
                711791: "北斗镇",
                711792: "田尾乡",
                711793: "埤头乡",
                711794: "溪州乡",
                711795: "竹塘乡",
                711796: "二林镇",
                711797: "大城乡",
                711798: "芳苑乡",
                711799: "二水乡",
                711982: "番路乡",
                711983: "梅山乡",
                711984: "竹崎乡",
                711985: "阿里山乡",
                711986: "中埔乡",
                711987: "大埔乡",
                711988: "水上乡",
                711989: "鹿草乡",
                711990: "太保市",
                711991: "朴子市",
                711992: "东石乡",
                711993: "六脚乡",
                711994: "新港乡",
                711995: "民雄乡",
                711996: "大林镇",
                711997: "溪口乡",
                711998: "义竹乡",
                711999: "布袋镇",
                712180: "斗南镇",
                712181: "大埤乡",
                712182: "虎尾镇",
                712183: "土库镇",
                712184: "褒忠乡",
                712185: "东势乡",
                712186: "台西乡",
                712187: "仑背乡",
                712188: "麦寮乡",
                712189: "斗六市",
                712190: "林内乡",
                712191: "古坑乡",
                712192: "莿桐乡",
                712193: "西螺镇",
                712194: "二仑乡",
                712195: "北港镇",
                712196: "水林乡",
                712197: "口湖乡",
                712198: "四湖乡",
                712199: "元长乡",
                712451: "崁顶乡",
                712467: "屏东市",
                712468: "三地门乡",
                712469: "雾台乡",
                712470: "玛家乡",
                712471: "九如乡",
                712472: "里港乡",
                712473: "高树乡",
                712474: "盐埔乡",
                712475: "长治乡",
                712476: "麟洛乡",
                712477: "竹田乡",
                712478: "内埔乡",
                712479: "万丹乡",
                712480: "潮州镇",
                712481: "泰武乡",
                712482: "来义乡",
                712483: "万峦乡",
                712484: "莰顶乡",
                712485: "新埤乡",
                712486: "南州乡",
                712487: "林边乡",
                712488: "东港镇",
                712489: "琉球乡",
                712490: "佳冬乡",
                712491: "新园乡",
                712492: "枋寮乡",
                712493: "枋山乡",
                712494: "春日乡",
                712495: "狮子乡",
                712496: "车城乡",
                712497: "牡丹乡",
                712498: "恒春镇",
                712499: "满州乡",
                712584: "台东市",
                712585: "绿岛乡",
                712586: "兰屿乡",
                712587: "延平乡",
                712588: "卑南乡",
                712589: "鹿野乡",
                712590: "关山镇",
                712591: "海端乡",
                712592: "池上乡",
                712593: "东河乡",
                712594: "成功镇",
                712595: "长滨乡",
                712596: "金峰乡",
                712597: "大武乡",
                712598: "达仁乡",
                712599: "太麻里乡",
                712686: "花莲市",
                712687: "新城乡",
                712688: "太鲁阁",
                712689: "秀林乡",
                712690: "吉安乡",
                712691: "寿丰乡",
                712692: "凤林镇",
                712693: "光复乡",
                712694: "丰滨乡",
                712695: "瑞穗乡",
                712696: "万荣乡",
                712697: "玉里镇",
                712698: "卓溪乡",
                712699: "富里乡",
                712794: "马公市",
                712795: "西屿乡",
                712796: "望安乡",
                712797: "七美乡",
                712798: "白沙乡",
                712799: "湖西乡",
                712896: "南竿乡",
                712897: "北竿乡",
                712898: "东引乡",
                712899: "莒光乡",
                810101: "中西区",
                810102: "湾仔区",
                810103: "东区",
                810104: "南区",
                810201: "九龙城区",
                810202: "油尖旺区",
                810203: "深水埗区",
                810204: "黄大仙区",
                810205: "观塘区",
                810301: "北区",
                810302: "大埔区",
                810303: "沙田区",
                810304: "西贡区",
                810305: "元朗区",
                810306: "屯门区",
                810307: "荃湾区",
                810308: "葵青区",
                810309: "离岛区",
                820102: "花地玛堂区",
                820103: "花王堂区",
                820104: "望德堂区",
                820105: "大堂区",
                820106: "风顺堂区",
                820202: "嘉模堂区",
                820203: "路氹填海区",
                820204: "圣方济各堂区"
            }
        };
    },
    3119: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Router = void 0;
        var r = n("9ab4"), o = n("c6ce"), i = function() {
            function e(t) {
                this.name = e.id, this._options = (0, r.__assign)({
                    enable: !0
                }, t);
            }
            return e.prototype.setupOnce = function() {
                var t = this;
                (0, o.addGlobalEventProcessor)(function(n) {
                    if ((0, o.getCurrentHub)().getIntegration(e) && t._options.enable) try {
                        var i = getCurrentPages().map(function(e) {
                            return {
                                route: e.route,
                                options: e.options
                            };
                        });
                        return (0, r.__assign)((0, r.__assign)({}, n), {
                            extra: (0, r.__assign)((0, r.__assign)({}, n.extra), {
                                routers: i
                            })
                        });
                    } catch (e) {
                        console.warn("sentry-miniapp get router info fail: " + e);
                    }
                    return n;
                });
            }, e.id = "Router", e;
        }();
        t.Router = i;
    },
    "32f1": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = n("24db");
        Object.keys(r).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return r[e];
                }
            });
        });
        var o = n("745c");
        Object.keys(o).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return o[e];
                }
            });
        });
        var i = n("670e");
        Object.keys(i).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return i[e];
                }
            });
        });
        var a = n("807a");
        Object.keys(a).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return a[e];
                }
            });
        });
        var u = n("648e");
        Object.keys(u).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return u[e];
                }
            });
        });
        var c = n("f658");
        Object.keys(c).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return c[e];
                }
            });
        });
        var s = n("2a13");
        Object.keys(s).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return s[e];
                }
            });
        });
        var f = n("c26a");
        Object.keys(f).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return f[e];
                }
            });
        });
        var l = n("82a9");
        Object.keys(l).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return l[e];
                }
            });
        });
        var p = n("d34a");
        Object.keys(p).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return p[e];
                }
            });
        });
        var d = n("71dd");
        Object.keys(d).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return d[e];
                }
            });
        });
        var h = n("1819");
        Object.keys(h).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return h[e];
                }
            });
        });
        var v = n("c63d");
        Object.keys(v).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return v[e];
                }
            });
        });
        var g = n("cc66");
        Object.keys(g).forEach(function(e) {
            "default" !== e && "__esModule" !== e && Object.defineProperty(t, e, {
                enumerable: !0,
                get: function() {
                    return g[e];
                }
            });
        });
    },
    3393: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.getIntegrationsToSetup = s, t.setupIntegration = f, t.setupIntegrations = function(e) {
            var t = {};
            return s(e).forEach(function(e) {
                t[e.name] = e, f(e);
            }), t;
        }, t.installedIntegrations = void 0;
        var o = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = u();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("9ab4")), i = r("4820"), a = r("32f1");
        function u() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return u = function() {
                return e;
            }, e;
        }
        var c = [];
        function s(e) {
            var t = e.defaultIntegrations && o.__spread(e.defaultIntegrations) || [], n = e.integrations, r = [];
            if (Array.isArray(n)) {
                var i = n.map(function(e) {
                    return e.name;
                }), a = [];
                t.forEach(function(e) {
                    -1 === i.indexOf(e.name) && -1 === a.indexOf(e.name) && (r.push(e), a.push(e.name));
                }), n.forEach(function(e) {
                    -1 === a.indexOf(e.name) && (r.push(e), a.push(e.name));
                });
            } else "function" == typeof n ? (r = n(t), r = Array.isArray(r) ? r : [ r ]) : r = o.__spread(t);
            var u = r.map(function(e) {
                return e.name;
            }), c = "Debug";
            return -1 !== u.indexOf(c) && r.push.apply(r, o.__spread(r.splice(u.indexOf(c), 1))), 
            r;
        }
        function f(e) {
            -1 === c.indexOf(e.name) && (e.setupOnce(i.addGlobalEventProcessor, i.getCurrentHub), 
            c.push(e.name), a.logger.log("Integration installed: " + e.name));
        }
        t.installedIntegrations = c;
    },
    "33d4": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            bycategory: function(e) {
                return (0, r.default)("get", "/api/wxapp/gift/bycategory/".concat(e));
            },
            getCnyCountByUnionId: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/cny/getCnyCountByUnionId/".concat(e), t, !1);
            },
            canHuAndBar: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/canHuAndBar", e, !1);
            },
            gangpai: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/gangpai", e, !1);
            },
            hupaiLuckDraw: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/hupaiLuckDraw", e, !1);
            },
            favour: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/favour", e, !1);
            },
            clickFavour: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/clickFavour", e, !1);
            },
            share: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/share", e, !1);
            },
            clickShare: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/clickShare", e, !1);
            },
            hupaiStock: function() {
                return (0, r.default)("get", "/api/wxapp/cny/hupaiStock", !1);
            },
            findAwardRecord: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/findAwardRecord", e, !1);
            },
            apitalRetention: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/apitalRetention", e, !1);
            },
            scanDraw: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/scanDraw", e, !1);
            },
            getBarOpenCount: function() {
                return (0, r.default)("get", "/api/wxapp/cny/getBarOpenCount", !1);
            },
            existsScanDraw: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/existsScanDraw", e, !1);
            },
            getCitys: function(e) {
                return (0, r.default)("get", "/api/wxapp/cny/getCitys", e, !1);
            },
            getQrcodeByUrl: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/getQrcodeByUrl", e, !1);
            },
            customerinfo: function(e, t) {
                return (0, r.default)("get", "/api/wxapp/qw/customerinfo/".concat(e), t, !1);
            },
            sendCoupon: function(e) {
                return (0, r.default)("post", "/api/wxapp/qw/sendCoupon", e, !1);
            },
            ebuySendCoupon: function(e) {
                return (0, r.default)("post", "/api/wxapp/qw/ebuySendCoupon", e, !1);
            },
            existsFavour: function(e) {
                return (0, r.default)("post", "/api/wxapp/cny/existsFavour", e, !1);
            },
            dimooShare: function(e) {
                return (0, r.default)("post", "/api/wxapp/winterEvaluation/share", e, !1);
            }
        };
        t.default = o;
    },
    "35c8": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MiniappClient = void 0;
        var r = n("9ab4"), o = n("c6ce"), i = n("32f1"), a = n("290d"), u = n("1f9b"), c = function(e) {
            function t(t) {
                return void 0 === t && (t = {}), e.call(this, a.MiniappBackend, t) || this;
            }
            return (0, r.__extends)(t, e), t.prototype._prepareEvent = function(t, n, o) {
                return t.platform = t.platform || "javascript", t.sdk = (0, r.__assign)((0, r.__assign)({}, t.sdk), {
                    name: u.SDK_NAME,
                    packages: (0, r.__spread)(t.sdk && t.sdk.packages || [], [ {
                        name: "npm:@sentry/miniapp",
                        version: u.SDK_VERSION
                    } ]),
                    version: u.SDK_VERSION
                }), e.prototype._prepareEvent.call(this, t, n, o);
            }, t.prototype.showReportDialog = function(e) {
                void 0 === e && (e = {});
                var t = (0, i.getGlobalObject)().document;
                if (t) if (this._isEnabled()) {
                    var n = e.dsn || this.getDsn();
                    if (e.eventId) if (n) {
                        var r = t.createElement("script");
                        r.async = !0, r.src = new o.API(n).getReportDialogEndpoint(e), e.onLoad && (r.onload = e.onLoad), 
                        (t.head || t.body).appendChild(r);
                    } else i.logger.error("Missing `Dsn` option in showReportDialog call"); else i.logger.error("Missing `eventId` option in showReportDialog call");
                } else i.logger.error("Trying to call showReportDialog with Sentry Client is disabled");
            }, t;
        }(o.BaseClient);
        t.MiniappClient = c;
    },
    "37dc": function(e, t, r) {
        (function(e, r) {
            function o(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e;
                }(e) || function(e, t) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                        var n = [], r = !0, o = !1, i = void 0;
                        try {
                            for (var a, u = e[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), 
                            !t || n.length !== t); r = !0) ;
                        } catch (e) {
                            o = !0, i = e;
                        } finally {
                            try {
                                r || null == u.return || u.return();
                            } finally {
                                if (o) throw i;
                            }
                        }
                        return n;
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" == typeof e) return i(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? i(e, t) : void 0;
                    }
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function i(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r;
            }
            function a(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function u(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                    Object.defineProperty(e, r.key, r);
                }
            }
            function c(e, t, n) {
                return t && u(e.prototype, t), n && u(e, n), e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.compileI18nJsonStr = function(e, t) {
                var n = t.locale, r = t.locales, o = t.delimiters;
                if (!A(e, o)) return e;
                P || (P = new p());
                var i = [];
                Object.keys(r).forEach(function(e) {
                    e !== n && i.push({
                        locale: e,
                        values: r[e]
                    });
                }), i.unshift({
                    locale: n,
                    values: r[n]
                });
                try {
                    return JSON.stringify(T(JSON.parse(e), i, o), null, 2);
                } catch (e) {}
                return e;
            }, t.hasI18nJson = function e(t, n) {
                return P || (P = new p()), D(t, function(t, r) {
                    var o = t[r];
                    return j(o) ? !!A(o, n) || void 0 : e(o, n);
                });
            }, t.initVueI18n = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = arguments.length > 2 ? arguments[2] : void 0, r = arguments.length > 3 ? arguments[3] : void 0;
                if ("string" != typeof e) {
                    var o = [ t, e ];
                    e = o[0], t = o[1];
                }
                "string" != typeof e && (e = k()), "string" != typeof n && (n = "undefined" != typeof __uniConfig && __uniConfig.fallbackLocale || m);
                var i = new S({
                    locale: e,
                    fallbackLocale: n,
                    messages: t,
                    watcher: r
                }), a = function(e, t) {
                    if ("function" != typeof getApp) a = function(e, t) {
                        return i.t(e, t);
                    }; else {
                        var n = !1;
                        a = function(e, t) {
                            var r = getApp().$vm;
                            return r && (r.$locale, n || (n = !0, E(r, i))), i.t(e, t);
                        };
                    }
                    return a(e, t);
                };
                return {
                    i18n: i,
                    f: function(e, t, n) {
                        return i.f(e, t, n);
                    },
                    t: function(e, t) {
                        return a(e, t);
                    },
                    add: function(e, t) {
                        var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                        return i.add(e, t, n);
                    },
                    watch: function(e) {
                        return i.watchLocale(e);
                    },
                    getLocale: function() {
                        return i.getLocale();
                    },
                    setLocale: function(e) {
                        return i.setLocale(e);
                    }
                };
            }, t.isI18nStr = A, t.normalizeLocale = O, t.parseI18nJson = function e(t, n, r) {
                return P || (P = new p()), D(t, function(t, o) {
                    var i = t[o];
                    j(i) ? A(i, r) && (t[o] = C(i, n, r)) : e(i, n, r);
                }), t;
            }, t.resolveLocale = function(e) {
                return function(t) {
                    return t ? function(e) {
                        var t = [], n = e.split("-");
                        for (;n.length; ) t.push(n.join("-")), n.pop();
                        return t;
                    }(t = O(t) || t).find(function(t) {
                        return e.indexOf(t) > -1;
                    }) : t;
                };
            }, t.isString = t.LOCALE_ZH_HANT = t.LOCALE_ZH_HANS = t.LOCALE_FR = t.LOCALE_ES = t.LOCALE_EN = t.I18n = t.Formatter = void 0;
            var s = Array.isArray, f = function(e) {
                return null !== e && "object" === (0, n.default)(e);
            }, l = [ "{", "}" ], p = function() {
                function e() {
                    a(this, e), this._caches = Object.create(null);
                }
                return c(e, [ {
                    key: "interpolate",
                    value: function(e, t) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : l;
                        if (!t) return [ e ];
                        var r = this._caches[e];
                        return r || (r = v(e, n), this._caches[e] = r), g(r, t);
                    }
                } ]), e;
            }();
            t.Formatter = p;
            var d = /^(?:\d)+/, h = /^(?:\w)+/;
            function v(e, t) {
                for (var n = o(t, 2), r = n[0], i = n[1], a = [], u = 0, c = ""; u < e.length; ) {
                    var s = e[u++];
                    if (s === r) {
                        c && a.push({
                            type: "text",
                            value: c
                        }), c = "";
                        var f = "";
                        for (s = e[u++]; void 0 !== s && s !== i; ) f += s, s = e[u++];
                        var l = s === i, p = d.test(f) ? "list" : l && h.test(f) ? "named" : "unknown";
                        a.push({
                            value: f,
                            type: p
                        });
                    } else c += s;
                }
                return c && a.push({
                    type: "text",
                    value: c
                }), a;
            }
            function g(e, t) {
                var n = [], r = 0, o = s(t) ? "list" : f(t) ? "named" : "unknown";
                if ("unknown" === o) return n;
                for (;r < e.length; ) {
                    var i = e[r];
                    switch (i.type) {
                      case "text":
                        n.push(i.value);
                        break;

                      case "list":
                        n.push(t[parseInt(i.value, 10)]);
                        break;

                      case "named":
                        "named" === o && n.push(t[i.value]);
                    }
                    r++;
                }
                return n;
            }
            var y = "zh-Hans";
            t.LOCALE_ZH_HANS = y;
            var b = "zh-Hant";
            t.LOCALE_ZH_HANT = b;
            var m = "en";
            t.LOCALE_EN = m;
            t.LOCALE_FR = "fr";
            t.LOCALE_ES = "es";
            var _ = Object.prototype.hasOwnProperty, w = function(e, t) {
                return _.call(e, t);
            }, x = new p();
            function O(e, t) {
                if (e) return e = e.trim().replace(/_/g, "-"), t && t[e] ? e : 0 === (e = e.toLowerCase()).indexOf("zh") ? e.indexOf("-hans") > -1 ? y : e.indexOf("-hant") > -1 || function(e, t) {
                    return !!t.find(function(t) {
                        return -1 !== e.indexOf(t);
                    });
                }(e, [ "-tw", "-hk", "-mo", "-cht" ]) ? b : y : function(e, t) {
                    return t.find(function(t) {
                        return 0 === e.indexOf(t);
                    });
                }(e, [ m, "fr", "es" ]) || void 0;
            }
            var S = function() {
                function e(t) {
                    var n = t.locale, r = t.fallbackLocale, o = t.messages, i = t.watcher, u = t.formater;
                    a(this, e), this.locale = m, this.fallbackLocale = m, this.message = {}, this.messages = {}, 
                    this.watchers = [], r && (this.fallbackLocale = r), this.formater = u || x, this.messages = o || {}, 
                    this.setLocale(n || m), i && this.watchLocale(i);
                }
                return c(e, [ {
                    key: "setLocale",
                    value: function(e) {
                        var t = this, n = this.locale;
                        this.locale = O(e, this.messages) || this.fallbackLocale, this.messages[this.locale] || (this.messages[this.locale] = {}), 
                        this.message = this.messages[this.locale], n !== this.locale && this.watchers.forEach(function(e) {
                            e(t.locale, n);
                        });
                    }
                }, {
                    key: "getLocale",
                    value: function() {
                        return this.locale;
                    }
                }, {
                    key: "watchLocale",
                    value: function(e) {
                        var t = this, n = this.watchers.push(e) - 1;
                        return function() {
                            t.watchers.splice(n, 1);
                        };
                    }
                }, {
                    key: "add",
                    value: function(e, t) {
                        var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], r = this.messages[e];
                        r ? n ? Object.assign(r, t) : Object.keys(t).forEach(function(e) {
                            w(r, e) || (r[e] = t[e]);
                        }) : this.messages[e] = t;
                    }
                }, {
                    key: "f",
                    value: function(e, t, n) {
                        return this.formater.interpolate(e, t, n).join("");
                    }
                }, {
                    key: "t",
                    value: function(e, t, n) {
                        var r = this.message;
                        return "string" == typeof t ? (t = O(t, this.messages)) && (r = this.messages[t]) : n = t, 
                        w(r, e) ? this.formater.interpolate(r[e], n).join("") : (console.warn("Cannot translate the value of keypath ".concat(e, ". Use the value of keypath as default.")), 
                        e);
                    }
                } ]), e;
            }();
            function E(e, t) {
                e.$watchLocale ? e.$watchLocale(function(e) {
                    t.setLocale(e);
                }) : e.$watch(function() {
                    return e.$locale;
                }, function(e) {
                    t.setLocale(e);
                });
            }
            function k() {
                return void 0 !== e && e.getLocale ? e.getLocale() : void 0 !== r && r.getLocale ? r.getLocale() : m;
            }
            t.I18n = S;
            var P, j = function(e) {
                return "string" == typeof e;
            };
            function A(e, t) {
                return e.indexOf(t[0]) > -1;
            }
            function C(e, t, n) {
                return P.interpolate(e, t, n).join("");
            }
            function T(e, t, n) {
                return D(e, function(e, r) {
                    !function(e, t, n, r) {
                        var o = e[t];
                        if (j(o)) {
                            if (A(o, r) && (e[t] = C(o, n[0].values, r), n.length > 1)) {
                                var i = e[t + "Locales"] = {};
                                n.forEach(function(e) {
                                    i[e.locale] = C(o, e.values, r);
                                });
                            }
                        } else T(o, n, r);
                    }(e, r, t, n);
                }), e;
            }
            function D(e, t) {
                if (s(e)) {
                    for (var n = 0; n < e.length; n++) if (t(e, n)) return !0;
                } else if (f(e)) for (var r in e) if (t(e, r)) return !0;
                return !1;
            }
            t.isString = j;
        }).call(this, r("543d").default, r("c8ba"));
    },
    "394d": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            getList: function(e) {
                return (0, r.default)("get", "/api/wxapp/banner/getList", e, !1);
            }
        };
        t.default = o;
    },
    "3baf": function(e, t, n) {
        var r;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SpanStatus = void 0, t.SpanStatus = r, function(e) {
            e.Ok = "ok", e.DeadlineExceeded = "deadline_exceeded", e.Unauthenticated = "unauthenticated", 
            e.PermissionDenied = "permission_denied", e.NotFound = "not_found", e.ResourceExhausted = "resource_exhausted", 
            e.InvalidArgument = "invalid_argument", e.Unimplemented = "unimplemented", e.Unavailable = "unavailable", 
            e.InternalError = "internal_error", e.UnknownError = "unknown_error", e.Cancelled = "cancelled", 
            e.AlreadyExists = "already_exists", e.FailedPrecondition = "failed_precondition", 
            e.Aborted = "aborted", e.OutOfRange = "out_of_range", e.DataLoss = "data_loss";
        }(r || (t.SpanStatus = r = {})), function(e) {
            e.fromHttpCode = function(t) {
                if (t < 400) return e.Ok;
                if (t >= 400 && t < 500) switch (t) {
                  case 401:
                    return e.Unauthenticated;

                  case 403:
                    return e.PermissionDenied;

                  case 404:
                    return e.NotFound;

                  case 409:
                    return e.AlreadyExists;

                  case 413:
                    return e.FailedPrecondition;

                  case 429:
                    return e.ResourceExhausted;

                  default:
                    return e.InvalidArgument;
                }
                if (t >= 500 && t < 600) switch (t) {
                  case 501:
                    return e.Unimplemented;

                  case 503:
                    return e.Unavailable;

                  case 504:
                    return e.DeadlineExceeded;

                  default:
                    return e.InternalError;
                }
                return e.UnknownError;
            };
        }(r || (t.SpanStatus = r = {}));
    },
    "3e83": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.eventFromUnknownInput = function(e, t, n) {
            var u;
            if (void 0 === n && (n = {}), (0, r.isErrorEvent)(e) && e.error) {
                return e = e.error, u = (0, o.eventFromStacktrace)((0, i.computeStackTrace)(e));
            }
            if ((0, r.isDOMError)(e) || (0, r.isDOMException)(e)) {
                var c = e, s = c.name || ((0, r.isDOMError)(c) ? "DOMError" : "DOMException"), f = c.message ? s + ": " + c.message : s;
                return u = a(f, t, n), (0, r.addExceptionTypeValue)(u, f), u;
            }
            if ((0, r.isError)(e)) return u = (0, o.eventFromStacktrace)((0, i.computeStackTrace)(e));
            if ((0, r.isPlainObject)(e) || (0, r.isEvent)(e)) {
                var l = e;
                return u = (0, o.eventFromPlainObject)(l, t, n.rejection), (0, r.addExceptionMechanism)(u, {
                    synthetic: !0
                }), u;
            }
            return u = a(e, t, n), (0, r.addExceptionTypeValue)(u, "" + e, void 0), (0, r.addExceptionMechanism)(u, {
                synthetic: !0
            }), u;
        }, t.eventFromString = a;
        var r = n("32f1"), o = n("ff36"), i = n("938b");
        function a(e, t, n) {
            void 0 === n && (n = {});
            var r = {
                message: e
            };
            if (n.attachStacktrace && t) {
                var a = (0, i.computeStackTrace)(t), u = (0, o.prepareFramesForEvent)(a.stack);
                r.stacktrace = {
                    frames: u
                };
            }
            return r;
        }
    },
    4028: function(e, t, n) {
        var r;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Severity = void 0, t.Severity = r, function(e) {
            e.Fatal = "fatal", e.Error = "error", e.Warning = "warning", e.Log = "log", e.Info = "info", 
            e.Debug = "debug", e.Critical = "critical";
        }(r || (t.Severity = r = {})), function(e) {
            e.fromString = function(t) {
                switch (t) {
                  case "debug":
                    return e.Debug;

                  case "info":
                    return e.Info;

                  case "warn":
                  case "warning":
                    return e.Warning;

                  case "error":
                    return e.Error;

                  case "fatal":
                    return e.Fatal;

                  case "critical":
                    return e.Critical;

                  case "log":
                  default:
                    return e.Log;
                }
            };
        }(r || (t.Severity = r = {}));
    },
    "40a0": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.initAndBind = function(e, t) {
            !0 === t.debug && o.logger.enable();
            var n = (0, r.getCurrentHub)(), i = new e(t);
            n.bindClient(i);
        };
        var r = n("4820"), o = n("32f1");
    },
    "413f": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.shouldIgnoreOnError = function() {
            return c > 0;
        }, t.ignoreNextOnError = s, t.wrap = function e(t, n, r) {
            if (void 0 === n && (n = {}), "function" != typeof t) return t;
            try {
                if (t.__sentry__) return t;
                if (t.__sentry_wrapped__) return t.__sentry_wrapped__;
            } catch (e) {
                return t;
            }
            var o = function() {
                r && "function" == typeof r && r.apply(this, arguments);
                var o = Array.prototype.slice.call(arguments);
                try {
                    var c = o.map(function(t) {
                        return e(t, n);
                    });
                    return t.handleEvent ? t.handleEvent.apply(this, c) : t.apply(this, c);
                } catch (e) {
                    throw s(), (0, a.withScope)(function(t) {
                        t.addEventProcessor(function(e) {
                            var t = (0, i.__assign)({}, e);
                            return n.mechanism && ((0, u.addExceptionTypeValue)(t, void 0, void 0), (0, u.addExceptionMechanism)(t, n.mechanism)), 
                            t.extra = (0, i.__assign)((0, i.__assign)({}, t.extra), {
                                arguments: (0, u.normalize)(o, 3)
                            }), t;
                        }), (0, a.captureException)(e);
                    }), e;
                }
            };
            try {
                for (var c in t) Object.prototype.hasOwnProperty.call(t, c) && (o[c] = t[c]);
            } catch (e) {}
            t.prototype = t.prototype || {}, o.prototype = t.prototype, Object.defineProperty(t, "__sentry_wrapped__", {
                enumerable: !1,
                value: o
            }), Object.defineProperties(o, {
                __sentry__: {
                    enumerable: !1,
                    value: !0
                },
                __sentry_original__: {
                    enumerable: !1,
                    value: t
                }
            });
            try {
                Object.getOwnPropertyDescriptor(o, "name").configurable && Object.defineProperty(o, "name", {
                    get: function() {
                        return t.name;
                    }
                });
            } catch (e) {}
            return o;
        }, t.breadcrumbEventHandler = l, t.keypressEventHandler = function() {
            return function(e) {
                var t;
                try {
                    t = e.target;
                } catch (e) {
                    return;
                }
                var n = t && t.tagName;
                n && ("INPUT" === n || "TEXTAREA" === n || t.isContentEditable) && (r || l("input")(e), 
                clearTimeout(r), r = setTimeout(function() {
                    r = void 0;
                }, 1e3));
            };
        };
        var r, o, i = n("9ab4"), a = n("c6ce"), u = n("32f1"), c = 0;
        function s() {
            c += 1, setTimeout(function() {
                c -= 1;
            });
        }
        var f = 0;
        function l(e, t) {
            return void 0 === t && (t = !1), function(n) {
                if (r = void 0, n && o !== n) {
                    o = n;
                    var i = function() {
                        var t;
                        try {
                            t = n.target ? (0, u.htmlTreeAsString)(n.target) : (0, u.htmlTreeAsString)(n);
                        } catch (e) {
                            t = "<unknown>";
                        }
                        0 !== t.length && (0, a.getCurrentHub)().addBreadcrumb({
                            category: "ui." + e,
                            message: t
                        }, {
                            event: n,
                            name: e
                        });
                    };
                    f && clearTimeout(f), t ? f = setTimeout(i) : i();
                }
            };
        }
    },
    4251: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.captureException = function(e) {
            var t;
            try {
                throw new Error("Sentry syntheticException");
            } catch (e) {
                t = e;
            }
            return u("captureException", e, {
                originalException: e,
                syntheticException: t
            });
        }, t.captureMessage = function(e, t) {
            var n;
            try {
                throw new Error(e);
            } catch (e) {
                n = e;
            }
            return u("captureMessage", e, t, {
                originalException: e,
                syntheticException: n
            });
        }, t.captureEvent = function(e) {
            return u("captureEvent", e);
        }, t.configureScope = function(e) {
            u("configureScope", e);
        }, t.addBreadcrumb = function(e) {
            u("addBreadcrumb", e);
        }, t.setContext = function(e, t) {
            u("setContext", e, t);
        }, t.setExtras = function(e) {
            u("setExtras", e);
        }, t.setTags = function(e) {
            u("setTags", e);
        }, t.setExtra = function(e, t) {
            u("setExtra", e, t);
        }, t.setTag = function(e, t) {
            u("setTag", e, t);
        }, t.setUser = function(e) {
            u("setUser", e);
        }, t.withScope = function(e) {
            u("withScope", e);
        }, t._callOnClient = c;
        var o = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = a();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var u = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                u && (u.get || u.set) ? Object.defineProperty(r, i, u) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("9ab4")), i = r("4820");
        function a() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return a = function() {
                return e;
            }, e;
        }
        function u(e) {
            for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
            var r = (0, i.getCurrentHub)();
            if (r && r[e]) return r[e].apply(r, o.__spread(t));
            throw new Error("No hub defined or " + e + " was not found on the hub, please open a bug report.");
        }
        function c(e) {
            for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
            u.apply(void 0, o.__spread([ "_invokeClient", e ], t));
        }
    },
    4362: function(e, t, n) {
        t.nextTick = function(e) {
            var t = Array.prototype.slice.call(arguments);
            t.shift(), setTimeout(function() {
                e.apply(null, t);
            }, 0);
        }, t.platform = t.arch = t.execPath = t.title = "browser", t.pid = 1, t.browser = !0, 
        t.env = {}, t.argv = [], t.binding = function(e) {
            throw new Error("No such module. (Possibly not yet loaded)");
        }, function() {
            var e, r = "/";
            t.cwd = function() {
                return r;
            }, t.chdir = function(t) {
                e || (e = n("df7c")), r = e.resolve(t, r);
            };
        }(), t.exit = t.kill = t.umask = t.dlopen = t.uptime = t.memoryUsage = t.uvCounters = function() {}, 
        t.features = {};
    },
    4820: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), Object.defineProperty(t, "addGlobalEventProcessor", {
            enumerable: !0,
            get: function() {
                return r.addGlobalEventProcessor;
            }
        }), Object.defineProperty(t, "Scope", {
            enumerable: !0,
            get: function() {
                return r.Scope;
            }
        }), Object.defineProperty(t, "getCurrentHub", {
            enumerable: !0,
            get: function() {
                return o.getCurrentHub;
            }
        }), Object.defineProperty(t, "getHubFromCarrier", {
            enumerable: !0,
            get: function() {
                return o.getHubFromCarrier;
            }
        }), Object.defineProperty(t, "getMainCarrier", {
            enumerable: !0,
            get: function() {
                return o.getMainCarrier;
            }
        }), Object.defineProperty(t, "Hub", {
            enumerable: !0,
            get: function() {
                return o.Hub;
            }
        }), Object.defineProperty(t, "makeMain", {
            enumerable: !0,
            get: function() {
                return o.makeMain;
            }
        }), Object.defineProperty(t, "setHubOnCarrier", {
            enumerable: !0,
            get: function() {
                return o.setHubOnCarrier;
            }
        });
        var r = n("2ed3"), o = n("c886");
    },
    "4c2a": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.GlobalHandlers = void 0;
        var r = n("9ab4"), o = n("c6ce"), i = n("32f1"), a = n("6916"), u = function() {
            function e(t) {
                this.name = e.id, this._onErrorHandlerInstalled = !1, this._onUnhandledRejectionHandlerInstalled = !1, 
                this._onPageNotFoundHandlerInstalled = !1, this._onMemoryWarningHandlerInstalled = !1, 
                this._options = (0, r.__assign)({
                    onerror: !0,
                    onunhandledrejection: !0,
                    onpagenotfound: !0,
                    onmemorywarning: !0
                }, t);
            }
            return e.prototype.setupOnce = function() {
                Error.stackTraceLimit = 50, this._options.onerror && (i.logger.log("Global Handler attached: onError"), 
                this._installGlobalOnErrorHandler()), this._options.onunhandledrejection && (i.logger.log("Global Handler attached: onunhandledrejection"), 
                this._installGlobalOnUnhandledRejectionHandler()), this._options.onpagenotfound && (i.logger.log("Global Handler attached: onPageNotFound"), 
                this._installGlobalOnPageNotFoundHandler()), this._options.onmemorywarning && (i.logger.log("Global Handler attached: onMemoryWarning"), 
                this._installGlobalOnMemoryWarningHandler());
            }, e.prototype._installGlobalOnErrorHandler = function() {
                if (!this._onErrorHandlerInstalled) {
                    if (a.sdk.onError) {
                        var e = (0, o.getCurrentHub)();
                        a.sdk.onError(function(t) {
                            var n = "string" == typeof t ? new Error(t) : t;
                            e.captureException(n);
                        });
                    }
                    this._onErrorHandlerInstalled = !0;
                }
            }, e.prototype._installGlobalOnUnhandledRejectionHandler = function() {
                if (!this._onUnhandledRejectionHandlerInstalled) {
                    if (a.sdk.onUnhandledRejection) {
                        var e = (0, o.getCurrentHub)();
                        a.sdk.onUnhandledRejection(function(t) {
                            var n = t.reason, r = t.promise, o = "string" == typeof n ? new Error(n) : n;
                            e.captureException(o, {
                                data: r
                            });
                        });
                    }
                    this._onUnhandledRejectionHandlerInstalled = !0;
                }
            }, e.prototype._installGlobalOnPageNotFoundHandler = function() {
                if (!this._onPageNotFoundHandlerInstalled) {
                    if (a.sdk.onPageNotFound) {
                        var e = (0, o.getCurrentHub)();
                        a.sdk.onPageNotFound(function(t) {
                            var n = t.path.split("?")[0];
                            e.setTag("pagenotfound", n), e.setExtra("message", JSON.stringify(t)), e.captureMessage("页面无法找到: " + n);
                        });
                    }
                    this._onPageNotFoundHandlerInstalled = !0;
                }
            }, e.prototype._installGlobalOnMemoryWarningHandler = function() {
                if (!this._onMemoryWarningHandlerInstalled) {
                    if (a.sdk.onMemoryWarning) {
                        var e = (0, o.getCurrentHub)();
                        a.sdk.onMemoryWarning(function(t) {
                            var n = t.level, r = void 0 === n ? -1 : n, o = "没有获取到告警级别信息";
                            switch (r) {
                              case 5:
                                o = "TRIM_MEMORY_RUNNING_MODERATE";
                                break;

                              case 10:
                                o = "TRIM_MEMORY_RUNNING_LOW";
                                break;

                              case 15:
                                o = "TRIM_MEMORY_RUNNING_CRITICAL";
                                break;

                              default:
                                return;
                            }
                            e.setTag("memory-warning", String(r)), e.setExtra("message", o), e.captureMessage("内存不足告警");
                        });
                    }
                    this._onMemoryWarningHandlerInstalled = !0;
                }
            }, e.id = "GlobalHandlers", e;
        }();
        t.GlobalHandlers = u;
    },
    "4f5c": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                getPoint: function(t, n) {
                    "--" == n ? t.points = n : (t.points = parseInt(n.availablePoint), t.nextMonthExpiredPoints = n.nextExpiredPoints ? parseInt(n.nextExpiredPoints) : 0, 
                    e.setStorageSync("pointAccountId", n.pointAccountId));
                },
                isHeightPhone: function(t, n) {
                    console.log(t, n), t.isHeightScreen = n;
                    try {
                        e.setStorageSync("isHeightScreen", n);
                    } catch (e) {}
                },
                userinfo: function(t, n) {
                    e.getStorageSync("logininfo_tierName") || e.setStorageSync("logininfo_tierName", n.tier.tierName), 
                    t.userinfo = n;
                },
                wxuserinfoAvatar: function(e, t) {
                    e.wxuserinfoAvatar = t;
                },
                existsSignIn: function(e, t) {
                    t ? (e.isSignIn = t.isSignIn, e.signInCount = t.signInCount) : (e.isSignIn = !1, 
                    e.signInCount = "--");
                },
                navbarHeight: function(e, t) {
                    console.log(e), e.navbarHeight_a = t;
                },
                updateUserInfo: function(t, n) {
                    "" != t.userinfo && (t.userinfo.tier.tierName = n, e.setStorageSync("logininfo", t.userinfo)), 
                    e.setStorageSync("logininfo_tierName", n);
                },
                updateScoreValue: function(e, t) {
                    e.updateScoreValue = t;
                },
                updateAmountValue: function(e, t) {
                    e.updateAmountValue = t;
                },
                appPath: function(e, t) {
                    e.appPath = t;
                }
            };
            t.default = n;
        }).call(this, n("543d").default);
    },
    "500b": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = i(n("eb5f")), o = i(n("234f"));
        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var a = {
            token: function(e) {
                return (0, r.default)("post", "/api/token", e, !1);
            },
            login: function(e) {
                return (0, r.default)("post", "/api/wxapp/fans/login", e, !1);
            },
            decrypt: function(e) {
                return (0, r.default)("post", "/api/wxapp/fans/decrypt", e, !1);
            },
            bindquery: function(e) {
                return (0, r.default)("post", "/api/wxapp/member/bindquery", e, !1);
            },
            bind: function(e) {
                return (0, r.default)("post", "/api/wxapp/member/bind", e);
            },
            getmember: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    idType: e.idType,
                    id: e.id
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("get", "/api/wxapp/member/getmember", e, !1);
            },
            convertWxCardId: function(e) {
                return (0, r.default)("get", "/api/wxapp/coupon/convertWxCardId", e);
            },
            getJsCardSignature: function(e) {
                return (0, r.default)("get", "/api/wmt/service/getJsCardSignature", e);
            },
            shareRecord: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/shareRecord", e);
            },
            couponAddedWechat: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/couponAddedWechat", e);
            },
            grantCover: function(e) {
                return (0, r.default)("post", "/api/wxapp/lottery/grantCover", e);
            },
            sendType: function(e, t) {
                return (0, r.default)("post", "/api/wmt/payCard/coupon/send/".concat(t), e);
            },
            getPopupList: function(e) {
                return (0, r.default)("get", "/api/wxapp/popup/getList", e, !1);
            },
            getByType: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/popup/getByType/".concat(e), t, !1);
            },
            home_delivery: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, r.default)("get", "/api/wxapp/indexCategory/findAll", e, !1);
            },
            plusPoints: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/gift/plusPoints/".concat(e), t, !1);
            },
            getdynamiccode: function(e) {
                return (0, r.default)("get", "/api/wxapp/member/getdynamiccode", e, !1);
            },
            hotHome: function(e) {
                return (0, r.default)("get", "/api/wxapp/homeHot/find", e, !1);
            },
            getJsonDate: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", e, t, !1);
            },
            existsGive: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/repeatBuy/existsGive/".concat(e), t, !1);
            },
            getmemberForProgress: function(e) {
                return (0, r.default)("post", "/api/wxapp/member/getmemberForProgress", e, !1);
            },
            queryBanner: function(e) {
                return (0, r.default)("post", "/api/wxapp/memberProcessBanner/queryBanner", e, !1);
            },
            queryInfo: function(e) {
                return (0, r.default)("post", "/api/wxapp/memberProcessBanner/queryInfo", e, !1);
            },
            baffleGetByType: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/baffle/getByType/".concat(e), t, !1);
            },
            memberProcessType: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, r.default)("get", "/api/wxapp/memberProcessType/typeList", e, !1);
            },
            typeParamList: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    unionid: e.unionid,
                    frontQueryType: e.frontQueryType
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("post", "/api/wxapp/memberProcessType/typeParamList", e, !1);
            },
            queryBannerByType: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    unionid: e.unionid,
                    backQqueryType: e.backQqueryType
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("post", "/api/wxapp/memberProcessBanner/queryBannerByType", e, !1);
            }
        };
        t.default = a;
    },
    "507c": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), Object.defineProperty(t, "LogLevel", {
            enumerable: !0,
            get: function() {
                return r.LogLevel;
            }
        }), Object.defineProperty(t, "Severity", {
            enumerable: !0,
            get: function() {
                return o.Severity;
            }
        }), Object.defineProperty(t, "SpanStatus", {
            enumerable: !0,
            get: function() {
                return i.SpanStatus;
            }
        }), Object.defineProperty(t, "Status", {
            enumerable: !0,
            get: function() {
                return a.Status;
            }
        });
        var r = n("567c"), o = n("4028"), i = n("3baf"), a = n("6e9a");
    },
    "543d": function(e, t, r) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.createApp = et, t.createComponent = ft, t.createPage = st, t.createPlugin = pt, 
            t.createSubpackageApp = lt, t.default = void 0;
            var o, i = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(r("66fd")), a = r("37dc");
            function u(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(n), !0).forEach(function(t) {
                        f(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function s(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e;
                }(e) || function(e, t) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                        var n = [], r = !0, o = !1, i = void 0;
                        try {
                            for (var a, u = e[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), 
                            !t || n.length !== t); r = !0) ;
                        } catch (e) {
                            o = !0, i = e;
                        } finally {
                            try {
                                r || null == u.return || u.return();
                            } finally {
                                if (o) throw i;
                            }
                        }
                        return n;
                    }
                }(e, t) || p(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function f(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function l(e) {
                return function(e) {
                    if (Array.isArray(e)) return d(e);
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e);
                }(e) || p(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function p(e, t) {
                if (e) {
                    if ("string" == typeof e) return d(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? d(e, t) : void 0;
                }
            }
            function d(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r;
            }
            var h = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", v = /^(?:[A-Za-z\d+/]{4})*?(?:[A-Za-z\d+/]{2}(?:==)?|[A-Za-z\d+/]{3}=?)?$/;
            function g() {
                var e, t = wx.getStorageSync("uni_id_token") || "", n = t.split(".");
                if (!t || 3 !== n.length) return {
                    uid: null,
                    role: [],
                    permission: [],
                    tokenExpired: 0
                };
                try {
                    e = JSON.parse(function(e) {
                        return decodeURIComponent(o(e).split("").map(function(e) {
                            return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2);
                        }).join(""));
                    }(n[1]));
                } catch (e) {
                    throw new Error("获取当前用户信息出错，详细错误信息为：" + e.message);
                }
                return e.tokenExpired = 1e3 * e.exp, delete e.exp, delete e.iat, e;
            }
            o = "function" != typeof atob ? function(e) {
                if (e = String(e).replace(/[\t\n\f\r ]+/g, ""), !v.test(e)) throw new Error("Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded.");
                var t;
                e += "==".slice(2 - (3 & e.length));
                for (var n, r, o = "", i = 0; i < e.length; ) t = h.indexOf(e.charAt(i++)) << 18 | h.indexOf(e.charAt(i++)) << 12 | (n = h.indexOf(e.charAt(i++))) << 6 | (r = h.indexOf(e.charAt(i++))), 
                o += 64 === n ? String.fromCharCode(t >> 16 & 255) : 64 === r ? String.fromCharCode(t >> 16 & 255, t >> 8 & 255) : String.fromCharCode(t >> 16 & 255, t >> 8 & 255, 255 & t);
                return o;
            } : atob;
            var y = Object.prototype.toString, b = Object.prototype.hasOwnProperty;
            function m(e) {
                return "function" == typeof e;
            }
            function _(e) {
                return "string" == typeof e;
            }
            function w(e) {
                return "[object Object]" === y.call(e);
            }
            function x(e, t) {
                return b.call(e, t);
            }
            function O() {}
            function S(e) {
                var t = Object.create(null);
                return function(n) {
                    return t[n] || (t[n] = e(n));
                };
            }
            var E = /-(\w)/g, k = S(function(e) {
                return e.replace(E, function(e, t) {
                    return t ? t.toUpperCase() : "";
                });
            }), P = [ "invoke", "success", "fail", "complete", "returnValue" ], j = {}, A = {};
            function C(e, t) {
                Object.keys(t).forEach(function(n) {
                    -1 !== P.indexOf(n) && m(t[n]) && (e[n] = function(e, t) {
                        var n = t ? e ? e.concat(t) : Array.isArray(t) ? t : [ t ] : e;
                        return n ? function(e) {
                            for (var t = [], n = 0; n < e.length; n++) -1 === t.indexOf(e[n]) && t.push(e[n]);
                            return t;
                        }(n) : n;
                    }(e[n], t[n]));
                });
            }
            function T(e, t) {
                e && t && Object.keys(t).forEach(function(n) {
                    -1 !== P.indexOf(n) && m(t[n]) && function(e, t) {
                        var n = e.indexOf(t);
                        -1 !== n && e.splice(n, 1);
                    }(e[n], t[n]);
                });
            }
            function D(e) {
                return function(t) {
                    return e(t) || t;
                };
            }
            function M(e) {
                return !!e && ("object" === (0, n.default)(e) || "function" == typeof e) && "function" == typeof e.then;
            }
            function I(e, t) {
                for (var n = !1, r = 0; r < e.length; r++) {
                    var o = e[r];
                    if (n) n = Promise.resolve(D(o)); else {
                        var i = o(t);
                        if (M(i) && (n = Promise.resolve(i)), !1 === i) return {
                            then: function() {}
                        };
                    }
                }
                return n || {
                    then: function(e) {
                        return e(t);
                    }
                };
            }
            function L(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return [ "success", "fail", "complete" ].forEach(function(n) {
                    if (Array.isArray(e[n])) {
                        var r = t[n];
                        t[n] = function(t) {
                            I(e[n], t).then(function(e) {
                                return m(r) && r(e) || e;
                            });
                        };
                    }
                }), t;
            }
            function $(e, t) {
                var n = [];
                Array.isArray(j.returnValue) && n.push.apply(n, l(j.returnValue));
                var r = A[e];
                return r && Array.isArray(r.returnValue) && n.push.apply(n, l(r.returnValue)), n.forEach(function(e) {
                    t = e(t) || t;
                }), t;
            }
            function N(e) {
                var t = Object.create(null);
                Object.keys(j).forEach(function(e) {
                    "returnValue" !== e && (t[e] = j[e].slice());
                });
                var n = A[e];
                return n && Object.keys(n).forEach(function(e) {
                    "returnValue" !== e && (t[e] = (t[e] || []).concat(n[e]));
                }), t;
            }
            function R(e, t, n) {
                for (var r = arguments.length, o = new Array(r > 3 ? r - 3 : 0), i = 3; i < r; i++) o[i - 3] = arguments[i];
                var a = N(e);
                if (a && Object.keys(a).length) {
                    if (Array.isArray(a.invoke)) {
                        var u = I(a.invoke, n);
                        return u.then(function(e) {
                            return t.apply(void 0, [ L(a, e) ].concat(o));
                        });
                    }
                    return t.apply(void 0, [ L(a, n) ].concat(o));
                }
                return t.apply(void 0, [ n ].concat(o));
            }
            var B = {
                returnValue: function(e) {
                    return M(e) ? new Promise(function(t, n) {
                        e.then(function(e) {
                            e[0] ? n(e[0]) : t(e[1]);
                        });
                    }) : e;
                }
            }, H = /^\$|Window$|WindowStyle$|sendNativeEvent|restoreGlobal|getCurrentSubNVue|getMenuButtonBoundingClientRect|^report|interceptors|Interceptor$|getSubNVueById|requireNativePlugin|upx2px|hideKeyboard|canIUse|^create|Sync$|Manager$|base64ToArrayBuffer|arrayBufferToBase64|getLocale|setLocale/, F = /^create|Manager$/, U = [ "createBLEConnection" ], G = [ "createBLEConnection" ], V = /^on|^off/;
            function W(e) {
                return F.test(e) && -1 === U.indexOf(e);
            }
            function z(e) {
                return H.test(e) && -1 === G.indexOf(e);
            }
            function q(e) {
                return e.then(function(e) {
                    return [ null, e ];
                }).catch(function(e) {
                    return [ e ];
                });
            }
            function Y(e) {
                return !(W(e) || z(e) || function(e) {
                    return V.test(e) && "onPush" !== e;
                }(e));
            }
            function K(e, t) {
                return Y(e) ? function() {
                    for (var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++) o[i - 1] = arguments[i];
                    return m(n.success) || m(n.fail) || m(n.complete) ? $(e, R.apply(void 0, [ e, t, n ].concat(o))) : $(e, q(new Promise(function(r, i) {
                        R.apply(void 0, [ e, t, Object.assign({}, n, {
                            success: r,
                            fail: i
                        }) ].concat(o));
                    })));
                } : t;
            }
            Promise.prototype.finally || (Promise.prototype.finally = function(e) {
                var t = this.constructor;
                return this.then(function(n) {
                    return t.resolve(e()).then(function() {
                        return n;
                    });
                }, function(n) {
                    return t.resolve(e()).then(function() {
                        throw n;
                    });
                });
            });
            var J = !1, Q = 0, X = 0;
            function Z() {
                var e = getApp({
                    allowDefault: !0
                });
                return e && e.$vm ? e.$vm.$locale : wx.getSystemInfoSync().language || "zh-Hans";
            }
            var ee = [];
            void 0 !== e && (e.getLocale = Z);
            var te = {
                promiseInterceptor: B
            }, ne = Object.freeze({
                __proto__: null,
                upx2px: function(e, t) {
                    if (0 === Q && function() {
                        var e = wx.getSystemInfoSync(), t = e.platform, n = e.pixelRatio, r = e.windowWidth;
                        Q = r, X = n, J = "ios" === t;
                    }(), 0 === (e = Number(e))) return 0;
                    var n = e / 750 * (t || Q);
                    return n < 0 && (n = -n), 0 === (n = Math.floor(n + 1e-4)) && (n = 1 !== X && J ? .5 : 1), 
                    e < 0 ? -n : n;
                },
                getLocale: Z,
                setLocale: function(e) {
                    var t = getApp();
                    return !!t && (t.$vm.$locale !== e && (t.$vm.$locale = e, ee.forEach(function(t) {
                        return t({
                            locale: e
                        });
                    }), !0));
                },
                onLocaleChange: function(e) {
                    -1 === ee.indexOf(e) && ee.push(e);
                },
                addInterceptor: function(e, t) {
                    "string" == typeof e && w(t) ? C(A[e] || (A[e] = {}), t) : w(e) && C(j, e);
                },
                removeInterceptor: function(e, t) {
                    "string" == typeof e ? w(t) ? T(A[e], t) : delete A[e] : w(e) && T(j, e);
                },
                interceptors: te
            });
            var re, oe = "__DC_STAT_UUID";
            var ie = {
                returnValue: function(e) {
                    (function(e) {
                        (re = re || wx.getStorageSync(oe)) || (re = Date.now() + "" + Math.floor(1e7 * Math.random()), 
                        wx.setStorage({
                            key: oe,
                            data: re
                        })), e.deviceId = re;
                    })(e), function(e) {
                        if (e.safeArea) {
                            var t = e.safeArea;
                            e.safeAreaInsets = {
                                top: t.top,
                                left: t.left,
                                right: e.windowWidth - t.right,
                                bottom: e.windowHeight - t.bottom
                            };
                        }
                    }(e);
                }
            }, ae = {
                redirectTo: {
                    name: function(e) {
                        return "back" === e.exists && e.delta ? "navigateBack" : "redirectTo";
                    },
                    args: function(e) {
                        if ("back" === e.exists && e.url) {
                            var t = function(e) {
                                for (var t = getCurrentPages(), n = t.length; n--; ) {
                                    var r = t[n];
                                    if (r.$page && r.$page.fullPath === e) return n;
                                }
                                return -1;
                            }(e.url);
                            if (-1 !== t) {
                                var n = getCurrentPages().length - 1 - t;
                                n > 0 && (e.delta = n);
                            }
                        }
                    }
                },
                previewImage: {
                    args: function(e) {
                        var t = parseInt(e.current);
                        if (!isNaN(t)) {
                            var n = e.urls;
                            if (Array.isArray(n)) {
                                var r = n.length;
                                if (r) return t < 0 ? t = 0 : t >= r && (t = r - 1), t > 0 ? (e.current = n[t], 
                                e.urls = n.filter(function(e, r) {
                                    return !(r < t) || e !== n[t];
                                })) : e.current = n[0], {
                                    indicator: !1,
                                    loop: !1
                                };
                            }
                        }
                    }
                },
                getSystemInfo: ie,
                getSystemInfoSync: ie
            }, ue = [ "success", "fail", "cancel", "complete" ];
            function ce(e, t, n) {
                return function(r) {
                    return t(fe(e, r, n));
                };
            }
            function se(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, o = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
                if (w(t)) {
                    var i = !0 === o ? t : {};
                    for (var a in m(n) && (n = n(t, i) || {}), t) if (x(n, a)) {
                        var u = n[a];
                        m(u) && (u = u(t[a], t, i)), u ? _(u) ? i[u] = t[a] : w(u) && (i[u.name ? u.name : a] = u.value) : console.warn("The '".concat(e, "' method of platform '微信小程序' does not support option '").concat(a, "'"));
                    } else -1 !== ue.indexOf(a) ? m(t[a]) && (i[a] = ce(e, t[a], r)) : o || (i[a] = t[a]);
                    return i;
                }
                return m(t) && (t = ce(e, t, r)), t;
            }
            function fe(e, t, n) {
                var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                return m(ae.returnValue) && (t = ae.returnValue(e, t)), se(e, t, n, {}, r);
            }
            function le(e, t) {
                if (x(ae, e)) {
                    var n = ae[e];
                    return n ? function(t, r) {
                        var o = n;
                        m(n) && (o = n(t));
                        var i = [ t = se(e, t, o.args, o.returnValue) ];
                        void 0 !== r && i.push(r), m(o.name) ? e = o.name(t) : _(o.name) && (e = o.name);
                        var a = wx[e].apply(wx, i);
                        return z(e) ? fe(e, a, o.returnValue, W(e)) : a;
                    } : function() {
                        console.error("Platform '微信小程序' does not support '".concat(e, "'."));
                    };
                }
                return t;
            }
            var pe = Object.create(null);
            [ "onTabBarMidButtonTap", "subscribePush", "unsubscribePush", "onPush", "offPush", "share" ].forEach(function(e) {
                pe[e] = function(e) {
                    return function(t) {
                        var n = t.fail, r = t.complete, o = {
                            errMsg: "".concat(e, ":fail method '").concat(e, "' not supported")
                        };
                        m(n) && n(o), m(r) && r(o);
                    };
                }(e);
            });
            var de = {
                oauth: [ "weixin" ],
                share: [ "weixin" ],
                payment: [ "wxpay" ],
                push: [ "weixin" ]
            };
            var he = Object.freeze({
                __proto__: null,
                getProvider: function(e) {
                    var t = e.service, n = e.success, r = e.fail, o = e.complete, i = !1;
                    de[t] ? (i = {
                        errMsg: "getProvider:ok",
                        service: t,
                        provider: de[t]
                    }, m(n) && n(i)) : (i = {
                        errMsg: "getProvider:fail service not found"
                    }, m(r) && r(i)), m(o) && o(i);
                }
            }), ve = function() {
                var e;
                return function() {
                    return e || (e = new i.default()), e;
                };
            }();
            function ge(e, t, n) {
                return e[t].apply(e, n);
            }
            var ye = Object.freeze({
                __proto__: null,
                $on: function() {
                    return ge(ve(), "$on", Array.prototype.slice.call(arguments));
                },
                $off: function() {
                    return ge(ve(), "$off", Array.prototype.slice.call(arguments));
                },
                $once: function() {
                    return ge(ve(), "$once", Array.prototype.slice.call(arguments));
                },
                $emit: function() {
                    return ge(ve(), "$emit", Array.prototype.slice.call(arguments));
                }
            }), be = Object.freeze({
                __proto__: null
            }), me = Page, _e = Component, we = /:/g, xe = S(function(e) {
                return k(e.replace(we, "-"));
            });
            function Oe(e) {
                if (wx.canIUse && wx.canIUse("nextTick")) {
                    var t = e.triggerEvent;
                    e.triggerEvent = function(n) {
                        for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++) o[i - 1] = arguments[i];
                        return t.apply(e, [ xe(n) ].concat(o));
                    };
                }
            }
            function Se(e, t, n) {
                var r = t[e];
                t[e] = r ? function() {
                    Oe(this);
                    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                    return r.apply(this, t);
                } : function() {
                    Oe(this);
                };
            }
            me.__$wrappered || (me.__$wrappered = !0, Page = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return Se("onLoad", e), me(e);
            }, Page.after = me.after, Component = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return Se("created", e), _e(e);
            });
            function Ee(e, t, n) {
                t.forEach(function(t) {
                    (function e(t, n) {
                        if (!n) return !0;
                        if (i.default.options && Array.isArray(i.default.options[t])) return !0;
                        if (m(n = n.default || n)) return !!m(n.extendOptions[t]) || !!(n.super && n.super.options && Array.isArray(n.super.options[t]));
                        if (m(n[t])) return !0;
                        var r = n.mixins;
                        return Array.isArray(r) ? !!r.find(function(n) {
                            return e(t, n);
                        }) : void 0;
                    })(t, n) && (e[t] = function(e) {
                        return this.$vm && this.$vm.__call_hook(t, e);
                    });
                });
            }
            function ke(e, t) {
                var n;
                return [ n = m(t = t.default || t) ? t : e.extend(t), t = n.options ];
            }
            function Pe(e, t) {
                if (Array.isArray(t) && t.length) {
                    var n = Object.create(null);
                    t.forEach(function(e) {
                        n[e] = !0;
                    }), e.$scopedSlots = e.$slots = n;
                }
            }
            function je(e, t) {
                var n = (e = (e || "").split(",")).length;
                1 === n ? t._$vueId = e[0] : 2 === n && (t._$vueId = e[0], t._$vuePid = e[1]);
            }
            function Ae(e, t) {
                var n = e.data || {}, r = e.methods || {};
                if ("function" == typeof n) try {
                    n = n.call(t);
                } catch (e) {
                    Object({
                        VUE_APP_NAME: "HGDSxcx",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && console.warn("根据 Vue 的 data 函数初始化小程序 data 失败，请尽量确保 data 函数中不访问 vm 对象，否则可能影响首次数据渲染速度。", n);
                } else try {
                    n = JSON.parse(JSON.stringify(n));
                } catch (e) {}
                return w(n) || (n = {}), Object.keys(r).forEach(function(e) {
                    -1 !== t.__lifecycle_hooks__.indexOf(e) || x(n, e) || (n[e] = r[e]);
                }), n;
            }
            var Ce = [ String, Number, Boolean, Object, Array, null ];
            function Te(e) {
                return function(t, n) {
                    this.$vm && (this.$vm[e] = t);
                };
            }
            function De(e, t) {
                var n = e.behaviors, r = e.extends, o = e.mixins, i = e.props;
                i || (e.props = i = []);
                var a = [];
                return Array.isArray(n) && n.forEach(function(e) {
                    a.push(e.replace("uni://", "wx".concat("://"))), "uni://form-field" === e && (Array.isArray(i) ? (i.push("name"), 
                    i.push("value")) : (i.name = {
                        type: String,
                        default: ""
                    }, i.value = {
                        type: [ String, Number, Boolean, Array, Object, Date ],
                        default: ""
                    }));
                }), w(r) && r.props && a.push(t({
                    properties: Ie(r.props, !0)
                })), Array.isArray(o) && o.forEach(function(e) {
                    w(e) && e.props && a.push(t({
                        properties: Ie(e.props, !0)
                    }));
                }), a;
            }
            function Me(e, t, n, r) {
                return Array.isArray(t) && 1 === t.length ? t[0] : t;
            }
            function Ie(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], n = {};
                return t || (n.vueId = {
                    type: String,
                    value: ""
                }, n.generic = {
                    type: Object,
                    value: null
                }, n.scopedSlotsCompiler = {
                    type: String,
                    value: ""
                }, n.vueSlots = {
                    type: null,
                    value: [],
                    observer: function(e, t) {
                        var n = Object.create(null);
                        e.forEach(function(e) {
                            n[e] = !0;
                        }), this.setData({
                            $slots: n
                        });
                    }
                }), Array.isArray(e) ? e.forEach(function(e) {
                    n[e] = {
                        type: null,
                        observer: Te(e)
                    };
                }) : w(e) && Object.keys(e).forEach(function(t) {
                    var r = e[t];
                    if (w(r)) {
                        var o = r.default;
                        m(o) && (o = o()), r.type = Me(0, r.type), n[t] = {
                            type: -1 !== Ce.indexOf(r.type) ? r.type : null,
                            value: o,
                            observer: Te(t)
                        };
                    } else {
                        var i = Me(0, r);
                        n[t] = {
                            type: -1 !== Ce.indexOf(i) ? i : null,
                            observer: Te(t)
                        };
                    }
                }), n;
            }
            function Le(e, t, n) {
                var r = {};
                return Array.isArray(t) && t.length && t.forEach(function(t, o) {
                    "string" == typeof t ? t ? "$event" === t ? r["$" + o] = n : "arguments" === t ? n.detail && n.detail.__args__ ? r["$" + o] = n.detail.__args__ : r["$" + o] = [ n ] : 0 === t.indexOf("$event.") ? r["$" + o] = e.__get_value(t.replace("$event.", ""), n) : r["$" + o] = e.__get_value(t) : r["$" + o] = e : r["$" + o] = function(e, t) {
                        var n = e;
                        return t.forEach(function(t) {
                            var r = t[0], o = t[2];
                            if (r || void 0 !== o) {
                                var i, a = t[1], u = t[3];
                                Number.isInteger(r) ? i = r : r ? "string" == typeof r && r && (i = 0 === r.indexOf("#s#") ? r.substr(3) : e.__get_value(r, n)) : i = n, 
                                Number.isInteger(i) ? n = o : a ? Array.isArray(i) ? n = i.find(function(t) {
                                    return e.__get_value(a, t) === o;
                                }) : w(i) ? n = Object.keys(i).find(function(t) {
                                    return e.__get_value(a, i[t]) === o;
                                }) : console.error("v-for 暂不支持循环数据：", i) : n = i[o], u && (n = e.__get_value(u, n));
                            }
                        }), n;
                    }(e, t);
                }), r;
            }
            function $e(e) {
                for (var t = {}, n = 1; n < e.length; n++) {
                    var r = e[n];
                    t[r[0]] = r[1];
                }
                return t;
            }
            function Ne(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [], r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [], o = arguments.length > 4 ? arguments[4] : void 0, i = arguments.length > 5 ? arguments[5] : void 0, a = !1;
                if (o && (a = t.currentTarget && t.currentTarget.dataset && "wx" === t.currentTarget.dataset.comType, 
                !n.length)) return a ? [ t ] : t.detail.__args__ || t.detail;
                var u = Le(e, r, t), c = [];
                return n.forEach(function(e) {
                    "$event" === e ? "__set_model" !== i || o ? o && !a ? c.push(t.detail.__args__[0]) : c.push(t) : c.push(t.target.value) : Array.isArray(e) && "o" === e[0] ? c.push($e(e)) : "string" == typeof e && x(u, e) ? c.push(u[e]) : c.push(e);
                }), c;
            }
            var Re;
            function Be(e) {
                var t = this, r = ((e = function(e) {
                    try {
                        e.mp = JSON.parse(JSON.stringify(e));
                    } catch (e) {}
                    return e.stopPropagation = O, e.preventDefault = O, e.target = e.target || {}, x(e, "detail") || (e.detail = {}), 
                    x(e, "markerId") && (e.detail = "object" === (0, n.default)(e.detail) ? e.detail : {}, 
                    e.detail.markerId = e.markerId), w(e.detail) && (e.target = Object.assign({}, e.target, e.detail)), 
                    e;
                }(e)).currentTarget || e.target).dataset;
                if (!r) return console.warn("事件信息不存在");
                var o = r.eventOpts || r["event-opts"];
                if (!o) return console.warn("事件信息不存在");
                var i = e.type, a = [];
                return o.forEach(function(n) {
                    var r = n[0], o = n[1], u = "^" === r.charAt(0), c = "~" === (r = u ? r.slice(1) : r).charAt(0);
                    r = c ? r.slice(1) : r, o && function(e, t) {
                        return e === t || "regionchange" === t && ("begin" === e || "end" === e);
                    }(i, r) && o.forEach(function(n) {
                        var r = n[0];
                        if (r) {
                            var o = t.$vm;
                            if (o.$options.generic && (o = function(e) {
                                for (var t = e.$parent; t && t.$parent && (t.$options.generic || t.$parent.$options.generic || t.$scope._$vuePid); ) t = t.$parent;
                                return t && t.$parent;
                            }(o) || o), "$emit" === r) return void o.$emit.apply(o, Ne(t.$vm, e, n[1], n[2], u, r));
                            var i = o[r];
                            if (!m(i)) throw new Error(" _vm.".concat(r, " is not a function"));
                            if (c) {
                                if (i.once) return;
                                i.once = !0;
                            }
                            var s = Ne(t.$vm, e, n[1], n[2], u, r);
                            s = Array.isArray(s) ? s : [], /=\s*\S+\.eventParams\s*\|\|\s*\S+\[['"]event-params['"]\]/.test(i.toString()) && (s = s.concat([ , , , , , , , , , , e ])), 
                            a.push(i.apply(o, s));
                        }
                    });
                }), "input" === i && 1 === a.length && void 0 !== a[0] ? a[0] : void 0;
            }
            Re = wx.getSystemInfoSync().language;
            var He = (0, a.initVueI18n)(Re, {}), Fe = He.t;
            He.mixin = {
                beforeCreate: function() {
                    var e = this, t = He.i18n.watchLocale(function() {
                        e.$forceUpdate();
                    });
                    this.$once("hook:beforeDestroy", function() {
                        t();
                    });
                },
                methods: {
                    $$t: function(e, t) {
                        return Fe(e, t);
                    }
                }
            }, He.setLocale, He.getLocale;
            var Ue = {}, Ge = [];
            var Ve = [ "onShow", "onHide", "onError", "onPageNotFound", "onThemeChange", "onUnhandledRejection" ];
            function We() {
                i.default.prototype.getOpenerEventChannel = function() {
                    return this.$scope.getOpenerEventChannel();
                };
                var e = i.default.prototype.__call_hook;
                i.default.prototype.__call_hook = function(t, n) {
                    return "onLoad" === t && n && n.__id__ && (this.__eventChannel__ = function(e) {
                        if (e) {
                            var t = Ue[e];
                            return delete Ue[e], t;
                        }
                        return Ge.shift();
                    }(n.__id__), delete n.__id__), e.call(this, t, n);
                };
            }
            function ze(e, t) {
                var n = t.mocks, r = t.initRefs;
                We(), function() {
                    var e = {}, t = {};
                    i.default.prototype.$hasScopedSlotsParams = function(n) {
                        var r = e[n];
                        return r || (t[n] = this, this.$on("hook:destory", function() {
                            delete t[n];
                        })), r;
                    }, i.default.prototype.$getScopedSlotsParams = function(n, r, o) {
                        var i = e[n];
                        if (i) {
                            var a = i[r] || {};
                            return o ? a[o] : a;
                        }
                        t[n] = this, this.$on("hook:destory", function() {
                            delete t[n];
                        });
                    }, i.default.prototype.$setScopedSlotsParams = function(n, r) {
                        var o = this.$options.propsData.vueId;
                        if (o) {
                            var i = o.split(",")[0];
                            (e[i] = e[i] || {})[n] = r, t[i] && t[i].$forceUpdate();
                        }
                    }, i.default.mixin({
                        destroyed: function() {
                            var n = this.$options.propsData, r = n && n.vueId;
                            r && (delete e[r], delete t[r]);
                        }
                    });
                }(), e.$options.store && (i.default.prototype.$store = e.$options.store), function(e) {
                    e.prototype.uniIDHasRole = function(e) {
                        return g().role.indexOf(e) > -1;
                    }, e.prototype.uniIDHasPermission = function(e) {
                        var t = g().permission;
                        return this.uniIDHasRole("admin") || t.indexOf(e) > -1;
                    }, e.prototype.uniIDTokenValid = function() {
                        return g().tokenExpired > Date.now();
                    };
                }(i.default), i.default.prototype.mpHost = "mp-weixin", i.default.mixin({
                    beforeCreate: function() {
                        if (this.$options.mpType) {
                            if (this.mpType = this.$options.mpType, this.$mp = f({
                                data: {}
                            }, this.mpType, this.$options.mpInstance), this.$scope = this.$options.mpInstance, 
                            delete this.$options.mpType, delete this.$options.mpInstance, "page" === this.mpType && "function" == typeof getApp) {
                                var e = getApp();
                                e.$vm && e.$vm.$i18n && (this._i18n = e.$vm.$i18n);
                            }
                            "app" !== this.mpType && (r(this), function(e, t) {
                                var n = e.$mp[e.mpType];
                                t.forEach(function(t) {
                                    x(n, t) && (e[t] = n[t]);
                                });
                            }(this, n));
                        }
                    }
                });
                var o = {
                    onLaunch: function(t) {
                        this.$vm || (wx.canIUse && !wx.canIUse("nextTick") && console.error("当前微信基础库版本过低，请将 微信开发者工具-详情-项目设置-调试基础库版本 更换为`2.3.0`以上"), 
                        this.$vm = e, this.$vm.$mp = {
                            app: this
                        }, this.$vm.$scope = this, this.$vm.globalData = this.globalData, this.$vm._isMounted = !0, 
                        this.$vm.__call_hook("mounted", t), this.$vm.__call_hook("onLaunch", t));
                    }
                };
                o.globalData = e.$options.globalData || {};
                var a = e.$options.methods;
                return a && Object.keys(a).forEach(function(e) {
                    o[e] = a[e];
                }), function(e, t, n) {
                    var r = e.observable({
                        locale: n || He.getLocale()
                    }), o = [];
                    t.$watchLocale = function(e) {
                        o.push(e);
                    }, Object.defineProperty(t, "$locale", {
                        get: function() {
                            return r.locale;
                        },
                        set: function(e) {
                            r.locale = e, o.forEach(function(t) {
                                return t(e);
                            });
                        }
                    });
                }(i.default, e, wx.getSystemInfoSync().language || "zh-Hans"), Ee(o, Ve), o;
            }
            var qe = [ "__route__", "__wxExparserNodeId__", "__wxWebviewId__" ];
            function Ye(e) {
                return Behavior(e);
            }
            function Ke() {
                return !!this.route;
            }
            function Je(e) {
                this.triggerEvent("__l", e);
            }
            function Qe(e) {
                var t = e.$scope;
                Object.defineProperty(e, "$refs", {
                    get: function() {
                        var e = {};
                        return function e(t, n, r) {
                            t.selectAllComponents(n).forEach(function(t) {
                                var o = t.dataset.ref;
                                r[o] = t.$vm || t, "scoped" === t.dataset.vueGeneric && t.selectAllComponents(".scoped-ref").forEach(function(t) {
                                    e(t, n, r);
                                });
                            });
                        }(t, ".vue-ref", e), t.selectAllComponents(".vue-ref-in-for").forEach(function(t) {
                            var n = t.dataset.ref;
                            e[n] || (e[n] = []), e[n].push(t.$vm || t);
                        }), e;
                    }
                });
            }
            function Xe(e) {
                var t, n = e.detail || e.value, r = n.vuePid, o = n.vueOptions;
                r && (t = function e(t, n) {
                    for (var r, o = t.$children, i = o.length - 1; i >= 0; i--) {
                        var a = o[i];
                        if (a.$scope._$vueId === n) return a;
                    }
                    for (var u = o.length - 1; u >= 0; u--) if (r = e(o[u], n)) return r;
                }(this.$vm, r)), t || (t = this.$vm), o.parent = t;
            }
            function Ze(e) {
                return ze(e, {
                    mocks: qe,
                    initRefs: Qe
                });
            }
            function et(e) {
                return App(Ze(e)), e;
            }
            var tt = /[!'()*]/g, nt = function(e) {
                return "%" + e.charCodeAt(0).toString(16);
            }, rt = /%2C/g, ot = function(e) {
                return encodeURIComponent(e).replace(tt, nt).replace(rt, ",");
            };
            function it(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ot, n = e ? Object.keys(e).map(function(n) {
                    var r = e[n];
                    if (void 0 === r) return "";
                    if (null === r) return t(n);
                    if (Array.isArray(r)) {
                        var o = [];
                        return r.forEach(function(e) {
                            void 0 !== e && (null === e ? o.push(t(n)) : o.push(t(n) + "=" + t(e)));
                        }), o.join("&");
                    }
                    return t(n) + "=" + t(r);
                }).filter(function(e) {
                    return e.length > 0;
                }).join("&") : null;
                return n ? "?".concat(n) : "";
            }
            function at(e) {
                return function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.isPage, r = t.initRelation, o = ke(i.default, e), a = s(o, 2), u = a[0], f = a[1], l = c({
                        multipleSlots: !0,
                        addGlobalClass: !0
                    }, f.options || {});
                    f["mp-weixin"] && f["mp-weixin"].options && Object.assign(l, f["mp-weixin"].options);
                    var p = {
                        options: l,
                        data: Ae(f, i.default.prototype),
                        behaviors: De(f, Ye),
                        properties: Ie(f.props, !1, f.__file),
                        lifetimes: {
                            attached: function() {
                                var e = this.properties, t = {
                                    mpType: n.call(this) ? "page" : "component",
                                    mpInstance: this,
                                    propsData: e
                                };
                                je(e.vueId, this), r.call(this, {
                                    vuePid: this._$vuePid,
                                    vueOptions: t
                                }), this.$vm = new u(t), Pe(this.$vm, e.vueSlots), this.$vm.$mount();
                            },
                            ready: function() {
                                this.$vm && (this.$vm._isMounted = !0, this.$vm.__call_hook("mounted"), this.$vm.__call_hook("onReady"));
                            },
                            detached: function() {
                                this.$vm && this.$vm.$destroy();
                            }
                        },
                        pageLifetimes: {
                            show: function(e) {
                                this.$vm && this.$vm.__call_hook("onPageShow", e);
                            },
                            hide: function() {
                                this.$vm && this.$vm.__call_hook("onPageHide");
                            },
                            resize: function(e) {
                                this.$vm && this.$vm.__call_hook("onPageResize", e);
                            }
                        },
                        methods: {
                            __l: Xe,
                            __e: Be
                        }
                    };
                    return f.externalClasses && (p.externalClasses = f.externalClasses), Array.isArray(f.wxsCallMethods) && f.wxsCallMethods.forEach(function(e) {
                        p.methods[e] = function(t) {
                            return this.$vm[e](t);
                        };
                    }), n ? p : [ p, u ];
                }(e, {
                    isPage: Ke,
                    initRelation: Je
                });
            }
            var ut = [ "onShow", "onHide", "onUnload" ];
            function ct(e) {
                return function(e, t) {
                    t.isPage, t.initRelation;
                    var n = at(e);
                    return Ee(n.methods, ut, e), n.methods.onLoad = function(e) {
                        this.options = e;
                        var t = Object.assign({}, e);
                        delete t.__id__, this.$page = {
                            fullPath: "/" + (this.route || this.is) + it(t)
                        }, this.$vm.$mp.query = e, this.$vm.__call_hook("onLoad", e);
                    }, n;
                }(e, {
                    isPage: Ke,
                    initRelation: Je
                });
            }
            function st(e) {
                return Component(ct(e));
            }
            function ft(e) {
                return Component(at(e));
            }
            function lt(e) {
                var t = Ze(e), n = getApp({
                    allowDefault: !0
                });
                e.$scope = n;
                var r = n.globalData;
                if (r && Object.keys(t.globalData).forEach(function(e) {
                    x(r, e) || (r[e] = t.globalData[e]);
                }), Object.keys(t).forEach(function(e) {
                    x(n, e) || (n[e] = t[e]);
                }), m(t.onShow) && wx.onAppShow && wx.onAppShow(function() {
                    for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    e.__call_hook("onShow", n);
                }), m(t.onHide) && wx.onAppHide && wx.onAppHide(function() {
                    for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                    e.__call_hook("onHide", n);
                }), m(t.onLaunch)) {
                    var o = wx.getLaunchOptionsSync && wx.getLaunchOptionsSync();
                    e.__call_hook("onLaunch", o);
                }
                return e;
            }
            function pt(e) {
                var t = Ze(e);
                if (m(t.onShow) && wx.onAppShow && wx.onAppShow(function() {
                    for (var n = arguments.length, r = new Array(n), o = 0; o < n; o++) r[o] = arguments[o];
                    t.onShow.apply(e, r);
                }), m(t.onHide) && wx.onAppHide && wx.onAppHide(function() {
                    for (var n = arguments.length, r = new Array(n), o = 0; o < n; o++) r[o] = arguments[o];
                    t.onHide.apply(e, r);
                }), m(t.onLaunch)) {
                    var n = wx.getLaunchOptionsSync && wx.getLaunchOptionsSync();
                    t.onLaunch.call(e, n);
                }
                return e;
            }
            ut.push.apply(ut, [ "onPullDownRefresh", "onReachBottom", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onPageScroll", "onResize", "onTabItemTap" ]), 
            [ "vibrate", "preloadPage", "unPreloadPage", "loadSubPackage" ].forEach(function(e) {
                ae[e] = !1;
            }), [].forEach(function(e) {
                var t = ae[e] && ae[e].name ? ae[e].name : e;
                wx.canIUse(t) || (ae[e] = !1);
            });
            var dt = {};
            "undefined" != typeof Proxy ? dt = new Proxy({}, {
                get: function(e, t) {
                    return x(e, t) ? e[t] : ne[t] ? ne[t] : be[t] ? K(t, be[t]) : he[t] ? K(t, he[t]) : pe[t] ? K(t, pe[t]) : ye[t] ? ye[t] : x(wx, t) || x(ae, t) ? K(t, le(t, wx[t])) : void 0;
                },
                set: function(e, t, n) {
                    return e[t] = n, !0;
                }
            }) : (Object.keys(ne).forEach(function(e) {
                dt[e] = ne[e];
            }), Object.keys(pe).forEach(function(e) {
                dt[e] = K(e, pe[e]);
            }), Object.keys(he).forEach(function(e) {
                dt[e] = K(e, pe[e]);
            }), Object.keys(ye).forEach(function(e) {
                dt[e] = ye[e];
            }), Object.keys(be).forEach(function(e) {
                dt[e] = K(e, be[e]);
            }), Object.keys(wx).forEach(function(e) {
                (x(wx, e) || x(ae, e)) && (dt[e] = K(e, le(e, wx[e])));
            })), wx.createApp = et, wx.createPage = st, wx.createComponent = ft, wx.createSubpackageApp = lt, 
            wx.createPlugin = pt;
            var ht = dt;
            t.default = ht;
        }).call(this, r("c8ba"));
    },
    "567c": function(e, t, n) {
        var r;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.LogLevel = void 0, t.LogLevel = r, function(e) {
            e[e.None = 0] = "None", e[e.Error = 1] = "Error", e[e.Debug = 2] = "Debug", e[e.Verbose = 3] = "Verbose";
        }(r || (t.LogLevel = r = {}));
    },
    5775: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = "https://haagendazs-oss.smarket.com.cn/UX/attendance/icon", r = {
                lunarInfo: [ 19416, 19168, 42352, 21717, 53856, 55632, 91476, 22176, 39632, 21970, 19168, 42422, 42192, 53840, 119381, 46400, 54944, 44450, 38320, 84343, 18800, 42160, 46261, 27216, 27968, 109396, 11104, 38256, 21234, 18800, 25958, 54432, 59984, 28309, 23248, 11104, 100067, 37600, 116951, 51536, 54432, 120998, 46416, 22176, 107956, 9680, 37584, 53938, 43344, 46423, 27808, 46416, 86869, 19872, 42416, 83315, 21168, 43432, 59728, 27296, 44710, 43856, 19296, 43748, 42352, 21088, 62051, 55632, 23383, 22176, 38608, 19925, 19152, 42192, 54484, 53840, 54616, 46400, 46752, 103846, 38320, 18864, 43380, 42160, 45690, 27216, 27968, 44870, 43872, 38256, 19189, 18800, 25776, 29859, 59984, 27480, 23232, 43872, 38613, 37600, 51552, 55636, 54432, 55888, 30034, 22176, 43959, 9680, 37584, 51893, 43344, 46240, 47780, 44368, 21977, 19360, 42416, 86390, 21168, 43312, 31060, 27296, 44368, 23378, 19296, 42726, 42208, 53856, 60005, 54576, 23200, 30371, 38608, 19195, 19152, 42192, 118966, 53840, 54560, 56645, 46496, 22224, 21938, 18864, 42359, 42160, 43600, 111189, 27936, 44448, 84835, 37744, 18936, 18800, 25776, 92326, 59984, 27424, 108228, 43744, 41696, 53987, 51552, 54615, 54432, 55888, 23893, 22176, 42704, 21972, 21200, 43448, 43344, 46240, 46758, 44368, 21920, 43940, 42416, 21168, 45683, 26928, 29495, 27296, 44368, 84821, 19296, 42352, 21732, 53600, 59752, 54560, 55968, 92838, 22224, 19168, 43476, 41680, 53584, 62034, 54560 ],
                solarMonth: [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ],
                Gan: [ "甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸" ],
                Zhi: [ "子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥" ],
                Animals: [ "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" ],
                solarTerm: [ "小寒", "大寒", "立春", "雨水", "惊蛰", "春分", "清明", "谷雨", "立夏", "小满", "芒种", "夏至", "小暑", "大暑", "立秋", "处暑", "白露", "秋分", "寒露", "霜降", "立冬", "小雪", "大雪", "冬至" ],
                sTermInfo: [ "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c3598082c95f8c965cc920f", "97bd0b06bdb0722c965ce1cfcc920f", "b027097bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd0b06bdb0722c965ce1cfcc920f", "b027097bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd0b06bdb0722c965ce1cfcc920f", "b027097bd097c36b0b6fc9274c91aa", "9778397bd19801ec9210c965cc920e", "97b6b97bd19801ec95f8c965cc920f", "97bd09801d98082c95f8e1cfcc920f", "97bd097bd097c36b0b6fc9210c8dc2", "9778397bd197c36c9210c9274c91aa", "97b6b97bd19801ec95f8c965cc920e", "97bd09801d98082c95f8e1cfcc920f", "97bd097bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c91aa", "97b6b97bd19801ec95f8c965cc920e", "97bcf97c3598082c95f8e1cfcc920f", "97bd097bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c3598082c95f8c965cc920f", "97bd097bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c3598082c95f8c965cc920f", "97bd097bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd097bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd097bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf97c359801ec95f8c965cc920f", "97bd097bd07f595b0b6fc920fb0722", "9778397bd097c36b0b6fc9210c8dc2", "9778397bd19801ec9210c9274c920e", "97b6b97bd19801ec95f8c965cc920f", "97bd07f5307f595b0b0bc920fb0722", "7f0e397bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c920e", "97b6b97bd19801ec95f8c965cc920f", "97bd07f5307f595b0b0bc920fb0722", "7f0e397bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bd07f1487f595b0b0bc920fb0722", "7f0e397bd097c36b0b6fc9210c8dc2", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf7f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf7f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf7f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c965cc920e", "97bcf7f1487f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b97bd19801ec9210c9274c920e", "97bcf7f0e47f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9210c91aa", "97b6b97bd197c36c9210c9274c920e", "97bcf7f0e47f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9210c8dc2", "9778397bd097c36c9210c9274c920e", "97b6b7f0e47f531b0723b0b6fb0722", "7f0e37f5307f595b0b0bc920fb0722", "7f0e397bd097c36b0b6fc9210c8dc2", "9778397bd097c36b0b70c9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e37f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc9210c8dc2", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e27f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9274c91aa", "97b6b7f0e47f531b0723b0787b0721", "7f0e27f0e47f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9210c91aa", "97b6b7f0e47f149b0723b0787b0721", "7f0e27f0e47f531b0723b0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "9778397bd097c36b0b6fc9210c8dc2", "977837f0e37f149b0723b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e37f5307f595b0b0bc920fb0722", "7f0e397bd097c35b0b6fc9210c8dc2", "977837f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e37f1487f595b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc9210c8dc2", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd097c35b0b6fc920fb0722", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "977837f0e37f14998082b0787b06bd", "7f07e7f0e47f149b0723b0787b0721", "7f0e27f0e47f531b0b0bb0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "977837f0e37f14998082b0723b06bd", "7f07e7f0e37f149b0723b0787b0721", "7f0e27f0e47f531b0723b0b6fb0722", "7f0e397bd07f595b0b0bc920fb0722", "977837f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e37f1487f595b0b0bb0b6fb0722", "7f0e37f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e37f1487f531b0b0bb0b6fb0722", "7f0e37f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e37f1487f531b0b0bb0b6fb0722", "7f0e37f0e37f14898082b072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e37f0e37f14898082b072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e37f0e366aa89801eb072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f149b0723b0787b0721", "7f0e27f1487f531b0b0bb0b6fb0722", "7f0e37f0e366aa89801eb072297c35", "7ec967f0e37f14998082b0723b06bd", "7f07e7f0e47f149b0723b0787b0721", "7f0e27f0e47f531b0723b0b6fb0722", "7f0e37f0e366aa89801eb072297c35", "7ec967f0e37f14998082b0723b06bd", "7f07e7f0e37f14998083b0787b0721", "7f0e27f0e47f531b0723b0b6fb0722", "7f0e37f0e366aa89801eb072297c35", "7ec967f0e37f14898082b0723b02d5", "7f07e7f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e36665b66aa89801e9808297c35", "665f67f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b0721", "7f07e7f0e47f531b0723b0b6fb0722", "7f0e36665b66a449801e9808297c35", "665f67f0e37f14898082b0723b02d5", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e36665b66a449801e9808297c35", "665f67f0e37f14898082b072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e26665b66a449801e9808297c35", "665f67f0e37f1489801eb072297c35", "7ec967f0e37f14998082b0787b06bd", "7f07e7f0e47f531b0723b0b6fb0721", "7f0e27f1487f531b0b0bb0b6fb0722" ],
                nStr1: [ "日", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十" ],
                nStr2: [ "初", "十", "廿", "卅" ],
                nStr3: [ "正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "冬", "腊" ],
                lYearDays: function(e) {
                    var t, n = 348;
                    for (t = 32768; t > 8; t >>= 1) n += this.lunarInfo[e - 1900] & t ? 1 : 0;
                    return n + this.leapDays(e);
                },
                leapMonth: function(e) {
                    return 15 & this.lunarInfo[e - 1900];
                },
                leapDays: function(e) {
                    return this.leapMonth(e) ? 65536 & this.lunarInfo[e - 1900] ? 30 : 29 : 0;
                },
                monthDays: function(e, t) {
                    return t > 12 || t < 1 ? -1 : this.lunarInfo[e - 1900] & 65536 >> t ? 30 : 29;
                },
                solarDays: function(e, t) {
                    if (t > 12 || t < 1) return -1;
                    var n = t - 1;
                    return 1 == n ? e % 4 == 0 && e % 100 != 0 || e % 400 == 0 ? 29 : 28 : this.solarMonth[n];
                },
                toGanZhiYear: function(e) {
                    var t = (e - 3) % 10, n = (e - 3) % 12;
                    return 0 == t && (t = 10), 0 == n && (n = 12), this.Gan[t - 1] + this.Zhi[n - 1];
                },
                toAstro: function(e, t) {
                    return "魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯".substr(2 * e - (t < [ 20, 19, 21, 21, 21, 22, 23, 23, 23, 23, 22, 22 ][e - 1] ? 2 : 0), 2) + "座";
                },
                toGanZhi: function(e) {
                    return this.Gan[e % 10] + this.Zhi[e % 12];
                },
                getTerm: function(e, t) {
                    if (e < 1900 || e > 2100) return -1;
                    if (t < 1 || t > 24) return -1;
                    var n = this.sTermInfo[e - 1900], r = [ parseInt("0x" + n.substr(0, 5)).toString(), parseInt("0x" + n.substr(5, 5)).toString(), parseInt("0x" + n.substr(10, 5)).toString(), parseInt("0x" + n.substr(15, 5)).toString(), parseInt("0x" + n.substr(20, 5)).toString(), parseInt("0x" + n.substr(25, 5)).toString() ], o = [ r[0].substr(0, 1), r[0].substr(1, 2), r[0].substr(3, 1), r[0].substr(4, 2), r[1].substr(0, 1), r[1].substr(1, 2), r[1].substr(3, 1), r[1].substr(4, 2), r[2].substr(0, 1), r[2].substr(1, 2), r[2].substr(3, 1), r[2].substr(4, 2), r[3].substr(0, 1), r[3].substr(1, 2), r[3].substr(3, 1), r[3].substr(4, 2), r[4].substr(0, 1), r[4].substr(1, 2), r[4].substr(3, 1), r[4].substr(4, 2), r[5].substr(0, 1), r[5].substr(1, 2), r[5].substr(3, 1), r[5].substr(4, 2) ];
                    return parseInt(o[t - 1]);
                },
                toChinaMonth: function(e) {
                    if (e > 12 || e < 1) return -1;
                    var t = this.nStr3[e - 1];
                    return t += "月";
                },
                toChinaMonthC: function(e) {
                    return e > 12 || e < 1 ? -1 : this.nStr3[e - 1];
                },
                toChinaDay: function(e) {
                    var t;
                    switch (e) {
                      case 10:
                        t = "初十";
                        break;

                      case 20:
                        t = "二十";
                        break;

                      case 30:
                        t = "三十";
                        break;

                      default:
                        t = this.nStr2[Math.floor(e / 10)], t += this.nStr1[e % 10];
                    }
                    return t;
                },
                getAnimal: function(e) {
                    return this.Animals[(e - 4) % 12];
                },
                getImgFestival: function(e, t, r, o) {
                    return this.toChinaMonthC(r), this.toChinaDay(o), 3 == e && 8 == t && {
                        festName: "女神节",
                        imghttp: n + "/nsj.png"
                    };
                },
                getAnniversary: function(t, n, r) {
                    var o = e.getStorageSync("logininfo").registDate;
                    if (!o) return !1;
                    var i = o.split("-")[0], a = o.split("-")[1], u = o.split("-")[2];
                    return t > i && n == a && r == u;
                },
                getFestival: function(e, t, n, r, o) {
                    var i = this.toChinaMonthC(n), a = this.toChinaDay(r);
                    if (1 == e && 1 == t) return "元旦";
                    if (4 == e && 1 == t) return "愚人节";
                    if ("正" == i && "初一" == a) return "春节";
                    if ("二" == i && "初二" == a) return "龙抬头";
                    if ("五" == i && "初五" == a) return "端午节";
                    if ("九" == i && "初九" == a) return "重阳节";
                    if ("正" == i && "十五" == a) return "元宵节";
                    if ("七" == i && "十五" == a) return "中元节";
                    if ("八" == i && "十五" == a) return "中秋节";
                    if ("十" == i && "十五" == a) return "下元节";
                    if ("腊" == i) if (29 == o) {
                        if ("廿九" == a) return "除夕";
                    } else if (30 == o && "三十" == a) return "除夕";
                },
                getBirthDay: function(t, n, r) {
                    var o = e.getStorageSync("logininfo").birthDate;
                    if (!o) return !1;
                    var i = e.getStorageSync("logininfo").tier.tierName, a = new Date().getFullYear(), u = o.split("-")[1], c = o.split("-")[2];
                    return a >= t && n == u && r == c && ("铂金卡会员" == i || "金卡会员" == i || "银卡会员" == i);
                },
                solar2lunar: function(t, r, o) {
                    if (t < 1900 || t > 2100) return -1;
                    if (1900 == t && 1 == r && o < 31) return -1;
                    if (t) i = new Date(t, parseInt(r) - 1, o); else var i = new Date();
                    var a, u, c = 0, s = (t = i.getFullYear(), r = i.getMonth() + 1, o = i.getDate(), 
                    (Date.UTC(i.getFullYear(), i.getMonth(), i.getDate()) - Date.UTC(1900, 0, 31)) / 864e5);
                    for (a = 1900; a < 2101 && s > 0; a++) s -= c = this.lYearDays(a);
                    s < 0 && (s += c, a--);
                    var f = new Date(), l = !1;
                    f.getFullYear() == t && f.getMonth() + 1 == r && f.getDate() == o && (l = !0);
                    var p = i.getDay(), d = this.nStr1[p];
                    0 == p && (p = 7);
                    var h = a, v = (u = this.leapMonth(a), !1);
                    for (a = 1; a < 13 && s > 0; a++) u > 0 && a == u + 1 && 0 == v ? (--a, v = !0, 
                    c = this.leapDays(h)) : c = this.monthDays(h, a), 1 == v && a == u + 1 && (v = !1), 
                    s -= c;
                    0 == s && u > 0 && a == u + 1 && (v ? v = !1 : (v = !0, --a)), s < 0 && (s += c, 
                    --a);
                    var g = a, y = s + 1, b = r - 1, m = this.toGanZhiYear(h), _ = this.getTerm(t, 2 * r - 1), w = this.getTerm(t, 2 * r), x = this.toGanZhi(12 * (t - 1900) + r + 11);
                    o >= _ && (x = this.toGanZhi(12 * (t - 1900) + r + 12));
                    var O = !1, S = null;
                    _ == o && (O = !0, S = this.solarTerm[2 * r - 2]), w == o && (O = !0, S = this.solarTerm[2 * r - 1]);
                    var E = this.getFestival(r, o, g, y, c);
                    E && (S = E);
                    var k = Date.UTC(t, b, 1, 0, 0, 0, 0) / 864e5 + 25567 + 10, P = this.toGanZhi(k + o - 1), j = this.toAstro(r, o), A = this.getImgFestival(r, o, g, y), C = this.getBirthDay(t, r, o);
                    if (this.getAnniversary(t, r, o), C) {
                        var T = e.getStorageSync("logininfo").tier.tierName, D = "";
                        "铂金卡会员" == T ? D = "BIR_PLATINUM" : "金卡会员" == T ? D = "BIR_GOLDEN" : "银卡会员" == T && (D = "BIR_SILVER"), 
                        A = {
                            festName: "生日礼",
                            imghttp: n + "/srl.png",
                            url: "/evaluation/birthLife/index?scence=" + D
                        };
                    }
                    return {
                        ishasImg: A,
                        isBirth: C,
                        lYear: h,
                        lMonth: g,
                        lDay: y,
                        Animal: this.getAnimal(h),
                        IMonthCn: (v ? "闰" : "") + this.toChinaMonth(g),
                        IDayCn: this.toChinaDay(y),
                        cYear: t,
                        cMonth: r,
                        cDay: o,
                        gzYear: m,
                        gzMonth: x,
                        gzDay: P,
                        isToday: l,
                        isLeap: v,
                        nWeek: p,
                        ncWeek: "星期" + d,
                        isTerm: O,
                        Term: S,
                        astro: j,
                        temp: c
                    };
                },
                lunar2solar: function(e, t, n, r) {
                    r = !!r;
                    var o = this.leapMonth(e);
                    if (this.leapDays(e), r && o != t) return -1;
                    if (2100 == e && 12 == t && n > 1 || 1900 == e && 1 == t && n < 31) return -1;
                    var i = this.monthDays(e, t), a = i;
                    if (r && (a = this.leapDays(e, t)), e < 1900 || e > 2100 || n > a) return -1;
                    for (var u = 0, c = 1900; c < e; c++) u += this.lYearDays(c);
                    var s = 0, f = !1;
                    for (c = 1; c < t; c++) s = this.leapMonth(e), f || s <= c && s > 0 && (u += this.leapDays(e), 
                    f = !0), u += this.monthDays(e, c);
                    r && (u += i);
                    var l = Date.UTC(1900, 1, 30, 0, 0, 0), p = new Date(864e5 * (u + n - 31) + l), d = p.getUTCFullYear(), h = p.getUTCMonth() + 1, v = p.getUTCDate();
                    return this.solar2lunar(d, h, v);
                }
            };
            t.default = r;
        }).call(this, n("543d").default);
    },
    "5a1c": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = c(n("66fd")), o = c(n("26cb")), i = c(n("0b67")), a = c(n("4f5c")), u = c(n("f0fd"));
            function c(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            r.default.use(o.default);
            var s = !1, f = "", l = "", p = u.default.ossurl + "UX/shop/";
            try {
                e.getStorageSync("isHeightScreen") && (s = e.getStorageSync("isHeightScreen")), 
                e.getStorageSync("logininfo") && (f = e.getStorageSync("logininfo"), e.getStorageSync("logininfo_tierName") || e.setStorageSync("logininfo_tierName", f.tier.tierName)), 
                e.getStorageSync("wxuserinfoAvatar") && (l = e.getStorageSync("wxuserinfoAvatar"));
            } catch (e) {}
            var d = new o.default.Store({
                state: {
                    count: 0,
                    bottomLife: 0,
                    points: 0,
                    nextMonthExpiredPoints: 0,
                    isHeightScreen: s,
                    userinfo: f,
                    wxuserinfoAvatar: l,
                    isSignIn: !1,
                    signInCount: 0,
                    navbarHeight_a: null,
                    updateScoreValue: 0,
                    updateScoreVal: 0,
                    updateAmountValue: 0,
                    appPath: ""
                },
                getters: {
                    signAgain: function(e) {
                        return e.signInCount > 60 && e.signInCount % 60 != 0 ? e.signInCount % 60 : e.signInCount;
                    },
                    signInCountNum: function(e) {
                        var t;
                        return 0 == (t = e.signInCount > 60 && e.signInCount % 60 != 0 ? e.signInCount % 60 : e.signInCount) ? 0 : 1 == t ? 11 : 2 == t ? 26 : 3 == t ? 42 : 4 == t ? 58 : 5 == t ? 74 : 6 == t ? 89 : t >= 7 ? 100 : void 0;
                    },
                    prograss: function(t) {
                        var n = {}, r = t.userinfo ? t.userinfo.tier.tierName : "";
                        return e.getStorageSync("logininfo_tierName") && (r = e.getStorageSync("logininfo_tierName")), 
                        "铂金卡会员" == r ? (n.num = 5e3, n.width = 100, n.hasNum = 5e3) : "哈根达斯会员" == r ? (n.width = 100 * parseFloat((300 - t.updateScoreVal) / 300).toFixed(2), 
                        n.num = 300, n.hasNum = 300 - t.updateScoreVal) : "银卡会员" == r ? (n.width = 100 * parseFloat((1e3 - t.updateScoreVal) / 1e3).toFixed(2), 
                        n.num = 1e3, n.hasNum = 1e3 - t.updateScoreVal, n.num = 1e3) : "金卡会员" == r ? (n.width = 100 * parseFloat((5e3 - t.updateScoreVal) / 5e3).toFixed(2), 
                        n.num = 5e3, n.hasNum = 5e3 - t.updateScoreVal, n.num = 5e3) : (n.width = 100 * parseFloat(300 - t.updateScoreVal).toFixed(2), 
                        n.num = 300, n.hasNum = 300 - t.updateScoreVal), n;
                    },
                    doneCount: function(e) {
                        return e.count > 0 ? e.count / 2 : e.count;
                    },
                    userName: function(e) {
                        return e.userinfo ? e.userinfo.fullName : "";
                    },
                    userinfoType: function(e) {
                        return e.userinfo ? e.userinfo.tier.tierName : "";
                    },
                    userinfoBg: function(e) {
                        var t = {
                            typeName: "a",
                            bgImgUrl: p + "bg_1@2x.png",
                            rightIcon: p + "crown1@2x.png",
                            textColorClass: "userTypeA",
                            default: !1
                        }, n = e.userinfo ? e.userinfo.tier.tierName : "";
                        return "铂金卡会员" == n ? (t.typeName = "d", t.bgImgUrl = p + "bg_4@2x.png", t.rightIcon = p + "crown4@2x.png", 
                        t.textColorClass = "userTypeD", t.default = !0, t.num = -1) : "哈根达斯会员" == n ? (t.typeName = "a", 
                        t.bgImgUrl = p + "bg_1@2x.png", t.rightIcon = p + "crown1@2x.png", t.textColorClass = "userTypeA", 
                        t.default = !1, t.num = 300) : "银卡会员" == n ? (t.typeName = "b", t.bgImgUrl = p + "bg_2@2x.png", 
                        t.rightIcon = p + "crown2@2x.png", t.textColorClass = "userTypeB", t.default = !1, 
                        t.num = 1e3) : "金卡会员" == n ? (t.typeName = "c", t.bgImgUrl = p + "bg_3@2x.png", 
                        t.rightIcon = p + "crown3@2x.png", t.textColorClass = "userTypeC", t.default = !0, 
                        t.num = 5e3) : (t.typeName = "a", t.bgImgUrl = p + "bg_1@2x.png", t.rightIcon = p + "crown1@2x.png", 
                        t.textColorClass = "userTypeA", t.default = !1, t.num = 300), t;
                    }
                },
                mutations: a.default,
                actions: i.default
            });
            t.default = d;
        }).call(this, n("543d").default);
    },
    6258: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("f0fd"));
        var o = {
            imgThankgiving: r.default.ossurl + "images/thanksGiving",
            img_home_shouye: r.default.ossurl + "images/home/shouye"
        };
        t.default = o;
    },
    "62e4": function(e, t) {
        e.exports = function(e) {
            return e.webpackPolyfill || (e.deprecate = function() {}, e.paths = [], e.children || (e.children = []), 
            Object.defineProperty(e, "loaded", {
                enumerable: !0,
                get: function() {
                    return e.l;
                }
            }), Object.defineProperty(e, "id", {
                enumerable: !0,
                get: function() {
                    return e.i;
                }
            }), e.webpackPolyfill = 1), e;
        };
    },
    "648e": function(e) {
        function t(t, n, r) {
            return e.apply(this, arguments);
        }
        return t.toString = function() {
            return e.toString();
        }, t;
    }(function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Memo = void 0;
        var r = function() {
            function e() {
                this._hasWeakSet = "function" == typeof WeakSet, this._inner = this._hasWeakSet ? new WeakSet() : [];
            }
            return e.prototype.memoize = function(e) {
                if (this._hasWeakSet) return !!this._inner.has(e) || (this._inner.add(e), !1);
                for (var t = 0; t < this._inner.length; t++) {
                    if (this._inner[t] === e) return !0;
                }
                return this._inner.push(e), !1;
            }, e.prototype.unmemoize = function(e) {
                if (this._hasWeakSet) this._inner.delete(e); else for (var t = 0; t < this._inner.length; t++) if (this._inner[t] === e) {
                    this._inner.splice(t, 1);
                    break;
                }
            }, e;
        }();
        t.Memo = r;
    }),
    "66fd": function(e, t, r) {
        r.r(t), function(e) {
            /*!
       * Vue.js v2.6.11
       * (c) 2014-2021 Evan You
       * Released under the MIT License.
       */
            var r = Object.freeze({});
            function o(e) {
                return null == e;
            }
            function i(e) {
                return null != e;
            }
            function a(e) {
                return !0 === e;
            }
            function u(e) {
                return "string" == typeof e || "number" == typeof e || "symbol" === (0, n.default)(e) || "boolean" == typeof e;
            }
            function c(e) {
                return null !== e && "object" === (0, n.default)(e);
            }
            var s = Object.prototype.toString;
            function f(e) {
                return "[object Object]" === s.call(e);
            }
            function l(e) {
                var t = parseFloat(String(e));
                return t >= 0 && Math.floor(t) === t && isFinite(e);
            }
            function p(e) {
                return i(e) && "function" == typeof e.then && "function" == typeof e.catch;
            }
            function d(e) {
                return null == e ? "" : Array.isArray(e) || f(e) && e.toString === s ? JSON.stringify(e, null, 2) : String(e);
            }
            function h(e) {
                var t = parseFloat(e);
                return isNaN(t) ? e : t;
            }
            function v(e, t) {
                for (var n = Object.create(null), r = e.split(","), o = 0; o < r.length; o++) n[r[o]] = !0;
                return t ? function(e) {
                    return n[e.toLowerCase()];
                } : function(e) {
                    return n[e];
                };
            }
            v("slot,component", !0);
            var g = v("key,ref,slot,slot-scope,is");
            function y(e, t) {
                if (e.length) {
                    var n = e.indexOf(t);
                    if (n > -1) return e.splice(n, 1);
                }
            }
            var b = Object.prototype.hasOwnProperty;
            function m(e, t) {
                return b.call(e, t);
            }
            function _(e) {
                var t = Object.create(null);
                return function(n) {
                    return t[n] || (t[n] = e(n));
                };
            }
            var w = /-(\w)/g, x = _(function(e) {
                return e.replace(w, function(e, t) {
                    return t ? t.toUpperCase() : "";
                });
            }), O = _(function(e) {
                return e.charAt(0).toUpperCase() + e.slice(1);
            }), S = /\B([A-Z])/g, E = _(function(e) {
                return e.replace(S, "-$1").toLowerCase();
            });
            var k = Function.prototype.bind ? function(e, t) {
                return e.bind(t);
            } : function(e, t) {
                function n(n) {
                    var r = arguments.length;
                    return r ? r > 1 ? e.apply(t, arguments) : e.call(t, n) : e.call(t);
                }
                return n._length = e.length, n;
            };
            function P(e, t) {
                t = t || 0;
                for (var n = e.length - t, r = new Array(n); n--; ) r[n] = e[n + t];
                return r;
            }
            function j(e, t) {
                for (var n in t) e[n] = t[n];
                return e;
            }
            function A(e) {
                for (var t = {}, n = 0; n < e.length; n++) e[n] && j(t, e[n]);
                return t;
            }
            function C(e, t, n) {}
            var T = function(e, t, n) {
                return !1;
            }, D = function(e) {
                return e;
            };
            function M(e, t) {
                if (e === t) return !0;
                var n = c(e), r = c(t);
                if (!n || !r) return !n && !r && String(e) === String(t);
                try {
                    var o = Array.isArray(e), i = Array.isArray(t);
                    if (o && i) return e.length === t.length && e.every(function(e, n) {
                        return M(e, t[n]);
                    });
                    if (e instanceof Date && t instanceof Date) return e.getTime() === t.getTime();
                    if (o || i) return !1;
                    var a = Object.keys(e), u = Object.keys(t);
                    return a.length === u.length && a.every(function(n) {
                        return M(e[n], t[n]);
                    });
                } catch (e) {
                    return !1;
                }
            }
            function I(e, t) {
                for (var n = 0; n < e.length; n++) if (M(e[n], t)) return n;
                return -1;
            }
            function L(e) {
                var t = !1;
                return function() {
                    t || (t = !0, e.apply(this, arguments));
                };
            }
            var $ = [ "component", "directive", "filter" ], N = [ "beforeCreate", "created", "beforeMount", "mounted", "beforeUpdate", "updated", "beforeDestroy", "destroyed", "activated", "deactivated", "errorCaptured", "serverPrefetch" ], R = {
                optionMergeStrategies: Object.create(null),
                silent: !1,
                productionTip: !1,
                devtools: !1,
                performance: !1,
                errorHandler: null,
                warnHandler: null,
                ignoredElements: [],
                keyCodes: Object.create(null),
                isReservedTag: T,
                isReservedAttr: T,
                isUnknownElement: T,
                getTagNamespace: C,
                parsePlatformTagName: D,
                mustUseProp: T,
                async: !0,
                _lifecycleHooks: N
            };
            function B(e) {
                var t = (e + "").charCodeAt(0);
                return 36 === t || 95 === t;
            }
            function H(e, t, n, r) {
                Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !!r,
                    writable: !0,
                    configurable: !0
                });
            }
            var F = new RegExp("[^" + /a-zA-Z\u00B7\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u037D\u037F-\u1FFF\u200C-\u200D\u203F-\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD/.source + ".$_\\d]");
            var U, G = "__proto__" in {}, V = "undefined" != typeof window, W = "undefined" != typeof WXEnvironment && !!WXEnvironment.platform, z = W && WXEnvironment.platform.toLowerCase(), q = V && window.navigator.userAgent.toLowerCase(), Y = q && /msie|trident/.test(q), K = (q && q.indexOf("msie 9.0"), 
            q && q.indexOf("edge/"), q && q.indexOf("android"), q && /iphone|ipad|ipod|ios/.test(q) || "ios" === z), J = (q && /chrome\/\d+/.test(q), 
            q && /phantomjs/.test(q), q && q.match(/firefox\/(\d+)/), {}.watch);
            if (V) try {
                var Q = {};
                Object.defineProperty(Q, "passive", {
                    get: function() {}
                }), window.addEventListener("test-passive", null, Q);
            } catch (e) {}
            var X = function() {
                return void 0 === U && (U = !V && !W && void 0 !== e && e.process && "server" === e.process.env.VUE_ENV), 
                U;
            }, Z = V && window.__VUE_DEVTOOLS_GLOBAL_HOOK__;
            function ee(e) {
                return "function" == typeof e && /native code/.test(e.toString());
            }
            var te, ne = "undefined" != typeof Symbol && ee(Symbol) && "undefined" != typeof Reflect && ee(Reflect.ownKeys);
            te = "undefined" != typeof Set && ee(Set) ? Set : function() {
                function e() {
                    this.set = Object.create(null);
                }
                return e.prototype.has = function(e) {
                    return !0 === this.set[e];
                }, e.prototype.add = function(e) {
                    this.set[e] = !0;
                }, e.prototype.clear = function() {
                    this.set = Object.create(null);
                }, e;
            }();
            var re = C, oe = 0, ie = function() {
                this.id = oe++, this.subs = [];
            };
            function ae(e) {
                ie.SharedObject.targetStack.push(e), ie.SharedObject.target = e, ie.target = e;
            }
            function ue() {
                ie.SharedObject.targetStack.pop(), ie.SharedObject.target = ie.SharedObject.targetStack[ie.SharedObject.targetStack.length - 1], 
                ie.target = ie.SharedObject.target;
            }
            ie.prototype.addSub = function(e) {
                this.subs.push(e);
            }, ie.prototype.removeSub = function(e) {
                y(this.subs, e);
            }, ie.prototype.depend = function() {
                ie.SharedObject.target && ie.SharedObject.target.addDep(this);
            }, ie.prototype.notify = function() {
                for (var e = this.subs.slice(), t = 0, n = e.length; t < n; t++) e[t].update();
            }, (ie.SharedObject = {}).target = null, ie.SharedObject.targetStack = [];
            var ce = function(e, t, n, r, o, i, a, u) {
                this.tag = e, this.data = t, this.children = n, this.text = r, this.elm = o, this.ns = void 0, 
                this.context = i, this.fnContext = void 0, this.fnOptions = void 0, this.fnScopeId = void 0, 
                this.key = t && t.key, this.componentOptions = a, this.componentInstance = void 0, 
                this.parent = void 0, this.raw = !1, this.isStatic = !1, this.isRootInsert = !0, 
                this.isComment = !1, this.isCloned = !1, this.isOnce = !1, this.asyncFactory = u, 
                this.asyncMeta = void 0, this.isAsyncPlaceholder = !1;
            }, se = {
                child: {
                    configurable: !0
                }
            };
            se.child.get = function() {
                return this.componentInstance;
            }, Object.defineProperties(ce.prototype, se);
            var fe = function(e) {
                void 0 === e && (e = "");
                var t = new ce();
                return t.text = e, t.isComment = !0, t;
            };
            function le(e) {
                return new ce(void 0, void 0, void 0, String(e));
            }
            var pe = Array.prototype, de = Object.create(pe);
            [ "push", "pop", "shift", "unshift", "splice", "sort", "reverse" ].forEach(function(e) {
                var t = pe[e];
                H(de, e, function() {
                    for (var n = [], r = arguments.length; r--; ) n[r] = arguments[r];
                    var o, i = t.apply(this, n), a = this.__ob__;
                    switch (e) {
                      case "push":
                      case "unshift":
                        o = n;
                        break;

                      case "splice":
                        o = n.slice(2);
                    }
                    return o && a.observeArray(o), a.dep.notify(), i;
                });
            });
            var he = Object.getOwnPropertyNames(de), ve = !0;
            function ge(e) {
                ve = e;
            }
            var ye = function(e) {
                this.value = e, this.dep = new ie(), this.vmCount = 0, H(e, "__ob__", this), Array.isArray(e) ? (G ? e.push !== e.__proto__.push ? be(e, de, he) : function(e, t) {
                    e.__proto__ = t;
                }(e, de) : be(e, de, he), this.observeArray(e)) : this.walk(e);
            };
            function be(e, t, n) {
                for (var r = 0, o = n.length; r < o; r++) {
                    var i = n[r];
                    H(e, i, t[i]);
                }
            }
            function me(e, t) {
                var n;
                if (c(e) && !(e instanceof ce)) return m(e, "__ob__") && e.__ob__ instanceof ye ? n = e.__ob__ : ve && !X() && (Array.isArray(e) || f(e)) && Object.isExtensible(e) && !e._isVue && (n = new ye(e)), 
                t && n && n.vmCount++, n;
            }
            function _e(e, t, n, r, o) {
                var i = new ie(), a = Object.getOwnPropertyDescriptor(e, t);
                if (!a || !1 !== a.configurable) {
                    var u = a && a.get, c = a && a.set;
                    u && !c || 2 !== arguments.length || (n = e[t]);
                    var s = !o && me(n);
                    Object.defineProperty(e, t, {
                        enumerable: !0,
                        configurable: !0,
                        get: function() {
                            var t = u ? u.call(e) : n;
                            return ie.SharedObject.target && (i.depend(), s && (s.dep.depend(), Array.isArray(t) && Oe(t))), 
                            t;
                        },
                        set: function(t) {
                            var r = u ? u.call(e) : n;
                            t === r || t != t && r != r || u && !c || (c ? c.call(e, t) : n = t, s = !o && me(t), 
                            i.notify());
                        }
                    });
                }
            }
            function we(e, t, n) {
                if (Array.isArray(e) && l(t)) return e.length = Math.max(e.length, t), e.splice(t, 1, n), 
                n;
                if (t in e && !(t in Object.prototype)) return e[t] = n, n;
                var r = e.__ob__;
                return e._isVue || r && r.vmCount ? n : r ? (_e(r.value, t, n), r.dep.notify(), 
                n) : (e[t] = n, n);
            }
            function xe(e, t) {
                if (Array.isArray(e) && l(t)) e.splice(t, 1); else {
                    var n = e.__ob__;
                    e._isVue || n && n.vmCount || m(e, t) && (delete e[t], n && n.dep.notify());
                }
            }
            function Oe(e) {
                for (var t = void 0, n = 0, r = e.length; n < r; n++) (t = e[n]) && t.__ob__ && t.__ob__.dep.depend(), 
                Array.isArray(t) && Oe(t);
            }
            ye.prototype.walk = function(e) {
                for (var t = Object.keys(e), n = 0; n < t.length; n++) _e(e, t[n]);
            }, ye.prototype.observeArray = function(e) {
                for (var t = 0, n = e.length; t < n; t++) me(e[t]);
            };
            var Se = R.optionMergeStrategies;
            function Ee(e, t) {
                if (!t) return e;
                for (var n, r, o, i = ne ? Reflect.ownKeys(t) : Object.keys(t), a = 0; a < i.length; a++) "__ob__" !== (n = i[a]) && (r = e[n], 
                o = t[n], m(e, n) ? r !== o && f(r) && f(o) && Ee(r, o) : we(e, n, o));
                return e;
            }
            function ke(e, t, n) {
                return n ? function() {
                    var r = "function" == typeof t ? t.call(n, n) : t, o = "function" == typeof e ? e.call(n, n) : e;
                    return r ? Ee(r, o) : o;
                } : t ? e ? function() {
                    return Ee("function" == typeof t ? t.call(this, this) : t, "function" == typeof e ? e.call(this, this) : e);
                } : t : e;
            }
            function Pe(e, t) {
                var n = t ? e ? e.concat(t) : Array.isArray(t) ? t : [ t ] : e;
                return n ? function(e) {
                    for (var t = [], n = 0; n < e.length; n++) -1 === t.indexOf(e[n]) && t.push(e[n]);
                    return t;
                }(n) : n;
            }
            function je(e, t, n, r) {
                var o = Object.create(e || null);
                return t ? j(o, t) : o;
            }
            Se.data = function(e, t, n) {
                return n ? ke(e, t, n) : t && "function" != typeof t ? e : ke(e, t);
            }, N.forEach(function(e) {
                Se[e] = Pe;
            }), $.forEach(function(e) {
                Se[e + "s"] = je;
            }), Se.watch = function(e, t, n, r) {
                if (e === J && (e = void 0), t === J && (t = void 0), !t) return Object.create(e || null);
                if (!e) return t;
                var o = {};
                for (var i in j(o, e), t) {
                    var a = o[i], u = t[i];
                    a && !Array.isArray(a) && (a = [ a ]), o[i] = a ? a.concat(u) : Array.isArray(u) ? u : [ u ];
                }
                return o;
            }, Se.props = Se.methods = Se.inject = Se.computed = function(e, t, n, r) {
                if (!e) return t;
                var o = Object.create(null);
                return j(o, e), t && j(o, t), o;
            }, Se.provide = ke;
            var Ae = function(e, t) {
                return void 0 === t ? e : t;
            };
            function Ce(e, t, n) {
                if ("function" == typeof t && (t = t.options), function(e, t) {
                    var n = e.props;
                    if (n) {
                        var r, o, i = {};
                        if (Array.isArray(n)) for (r = n.length; r--; ) "string" == typeof (o = n[r]) && (i[x(o)] = {
                            type: null
                        }); else if (f(n)) for (var a in n) o = n[a], i[x(a)] = f(o) ? o : {
                            type: o
                        };
                        e.props = i;
                    }
                }(t), function(e, t) {
                    var n = e.inject;
                    if (n) {
                        var r = e.inject = {};
                        if (Array.isArray(n)) for (var o = 0; o < n.length; o++) r[n[o]] = {
                            from: n[o]
                        }; else if (f(n)) for (var i in n) {
                            var a = n[i];
                            r[i] = f(a) ? j({
                                from: i
                            }, a) : {
                                from: a
                            };
                        }
                    }
                }(t), function(e) {
                    var t = e.directives;
                    if (t) for (var n in t) {
                        var r = t[n];
                        "function" == typeof r && (t[n] = {
                            bind: r,
                            update: r
                        });
                    }
                }(t), !t._base && (t.extends && (e = Ce(e, t.extends, n)), t.mixins)) for (var r = 0, o = t.mixins.length; r < o; r++) e = Ce(e, t.mixins[r], n);
                var i, a = {};
                for (i in e) u(i);
                for (i in t) m(e, i) || u(i);
                function u(r) {
                    var o = Se[r] || Ae;
                    a[r] = o(e[r], t[r], n, r);
                }
                return a;
            }
            function Te(e, t, n, r) {
                if ("string" == typeof n) {
                    var o = e[t];
                    if (m(o, n)) return o[n];
                    var i = x(n);
                    if (m(o, i)) return o[i];
                    var a = O(i);
                    return m(o, a) ? o[a] : o[n] || o[i] || o[a];
                }
            }
            function De(e, t, n, r) {
                var o = t[e], i = !m(n, e), a = n[e], u = Le(Boolean, o.type);
                if (u > -1) if (i && !m(o, "default")) a = !1; else if ("" === a || a === E(e)) {
                    var c = Le(String, o.type);
                    (c < 0 || u < c) && (a = !0);
                }
                if (void 0 === a) {
                    a = function(e, t, n) {
                        if (m(t, "default")) {
                            var r = t.default;
                            return e && e.$options.propsData && void 0 === e.$options.propsData[n] && void 0 !== e._props[n] ? e._props[n] : "function" == typeof r && "Function" !== Me(t.type) ? r.call(e) : r;
                        }
                    }(r, o, e);
                    var s = ve;
                    ge(!0), me(a), ge(s);
                }
                return a;
            }
            function Me(e) {
                var t = e && e.toString().match(/^\s*function (\w+)/);
                return t ? t[1] : "";
            }
            function Ie(e, t) {
                return Me(e) === Me(t);
            }
            function Le(e, t) {
                if (!Array.isArray(t)) return Ie(t, e) ? 0 : -1;
                for (var n = 0, r = t.length; n < r; n++) if (Ie(t[n], e)) return n;
                return -1;
            }
            function $e(e, t, n) {
                ae();
                try {
                    if (t) for (var r = t; r = r.$parent; ) {
                        var o = r.$options.errorCaptured;
                        if (o) for (var i = 0; i < o.length; i++) try {
                            if (!1 === o[i].call(r, e, t, n)) return;
                        } catch (e) {
                            Re(e, r, "errorCaptured hook");
                        }
                    }
                    Re(e, t, n);
                } finally {
                    ue();
                }
            }
            function Ne(e, t, n, r, o) {
                var i;
                try {
                    (i = n ? e.apply(t, n) : e.call(t)) && !i._isVue && p(i) && !i._handled && (i.catch(function(e) {
                        return $e(e, r, o + " (Promise/async)");
                    }), i._handled = !0);
                } catch (e) {
                    $e(e, r, o);
                }
                return i;
            }
            function Re(e, t, n) {
                if (R.errorHandler) try {
                    return R.errorHandler.call(null, e, t, n);
                } catch (t) {
                    t !== e && Be(t, null, "config.errorHandler");
                }
                Be(e, t, n);
            }
            function Be(e, t, n) {
                if (!V && !W || "undefined" == typeof console) throw e;
                console.error(e);
            }
            var He, Fe = [], Ue = !1;
            function Ge() {
                Ue = !1;
                var e = Fe.slice(0);
                Fe.length = 0;
                for (var t = 0; t < e.length; t++) e[t]();
            }
            if ("undefined" != typeof Promise && ee(Promise)) {
                var Ve = Promise.resolve();
                He = function() {
                    Ve.then(Ge), K && setTimeout(C);
                };
            } else if (Y || "undefined" == typeof MutationObserver || !ee(MutationObserver) && "[object MutationObserverConstructor]" !== MutationObserver.toString()) He = "undefined" != typeof setImmediate && ee(setImmediate) ? function() {
                setImmediate(Ge);
            } : function() {
                setTimeout(Ge, 0);
            }; else {
                var We = 1, ze = new MutationObserver(Ge), qe = document.createTextNode(String(We));
                ze.observe(qe, {
                    characterData: !0
                }), He = function() {
                    We = (We + 1) % 2, qe.data = String(We);
                };
            }
            function Ye(e, t) {
                var n;
                if (Fe.push(function() {
                    if (e) try {
                        e.call(t);
                    } catch (e) {
                        $e(e, t, "nextTick");
                    } else n && n(t);
                }), Ue || (Ue = !0, He()), !e && "undefined" != typeof Promise) return new Promise(function(e) {
                    n = e;
                });
            }
            var Ke = new te();
            function Je(e) {
                (function e(t, n) {
                    var r, o, i = Array.isArray(t);
                    if (!(!i && !c(t) || Object.isFrozen(t) || t instanceof ce)) {
                        if (t.__ob__) {
                            var a = t.__ob__.dep.id;
                            if (n.has(a)) return;
                            n.add(a);
                        }
                        if (i) for (r = t.length; r--; ) e(t[r], n); else for (o = Object.keys(t), r = o.length; r--; ) e(t[o[r]], n);
                    }
                })(e, Ke), Ke.clear();
            }
            var Qe = _(function(e) {
                var t = "&" === e.charAt(0), n = "~" === (e = t ? e.slice(1) : e).charAt(0), r = "!" === (e = n ? e.slice(1) : e).charAt(0);
                return {
                    name: e = r ? e.slice(1) : e,
                    once: n,
                    capture: r,
                    passive: t
                };
            });
            function Xe(e, t) {
                function n() {
                    var e = arguments, r = n.fns;
                    if (!Array.isArray(r)) return Ne(r, null, arguments, t, "v-on handler");
                    for (var o = r.slice(), i = 0; i < o.length; i++) Ne(o[i], null, e, t, "v-on handler");
                }
                return n.fns = e, n;
            }
            function Ze(e, t, n, r) {
                var a = t.options.mpOptions && t.options.mpOptions.properties;
                if (o(a)) return n;
                var u = t.options.mpOptions.externalClasses || [], c = e.attrs, s = e.props;
                if (i(c) || i(s)) for (var f in a) {
                    var l = E(f);
                    (et(n, s, f, l, !0) || et(n, c, f, l, !1)) && n[f] && -1 !== u.indexOf(l) && r[x(n[f])] && (n[f] = r[x(n[f])]);
                }
                return n;
            }
            function et(e, t, n, r, o) {
                if (i(t)) {
                    if (m(t, n)) return e[n] = t[n], o || delete t[n], !0;
                    if (m(t, r)) return e[n] = t[r], o || delete t[r], !0;
                }
                return !1;
            }
            function tt(e) {
                return u(e) ? [ le(e) ] : Array.isArray(e) ? function e(t, n) {
                    var r, c, s, f, l = [];
                    for (r = 0; r < t.length; r++) o(c = t[r]) || "boolean" == typeof c || (s = l.length - 1, 
                    f = l[s], Array.isArray(c) ? c.length > 0 && (nt((c = e(c, (n || "") + "_" + r))[0]) && nt(f) && (l[s] = le(f.text + c[0].text), 
                    c.shift()), l.push.apply(l, c)) : u(c) ? nt(f) ? l[s] = le(f.text + c) : "" !== c && l.push(le(c)) : nt(c) && nt(f) ? l[s] = le(f.text + c.text) : (a(t._isVList) && i(c.tag) && o(c.key) && i(n) && (c.key = "__vlist" + n + "_" + r + "__"), 
                    l.push(c)));
                    return l;
                }(e) : void 0;
            }
            function nt(e) {
                return i(e) && i(e.text) && function(e) {
                    return !1 === e;
                }(e.isComment);
            }
            function rt(e) {
                var t = e.$options.provide;
                t && (e._provided = "function" == typeof t ? t.call(e) : t);
            }
            function ot(e) {
                var t = it(e.$options.inject, e);
                t && (ge(!1), Object.keys(t).forEach(function(n) {
                    _e(e, n, t[n]);
                }), ge(!0));
            }
            function it(e, t) {
                if (e) {
                    for (var n = Object.create(null), r = ne ? Reflect.ownKeys(e) : Object.keys(e), o = 0; o < r.length; o++) {
                        var i = r[o];
                        if ("__ob__" !== i) {
                            for (var a = e[i].from, u = t; u; ) {
                                if (u._provided && m(u._provided, a)) {
                                    n[i] = u._provided[a];
                                    break;
                                }
                                u = u.$parent;
                            }
                            if (!u && "default" in e[i]) {
                                var c = e[i].default;
                                n[i] = "function" == typeof c ? c.call(t) : c;
                            }
                        }
                    }
                    return n;
                }
            }
            function at(e, t) {
                if (!e || !e.length) return {};
                for (var n = {}, r = 0, o = e.length; r < o; r++) {
                    var i = e[r], a = i.data;
                    if (a && a.attrs && a.attrs.slot && delete a.attrs.slot, i.context !== t && i.fnContext !== t || !a || null == a.slot) i.asyncMeta && i.asyncMeta.data && "page" === i.asyncMeta.data.slot ? (n.page || (n.page = [])).push(i) : (n.default || (n.default = [])).push(i); else {
                        var u = a.slot, c = n[u] || (n[u] = []);
                        "template" === i.tag ? c.push.apply(c, i.children || []) : c.push(i);
                    }
                }
                for (var s in n) n[s].every(ut) && delete n[s];
                return n;
            }
            function ut(e) {
                return e.isComment && !e.asyncFactory || " " === e.text;
            }
            function ct(e, t, n) {
                var o, i = Object.keys(t).length > 0, a = e ? !!e.$stable : !i, u = e && e.$key;
                if (e) {
                    if (e._normalized) return e._normalized;
                    if (a && n && n !== r && u === n.$key && !i && !n.$hasNormal) return n;
                    for (var c in o = {}, e) e[c] && "$" !== c[0] && (o[c] = st(t, c, e[c]));
                } else o = {};
                for (var s in t) s in o || (o[s] = ft(t, s));
                return e && Object.isExtensible(e) && (e._normalized = o), H(o, "$stable", a), H(o, "$key", u), 
                H(o, "$hasNormal", i), o;
            }
            function st(e, t, r) {
                var o = function() {
                    var e = arguments.length ? r.apply(null, arguments) : r({});
                    return (e = e && "object" === (0, n.default)(e) && !Array.isArray(e) ? [ e ] : tt(e)) && (0 === e.length || 1 === e.length && e[0].isComment) ? void 0 : e;
                };
                return r.proxy && Object.defineProperty(e, t, {
                    get: o,
                    enumerable: !0,
                    configurable: !0
                }), o;
            }
            function ft(e, t) {
                return function() {
                    return e[t];
                };
            }
            function lt(e, t) {
                var n, r, o, a, u;
                if (Array.isArray(e) || "string" == typeof e) for (n = new Array(e.length), r = 0, 
                o = e.length; r < o; r++) n[r] = t(e[r], r, r, r); else if ("number" == typeof e) for (n = new Array(e), 
                r = 0; r < e; r++) n[r] = t(r + 1, r, r, r); else if (c(e)) if (ne && e[Symbol.iterator]) {
                    n = [];
                    for (var s = e[Symbol.iterator](), f = s.next(); !f.done; ) n.push(t(f.value, n.length, r, r++)), 
                    f = s.next();
                } else for (a = Object.keys(e), n = new Array(a.length), r = 0, o = a.length; r < o; r++) u = a[r], 
                n[r] = t(e[u], u, r, r);
                return i(n) || (n = []), n._isVList = !0, n;
            }
            function pt(e, t, n, r) {
                var o, i = this.$scopedSlots[e];
                i ? (n = n || {}, r && (n = j(j({}, r), n)), o = i(n, this, n._i) || t) : o = this.$slots[e] || t;
                var a = n && n.slot;
                return a ? this.$createElement("template", {
                    slot: a
                }, o) : o;
            }
            function dt(e) {
                return Te(this.$options, "filters", e) || D;
            }
            function ht(e, t) {
                return Array.isArray(e) ? -1 === e.indexOf(t) : e !== t;
            }
            function vt(e, t, n, r, o) {
                var i = R.keyCodes[t] || n;
                return o && r && !R.keyCodes[t] ? ht(o, r) : i ? ht(i, e) : r ? E(r) !== t : void 0;
            }
            function gt(e, t, n, r, o) {
                if (n && c(n)) {
                    var i;
                    Array.isArray(n) && (n = A(n));
                    var a = function(a) {
                        if ("class" === a || "style" === a || g(a)) i = e; else {
                            var u = e.attrs && e.attrs.type;
                            i = r || R.mustUseProp(t, u, a) ? e.domProps || (e.domProps = {}) : e.attrs || (e.attrs = {});
                        }
                        var c = x(a), s = E(a);
                        c in i || s in i || (i[a] = n[a], !o) || ((e.on || (e.on = {}))["update:" + a] = function(e) {
                            n[a] = e;
                        });
                    };
                    for (var u in n) a(u);
                }
                return e;
            }
            function yt(e, t) {
                var n = this._staticTrees || (this._staticTrees = []), r = n[e];
                return r && !t || mt(r = n[e] = this.$options.staticRenderFns[e].call(this._renderProxy, null, this), "__static__" + e, !1), 
                r;
            }
            function bt(e, t, n) {
                return mt(e, "__once__" + t + (n ? "_" + n : ""), !0), e;
            }
            function mt(e, t, n) {
                if (Array.isArray(e)) for (var r = 0; r < e.length; r++) e[r] && "string" != typeof e[r] && _t(e[r], t + "_" + r, n); else _t(e, t, n);
            }
            function _t(e, t, n) {
                e.isStatic = !0, e.key = t, e.isOnce = n;
            }
            function wt(e, t) {
                if (t && f(t)) {
                    var n = e.on = e.on ? j({}, e.on) : {};
                    for (var r in t) {
                        var o = n[r], i = t[r];
                        n[r] = o ? [].concat(o, i) : i;
                    }
                }
                return e;
            }
            function xt(e, t, n, r) {
                t = t || {
                    $stable: !n
                };
                for (var o = 0; o < e.length; o++) {
                    var i = e[o];
                    Array.isArray(i) ? xt(i, t, n) : i && (i.proxy && (i.fn.proxy = !0), t[i.key] = i.fn);
                }
                return r && (t.$key = r), t;
            }
            function Ot(e, t) {
                for (var n = 0; n < t.length; n += 2) {
                    var r = t[n];
                    "string" == typeof r && r && (e[t[n]] = t[n + 1]);
                }
                return e;
            }
            function St(e, t) {
                return "string" == typeof e ? t + e : e;
            }
            function Et(e) {
                e._o = bt, e._n = h, e._s = d, e._l = lt, e._t = pt, e._q = M, e._i = I, e._m = yt, 
                e._f = dt, e._k = vt, e._b = gt, e._v = le, e._e = fe, e._u = xt, e._g = wt, e._d = Ot, 
                e._p = St;
            }
            function kt(e, t, n, o, i) {
                var u, c = this, s = i.options;
                m(o, "_uid") ? (u = Object.create(o))._original = o : (u = o, o = o._original);
                var f = a(s._compiled), l = !f;
                this.data = e, this.props = t, this.children = n, this.parent = o, this.listeners = e.on || r, 
                this.injections = it(s.inject, o), this.slots = function() {
                    return c.$slots || ct(e.scopedSlots, c.$slots = at(n, o)), c.$slots;
                }, Object.defineProperty(this, "scopedSlots", {
                    enumerable: !0,
                    get: function() {
                        return ct(e.scopedSlots, this.slots());
                    }
                }), f && (this.$options = s, this.$slots = this.slots(), this.$scopedSlots = ct(e.scopedSlots, this.$slots)), 
                s._scopeId ? this._c = function(e, t, n, r) {
                    var i = It(u, e, t, n, r, l);
                    return i && !Array.isArray(i) && (i.fnScopeId = s._scopeId, i.fnContext = o), i;
                } : this._c = function(e, t, n, r) {
                    return It(u, e, t, n, r, l);
                };
            }
            function Pt(e, t, n, o, a) {
                var u = e.options, c = {}, s = u.props;
                if (i(s)) for (var f in s) c[f] = De(f, s, t || r); else i(n.attrs) && At(c, n.attrs), 
                i(n.props) && At(c, n.props);
                var l = new kt(n, c, a, o, e), p = u.render.call(null, l._c, l);
                if (p instanceof ce) return jt(p, n, l.parent, u, l);
                if (Array.isArray(p)) {
                    for (var d = tt(p) || [], h = new Array(d.length), v = 0; v < d.length; v++) h[v] = jt(d[v], n, l.parent, u, l);
                    return h;
                }
            }
            function jt(e, t, n, r, o) {
                var i = function(e) {
                    var t = new ce(e.tag, e.data, e.children && e.children.slice(), e.text, e.elm, e.context, e.componentOptions, e.asyncFactory);
                    return t.ns = e.ns, t.isStatic = e.isStatic, t.key = e.key, t.isComment = e.isComment, 
                    t.fnContext = e.fnContext, t.fnOptions = e.fnOptions, t.fnScopeId = e.fnScopeId, 
                    t.asyncMeta = e.asyncMeta, t.isCloned = !0, t;
                }(e);
                return i.fnContext = n, i.fnOptions = r, t.slot && ((i.data || (i.data = {})).slot = t.slot), 
                i;
            }
            function At(e, t) {
                for (var n in t) e[x(n)] = t[n];
            }
            Et(kt.prototype);
            var Ct = {
                init: function(e, t) {
                    if (e.componentInstance && !e.componentInstance._isDestroyed && e.data.keepAlive) {
                        var n = e;
                        Ct.prepatch(n, n);
                    } else {
                        (e.componentInstance = function(e, t) {
                            var n = {
                                _isComponent: !0,
                                _parentVnode: e,
                                parent: t
                            }, r = e.data.inlineTemplate;
                            return i(r) && (n.render = r.render, n.staticRenderFns = r.staticRenderFns), new e.componentOptions.Ctor(n);
                        }(e, qt)).$mount(t ? e.elm : void 0, t);
                    }
                },
                prepatch: function(e, t) {
                    var n = t.componentOptions;
                    Yt(t.componentInstance = e.componentInstance, n.propsData, n.listeners, t, n.children);
                },
                insert: function(e) {
                    var t = e.context, n = e.componentInstance;
                    n._isMounted || (Qt(n, "onServiceCreated"), Qt(n, "onServiceAttached"), n._isMounted = !0, 
                    Qt(n, "mounted")), e.data.keepAlive && (t._isMounted ? function(e) {
                        e._inactive = !1, Zt.push(e);
                    }(n) : Jt(n, !0));
                },
                destroy: function(e) {
                    var t = e.componentInstance;
                    t._isDestroyed || (e.data.keepAlive ? function e(t, n) {
                        if (!(n && (t._directInactive = !0, Kt(t)) || t._inactive)) {
                            t._inactive = !0;
                            for (var r = 0; r < t.$children.length; r++) e(t.$children[r]);
                            Qt(t, "deactivated");
                        }
                    }(t, !0) : t.$destroy());
                }
            }, Tt = Object.keys(Ct);
            function Dt(e, t, n, r, u) {
                if (!o(e)) {
                    var s = n.$options._base;
                    if (c(e) && (e = s.extend(e)), "function" == typeof e) {
                        var f;
                        if (o(e.cid) && void 0 === (e = Ht(f = e, s))) return function(e, t, n, r, o) {
                            var i = fe();
                            return i.asyncFactory = e, i.asyncMeta = {
                                data: t,
                                context: n,
                                children: r,
                                tag: o
                            }, i;
                        }(f, t, n, r, u);
                        t = t || {}, mn(e), i(t.model) && function(e, t) {
                            var n = e.model && e.model.prop || "value", r = e.model && e.model.event || "input";
                            (t.attrs || (t.attrs = {}))[n] = t.model.value;
                            var o = t.on || (t.on = {}), a = o[r], u = t.model.callback;
                            i(a) ? (Array.isArray(a) ? -1 === a.indexOf(u) : a !== u) && (o[r] = [ u ].concat(a)) : o[r] = u;
                        }(e.options, t);
                        var l = function(e, t, n, r) {
                            var a = t.options.props;
                            if (o(a)) return Ze(e, t, {}, r);
                            var u = {}, c = e.attrs, s = e.props;
                            if (i(c) || i(s)) for (var f in a) {
                                var l = E(f);
                                et(u, s, f, l, !0) || et(u, c, f, l, !1);
                            }
                            return Ze(e, t, u, r);
                        }(t, e, 0, n);
                        if (a(e.options.functional)) return Pt(e, l, t, n, r);
                        var p = t.on;
                        if (t.on = t.nativeOn, a(e.options.abstract)) {
                            var d = t.slot;
                            t = {}, d && (t.slot = d);
                        }
                        !function(e) {
                            for (var t = e.hook || (e.hook = {}), n = 0; n < Tt.length; n++) {
                                var r = Tt[n], o = t[r], i = Ct[r];
                                o === i || o && o._merged || (t[r] = o ? Mt(i, o) : i);
                            }
                        }(t);
                        var h = e.options.name || u;
                        return new ce("vue-component-" + e.cid + (h ? "-" + h : ""), t, void 0, void 0, void 0, n, {
                            Ctor: e,
                            propsData: l,
                            listeners: p,
                            tag: u,
                            children: r
                        }, f);
                    }
                }
            }
            function Mt(e, t) {
                var n = function(n, r) {
                    e(n, r), t(n, r);
                };
                return n._merged = !0, n;
            }
            function It(e, t, n, r, o, i) {
                return (Array.isArray(n) || u(n)) && (o = r, r = n, n = void 0), a(i) && (o = 2), 
                Lt(e, t, n, r, o);
            }
            function Lt(e, t, n, r, o) {
                return i(n) && i(n.__ob__) ? fe() : (i(n) && i(n.is) && (t = n.is), t ? (Array.isArray(r) && "function" == typeof r[0] && ((n = n || {}).scopedSlots = {
                    default: r[0]
                }, r.length = 0), 2 === o ? r = tt(r) : 1 === o && (r = function(e) {
                    for (var t = 0; t < e.length; t++) if (Array.isArray(e[t])) return Array.prototype.concat.apply([], e);
                    return e;
                }(r)), "string" == typeof t ? (u = e.$vnode && e.$vnode.ns || R.getTagNamespace(t), 
                a = R.isReservedTag(t) ? new ce(R.parsePlatformTagName(t), n, r, void 0, void 0, e) : n && n.pre || !i(s = Te(e.$options, "components", t)) ? new ce(t, n, r, void 0, void 0, e) : Dt(s, n, e, r, t)) : a = Dt(t, n, e, r), 
                Array.isArray(a) ? a : i(a) ? (i(u) && $t(a, u), i(n) && function(e) {
                    c(e.style) && Je(e.style), c(e.class) && Je(e.class);
                }(n), a) : fe()) : fe());
                var a, u, s;
            }
            function $t(e, t, n) {
                if (e.ns = t, "foreignObject" === e.tag && (t = void 0, n = !0), i(e.children)) for (var r = 0, u = e.children.length; r < u; r++) {
                    var c = e.children[r];
                    i(c.tag) && (o(c.ns) || a(n) && "svg" !== c.tag) && $t(c, t, n);
                }
            }
            var Nt, Rt = null;
            function Bt(e, t) {
                return (e.__esModule || ne && "Module" === e[Symbol.toStringTag]) && (e = e.default), 
                c(e) ? t.extend(e) : e;
            }
            function Ht(e, t) {
                if (a(e.error) && i(e.errorComp)) return e.errorComp;
                if (i(e.resolved)) return e.resolved;
                var n = Rt;
                if (n && i(e.owners) && -1 === e.owners.indexOf(n) && e.owners.push(n), a(e.loading) && i(e.loadingComp)) return e.loadingComp;
                if (n && !i(e.owners)) {
                    var r = e.owners = [ n ], u = !0, s = null, f = null;
                    n.$on("hook:destroyed", function() {
                        return y(r, n);
                    });
                    var l = function(e) {
                        for (var t = 0, n = r.length; t < n; t++) r[t].$forceUpdate();
                        e && (r.length = 0, null !== s && (clearTimeout(s), s = null), null !== f && (clearTimeout(f), 
                        f = null));
                    }, d = L(function(n) {
                        e.resolved = Bt(n, t), u ? r.length = 0 : l(!0);
                    }), h = L(function(t) {
                        i(e.errorComp) && (e.error = !0, l(!0));
                    }), v = e(d, h);
                    return c(v) && (p(v) ? o(e.resolved) && v.then(d, h) : p(v.component) && (v.component.then(d, h), 
                    i(v.error) && (e.errorComp = Bt(v.error, t)), i(v.loading) && (e.loadingComp = Bt(v.loading, t), 
                    0 === v.delay ? e.loading = !0 : s = setTimeout(function() {
                        s = null, o(e.resolved) && o(e.error) && (e.loading = !0, l(!1));
                    }, v.delay || 200)), i(v.timeout) && (f = setTimeout(function() {
                        f = null, o(e.resolved) && h(null);
                    }, v.timeout)))), u = !1, e.loading ? e.loadingComp : e.resolved;
                }
            }
            function Ft(e) {
                return e.isComment && e.asyncFactory;
            }
            function Ut(e) {
                if (Array.isArray(e)) for (var t = 0; t < e.length; t++) {
                    var n = e[t];
                    if (i(n) && (i(n.componentOptions) || Ft(n))) return n;
                }
            }
            function Gt(e, t) {
                Nt.$on(e, t);
            }
            function Vt(e, t) {
                Nt.$off(e, t);
            }
            function Wt(e, t) {
                var n = Nt;
                return function r() {
                    var o = t.apply(null, arguments);
                    null !== o && n.$off(e, r);
                };
            }
            function zt(e, t, n) {
                Nt = e, function(e, t, n, r, i, u) {
                    var c, s, f, l;
                    for (c in e) s = e[c], f = t[c], l = Qe(c), o(s) || (o(f) ? (o(s.fns) && (s = e[c] = Xe(s, u)), 
                    a(l.once) && (s = e[c] = i(l.name, s, l.capture)), n(l.name, s, l.capture, l.passive, l.params)) : s !== f && (f.fns = s, 
                    e[c] = f));
                    for (c in t) o(e[c]) && r((l = Qe(c)).name, t[c], l.capture);
                }(t, n || {}, Gt, Vt, Wt, e), Nt = void 0;
            }
            var qt = null;
            function Yt(e, t, n, o, i) {
                var a = o.data.scopedSlots, u = e.$scopedSlots, c = !!(a && !a.$stable || u !== r && !u.$stable || a && e.$scopedSlots.$key !== a.$key), s = !!(i || e.$options._renderChildren || c);
                if (e.$options._parentVnode = o, e.$vnode = o, e._vnode && (e._vnode.parent = o), 
                e.$options._renderChildren = i, e.$attrs = o.data.attrs || r, e.$listeners = n || r, 
                t && e.$options.props) {
                    ge(!1);
                    for (var f = e._props, l = e.$options._propKeys || [], p = 0; p < l.length; p++) {
                        var d = l[p], h = e.$options.props;
                        f[d] = De(d, h, t, e);
                    }
                    ge(!0), e.$options.propsData = t;
                }
                e._$updateProperties && e._$updateProperties(e), n = n || r;
                var v = e.$options._parentListeners;
                e.$options._parentListeners = n, zt(e, n, v), s && (e.$slots = at(i, o.context), 
                e.$forceUpdate());
            }
            function Kt(e) {
                for (;e && (e = e.$parent); ) if (e._inactive) return !0;
                return !1;
            }
            function Jt(e, t) {
                if (t) {
                    if (e._directInactive = !1, Kt(e)) return;
                } else if (e._directInactive) return;
                if (e._inactive || null === e._inactive) {
                    e._inactive = !1;
                    for (var n = 0; n < e.$children.length; n++) Jt(e.$children[n]);
                    Qt(e, "activated");
                }
            }
            function Qt(e, t) {
                ae();
                var n = e.$options[t], r = t + " hook";
                if (n) for (var o = 0, i = n.length; o < i; o++) Ne(n[o], e, null, e, r);
                e._hasHookEvent && e.$emit("hook:" + t), ue();
            }
            var Xt = [], Zt = [], en = {}, tn = !1, nn = !1, rn = 0;
            var on = Date.now;
            if (V && !Y) {
                var an = window.performance;
                an && "function" == typeof an.now && on() > document.createEvent("Event").timeStamp && (on = function() {
                    return an.now();
                });
            }
            function un() {
                var e, t;
                for (on(), nn = !0, Xt.sort(function(e, t) {
                    return e.id - t.id;
                }), rn = 0; rn < Xt.length; rn++) (e = Xt[rn]).before && e.before(), t = e.id, en[t] = null, 
                e.run();
                var n = Zt.slice(), r = Xt.slice();
                rn = Xt.length = Zt.length = 0, en = {}, tn = nn = !1, function(e) {
                    for (var t = 0; t < e.length; t++) e[t]._inactive = !0, Jt(e[t], !0);
                }(n), function(e) {
                    var t = e.length;
                    for (;t--; ) {
                        var n = e[t], r = n.vm;
                        r._watcher === n && r._isMounted && !r._isDestroyed && Qt(r, "updated");
                    }
                }(r), Z && R.devtools && Z.emit("flush");
            }
            var cn = 0, sn = function(e, t, n, r, o) {
                this.vm = e, o && (e._watcher = this), e._watchers.push(this), r ? (this.deep = !!r.deep, 
                this.user = !!r.user, this.lazy = !!r.lazy, this.sync = !!r.sync, this.before = r.before) : this.deep = this.user = this.lazy = this.sync = !1, 
                this.cb = n, this.id = ++cn, this.active = !0, this.dirty = this.lazy, this.deps = [], 
                this.newDeps = [], this.depIds = new te(), this.newDepIds = new te(), this.expression = "", 
                "function" == typeof t ? this.getter = t : (this.getter = function(e) {
                    if (!F.test(e)) {
                        var t = e.split(".");
                        return function(e) {
                            for (var n = 0; n < t.length; n++) {
                                if (!e) return;
                                e = e[t[n]];
                            }
                            return e;
                        };
                    }
                }(t), this.getter || (this.getter = C)), this.value = this.lazy ? void 0 : this.get();
            };
            sn.prototype.get = function() {
                var e;
                ae(this);
                var t = this.vm;
                try {
                    e = this.getter.call(t, t);
                } catch (e) {
                    if (!this.user) throw e;
                    $e(e, t, 'getter for watcher "' + this.expression + '"');
                } finally {
                    this.deep && Je(e), ue(), this.cleanupDeps();
                }
                return e;
            }, sn.prototype.addDep = function(e) {
                var t = e.id;
                this.newDepIds.has(t) || (this.newDepIds.add(t), this.newDeps.push(e), this.depIds.has(t) || e.addSub(this));
            }, sn.prototype.cleanupDeps = function() {
                for (var e = this.deps.length; e--; ) {
                    var t = this.deps[e];
                    this.newDepIds.has(t.id) || t.removeSub(this);
                }
                var n = this.depIds;
                this.depIds = this.newDepIds, this.newDepIds = n, this.newDepIds.clear(), n = this.deps, 
                this.deps = this.newDeps, this.newDeps = n, this.newDeps.length = 0;
            }, sn.prototype.update = function() {
                this.lazy ? this.dirty = !0 : this.sync ? this.run() : function(e) {
                    var t = e.id;
                    if (null == en[t]) {
                        if (en[t] = !0, nn) {
                            for (var n = Xt.length - 1; n > rn && Xt[n].id > e.id; ) n--;
                            Xt.splice(n + 1, 0, e);
                        } else Xt.push(e);
                        tn || (tn = !0, Ye(un));
                    }
                }(this);
            }, sn.prototype.run = function() {
                if (this.active) {
                    var e = this.get();
                    if (e !== this.value || c(e) || this.deep) {
                        var t = this.value;
                        if (this.value = e, this.user) try {
                            this.cb.call(this.vm, e, t);
                        } catch (e) {
                            $e(e, this.vm, 'callback for watcher "' + this.expression + '"');
                        } else this.cb.call(this.vm, e, t);
                    }
                }
            }, sn.prototype.evaluate = function() {
                this.value = this.get(), this.dirty = !1;
            }, sn.prototype.depend = function() {
                for (var e = this.deps.length; e--; ) this.deps[e].depend();
            }, sn.prototype.teardown = function() {
                if (this.active) {
                    this.vm._isBeingDestroyed || y(this.vm._watchers, this);
                    for (var e = this.deps.length; e--; ) this.deps[e].removeSub(this);
                    this.active = !1;
                }
            };
            var fn = {
                enumerable: !0,
                configurable: !0,
                get: C,
                set: C
            };
            function ln(e, t, n) {
                fn.get = function() {
                    return this[t][n];
                }, fn.set = function(e) {
                    this[t][n] = e;
                }, Object.defineProperty(e, n, fn);
            }
            function pn(e) {
                e._watchers = [];
                var t = e.$options;
                t.props && function(e, t) {
                    var n = e.$options.propsData || {}, r = e._props = {}, o = e.$options._propKeys = [];
                    !e.$parent || ge(!1);
                    var i = function(i) {
                        o.push(i);
                        var a = De(i, t, n, e);
                        _e(r, i, a), i in e || ln(e, "_props", i);
                    };
                    for (var a in t) i(a);
                    ge(!0);
                }(e, t.props), t.methods && function(e, t) {
                    for (var n in e.$options.props, t) e[n] = "function" != typeof t[n] ? C : k(t[n], e);
                }(e, t.methods), t.data ? function(e) {
                    var t = e.$options.data;
                    f(t = e._data = "function" == typeof t ? function(e, t) {
                        ae();
                        try {
                            return e.call(t, t);
                        } catch (e) {
                            return $e(e, t, "data()"), {};
                        } finally {
                            ue();
                        }
                    }(t, e) : t || {}) || (t = {});
                    var n = Object.keys(t), r = e.$options.props, o = (e.$options.methods, n.length);
                    for (;o--; ) {
                        var i = n[o];
                        r && m(r, i) || B(i) || ln(e, "_data", i);
                    }
                    me(t, !0);
                }(e) : me(e._data = {}, !0), t.computed && function(e, t) {
                    var n = e._computedWatchers = Object.create(null), r = X();
                    for (var o in t) {
                        var i = t[o], a = "function" == typeof i ? i : i.get;
                        r || (n[o] = new sn(e, a || C, C, dn)), o in e || hn(e, o, i);
                    }
                }(e, t.computed), t.watch && t.watch !== J && function(e, t) {
                    for (var n in t) {
                        var r = t[n];
                        if (Array.isArray(r)) for (var o = 0; o < r.length; o++) yn(e, n, r[o]); else yn(e, n, r);
                    }
                }(e, t.watch);
            }
            var dn = {
                lazy: !0
            };
            function hn(e, t, n) {
                var r = !X();
                "function" == typeof n ? (fn.get = r ? vn(t) : gn(n), fn.set = C) : (fn.get = n.get ? r && !1 !== n.cache ? vn(t) : gn(n.get) : C, 
                fn.set = n.set || C), Object.defineProperty(e, t, fn);
            }
            function vn(e) {
                return function() {
                    var t = this._computedWatchers && this._computedWatchers[e];
                    if (t) return t.dirty && t.evaluate(), ie.SharedObject.target && t.depend(), t.value;
                };
            }
            function gn(e) {
                return function() {
                    return e.call(this, this);
                };
            }
            function yn(e, t, n, r) {
                return f(n) && (r = n, n = n.handler), "string" == typeof n && (n = e[n]), e.$watch(t, n, r);
            }
            var bn = 0;
            function mn(e) {
                var t = e.options;
                if (e.super) {
                    var n = mn(e.super);
                    if (n !== e.superOptions) {
                        e.superOptions = n;
                        var r = function(e) {
                            var t, n = e.options, r = e.sealedOptions;
                            for (var o in n) n[o] !== r[o] && (t || (t = {}), t[o] = n[o]);
                            return t;
                        }(e);
                        r && j(e.extendOptions, r), (t = e.options = Ce(n, e.extendOptions)).name && (t.components[t.name] = e);
                    }
                }
                return t;
            }
            function _n(e) {
                this._init(e);
            }
            function wn(e) {
                e.cid = 0;
                var t = 1;
                e.extend = function(e) {
                    e = e || {};
                    var n = this, r = n.cid, o = e._Ctor || (e._Ctor = {});
                    if (o[r]) return o[r];
                    var i = e.name || n.options.name, a = function(e) {
                        this._init(e);
                    };
                    return (a.prototype = Object.create(n.prototype)).constructor = a, a.cid = t++, 
                    a.options = Ce(n.options, e), a.super = n, a.options.props && function(e) {
                        var t = e.options.props;
                        for (var n in t) ln(e.prototype, "_props", n);
                    }(a), a.options.computed && function(e) {
                        var t = e.options.computed;
                        for (var n in t) hn(e.prototype, n, t[n]);
                    }(a), a.extend = n.extend, a.mixin = n.mixin, a.use = n.use, $.forEach(function(e) {
                        a[e] = n[e];
                    }), i && (a.options.components[i] = a), a.superOptions = n.options, a.extendOptions = e, 
                    a.sealedOptions = j({}, a.options), o[r] = a, a;
                };
            }
            function xn(e) {
                return e && (e.Ctor.options.name || e.tag);
            }
            function On(e, t) {
                return Array.isArray(e) ? e.indexOf(t) > -1 : "string" == typeof e ? e.split(",").indexOf(t) > -1 : !!function(e) {
                    return "[object RegExp]" === s.call(e);
                }(e) && e.test(t);
            }
            function Sn(e, t) {
                var n = e.cache, r = e.keys, o = e._vnode;
                for (var i in n) {
                    var a = n[i];
                    if (a) {
                        var u = xn(a.componentOptions);
                        u && !t(u) && En(n, i, r, o);
                    }
                }
            }
            function En(e, t, n, r) {
                var o = e[t];
                !o || r && o.tag === r.tag || o.componentInstance.$destroy(), e[t] = null, y(n, t);
            }
            (function(e) {
                e.prototype._init = function(e) {
                    var t = this;
                    t._uid = bn++, t._isVue = !0, e && e._isComponent ? function(e, t) {
                        var n = e.$options = Object.create(e.constructor.options), r = t._parentVnode;
                        n.parent = t.parent, n._parentVnode = r;
                        var o = r.componentOptions;
                        n.propsData = o.propsData, n._parentListeners = o.listeners, n._renderChildren = o.children, 
                        n._componentTag = o.tag, t.render && (n.render = t.render, n.staticRenderFns = t.staticRenderFns);
                    }(t, e) : t.$options = Ce(mn(t.constructor), e || {}, t), t._renderProxy = t, t._self = t, 
                    function(e) {
                        var t = e.$options, n = t.parent;
                        if (n && !t.abstract) {
                            for (;n.$options.abstract && n.$parent; ) n = n.$parent;
                            n.$children.push(e);
                        }
                        e.$parent = n, e.$root = n ? n.$root : e, e.$children = [], e.$refs = {}, e._watcher = null, 
                        e._inactive = null, e._directInactive = !1, e._isMounted = !1, e._isDestroyed = !1, 
                        e._isBeingDestroyed = !1;
                    }(t), function(e) {
                        e._events = Object.create(null), e._hasHookEvent = !1;
                        var t = e.$options._parentListeners;
                        t && zt(e, t);
                    }(t), function(e) {
                        e._vnode = null, e._staticTrees = null;
                        var t = e.$options, n = e.$vnode = t._parentVnode, o = n && n.context;
                        e.$slots = at(t._renderChildren, o), e.$scopedSlots = r, e._c = function(t, n, r, o) {
                            return It(e, t, n, r, o, !1);
                        }, e.$createElement = function(t, n, r, o) {
                            return It(e, t, n, r, o, !0);
                        };
                        var i = n && n.data;
                        _e(e, "$attrs", i && i.attrs || r, null, !0), _e(e, "$listeners", t._parentListeners || r, null, !0);
                    }(t), Qt(t, "beforeCreate"), !t._$fallback && ot(t), pn(t), !t._$fallback && rt(t), 
                    !t._$fallback && Qt(t, "created"), t.$options.el && t.$mount(t.$options.el);
                };
            })(_n), function(e) {
                Object.defineProperty(e.prototype, "$data", {
                    get: function() {
                        return this._data;
                    }
                }), Object.defineProperty(e.prototype, "$props", {
                    get: function() {
                        return this._props;
                    }
                }), e.prototype.$set = we, e.prototype.$delete = xe, e.prototype.$watch = function(e, t, n) {
                    var r = this;
                    if (f(t)) return yn(r, e, t, n);
                    (n = n || {}).user = !0;
                    var o = new sn(r, e, t, n);
                    if (n.immediate) try {
                        t.call(r, o.value);
                    } catch (e) {
                        $e(e, r, 'callback for immediate watcher "' + o.expression + '"');
                    }
                    return function() {
                        o.teardown();
                    };
                };
            }(_n), function(e) {
                var t = /^hook:/;
                e.prototype.$on = function(e, n) {
                    var r = this;
                    if (Array.isArray(e)) for (var o = 0, i = e.length; o < i; o++) r.$on(e[o], n); else (r._events[e] || (r._events[e] = [])).push(n), 
                    t.test(e) && (r._hasHookEvent = !0);
                    return r;
                }, e.prototype.$once = function(e, t) {
                    var n = this;
                    function r() {
                        n.$off(e, r), t.apply(n, arguments);
                    }
                    return r.fn = t, n.$on(e, r), n;
                }, e.prototype.$off = function(e, t) {
                    var n = this;
                    if (!arguments.length) return n._events = Object.create(null), n;
                    if (Array.isArray(e)) {
                        for (var r = 0, o = e.length; r < o; r++) n.$off(e[r], t);
                        return n;
                    }
                    var i, a = n._events[e];
                    if (!a) return n;
                    if (!t) return n._events[e] = null, n;
                    for (var u = a.length; u--; ) if ((i = a[u]) === t || i.fn === t) {
                        a.splice(u, 1);
                        break;
                    }
                    return n;
                }, e.prototype.$emit = function(e) {
                    var t = this, n = t._events[e];
                    if (n) {
                        n = n.length > 1 ? P(n) : n;
                        for (var r = P(arguments, 1), o = 'event handler for "' + e + '"', i = 0, a = n.length; i < a; i++) Ne(n[i], t, r, t, o);
                    }
                    return t;
                };
            }(_n), function(e) {
                e.prototype._update = function(e, t) {
                    var n = this, r = n.$el, o = n._vnode, i = function(e) {
                        var t = qt;
                        return qt = e, function() {
                            qt = t;
                        };
                    }(n);
                    n._vnode = e, n.$el = o ? n.__patch__(o, e) : n.__patch__(n.$el, e, t, !1), i(), 
                    r && (r.__vue__ = null), n.$el && (n.$el.__vue__ = n), n.$vnode && n.$parent && n.$vnode === n.$parent._vnode && (n.$parent.$el = n.$el);
                }, e.prototype.$forceUpdate = function() {
                    this._watcher && this._watcher.update();
                }, e.prototype.$destroy = function() {
                    var e = this;
                    if (!e._isBeingDestroyed) {
                        Qt(e, "beforeDestroy"), e._isBeingDestroyed = !0;
                        var t = e.$parent;
                        !t || t._isBeingDestroyed || e.$options.abstract || y(t.$children, e), e._watcher && e._watcher.teardown();
                        for (var n = e._watchers.length; n--; ) e._watchers[n].teardown();
                        e._data.__ob__ && e._data.__ob__.vmCount--, e._isDestroyed = !0, e.__patch__(e._vnode, null), 
                        Qt(e, "destroyed"), e.$off(), e.$el && (e.$el.__vue__ = null), e.$vnode && (e.$vnode.parent = null);
                    }
                };
            }(_n), function(e) {
                Et(e.prototype), e.prototype.$nextTick = function(e) {
                    return Ye(e, this);
                }, e.prototype._render = function() {
                    var e, t = this, n = t.$options, r = n.render, o = n._parentVnode;
                    o && (t.$scopedSlots = ct(o.data.scopedSlots, t.$slots, t.$scopedSlots)), t.$vnode = o;
                    try {
                        Rt = t, e = r.call(t._renderProxy, t.$createElement);
                    } catch (n) {
                        $e(n, t, "render"), e = t._vnode;
                    } finally {
                        Rt = null;
                    }
                    return Array.isArray(e) && 1 === e.length && (e = e[0]), e instanceof ce || (e = fe()), 
                    e.parent = o, e;
                };
            }(_n);
            var kn = [ String, RegExp, Array ], Pn = {
                KeepAlive: {
                    name: "keep-alive",
                    abstract: !0,
                    props: {
                        include: kn,
                        exclude: kn,
                        max: [ String, Number ]
                    },
                    created: function() {
                        this.cache = Object.create(null), this.keys = [];
                    },
                    destroyed: function() {
                        for (var e in this.cache) En(this.cache, e, this.keys);
                    },
                    mounted: function() {
                        var e = this;
                        this.$watch("include", function(t) {
                            Sn(e, function(e) {
                                return On(t, e);
                            });
                        }), this.$watch("exclude", function(t) {
                            Sn(e, function(e) {
                                return !On(t, e);
                            });
                        });
                    },
                    render: function() {
                        var e = this.$slots.default, t = Ut(e), n = t && t.componentOptions;
                        if (n) {
                            var r = xn(n), o = this.include, i = this.exclude;
                            if (o && (!r || !On(o, r)) || i && r && On(i, r)) return t;
                            var a = this.cache, u = this.keys, c = null == t.key ? n.Ctor.cid + (n.tag ? "::" + n.tag : "") : t.key;
                            a[c] ? (t.componentInstance = a[c].componentInstance, y(u, c), u.push(c)) : (a[c] = t, 
                            u.push(c), this.max && u.length > parseInt(this.max) && En(a, u[0], u, this._vnode)), 
                            t.data.keepAlive = !0;
                        }
                        return t || e && e[0];
                    }
                }
            };
            (function(e) {
                var t = {
                    get: function() {
                        return R;
                    }
                };
                Object.defineProperty(e, "config", t), e.util = {
                    warn: re,
                    extend: j,
                    mergeOptions: Ce,
                    defineReactive: _e
                }, e.set = we, e.delete = xe, e.nextTick = Ye, e.observable = function(e) {
                    return me(e), e;
                }, e.options = Object.create(null), $.forEach(function(t) {
                    e.options[t + "s"] = Object.create(null);
                }), e.options._base = e, j(e.options.components, Pn), function(e) {
                    e.use = function(e) {
                        var t = this._installedPlugins || (this._installedPlugins = []);
                        if (t.indexOf(e) > -1) return this;
                        var n = P(arguments, 1);
                        return n.unshift(this), "function" == typeof e.install ? e.install.apply(e, n) : "function" == typeof e && e.apply(null, n), 
                        t.push(e), this;
                    };
                }(e), function(e) {
                    e.mixin = function(e) {
                        return this.options = Ce(this.options, e), this;
                    };
                }(e), wn(e), function(e) {
                    $.forEach(function(t) {
                        e[t] = function(e, n) {
                            return n ? ("component" === t && f(n) && (n.name = n.name || e, n = this.options._base.extend(n)), 
                            "directive" === t && "function" == typeof n && (n = {
                                bind: n,
                                update: n
                            }), this.options[t + "s"][e] = n, n) : this.options[t + "s"][e];
                        };
                    });
                }(e);
            })(_n), Object.defineProperty(_n.prototype, "$isServer", {
                get: X
            }), Object.defineProperty(_n.prototype, "$ssrContext", {
                get: function() {
                    return this.$vnode && this.$vnode.ssrContext;
                }
            }), Object.defineProperty(_n, "FunctionalRenderContext", {
                value: kt
            }), _n.version = "2.6.11";
            var jn = "[object Array]", An = "[object Object]";
            function Cn(e, t) {
                var n = {};
                return function e(t, n) {
                    if (t !== n) {
                        var r = Dn(t), o = Dn(n);
                        if (r == An && o == An) {
                            if (Object.keys(t).length >= Object.keys(n).length) for (var i in n) {
                                var a = t[i];
                                void 0 === a ? t[i] = null : e(a, n[i]);
                            }
                        } else r == jn && o == jn && t.length >= n.length && n.forEach(function(n, r) {
                            e(t[r], n);
                        });
                    }
                }(e, t), function e(t, n, r, o) {
                    if (t !== n) {
                        var i = Dn(t), a = Dn(n);
                        if (i == An) if (a != An || Object.keys(t).length < Object.keys(n).length) Tn(o, r, t); else {
                            var u = function(i) {
                                var a = t[i], u = n[i], c = Dn(a), s = Dn(u);
                                if (c != jn && c != An) a !== n[i] && Tn(o, ("" == r ? "" : r + ".") + i, a); else if (c == jn) s != jn || a.length < u.length ? Tn(o, ("" == r ? "" : r + ".") + i, a) : a.forEach(function(t, n) {
                                    e(t, u[n], ("" == r ? "" : r + ".") + i + "[" + n + "]", o);
                                }); else if (c == An) if (s != An || Object.keys(a).length < Object.keys(u).length) Tn(o, ("" == r ? "" : r + ".") + i, a); else for (var f in a) e(a[f], u[f], ("" == r ? "" : r + ".") + i + "." + f, o);
                            };
                            for (var c in t) u(c);
                        } else i == jn ? a != jn || t.length < n.length ? Tn(o, r, t) : t.forEach(function(t, i) {
                            e(t, n[i], r + "[" + i + "]", o);
                        }) : Tn(o, r, t);
                    }
                }(e, t, "", n), n;
            }
            function Tn(e, t, n) {
                e[t] = n;
            }
            function Dn(e) {
                return Object.prototype.toString.call(e);
            }
            function Mn(e) {
                if (e.__next_tick_callbacks && e.__next_tick_callbacks.length) {
                    if (Object({
                        VUE_APP_NAME: "HGDSxcx",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG) {
                        var t = e.$scope;
                        console.log("[" + +new Date() + "][" + (t.is || t.route) + "][" + e._uid + "]:flushCallbacks[" + e.__next_tick_callbacks.length + "]");
                    }
                    var n = e.__next_tick_callbacks.slice(0);
                    e.__next_tick_callbacks.length = 0;
                    for (var r = 0; r < n.length; r++) n[r]();
                }
            }
            function In(e, t) {
                if (!e.__next_tick_pending && !function(e) {
                    return Xt.find(function(t) {
                        return e._watcher === t;
                    });
                }(e)) {
                    if (Object({
                        VUE_APP_NAME: "HGDSxcx",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG) {
                        var n = e.$scope;
                        console.log("[" + +new Date() + "][" + (n.is || n.route) + "][" + e._uid + "]:nextVueTick");
                    }
                    return Ye(t, e);
                }
                if (Object({
                    VUE_APP_NAME: "HGDSxcx",
                    VUE_APP_PLATFORM: "mp-weixin",
                    NODE_ENV: "production",
                    BASE_URL: "/"
                }).VUE_APP_DEBUG) {
                    var r = e.$scope;
                    console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + e._uid + "]:nextMPTick");
                }
                var o;
                if (e.__next_tick_callbacks || (e.__next_tick_callbacks = []), e.__next_tick_callbacks.push(function() {
                    if (t) try {
                        t.call(e);
                    } catch (t) {
                        $e(t, e, "nextTick");
                    } else o && o(e);
                }), !t && "undefined" != typeof Promise) return new Promise(function(e) {
                    o = e;
                });
            }
            function Ln() {}
            function $n(e) {
                return Array.isArray(e) ? function(e) {
                    for (var t, n = "", r = 0, o = e.length; r < o; r++) i(t = $n(e[r])) && "" !== t && (n && (n += " "), 
                    n += t);
                    return n;
                }(e) : c(e) ? function(e) {
                    var t = "";
                    for (var n in e) e[n] && (t && (t += " "), t += n);
                    return t;
                }(e) : "string" == typeof e ? e : "";
            }
            var Nn = _(function(e) {
                var t = {}, n = /:(.+)/;
                return e.split(/;(?![^(]*\))/g).forEach(function(e) {
                    if (e) {
                        var r = e.split(n);
                        r.length > 1 && (t[r[0].trim()] = r[1].trim());
                    }
                }), t;
            });
            var Rn = [ "createSelectorQuery", "createIntersectionObserver", "selectAllComponents", "selectComponent" ];
            var Bn = [ "onLaunch", "onShow", "onHide", "onUniNViewMessage", "onPageNotFound", "onThemeChange", "onError", "onUnhandledRejection", "onInit", "onLoad", "onReady", "onUnload", "onPullDownRefresh", "onReachBottom", "onTabItemTap", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onResize", "onPageScroll", "onNavigationBarButtonTap", "onBackPress", "onNavigationBarSearchInputChanged", "onNavigationBarSearchInputConfirmed", "onNavigationBarSearchInputClicked", "onPageShow", "onPageHide", "onPageResize" ];
            _n.prototype.__patch__ = function(e, t) {
                var n = this;
                if (null !== t && ("page" === this.mpType || "component" === this.mpType)) {
                    var r = this.$scope, o = Object.create(null);
                    try {
                        o = function(e) {
                            var t = Object.create(null);
                            [].concat(Object.keys(e._data || {}), Object.keys(e._computedWatchers || {})).reduce(function(t, n) {
                                return t[n] = e[n], t;
                            }, t);
                            var n = e.__composition_api_state__ || e.__secret_vfa_state__, r = n && n.rawBindings;
                            return r && Object.keys(r).forEach(function(n) {
                                t[n] = e[n];
                            }), Object.assign(t, e.$mp.data || {}), Array.isArray(e.$options.behaviors) && -1 !== e.$options.behaviors.indexOf("uni://form-field") && (t.name = e.name, 
                            t.value = e.value), JSON.parse(JSON.stringify(t));
                        }(this);
                    } catch (e) {
                        console.error(e);
                    }
                    o.__webviewId__ = r.data.__webviewId__;
                    var i = Object.create(null);
                    Object.keys(o).forEach(function(e) {
                        i[e] = r.data[e];
                    });
                    var a = !1 === this.$shouldDiffData ? o : Cn(o, i);
                    Object.keys(a).length ? (Object({
                        VUE_APP_NAME: "HGDSxcx",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + this._uid + "]差量更新", JSON.stringify(a)), 
                    this.__next_tick_pending = !0, r.setData(a, function() {
                        n.__next_tick_pending = !1, Mn(n);
                    })) : Mn(this);
                }
            }, _n.prototype.$mount = function(e, t) {
                return function(e, t, n) {
                    return e.mpType ? ("app" === e.mpType && (e.$options.render = Ln), e.$options.render || (e.$options.render = Ln), 
                    !e._$fallback && Qt(e, "beforeMount"), new sn(e, function() {
                        e._update(e._render(), n);
                    }, C, {
                        before: function() {
                            e._isMounted && !e._isDestroyed && Qt(e, "beforeUpdate");
                        }
                    }, !0), n = !1, e) : e;
                }(this, 0, t);
            }, function(e) {
                var t = e.extend;
                e.extend = function(e) {
                    var n = (e = e || {}).methods;
                    return n && Object.keys(n).forEach(function(t) {
                        -1 !== Bn.indexOf(t) && (e[t] = n[t], delete n[t]);
                    }), t.call(this, e);
                };
                var n = e.config.optionMergeStrategies, r = n.created;
                Bn.forEach(function(e) {
                    n[e] = r;
                }), e.prototype.__lifecycle_hooks__ = Bn;
            }(_n), function(e) {
                e.config.errorHandler = function(t, n, r) {
                    e.util.warn("Error in " + r + ': "' + t.toString() + '"', n), console.error(t);
                    var o = "function" == typeof getApp && getApp();
                    o && o.onError && o.onError(t);
                };
                var t = e.prototype.$emit;
                e.prototype.$emit = function(e) {
                    return this.$scope && e && this.$scope.triggerEvent(e, {
                        __args__: P(arguments, 1)
                    }), t.apply(this, arguments);
                }, e.prototype.$nextTick = function(e) {
                    return In(this, e);
                }, Rn.forEach(function(t) {
                    e.prototype[t] = function(e) {
                        return this.$scope && this.$scope[t] ? this.$scope[t](e) : "undefined" != typeof my ? "createSelectorQuery" === t ? my.createSelectorQuery(e) : "createIntersectionObserver" === t ? my.createIntersectionObserver(e) : void 0 : void 0;
                    };
                }), e.prototype.__init_provide = rt, e.prototype.__init_injections = ot, e.prototype.__call_hook = function(e, t) {
                    var n = this;
                    ae();
                    var r, o = n.$options[e], i = e + " hook";
                    if (o) for (var a = 0, u = o.length; a < u; a++) r = Ne(o[a], n, t ? [ t ] : null, n, i);
                    return n._hasHookEvent && n.$emit("hook:" + e, t), ue(), r;
                }, e.prototype.__set_model = function(e, t, n, r) {
                    Array.isArray(r) && (-1 !== r.indexOf("trim") && (n = n.trim()), -1 !== r.indexOf("number") && (n = this._n(n))), 
                    e || (e = this), e[t] = n;
                }, e.prototype.__set_sync = function(e, t, n) {
                    e || (e = this), e[t] = n;
                }, e.prototype.__get_orig = function(e) {
                    return f(e) && e.$orig || e;
                }, e.prototype.__get_value = function(e, t) {
                    return function e(t, n) {
                        var r = n.split("."), o = r[0];
                        return 0 === o.indexOf("__$n") && (o = parseInt(o.replace("__$n", ""))), 1 === r.length ? t[o] : e(t[o], r.slice(1).join("."));
                    }(t || this, e);
                }, e.prototype.__get_class = function(e, t) {
                    return function(e, t) {
                        return i(e) || i(t) ? function(e, t) {
                            return e ? t ? e + " " + t : e : t || "";
                        }(e, $n(t)) : "";
                    }(t, e);
                }, e.prototype.__get_style = function(e, t) {
                    if (!e && !t) return "";
                    var n = function(e) {
                        return Array.isArray(e) ? A(e) : "string" == typeof e ? Nn(e) : e;
                    }(e), r = t ? j(t, n) : n;
                    return Object.keys(r).map(function(e) {
                        return E(e) + ":" + r[e];
                    }).join(";");
                }, e.prototype.__map = function(e, t) {
                    var n, r, o, i, a;
                    if (Array.isArray(e)) {
                        for (n = new Array(e.length), r = 0, o = e.length; r < o; r++) n[r] = t(e[r], r);
                        return n;
                    }
                    if (c(e)) {
                        for (i = Object.keys(e), n = Object.create(null), r = 0, o = i.length; r < o; r++) n[a = i[r]] = t(e[a], a, r);
                        return n;
                    }
                    if ("number" == typeof e) {
                        for (n = new Array(e), r = 0, o = e; r < o; r++) n[r] = t(r, r);
                        return n;
                    }
                    return [];
                };
            }(_n), t.default = _n;
        }.call(this, r("c8ba"));
    },
    "670e": function(e) {
        function t(t, n, r) {
            return e.apply(this, arguments);
        }
        return t.toString = function() {
            return e.toString();
        }, t;
    }(function(e, t, r) {
        function o(e) {
            return "[object Object]" === Object.prototype.toString.call(e);
        }
        function i(e, t) {
            try {
                return e instanceof t;
            } catch (e) {
                return !1;
            }
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.isError = function(e) {
            switch (Object.prototype.toString.call(e)) {
              case "[object Error]":
              case "[object Exception]":
              case "[object DOMException]":
                return !0;

              default:
                return i(e, Error);
            }
        }, t.isErrorEvent = function(e) {
            return "[object ErrorEvent]" === Object.prototype.toString.call(e);
        }, t.isDOMError = function(e) {
            return "[object DOMError]" === Object.prototype.toString.call(e);
        }, t.isDOMException = function(e) {
            return "[object DOMException]" === Object.prototype.toString.call(e);
        }, t.isString = function(e) {
            return "[object String]" === Object.prototype.toString.call(e);
        }, t.isPrimitive = function(e) {
            return null === e || "object" !== (0, n.default)(e) && "function" != typeof e;
        }, t.isPlainObject = o, t.isEvent = function(e) {
            return "undefined" != typeof Event && i(e, Event);
        }, t.isElement = function(e) {
            return "undefined" != typeof Element && i(e, Element);
        }, t.isRegExp = function(e) {
            return "[object RegExp]" === Object.prototype.toString.call(e);
        }, t.isThenable = function(e) {
            return Boolean(e && e.then && "function" == typeof e.then);
        }, t.isSyntheticEvent = function(e) {
            return o(e) && "nativeEvent" in e && "preventDefault" in e && "stopPropagation" in e;
        }, t.isInstanceOf = i;
    }),
    "68b0": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = i(n("eb5f")), o = i(n("234f"));
        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var a = {
            pointList: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    id: e.id,
                    idType: e.idType,
                    pointAccountId: e.pointAccountId
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("get", "/api/wxapp/point/point-list", e);
            }
        };
        t.default = a;
    },
    6916: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.appName = t.sdk = void 0;
        var o = function() {
            var e = {
                request: function() {},
                httpRequest: function() {},
                getSystemInfoSync: function() {}
            };
            if ("object" === ("undefined" == typeof wx ? "undefined" : (0, n.default)(wx))) e = wx; else if ("object" === ("undefined" == typeof my ? "undefined" : (0, 
            n.default)(my))) e = my; else if ("object" === ("undefined" == typeof tt ? "undefined" : (0, 
            n.default)(tt))) e = tt; else if ("object" === ("undefined" == typeof dd ? "undefined" : (0, 
            n.default)(dd))) e = dd; else if ("object" === ("undefined" == typeof qq ? "undefined" : (0, 
            n.default)(qq))) e = qq; else {
                if ("object" !== ("undefined" == typeof swan ? "undefined" : (0, n.default)(swan))) throw new Error("sentry-miniapp 暂不支持此平台");
                e = swan;
            }
            return e;
        }();
        t.sdk = o;
        var i = function() {
            var e = "unknown";
            return "object" === ("undefined" == typeof wx ? "undefined" : (0, n.default)(wx)) ? e = "wechat" : "object" === ("undefined" == typeof my ? "undefined" : (0, 
            n.default)(my)) ? e = "alipay" : "object" === ("undefined" == typeof tt ? "undefined" : (0, 
            n.default)(tt)) ? e = "bytedance" : "object" === ("undefined" == typeof dd ? "undefined" : (0, 
            n.default)(dd)) ? e = "dingtalk" : "object" === ("undefined" == typeof qq ? "undefined" : (0, 
            n.default)(qq)) ? e = "qq" : "object" === ("undefined" == typeof swan ? "undefined" : (0, 
            n.default)(swan)) && (e = "swan"), e;
        }();
        t.appName = i;
    },
    "6bd2": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            saveLoginRecord: function(e) {
                return (0, r.default)("post", "/api/wxapp/relevant/saveLoginRecord", e, !1);
            },
            uploadImg: function(e) {
                return (0, r.default)("post", "/api/wxapp/evaluate/upload", e, !1);
            },
            savePv: function(e) {
                return (0, r.default)("post", "/api/wxapp/visitRecord/save", e, !1);
            },
            repeatBuy: function(e) {
                return (0, r.default)("post", "/api/wxapp/repeatBuy/give", e, !1);
            }
        };
        t.default = o;
    },
    "6e9a": function(e, t, n) {
        var r;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Status = void 0, t.Status = r, function(e) {
            e.Unknown = "unknown", e.Skipped = "skipped", e.Success = "success", e.RateLimit = "rate_limit", 
            e.Invalid = "invalid", e.Failed = "failed";
        }(r || (t.Status = r = {})), function(e) {
            e.fromHttpCode = function(t) {
                return t >= 200 && t < 300 ? e.Success : 429 === t ? e.RateLimit : t >= 400 && t < 500 ? e.Invalid : t >= 500 ? e.Failed : e.Unknown;
            };
        }(r || (t.Status = r = {}));
    },
    "717a": function(e, t) {
        function n(e, t) {
            var n = (65535 & e) + (65535 & t);
            return (e >> 16) + (t >> 16) + (n >> 16) << 16 | 65535 & n;
        }
        function r(e, t, r, o, i, a) {
            return n(function(e, t) {
                return e << t | e >>> 32 - t;
            }(n(n(t, e), n(o, a)), i), r);
        }
        function o(e, t, n, o, i, a, u) {
            return r(t & n | ~t & o, e, t, i, a, u);
        }
        function i(e, t, n, o, i, a, u) {
            return r(t & o | n & ~o, e, t, i, a, u);
        }
        function a(e, t, n, o, i, a, u) {
            return r(t ^ n ^ o, e, t, i, a, u);
        }
        function u(e, t, n, o, i, a, u) {
            return r(n ^ (t | ~o), e, t, i, a, u);
        }
        e.exports = {
            hexMD5: function(e) {
                return function(e) {
                    for (var t = "0123456789abcdef", n = "", r = 0; r < 4 * e.length; r++) n += t.charAt(e[r >> 2] >> r % 4 * 8 + 4 & 15) + t.charAt(e[r >> 2] >> r % 4 * 8 & 15);
                    return n;
                }(function(e) {
                    for (var t = 1732584193, r = -271733879, c = -1732584194, s = 271733878, f = 0; f < e.length; f += 16) {
                        var l = t, p = r, d = c, h = s;
                        t = o(t, r, c, s, e[f + 0], 7, -680876936), s = o(s, t, r, c, e[f + 1], 12, -389564586), 
                        c = o(c, s, t, r, e[f + 2], 17, 606105819), r = o(r, c, s, t, e[f + 3], 22, -1044525330), 
                        t = o(t, r, c, s, e[f + 4], 7, -176418897), s = o(s, t, r, c, e[f + 5], 12, 1200080426), 
                        c = o(c, s, t, r, e[f + 6], 17, -1473231341), r = o(r, c, s, t, e[f + 7], 22, -45705983), 
                        t = o(t, r, c, s, e[f + 8], 7, 1770035416), s = o(s, t, r, c, e[f + 9], 12, -1958414417), 
                        c = o(c, s, t, r, e[f + 10], 17, -42063), r = o(r, c, s, t, e[f + 11], 22, -1990404162), 
                        t = o(t, r, c, s, e[f + 12], 7, 1804603682), s = o(s, t, r, c, e[f + 13], 12, -40341101), 
                        c = o(c, s, t, r, e[f + 14], 17, -1502002290), r = o(r, c, s, t, e[f + 15], 22, 1236535329), 
                        t = i(t, r, c, s, e[f + 1], 5, -165796510), s = i(s, t, r, c, e[f + 6], 9, -1069501632), 
                        c = i(c, s, t, r, e[f + 11], 14, 643717713), r = i(r, c, s, t, e[f + 0], 20, -373897302), 
                        t = i(t, r, c, s, e[f + 5], 5, -701558691), s = i(s, t, r, c, e[f + 10], 9, 38016083), 
                        c = i(c, s, t, r, e[f + 15], 14, -660478335), r = i(r, c, s, t, e[f + 4], 20, -405537848), 
                        t = i(t, r, c, s, e[f + 9], 5, 568446438), s = i(s, t, r, c, e[f + 14], 9, -1019803690), 
                        c = i(c, s, t, r, e[f + 3], 14, -187363961), r = i(r, c, s, t, e[f + 8], 20, 1163531501), 
                        t = i(t, r, c, s, e[f + 13], 5, -1444681467), s = i(s, t, r, c, e[f + 2], 9, -51403784), 
                        c = i(c, s, t, r, e[f + 7], 14, 1735328473), t = a(t, r = i(r, c, s, t, e[f + 12], 20, -1926607734), c, s, e[f + 5], 4, -378558), 
                        s = a(s, t, r, c, e[f + 8], 11, -2022574463), c = a(c, s, t, r, e[f + 11], 16, 1839030562), 
                        r = a(r, c, s, t, e[f + 14], 23, -35309556), t = a(t, r, c, s, e[f + 1], 4, -1530992060), 
                        s = a(s, t, r, c, e[f + 4], 11, 1272893353), c = a(c, s, t, r, e[f + 7], 16, -155497632), 
                        r = a(r, c, s, t, e[f + 10], 23, -1094730640), t = a(t, r, c, s, e[f + 13], 4, 681279174), 
                        s = a(s, t, r, c, e[f + 0], 11, -358537222), c = a(c, s, t, r, e[f + 3], 16, -722521979), 
                        r = a(r, c, s, t, e[f + 6], 23, 76029189), t = a(t, r, c, s, e[f + 9], 4, -640364487), 
                        s = a(s, t, r, c, e[f + 12], 11, -421815835), c = a(c, s, t, r, e[f + 15], 16, 530742520), 
                        t = u(t, r = a(r, c, s, t, e[f + 2], 23, -995338651), c, s, e[f + 0], 6, -198630844), 
                        s = u(s, t, r, c, e[f + 7], 10, 1126891415), c = u(c, s, t, r, e[f + 14], 15, -1416354905), 
                        r = u(r, c, s, t, e[f + 5], 21, -57434055), t = u(t, r, c, s, e[f + 12], 6, 1700485571), 
                        s = u(s, t, r, c, e[f + 3], 10, -1894986606), c = u(c, s, t, r, e[f + 10], 15, -1051523), 
                        r = u(r, c, s, t, e[f + 1], 21, -2054922799), t = u(t, r, c, s, e[f + 8], 6, 1873313359), 
                        s = u(s, t, r, c, e[f + 15], 10, -30611744), c = u(c, s, t, r, e[f + 6], 15, -1560198380), 
                        r = u(r, c, s, t, e[f + 13], 21, 1309151649), t = u(t, r, c, s, e[f + 4], 6, -145523070), 
                        s = u(s, t, r, c, e[f + 11], 10, -1120210379), c = u(c, s, t, r, e[f + 2], 15, 718787259), 
                        r = u(r, c, s, t, e[f + 9], 21, -343485551), t = n(t, l), r = n(r, p), c = n(c, d), 
                        s = n(s, h);
                    }
                    return [ t, r, c, s ];
                }(function(e) {
                    for (var t = 1 + (e.length + 8 >> 6), n = new Array(16 * t), r = 0; r < 16 * t; r++) n[r] = 0;
                    for (r = 0; r < e.length; r++) n[r >> 2] |= (255 & e.charCodeAt(r)) << r % 4 * 8;
                    return n[r >> 2] |= 128 << r % 4 * 8, n[16 * t - 2] = 8 * e.length, n;
                }(e)));
            }
        };
    },
    "71dd": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.supportsErrorEvent = function() {
            try {
                return new ErrorEvent(""), !0;
            } catch (e) {
                return !1;
            }
        }, t.supportsDOMError = function() {
            try {
                return new DOMError(""), !0;
            } catch (e) {
                return !1;
            }
        }, t.supportsDOMException = function() {
            try {
                return new DOMException(""), !0;
            } catch (e) {
                return !1;
            }
        }, t.supportsFetch = i, t.supportsNativeFetch = function() {
            if (!i()) return !1;
            var e = (0, o.getGlobalObject)();
            if (a(e.fetch)) return !0;
            var t = !1, n = e.document;
            if (n && "function" == typeof n.createElement) try {
                var u = n.createElement("iframe");
                u.hidden = !0, n.head.appendChild(u), u.contentWindow && u.contentWindow.fetch && (t = a(u.contentWindow.fetch)), 
                n.head.removeChild(u);
            } catch (e) {
                r.logger.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ", e);
            }
            return t;
        }, t.supportsReportingObserver = function() {
            return "ReportingObserver" in (0, o.getGlobalObject)();
        }, t.supportsReferrerPolicy = function() {
            if (!i()) return !1;
            try {
                return new Request("_", {
                    referrerPolicy: "origin"
                }), !0;
            } catch (e) {
                return !1;
            }
        }, t.supportsHistory = function() {
            var e = (0, o.getGlobalObject)(), t = e.chrome, n = t && t.app && t.app.runtime, r = "history" in e && !!e.history.pushState && !!e.history.replaceState;
            return !n && r;
        };
        var r = n("807a"), o = n("f658");
        function i() {
            if (!("fetch" in (0, o.getGlobalObject)())) return !1;
            try {
                return new Headers(), new Request(""), new Response(), !0;
            } catch (e) {
                return !1;
            }
        }
        function a(e) {
            return e && /^function fetch\(\)\s+\{\s+\[native code\]\s+\}$/.test(e.toString());
        }
    },
    "727b": function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {};
            !function() {
                function t(e) {
                    this.mode = o.MODE_8BIT_BYTE, this.data = e;
                }
                function r(e, t) {
                    this.typeNumber = e, this.errorCorrectLevel = t, this.modules = null, this.moduleCount = 0, 
                    this.dataCache = null, this.dataList = new Array();
                }
                t.prototype = {
                    getLength: function(e) {
                        return this.data.length;
                    },
                    write: function(e) {
                        for (var t = 0; t < this.data.length; t++) e.put(this.data.charCodeAt(t), 8);
                    }
                }, r.prototype = {
                    addData: function(e) {
                        var n = new t(e);
                        this.dataList.push(n), this.dataCache = null;
                    },
                    isDark: function(e, t) {
                        if (e < 0 || this.moduleCount <= e || t < 0 || this.moduleCount <= t) throw new Error(e + "," + t);
                        return this.modules[e][t];
                    },
                    getModuleCount: function() {
                        return this.moduleCount;
                    },
                    make: function() {
                        if (this.typeNumber < 1) {
                            var e = 1;
                            for (e = 1; e < 40; e++) {
                                for (var t = l.getRSBlocks(e, this.errorCorrectLevel), n = new p(), r = 0, o = 0; o < t.length; o++) r += t[o].dataCount;
                                for (o = 0; o < this.dataList.length; o++) {
                                    var i = this.dataList[o];
                                    n.put(i.mode, 4), n.put(i.getLength(), u.getLengthInBits(i.mode, e)), i.write(n);
                                }
                                if (n.getLengthInBits() <= 8 * r) break;
                            }
                            this.typeNumber = e;
                        }
                        this.makeImpl(!1, this.getBestMaskPattern());
                    },
                    makeImpl: function(e, t) {
                        this.moduleCount = 4 * this.typeNumber + 17, this.modules = new Array(this.moduleCount);
                        for (var n = 0; n < this.moduleCount; n++) {
                            this.modules[n] = new Array(this.moduleCount);
                            for (var o = 0; o < this.moduleCount; o++) this.modules[n][o] = null;
                        }
                        this.setupPositionProbePattern(0, 0), this.setupPositionProbePattern(this.moduleCount - 7, 0), 
                        this.setupPositionProbePattern(0, this.moduleCount - 7), this.setupPositionAdjustPattern(), 
                        this.setupTimingPattern(), this.setupTypeInfo(e, t), this.typeNumber >= 7 && this.setupTypeNumber(e), 
                        null == this.dataCache && (this.dataCache = r.createData(this.typeNumber, this.errorCorrectLevel, this.dataList)), 
                        this.mapData(this.dataCache, t);
                    },
                    setupPositionProbePattern: function(e, t) {
                        for (var n = -1; n <= 7; n++) if (!(e + n <= -1 || this.moduleCount <= e + n)) for (var r = -1; r <= 7; r++) t + r <= -1 || this.moduleCount <= t + r || (this.modules[e + n][t + r] = 0 <= n && n <= 6 && (0 == r || 6 == r) || 0 <= r && r <= 6 && (0 == n || 6 == n) || 2 <= n && n <= 4 && 2 <= r && r <= 4);
                    },
                    getBestMaskPattern: function() {
                        for (var e = 0, t = 0, n = 0; n < 8; n++) {
                            this.makeImpl(!0, n);
                            var r = u.getLostPoint(this);
                            (0 == n || e > r) && (e = r, t = n);
                        }
                        return t;
                    },
                    createMovieClip: function(e, t, n) {
                        var r = e.createEmptyMovieClip(t, n);
                        this.make();
                        for (var o = 0; o < this.modules.length; o++) for (var i = 1 * o, a = 0; a < this.modules[o].length; a++) {
                            var u = 1 * a;
                            this.modules[o][a] && (r.beginFill(0, 100), r.moveTo(u, i), r.lineTo(u + 1, i), 
                            r.lineTo(u + 1, i + 1), r.lineTo(u, i + 1), r.endFill());
                        }
                        return r;
                    },
                    setupTimingPattern: function() {
                        for (var e = 8; e < this.moduleCount - 8; e++) null == this.modules[e][6] && (this.modules[e][6] = e % 2 == 0);
                        for (var t = 8; t < this.moduleCount - 8; t++) null == this.modules[6][t] && (this.modules[6][t] = t % 2 == 0);
                    },
                    setupPositionAdjustPattern: function() {
                        for (var e = u.getPatternPosition(this.typeNumber), t = 0; t < e.length; t++) for (var n = 0; n < e.length; n++) {
                            var r = e[t], o = e[n];
                            if (null == this.modules[r][o]) for (var i = -2; i <= 2; i++) for (var a = -2; a <= 2; a++) this.modules[r + i][o + a] = -2 == i || 2 == i || -2 == a || 2 == a || 0 == i && 0 == a;
                        }
                    },
                    setupTypeNumber: function(e) {
                        for (var t = u.getBCHTypeNumber(this.typeNumber), n = 0; n < 18; n++) {
                            var r = !e && 1 == (t >> n & 1);
                            this.modules[Math.floor(n / 3)][n % 3 + this.moduleCount - 8 - 3] = r;
                        }
                        for (n = 0; n < 18; n++) r = !e && 1 == (t >> n & 1), this.modules[n % 3 + this.moduleCount - 8 - 3][Math.floor(n / 3)] = r;
                    },
                    setupTypeInfo: function(e, t) {
                        for (var n = this.errorCorrectLevel << 3 | t, r = u.getBCHTypeInfo(n), o = 0; o < 15; o++) {
                            var i = !e && 1 == (r >> o & 1);
                            o < 6 ? this.modules[o][8] = i : o < 8 ? this.modules[o + 1][8] = i : this.modules[this.moduleCount - 15 + o][8] = i;
                        }
                        for (o = 0; o < 15; o++) i = !e && 1 == (r >> o & 1), o < 8 ? this.modules[8][this.moduleCount - o - 1] = i : o < 9 ? this.modules[8][15 - o - 1 + 1] = i : this.modules[8][15 - o - 1] = i;
                        this.modules[this.moduleCount - 8][8] = !e;
                    },
                    mapData: function(e, t) {
                        for (var n = -1, r = this.moduleCount - 1, o = 7, i = 0, a = this.moduleCount - 1; a > 0; a -= 2) for (6 == a && a--; ;) {
                            for (var c = 0; c < 2; c++) if (null == this.modules[r][a - c]) {
                                var s = !1;
                                i < e.length && (s = 1 == (e[i] >>> o & 1)), u.getMask(t, r, a - c) && (s = !s), 
                                this.modules[r][a - c] = s, -1 == --o && (i++, o = 7);
                            }
                            if ((r += n) < 0 || this.moduleCount <= r) {
                                r -= n, n = -n;
                                break;
                            }
                        }
                    }
                }, r.PAD0 = 236, r.PAD1 = 17, r.createData = function(e, t, n) {
                    for (var o = l.getRSBlocks(e, t), i = new p(), a = 0; a < n.length; a++) {
                        var c = n[a];
                        i.put(c.mode, 4), i.put(c.getLength(), u.getLengthInBits(c.mode, e)), c.write(i);
                    }
                    var s = 0;
                    for (a = 0; a < o.length; a++) s += o[a].dataCount;
                    if (i.getLengthInBits() > 8 * s) throw new Error("code length overflow. (" + i.getLengthInBits() + ">" + 8 * s + ")");
                    for (i.getLengthInBits() + 4 <= 8 * s && i.put(0, 4); i.getLengthInBits() % 8 != 0; ) i.putBit(!1);
                    for (;!(i.getLengthInBits() >= 8 * s || (i.put(r.PAD0, 8), i.getLengthInBits() >= 8 * s)); ) i.put(r.PAD1, 8);
                    return r.createBytes(i, o);
                }, r.createBytes = function(e, t) {
                    for (var n = 0, r = 0, o = 0, i = new Array(t.length), a = new Array(t.length), c = 0; c < t.length; c++) {
                        var s = t[c].dataCount, l = t[c].totalCount - s;
                        r = Math.max(r, s), o = Math.max(o, l), i[c] = new Array(s);
                        for (var p = 0; p < i[c].length; p++) i[c][p] = 255 & e.buffer[p + n];
                        n += s;
                        var d = u.getErrorCorrectPolynomial(l), h = new f(i[c], d.getLength() - 1).mod(d);
                        for (a[c] = new Array(d.getLength() - 1), p = 0; p < a[c].length; p++) {
                            var v = p + h.getLength() - a[c].length;
                            a[c][p] = v >= 0 ? h.get(v) : 0;
                        }
                    }
                    var g = 0;
                    for (p = 0; p < t.length; p++) g += t[p].totalCount;
                    var y = new Array(g), b = 0;
                    for (p = 0; p < r; p++) for (c = 0; c < t.length; c++) p < i[c].length && (y[b++] = i[c][p]);
                    for (p = 0; p < o; p++) for (c = 0; c < t.length; c++) p < a[c].length && (y[b++] = a[c][p]);
                    return y;
                };
                for (var o = {
                    MODE_NUMBER: 1,
                    MODE_ALPHA_NUM: 2,
                    MODE_8BIT_BYTE: 4,
                    MODE_KANJI: 8
                }, i = {
                    L: 1,
                    M: 0,
                    Q: 3,
                    H: 2
                }, a = {
                    PATTERN000: 0,
                    PATTERN001: 1,
                    PATTERN010: 2,
                    PATTERN011: 3,
                    PATTERN100: 4,
                    PATTERN101: 5,
                    PATTERN110: 6,
                    PATTERN111: 7
                }, u = {
                    PATTERN_POSITION_TABLE: [ [], [ 6, 18 ], [ 6, 22 ], [ 6, 26 ], [ 6, 30 ], [ 6, 34 ], [ 6, 22, 38 ], [ 6, 24, 42 ], [ 6, 26, 46 ], [ 6, 28, 50 ], [ 6, 30, 54 ], [ 6, 32, 58 ], [ 6, 34, 62 ], [ 6, 26, 46, 66 ], [ 6, 26, 48, 70 ], [ 6, 26, 50, 74 ], [ 6, 30, 54, 78 ], [ 6, 30, 56, 82 ], [ 6, 30, 58, 86 ], [ 6, 34, 62, 90 ], [ 6, 28, 50, 72, 94 ], [ 6, 26, 50, 74, 98 ], [ 6, 30, 54, 78, 102 ], [ 6, 28, 54, 80, 106 ], [ 6, 32, 58, 84, 110 ], [ 6, 30, 58, 86, 114 ], [ 6, 34, 62, 90, 118 ], [ 6, 26, 50, 74, 98, 122 ], [ 6, 30, 54, 78, 102, 126 ], [ 6, 26, 52, 78, 104, 130 ], [ 6, 30, 56, 82, 108, 134 ], [ 6, 34, 60, 86, 112, 138 ], [ 6, 30, 58, 86, 114, 142 ], [ 6, 34, 62, 90, 118, 146 ], [ 6, 30, 54, 78, 102, 126, 150 ], [ 6, 24, 50, 76, 102, 128, 154 ], [ 6, 28, 54, 80, 106, 132, 158 ], [ 6, 32, 58, 84, 110, 136, 162 ], [ 6, 26, 54, 82, 110, 138, 166 ], [ 6, 30, 58, 86, 114, 142, 170 ] ],
                    G15: 1335,
                    G18: 7973,
                    G15_MASK: 21522,
                    getBCHTypeInfo: function(e) {
                        for (var t = e << 10; u.getBCHDigit(t) - u.getBCHDigit(u.G15) >= 0; ) t ^= u.G15 << u.getBCHDigit(t) - u.getBCHDigit(u.G15);
                        return (e << 10 | t) ^ u.G15_MASK;
                    },
                    getBCHTypeNumber: function(e) {
                        for (var t = e << 12; u.getBCHDigit(t) - u.getBCHDigit(u.G18) >= 0; ) t ^= u.G18 << u.getBCHDigit(t) - u.getBCHDigit(u.G18);
                        return e << 12 | t;
                    },
                    getBCHDigit: function(e) {
                        for (var t = 0; 0 != e; ) t++, e >>>= 1;
                        return t;
                    },
                    getPatternPosition: function(e) {
                        return u.PATTERN_POSITION_TABLE[e - 1];
                    },
                    getMask: function(e, t, n) {
                        switch (e) {
                          case a.PATTERN000:
                            return (t + n) % 2 == 0;

                          case a.PATTERN001:
                            return t % 2 == 0;

                          case a.PATTERN010:
                            return n % 3 == 0;

                          case a.PATTERN011:
                            return (t + n) % 3 == 0;

                          case a.PATTERN100:
                            return (Math.floor(t / 2) + Math.floor(n / 3)) % 2 == 0;

                          case a.PATTERN101:
                            return t * n % 2 + t * n % 3 == 0;

                          case a.PATTERN110:
                            return (t * n % 2 + t * n % 3) % 2 == 0;

                          case a.PATTERN111:
                            return (t * n % 3 + (t + n) % 2) % 2 == 0;

                          default:
                            throw new Error("bad maskPattern:" + e);
                        }
                    },
                    getErrorCorrectPolynomial: function(e) {
                        for (var t = new f([ 1 ], 0), n = 0; n < e; n++) t = t.multiply(new f([ 1, c.gexp(n) ], 0));
                        return t;
                    },
                    getLengthInBits: function(e, t) {
                        if (1 <= t && t < 10) switch (e) {
                          case o.MODE_NUMBER:
                            return 10;

                          case o.MODE_ALPHA_NUM:
                            return 9;

                          case o.MODE_8BIT_BYTE:
                          case o.MODE_KANJI:
                            return 8;

                          default:
                            throw new Error("mode:" + e);
                        } else if (t < 27) switch (e) {
                          case o.MODE_NUMBER:
                            return 12;

                          case o.MODE_ALPHA_NUM:
                            return 11;

                          case o.MODE_8BIT_BYTE:
                            return 16;

                          case o.MODE_KANJI:
                            return 10;

                          default:
                            throw new Error("mode:" + e);
                        } else {
                            if (!(t < 41)) throw new Error("type:" + t);
                            switch (e) {
                              case o.MODE_NUMBER:
                                return 14;

                              case o.MODE_ALPHA_NUM:
                                return 13;

                              case o.MODE_8BIT_BYTE:
                                return 16;

                              case o.MODE_KANJI:
                                return 12;

                              default:
                                throw new Error("mode:" + e);
                            }
                        }
                    },
                    getLostPoint: function(e) {
                        for (var t = e.getModuleCount(), n = 0, r = 0; r < t; r++) for (var o = 0; o < t; o++) {
                            for (var i = 0, a = e.isDark(r, o), u = -1; u <= 1; u++) if (!(r + u < 0 || t <= r + u)) for (var c = -1; c <= 1; c++) o + c < 0 || t <= o + c || 0 == u && 0 == c || a == e.isDark(r + u, o + c) && i++;
                            i > 5 && (n += 3 + i - 5);
                        }
                        for (r = 0; r < t - 1; r++) for (o = 0; o < t - 1; o++) {
                            var s = 0;
                            e.isDark(r, o) && s++, e.isDark(r + 1, o) && s++, e.isDark(r, o + 1) && s++, e.isDark(r + 1, o + 1) && s++, 
                            0 != s && 4 != s || (n += 3);
                        }
                        for (r = 0; r < t; r++) for (o = 0; o < t - 6; o++) e.isDark(r, o) && !e.isDark(r, o + 1) && e.isDark(r, o + 2) && e.isDark(r, o + 3) && e.isDark(r, o + 4) && !e.isDark(r, o + 5) && e.isDark(r, o + 6) && (n += 40);
                        for (o = 0; o < t; o++) for (r = 0; r < t - 6; r++) e.isDark(r, o) && !e.isDark(r + 1, o) && e.isDark(r + 2, o) && e.isDark(r + 3, o) && e.isDark(r + 4, o) && !e.isDark(r + 5, o) && e.isDark(r + 6, o) && (n += 40);
                        var f = 0;
                        for (o = 0; o < t; o++) for (r = 0; r < t; r++) e.isDark(r, o) && f++;
                        return n += 10 * (Math.abs(100 * f / t / t - 50) / 5);
                    }
                }, c = {
                    glog: function(e) {
                        if (e < 1) throw new Error("glog(" + e + ")");
                        return c.LOG_TABLE[e];
                    },
                    gexp: function(e) {
                        for (;e < 0; ) e += 255;
                        for (;e >= 256; ) e -= 255;
                        return c.EXP_TABLE[e];
                    },
                    EXP_TABLE: new Array(256),
                    LOG_TABLE: new Array(256)
                }, s = 0; s < 8; s++) c.EXP_TABLE[s] = 1 << s;
                for (s = 8; s < 256; s++) c.EXP_TABLE[s] = c.EXP_TABLE[s - 4] ^ c.EXP_TABLE[s - 5] ^ c.EXP_TABLE[s - 6] ^ c.EXP_TABLE[s - 8];
                for (s = 0; s < 255; s++) c.LOG_TABLE[c.EXP_TABLE[s]] = s;
                function f(e, t) {
                    if (null == e.length) throw new Error(e.length + "/" + t);
                    for (var n = 0; n < e.length && 0 == e[n]; ) n++;
                    this.num = new Array(e.length - n + t);
                    for (var r = 0; r < e.length - n; r++) this.num[r] = e[r + n];
                }
                function l(e, t) {
                    this.totalCount = e, this.dataCount = t;
                }
                function p() {
                    this.buffer = new Array(), this.length = 0;
                }
                f.prototype = {
                    get: function(e) {
                        return this.num[e];
                    },
                    getLength: function() {
                        return this.num.length;
                    },
                    multiply: function(e) {
                        for (var t = new Array(this.getLength() + e.getLength() - 1), n = 0; n < this.getLength(); n++) for (var r = 0; r < e.getLength(); r++) t[n + r] ^= c.gexp(c.glog(this.get(n)) + c.glog(e.get(r)));
                        return new f(t, 0);
                    },
                    mod: function(e) {
                        if (this.getLength() - e.getLength() < 0) return this;
                        for (var t = c.glog(this.get(0)) - c.glog(e.get(0)), n = new Array(this.getLength()), r = 0; r < this.getLength(); r++) n[r] = this.get(r);
                        for (r = 0; r < e.getLength(); r++) n[r] ^= c.gexp(c.glog(e.get(r)) + t);
                        return new f(n, 0).mod(e);
                    }
                }, l.RS_BLOCK_TABLE = [ [ 1, 26, 19 ], [ 1, 26, 16 ], [ 1, 26, 13 ], [ 1, 26, 9 ], [ 1, 44, 34 ], [ 1, 44, 28 ], [ 1, 44, 22 ], [ 1, 44, 16 ], [ 1, 70, 55 ], [ 1, 70, 44 ], [ 2, 35, 17 ], [ 2, 35, 13 ], [ 1, 100, 80 ], [ 2, 50, 32 ], [ 2, 50, 24 ], [ 4, 25, 9 ], [ 1, 134, 108 ], [ 2, 67, 43 ], [ 2, 33, 15, 2, 34, 16 ], [ 2, 33, 11, 2, 34, 12 ], [ 2, 86, 68 ], [ 4, 43, 27 ], [ 4, 43, 19 ], [ 4, 43, 15 ], [ 2, 98, 78 ], [ 4, 49, 31 ], [ 2, 32, 14, 4, 33, 15 ], [ 4, 39, 13, 1, 40, 14 ], [ 2, 121, 97 ], [ 2, 60, 38, 2, 61, 39 ], [ 4, 40, 18, 2, 41, 19 ], [ 4, 40, 14, 2, 41, 15 ], [ 2, 146, 116 ], [ 3, 58, 36, 2, 59, 37 ], [ 4, 36, 16, 4, 37, 17 ], [ 4, 36, 12, 4, 37, 13 ], [ 2, 86, 68, 2, 87, 69 ], [ 4, 69, 43, 1, 70, 44 ], [ 6, 43, 19, 2, 44, 20 ], [ 6, 43, 15, 2, 44, 16 ], [ 4, 101, 81 ], [ 1, 80, 50, 4, 81, 51 ], [ 4, 50, 22, 4, 51, 23 ], [ 3, 36, 12, 8, 37, 13 ], [ 2, 116, 92, 2, 117, 93 ], [ 6, 58, 36, 2, 59, 37 ], [ 4, 46, 20, 6, 47, 21 ], [ 7, 42, 14, 4, 43, 15 ], [ 4, 133, 107 ], [ 8, 59, 37, 1, 60, 38 ], [ 8, 44, 20, 4, 45, 21 ], [ 12, 33, 11, 4, 34, 12 ], [ 3, 145, 115, 1, 146, 116 ], [ 4, 64, 40, 5, 65, 41 ], [ 11, 36, 16, 5, 37, 17 ], [ 11, 36, 12, 5, 37, 13 ], [ 5, 109, 87, 1, 110, 88 ], [ 5, 65, 41, 5, 66, 42 ], [ 5, 54, 24, 7, 55, 25 ], [ 11, 36, 12 ], [ 5, 122, 98, 1, 123, 99 ], [ 7, 73, 45, 3, 74, 46 ], [ 15, 43, 19, 2, 44, 20 ], [ 3, 45, 15, 13, 46, 16 ], [ 1, 135, 107, 5, 136, 108 ], [ 10, 74, 46, 1, 75, 47 ], [ 1, 50, 22, 15, 51, 23 ], [ 2, 42, 14, 17, 43, 15 ], [ 5, 150, 120, 1, 151, 121 ], [ 9, 69, 43, 4, 70, 44 ], [ 17, 50, 22, 1, 51, 23 ], [ 2, 42, 14, 19, 43, 15 ], [ 3, 141, 113, 4, 142, 114 ], [ 3, 70, 44, 11, 71, 45 ], [ 17, 47, 21, 4, 48, 22 ], [ 9, 39, 13, 16, 40, 14 ], [ 3, 135, 107, 5, 136, 108 ], [ 3, 67, 41, 13, 68, 42 ], [ 15, 54, 24, 5, 55, 25 ], [ 15, 43, 15, 10, 44, 16 ], [ 4, 144, 116, 4, 145, 117 ], [ 17, 68, 42 ], [ 17, 50, 22, 6, 51, 23 ], [ 19, 46, 16, 6, 47, 17 ], [ 2, 139, 111, 7, 140, 112 ], [ 17, 74, 46 ], [ 7, 54, 24, 16, 55, 25 ], [ 34, 37, 13 ], [ 4, 151, 121, 5, 152, 122 ], [ 4, 75, 47, 14, 76, 48 ], [ 11, 54, 24, 14, 55, 25 ], [ 16, 45, 15, 14, 46, 16 ], [ 6, 147, 117, 4, 148, 118 ], [ 6, 73, 45, 14, 74, 46 ], [ 11, 54, 24, 16, 55, 25 ], [ 30, 46, 16, 2, 47, 17 ], [ 8, 132, 106, 4, 133, 107 ], [ 8, 75, 47, 13, 76, 48 ], [ 7, 54, 24, 22, 55, 25 ], [ 22, 45, 15, 13, 46, 16 ], [ 10, 142, 114, 2, 143, 115 ], [ 19, 74, 46, 4, 75, 47 ], [ 28, 50, 22, 6, 51, 23 ], [ 33, 46, 16, 4, 47, 17 ], [ 8, 152, 122, 4, 153, 123 ], [ 22, 73, 45, 3, 74, 46 ], [ 8, 53, 23, 26, 54, 24 ], [ 12, 45, 15, 28, 46, 16 ], [ 3, 147, 117, 10, 148, 118 ], [ 3, 73, 45, 23, 74, 46 ], [ 4, 54, 24, 31, 55, 25 ], [ 11, 45, 15, 31, 46, 16 ], [ 7, 146, 116, 7, 147, 117 ], [ 21, 73, 45, 7, 74, 46 ], [ 1, 53, 23, 37, 54, 24 ], [ 19, 45, 15, 26, 46, 16 ], [ 5, 145, 115, 10, 146, 116 ], [ 19, 75, 47, 10, 76, 48 ], [ 15, 54, 24, 25, 55, 25 ], [ 23, 45, 15, 25, 46, 16 ], [ 13, 145, 115, 3, 146, 116 ], [ 2, 74, 46, 29, 75, 47 ], [ 42, 54, 24, 1, 55, 25 ], [ 23, 45, 15, 28, 46, 16 ], [ 17, 145, 115 ], [ 10, 74, 46, 23, 75, 47 ], [ 10, 54, 24, 35, 55, 25 ], [ 19, 45, 15, 35, 46, 16 ], [ 17, 145, 115, 1, 146, 116 ], [ 14, 74, 46, 21, 75, 47 ], [ 29, 54, 24, 19, 55, 25 ], [ 11, 45, 15, 46, 46, 16 ], [ 13, 145, 115, 6, 146, 116 ], [ 14, 74, 46, 23, 75, 47 ], [ 44, 54, 24, 7, 55, 25 ], [ 59, 46, 16, 1, 47, 17 ], [ 12, 151, 121, 7, 152, 122 ], [ 12, 75, 47, 26, 76, 48 ], [ 39, 54, 24, 14, 55, 25 ], [ 22, 45, 15, 41, 46, 16 ], [ 6, 151, 121, 14, 152, 122 ], [ 6, 75, 47, 34, 76, 48 ], [ 46, 54, 24, 10, 55, 25 ], [ 2, 45, 15, 64, 46, 16 ], [ 17, 152, 122, 4, 153, 123 ], [ 29, 74, 46, 14, 75, 47 ], [ 49, 54, 24, 10, 55, 25 ], [ 24, 45, 15, 46, 46, 16 ], [ 4, 152, 122, 18, 153, 123 ], [ 13, 74, 46, 32, 75, 47 ], [ 48, 54, 24, 14, 55, 25 ], [ 42, 45, 15, 32, 46, 16 ], [ 20, 147, 117, 4, 148, 118 ], [ 40, 75, 47, 7, 76, 48 ], [ 43, 54, 24, 22, 55, 25 ], [ 10, 45, 15, 67, 46, 16 ], [ 19, 148, 118, 6, 149, 119 ], [ 18, 75, 47, 31, 76, 48 ], [ 34, 54, 24, 34, 55, 25 ], [ 20, 45, 15, 61, 46, 16 ] ], 
                l.getRSBlocks = function(e, t) {
                    var n = l.getRsBlockTable(e, t);
                    if (null == n) throw new Error("bad rs block @ typeNumber:" + e + "/errorCorrectLevel:" + t);
                    for (var r = n.length / 3, o = new Array(), i = 0; i < r; i++) for (var a = n[3 * i + 0], u = n[3 * i + 1], c = n[3 * i + 2], s = 0; s < a; s++) o.push(new l(u, c));
                    return o;
                }, l.getRsBlockTable = function(e, t) {
                    switch (t) {
                      case i.L:
                        return l.RS_BLOCK_TABLE[4 * (e - 1) + 0];

                      case i.M:
                        return l.RS_BLOCK_TABLE[4 * (e - 1) + 1];

                      case i.Q:
                        return l.RS_BLOCK_TABLE[4 * (e - 1) + 2];

                      case i.H:
                        return l.RS_BLOCK_TABLE[4 * (e - 1) + 3];

                      default:
                        return;
                    }
                }, p.prototype = {
                    get: function(e) {
                        var t = Math.floor(e / 8);
                        return 1 == (this.buffer[t] >>> 7 - e % 8 & 1);
                    },
                    put: function(e, t) {
                        for (var n = 0; n < t; n++) this.putBit(1 == (e >>> t - n - 1 & 1));
                    },
                    getLengthInBits: function() {
                        return this.length;
                    },
                    putBit: function(e) {
                        var t = Math.floor(this.length / 8);
                        this.buffer.length <= t && this.buffer.push(0), e && (this.buffer[t] |= 128 >>> this.length % 8), 
                        this.length++;
                    }
                }, n = {
                    defaults: {
                        size: 258,
                        margin: 0,
                        backgroundColor: "#ffffff",
                        foregroundColor: "#000000",
                        fileType: "png",
                        correctLevel: 3,
                        typeNumber: -1
                    },
                    make: function(t) {
                        var n = {
                            canvasId: t.canvasId,
                            componentInstance: t.componentInstance,
                            text: t.text,
                            size: this.defaults.size,
                            margin: this.defaults.margin,
                            backgroundColor: this.defaults.backgroundColor,
                            foregroundColor: this.defaults.foregroundColor,
                            fileType: this.defaults.fileType,
                            correctLevel: this.defaults.correctLevel,
                            typeNumber: this.defaults.typeNumber
                        };
                        if (t) for (var o in t) n[o] = t[o];
                        (t = n).canvasId ? function() {
                            var n = new r(t.typeNumber, t.correctLevel);
                            n.addData(function(e) {
                                for (var t, n = "", r = 0; r < e.length; r++) (t = e.charCodeAt(r)) >= 1 && t <= 127 ? n += e.charAt(r) : t > 2047 ? (n += String.fromCharCode(224 | t >> 12 & 15), 
                                n += String.fromCharCode(128 | t >> 6 & 63), n += String.fromCharCode(128 | t >> 0 & 63)) : (n += String.fromCharCode(192 | t >> 6 & 31), 
                                n += String.fromCharCode(128 | t >> 0 & 63));
                                return n;
                            }(t.text)), n.make();
                            var o = e.createCanvasContext(t.canvasId, t.componentInstance);
                            o.setFillStyle(t.backgroundColor), o.fillRect(0, 0, t.size, t.size);
                            for (var i = (t.size - 2 * t.margin) / n.getModuleCount(), a = i, u = 0; u < n.getModuleCount(); u++) for (var c = 0; c < n.getModuleCount(); c++) {
                                var s = n.isDark(u, c) ? t.foregroundColor : t.backgroundColor;
                                o.setFillStyle(s);
                                var f = Math.round(c * i) + t.margin, l = Math.round(u * a) + t.margin, p = Math.ceil((c + 1) * i) - Math.floor(c * i), d = Math.ceil((u + 1) * i) - Math.floor(u * i);
                                o.fillRect(f, l, p, d);
                            }
                            setTimeout(function() {
                                o.draw(!1, function() {
                                    setTimeout(function() {
                                        e.canvasToTempFilePath({
                                            canvasId: t.canvasId,
                                            fileType: t.fileType,
                                            width: t.size,
                                            height: t.size,
                                            destWidth: t.size,
                                            destHeight: t.size,
                                            success: function(e) {
                                                t.success && t.success(e.tempFilePath);
                                            },
                                            fail: function(e) {
                                                t.fail && t.fail(e);
                                            },
                                            complete: function(e) {
                                                t.complete && t.complete(e);
                                            }
                                        }, t.componentInstance);
                                    }, t.text.length + 100);
                                });
                            }, 150);
                        }() : console.error("uQRCode: Please set canvasId!");
                    }
                };
            }();
            var r = n;
            t.default = r;
        }).call(this, n("543d").default);
    },
    "745c": function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SentryError = void 0;
        var o = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = a();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var u = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                u && (u.get || u.set) ? Object.defineProperty(r, i, u) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("9ab4")), i = r("95c7");
        function a() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return a = function() {
                return e;
            }, e;
        }
        var u = function(e) {
            function t(t) {
                var n = this.constructor, r = e.call(this, t) || this;
                return r.message = t, r.name = n.prototype.constructor.name, (0, i.setPrototypeOf)(r, n.prototype), 
                r;
            }
            return o.__extends(t, e), t;
        }(Error);
        t.SentryError = u;
    },
    "77a2": function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(r("5775"));
        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function a(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        var u = function() {
            function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = t.date, r = t.selected, o = t.startDate, a = t.endDate, u = t.range;
                i(this, e), this.date = this.getDate(n), this.selected = r || [], this.startDate = o, 
                this.endDate = a, this.range = u, this.multipleStatus = {
                    before: "",
                    after: "",
                    data: []
                }, this.weeks = {}, this._getWeek(this.date.fullDate);
            }
            return function(e, t, n) {
                t && a(e.prototype, t), n && a(e, n);
            }(e, [ {
                key: "getDate",
                value: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "day";
                    e || (e = new Date()), "object" !== (0, n.default)(e) && (e = e.replace(/-/g, "/"));
                    var o = new Date(e);
                    switch (r) {
                      case "day":
                        o.setDate(o.getDate() + t);
                        break;

                      case "month":
                        31 === o.getDate() ? o.setDate(o.getDate() + t) : o.setMonth(o.getMonth() + t);
                        break;

                      case "year":
                        o.setFullYear(o.getFullYear() + t);
                    }
                    var i = o.getFullYear(), a = o.getMonth() + 1 < 10 ? "0" + (o.getMonth() + 1) : o.getMonth() + 1, u = o.getDate() < 10 ? "0" + o.getDate() : o.getDate();
                    return {
                        fullDate: i + "-" + a + "-" + u,
                        year: i,
                        month: a,
                        date: u,
                        day: o.getDay()
                    };
                }
            }, {
                key: "_getLastMonthDays",
                value: function(e, t) {
                    for (var n = [], r = e; r > 0; r--) {
                        var o = new Date(t.year, t.month - 1, 1 - r).getDate();
                        n.push({
                            date: o,
                            month: t.month - 1,
                            lunar: this.getlunar(t.year, t.month - 1, o),
                            disable: !0
                        });
                    }
                    return n;
                }
            }, {
                key: "addOneDay",
                value: function(e) {
                    var t = new Date(e);
                    return t = +t + 864e5, (t = new Date(t)).getFullYear() + "-" + (t.getMonth() + 1) + "-" + t.getDate();
                }
            }, {
                key: "simpleDate",
                value: function(e) {
                    var t = e.split("-");
                    return t[1] = 1 == t[1].length ? "0" + t[1] : t[1], t[2] = 1 == t[2].length ? "0" + t[2] : t[2], 
                    t.join("-");
                }
            }, {
                key: "_activityDay",
                value: function(e, t) {
                    for (var n = [ e ], r = (new Date(t) - new Date(e)) / 864e5, o = 0; o < r; o++) {
                        var i = this.addOneDay(n[o]);
                        i = this.simpleDate(i), n.push(i);
                    }
                    return n;
                }
            }, {
                key: "_currentMonthDys",
                value: function(e, t) {
                    for (var n = this, r = [], o = this.date.fullDate, i = this.date.month, a = (this.date.year, 
                    this._activityDay("2021-11-22", "2021-12-12")), u = function(e) {
                        var u = t.year + "-" + (t.month, t.month + "-") + (e < 10 ? "0" + e : e), c = o === u, s = a.includes(u), f = n.selected && n.selected.find(function(e) {
                            if (n.dateEqual(u, e.date)) return e;
                        });
                        if (n.startDate) {
                            var l = n.dateCompare(n.startDate, o);
                            n.dateCompare(l ? n.startDate : o, u);
                        }
                        if (n.endDate) {
                            var p = n.dateCompare(o, n.endDate);
                            n.dateCompare(u, p ? n.endDate : o);
                        }
                        var d = n.multipleStatus.data, h = !1, v = -1;
                        n.range && (d && (v = d.findIndex(function(e) {
                            return n.dateEqual(e, u);
                        })), -1 !== v && (h = !0));
                        var g = {
                            fullDate: u,
                            year: t.year,
                            date: e,
                            multiple: !!n.range && h,
                            month: t.month,
                            lunar: n.getlunar(t.year, t.month, e),
                            disable: t.month != i,
                            isDay: c,
                            isActivity: s
                        };
                        f && (g.extraInfo = f), r.push(g);
                    }, c = 1; c <= e; c++) u(c);
                    return r;
                }
            }, {
                key: "_getNextMonthDays",
                value: function(e, t) {
                    for (var n = [], r = 1; r < e + 1; r++) n.push({
                        date: r,
                        month: Number(t.month) + 1,
                        lunar: this.getlunar(t.year, Number(t.month) + 1, r),
                        disable: !0
                    });
                    return n;
                }
            }, {
                key: "setDate",
                value: function(e) {
                    this._getWeek(e);
                }
            }, {
                key: "getInfo",
                value: function(e) {
                    var t = this;
                    return e || (e = new Date()), this.canlender.find(function(n) {
                        return n.fullDate === t.getDate(e).fullDate;
                    });
                }
            }, {
                key: "dateCompare",
                value: function(e, t) {
                    return (e = new Date(e.replace("-", "/").replace("-", "/"))) <= (t = new Date(t.replace("-", "/").replace("-", "/")));
                }
            }, {
                key: "dateEqual",
                value: function(e, t) {
                    return e = new Date(e.replace("-", "/").replace("-", "/")), t = new Date(t.replace("-", "/").replace("-", "/")), 
                    e.getTime() - t.getTime() == 0;
                }
            }, {
                key: "geDateAll",
                value: function(e, t) {
                    var n = [], r = e.split("-"), o = t.split("-"), i = new Date();
                    i.setFullYear(r[0], r[1] - 1, r[2]);
                    var a = new Date();
                    a.setFullYear(o[0], o[1] - 1, o[2]);
                    for (var u = i.getTime() - 864e5, c = a.getTime() - 864e5, s = u; s <= c; ) s += 864e5, 
                    n.push(this.getDate(new Date(parseInt(s))).fullDate);
                    return n;
                }
            }, {
                key: "getlunar",
                value: function(e, t, n) {
                    return o.default.solar2lunar(e, t, n);
                }
            }, {
                key: "setSelectInfo",
                value: function(e, t, n) {
                    return this.selected = t, this._getWeek(e), console.log(n), n;
                }
            }, {
                key: "setMultiple",
                value: function(e) {
                    var t = this.multipleStatus, n = t.before, r = t.after;
                    this.range && (n && r ? (this.multipleStatus.before = "", this.multipleStatus.after = "", 
                    this.multipleStatus.data = [], this._getWeek(e)) : n ? (this.multipleStatus.after = e, 
                    this.dateCompare(this.multipleStatus.before, this.multipleStatus.after) ? this.multipleStatus.data = this.geDateAll(this.multipleStatus.before, this.multipleStatus.after) : this.multipleStatus.data = this.geDateAll(this.multipleStatus.after, this.multipleStatus.before), 
                    this._getWeek(e)) : this.multipleStatus.before = e);
                }
            }, {
                key: "_getWeek",
                value: function(e) {
                    var t = this.getDate(e), n = (t.fullDate, t.year), r = t.month, o = (t.date, t.day, 
                    new Date(n, r - 1, 1).getDay()), i = new Date(n, r, 0).getDate(), a = {
                        lastMonthDays: this._getLastMonthDays(o, this.getDate(e)),
                        currentMonthDys: this._currentMonthDys(i, this.getDate(e)),
                        nextMonthDays: [],
                        weeks: []
                    }, u = [], c = 42 - (a.lastMonthDays.length + a.currentMonthDys.length);
                    a.nextMonthDays = this._getNextMonthDays(c, this.getDate(e)), u = u.concat(a.lastMonthDays, a.currentMonthDys, a.nextMonthDays);
                    for (var s = {}, f = 0; f < u.length; f++) f % 7 == 0 && (s[parseInt(f / 7)] = new Array(7)), 
                    s[parseInt(f / 7)][f % 7] = u[f];
                    this.canlender = u, this.weeks = s;
                }
            } ]), e;
        }();
        t.default = u;
    },
    7807: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.InboundFilters = void 0;
        var o = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = u();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("9ab4")), i = r("4820"), a = r("32f1");
        function u() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return u = function() {
                return e;
            }, e;
        }
        var c = [ /^Script error\.?$/, /^Javascript error: Script error\.? on line 0$/ ], s = function() {
            function e(t) {
                void 0 === t && (t = {}), this._options = t, this.name = e.id;
            }
            return e.prototype.setupOnce = function() {
                (0, i.addGlobalEventProcessor)(function(t) {
                    var n = (0, i.getCurrentHub)();
                    if (!n) return t;
                    var r = n.getIntegration(e);
                    if (r) {
                        var o = n.getClient(), a = o ? o.getOptions() : {}, u = r._mergeOptions(a);
                        if (r._shouldDropEvent(t, u)) return null;
                    }
                    return t;
                });
            }, e.prototype._shouldDropEvent = function(e, t) {
                return this._isSentryError(e, t) ? (a.logger.warn("Event dropped due to being internal Sentry Error.\nEvent: " + (0, 
                a.getEventDescription)(e)), !0) : this._isIgnoredError(e, t) ? (a.logger.warn("Event dropped due to being matched by `ignoreErrors` option.\nEvent: " + (0, 
                a.getEventDescription)(e)), !0) : this._isBlacklistedUrl(e, t) ? (a.logger.warn("Event dropped due to being matched by `blacklistUrls` option.\nEvent: " + (0, 
                a.getEventDescription)(e) + ".\nUrl: " + this._getEventFilterUrl(e)), !0) : !this._isWhitelistedUrl(e, t) && (a.logger.warn("Event dropped due to not being matched by `whitelistUrls` option.\nEvent: " + (0, 
                a.getEventDescription)(e) + ".\nUrl: " + this._getEventFilterUrl(e)), !0);
            }, e.prototype._isSentryError = function(e, t) {
                if (void 0 === t && (t = {}), !t.ignoreInternal) return !1;
                try {
                    return e && e.exception && e.exception.values && e.exception.values[0] && "SentryError" === e.exception.values[0].type || !1;
                } catch (e) {
                    return !1;
                }
            }, e.prototype._isIgnoredError = function(e, t) {
                return void 0 === t && (t = {}), !(!t.ignoreErrors || !t.ignoreErrors.length) && this._getPossibleEventMessages(e).some(function(e) {
                    return t.ignoreErrors.some(function(t) {
                        return (0, a.isMatchingPattern)(e, t);
                    });
                });
            }, e.prototype._isBlacklistedUrl = function(e, t) {
                if (void 0 === t && (t = {}), !t.blacklistUrls || !t.blacklistUrls.length) return !1;
                var n = this._getEventFilterUrl(e);
                return !!n && t.blacklistUrls.some(function(e) {
                    return (0, a.isMatchingPattern)(n, e);
                });
            }, e.prototype._isWhitelistedUrl = function(e, t) {
                if (void 0 === t && (t = {}), !t.whitelistUrls || !t.whitelistUrls.length) return !0;
                var n = this._getEventFilterUrl(e);
                return !n || t.whitelistUrls.some(function(e) {
                    return (0, a.isMatchingPattern)(n, e);
                });
            }, e.prototype._mergeOptions = function(e) {
                return void 0 === e && (e = {}), {
                    blacklistUrls: o.__spread(this._options.blacklistUrls || [], e.blacklistUrls || []),
                    ignoreErrors: o.__spread(this._options.ignoreErrors || [], e.ignoreErrors || [], c),
                    ignoreInternal: void 0 === this._options.ignoreInternal || this._options.ignoreInternal,
                    whitelistUrls: o.__spread(this._options.whitelistUrls || [], e.whitelistUrls || [])
                };
            }, e.prototype._getPossibleEventMessages = function(e) {
                if (e.message) return [ e.message ];
                if (e.exception) try {
                    var t = e.exception.values && e.exception.values[0] || {}, n = t.type, r = void 0 === n ? "" : n, o = t.value, i = void 0 === o ? "" : o;
                    return [ "" + i, r + ": " + i ];
                } catch (t) {
                    return a.logger.error("Cannot extract message for event " + (0, a.getEventDescription)(e)), 
                    [];
                }
                return [];
            }, e.prototype._getEventFilterUrl = function(e) {
                try {
                    if (e.stacktrace) {
                        var t = e.stacktrace.frames;
                        return t && t[t.length - 1].filename || null;
                    }
                    if (e.exception) {
                        var n = e.exception.values && e.exception.values[0].stacktrace && e.exception.values[0].stacktrace.frames;
                        return n && n[n.length - 1].filename || null;
                    }
                    return null;
                } catch (t) {
                    return a.logger.error("Cannot extract url for event " + (0, a.getEventDescription)(e)), 
                    null;
                }
            }, e.id = "InboundFilters", e;
        }();
        t.InboundFilters = s;
    },
    "7b45": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BaseTransport = void 0;
        var r = n("c6ce"), o = n("32f1"), i = function() {
            function e(e) {
                this.options = e, this._buffer = new o.PromiseBuffer(30), this.url = new r.API(this.options.dsn).getStoreEndpointWithUrlEncodedAuth();
            }
            return e.prototype.sendEvent = function(e) {
                throw new o.SentryError("Transport Class has to implement `sendEvent` method");
            }, e.prototype.close = function(e) {
                return this._buffer.drain(e);
            }, e;
        }();
        t.BaseTransport = i;
    },
    "7d86": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = i(n("eb5f")), o = i(n("234f"));
        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var a = {
            exchangeSave: function(e) {
                return (0, r.default)("post", "/api/wxapp/gift/exchangeSave", e, !1);
            },
            exchangeSaveTwo: function(e) {
                return (0, r.default)("post", "/api/wxapp/gift/exchangeSaveTwo", e);
            },
            mooncakeorderList: function(e) {
                return (0, r.default)("get", "/api/wxapp/order/mooncakeorderList", e);
            },
            addressList: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/address/list", e);
            },
            addressSave: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/address/save", e);
            },
            removeAddress: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/delivery/address/remove/".concat(e), t);
            },
            addressDetail: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/delivery/address/detail/".concat(e), t);
            },
            addressEdit: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/address/edit", e);
            },
            isShare: function(e) {
                return (0, r.default)("post", "/api/wxapp/memberPreheat/isShare", e, !1);
            },
            shareCard: function(e) {
                return (0, r.default)("post", "/api/wxapp/memberPreheat/share", e, !1);
            },
            getList: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    socialhubId: e.socialhubId
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("post", "/api/wxapp/ebuyGiftCard/getList", e, !1);
            },
            lifeCycleList: function(e) {
                return (0, r.default)("get", "/api/wxapp/coupon/lifeCycleList", e);
            },
            getcoupon: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/getcoupon", e, !1);
            },
            getScenceCoupon: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/getScenceCoupon", e, !1);
            },
            getCity: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, r.default)("get", "/api/wxapp/gift/getCity", e);
            },
            getCategorys: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, r.default)("get", "/api/wxapp/wish/getCategorys", e);
            },
            wishPublish: function(e) {
                return (0, r.default)("post", "/api/wxapp/wish/publish", e);
            },
            pagingView: function(e) {
                return (0, r.default)("post", "/api/wxapp/wish/pagingView", e);
            },
            detail: function(e) {
                return (0, r.default)("post", "/api/wxapp/wish/detail", e);
            },
            click: function(e) {
                return (0, r.default)("post", "/api/wxapp/wish/click", e);
            },
            thisTop20: function(e) {
                return (0, r.default)("post", "/api/wxapp/wish/thisTop20", e);
            },
            top100: function(e) {
                return (0, r.default)("post", "/api/wxapp/wish/top100", e);
            },
            lastTop20: function(e) {
                return (0, r.default)("post", "/api/wxapp/wish/lastTop20", e);
            },
            awardCapital: function(e) {
                return (0, r.default)("post", "/api/wxapp/wish/awardCapital", e);
            },
            getBillNo: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/deliveryMoonOrder/getBillNo/".concat(e), t);
            },
            awardDetail: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/wish/awardDetail/".concat(e), t);
            },
            getCityByRuleId: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/gift/getCityByRuleId/".concat(e), t);
            },
            moonGet: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, r.default)("get", "/api/wxapp/gift/moonGet", e);
            },
            findMoonRank: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/gift/findMoonRank/".concat(e), t);
            },
            saveMoonRank: function(e) {
                return (0, r.default)("post", "/api/wxapp/gift/saveMoonRank", e);
            }
        };
        t.default = a;
    },
    "7da8": function(e, t, n) {
        var r;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.FunctionToString = void 0;
        var o = function() {
            function e() {
                this.name = e.id;
            }
            return e.prototype.setupOnce = function() {
                r = Function.prototype.toString, Function.prototype.toString = function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    var n = this.__sentry_original__ || this;
                    return r.apply(n, e);
                };
            }, e.id = "FunctionToString", e;
        }();
        t.FunctionToString = o;
    },
    8021: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), Object.defineProperty(t, "FunctionToString", {
            enumerable: !0,
            get: function() {
                return r.FunctionToString;
            }
        }), Object.defineProperty(t, "InboundFilters", {
            enumerable: !0,
            get: function() {
                return o.InboundFilters;
            }
        });
        var r = n("7da8"), o = n("7807");
    },
    "807a": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.logger = void 0;
        var r = n("f658"), o = (0, r.getGlobalObject)(), i = "Sentry Logger ", a = function() {
            function e() {
                this._enabled = !1;
            }
            return e.prototype.disable = function() {
                this._enabled = !1;
            }, e.prototype.enable = function() {
                this._enabled = !0;
            }, e.prototype.log = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                this._enabled && (0, r.consoleSandbox)(function() {
                    o.console.log(i + "[Log]: " + e.join(" "));
                });
            }, e.prototype.warn = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                this._enabled && (0, r.consoleSandbox)(function() {
                    o.console.warn(i + "[Warn]: " + e.join(" "));
                });
            }, e.prototype.error = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                this._enabled && (0, r.consoleSandbox)(function() {
                    o.console.error(i + "[Error]: " + e.join(" "));
                });
            }, e;
        }();
        o.__SENTRY__ = o.__SENTRY__ || {};
        var u = o.__SENTRY__.logger || (o.__SENTRY__.logger = new a());
        t.logger = u;
    },
    "82a9": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.PromiseBuffer = void 0;
        var r = n("745c"), o = n("1819"), i = function() {
            function e(e) {
                this._limit = e, this._buffer = [];
            }
            return e.prototype.isReady = function() {
                return void 0 === this._limit || this.length() < this._limit;
            }, e.prototype.add = function(e) {
                var t = this;
                return this.isReady() ? (-1 === this._buffer.indexOf(e) && this._buffer.push(e), 
                e.then(function() {
                    return t.remove(e);
                }).then(null, function() {
                    return t.remove(e).then(null, function() {});
                }), e) : o.SyncPromise.reject(new r.SentryError("Not adding Promise due to buffer limit reached."));
            }, e.prototype.remove = function(e) {
                return this._buffer.splice(this._buffer.indexOf(e), 1)[0];
            }, e.prototype.length = function() {
                return this._buffer.length;
            }, e.prototype.drain = function(e) {
                var t = this;
                return new o.SyncPromise(function(n) {
                    var r = setTimeout(function() {
                        e && e > 0 && n(!1);
                    }, e);
                    o.SyncPromise.all(t._buffer).then(function() {
                        clearTimeout(r), n(!0);
                    }).then(null, function() {
                        n(!0);
                    });
                });
            }, e;
        }();
        t.PromiseBuffer = i;
    },
    "844c": function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BaseClient = void 0;
        var o = c(r("9ab4")), i = r("32f1"), a = r("3393");
        function u() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return u = function() {
                return e;
            }, e;
        }
        function c(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = u();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }
        var s = function() {
            function e(e, t) {
                this._integrations = {}, this._processing = !1, this._backend = new e(t), this._options = t, 
                t.dsn && (this._dsn = new i.Dsn(t.dsn));
            }
            return e.prototype.captureException = function(e, t, n) {
                var r = this, o = t && t.event_id;
                return this._processing = !0, this._getBackend().eventFromException(e, t).then(function(e) {
                    return r._processEvent(e, t, n);
                }).then(function(e) {
                    o = e && e.event_id, r._processing = !1;
                }).then(null, function(e) {
                    i.logger.error(e), r._processing = !1;
                }), o;
            }, e.prototype.captureMessage = function(e, t, n, r) {
                var o = this, a = n && n.event_id;
                return this._processing = !0, ((0, i.isPrimitive)(e) ? this._getBackend().eventFromMessage("" + e, t, n) : this._getBackend().eventFromException(e, n)).then(function(e) {
                    return o._processEvent(e, n, r);
                }).then(function(e) {
                    a = e && e.event_id, o._processing = !1;
                }).then(null, function(e) {
                    i.logger.error(e), o._processing = !1;
                }), a;
            }, e.prototype.captureEvent = function(e, t, n) {
                var r = this, o = t && t.event_id;
                return this._processing = !0, this._processEvent(e, t, n).then(function(e) {
                    o = e && e.event_id, r._processing = !1;
                }).then(null, function(e) {
                    i.logger.error(e), r._processing = !1;
                }), o;
            }, e.prototype.getDsn = function() {
                return this._dsn;
            }, e.prototype.getOptions = function() {
                return this._options;
            }, e.prototype.flush = function(e) {
                var t = this;
                return this._isClientProcessing(e).then(function(n) {
                    return clearInterval(n.interval), t._getBackend().getTransport().close(e).then(function(e) {
                        return n.ready && e;
                    });
                });
            }, e.prototype.close = function(e) {
                var t = this;
                return this.flush(e).then(function(e) {
                    return t.getOptions().enabled = !1, e;
                });
            }, e.prototype.setupIntegrations = function() {
                this._isEnabled() && (this._integrations = (0, a.setupIntegrations)(this._options));
            }, e.prototype.getIntegration = function(e) {
                try {
                    return this._integrations[e.id] || null;
                } catch (t) {
                    return i.logger.warn("Cannot retrieve integration " + e.id + " from the current Client"), 
                    null;
                }
            }, e.prototype._isClientProcessing = function(e) {
                var t = this;
                return new i.SyncPromise(function(n) {
                    var r = 0, o = 0;
                    clearInterval(o), o = setInterval(function() {
                        t._processing ? (r += 1, e && r >= e && n({
                            interval: o,
                            ready: !1
                        })) : n({
                            interval: o,
                            ready: !0
                        });
                    }, 1);
                });
            }, e.prototype._getBackend = function() {
                return this._backend;
            }, e.prototype._isEnabled = function() {
                return !1 !== this.getOptions().enabled && void 0 !== this._dsn;
            }, e.prototype._prepareEvent = function(e, t, n) {
                var r = this, a = this.getOptions(), u = a.environment, c = a.release, s = a.dist, f = a.maxValueLength, l = void 0 === f ? 250 : f, p = a.normalizeDepth, d = void 0 === p ? 3 : p, h = o.__assign({}, e);
                void 0 === h.environment && void 0 !== u && (h.environment = u), void 0 === h.release && void 0 !== c && (h.release = c), 
                void 0 === h.dist && void 0 !== s && (h.dist = s), h.message && (h.message = (0, 
                i.truncate)(h.message, l));
                var v = h.exception && h.exception.values && h.exception.values[0];
                v && v.value && (v.value = (0, i.truncate)(v.value, l));
                var g = h.request;
                g && g.url && (g.url = (0, i.truncate)(g.url, l)), void 0 === h.event_id && (h.event_id = n && n.event_id ? n.event_id : (0, 
                i.uuid4)()), this._addIntegrations(h.sdk);
                var y = i.SyncPromise.resolve(h);
                return t && (y = t.applyToEvent(h, n)), y.then(function(e) {
                    return "number" == typeof d && d > 0 ? r._normalizeEvent(e, d) : e;
                });
            }, e.prototype._normalizeEvent = function(e, t) {
                return e ? o.__assign({}, e, e.breadcrumbs && {
                    breadcrumbs: e.breadcrumbs.map(function(e) {
                        return o.__assign({}, e, e.data && {
                            data: (0, i.normalize)(e.data, t)
                        });
                    })
                }, e.user && {
                    user: (0, i.normalize)(e.user, t)
                }, e.contexts && {
                    contexts: (0, i.normalize)(e.contexts, t)
                }, e.extra && {
                    extra: (0, i.normalize)(e.extra, t)
                }) : null;
            }, e.prototype._addIntegrations = function(e) {
                var t = Object.keys(this._integrations);
                e && t.length > 0 && (e.integrations = t);
            }, e.prototype._processEvent = function(e, t, n) {
                var r = this, o = this.getOptions(), a = o.beforeSend, u = o.sampleRate;
                return this._isEnabled() ? "number" == typeof u && Math.random() > u ? i.SyncPromise.reject("This event has been sampled, will not send event.") : new i.SyncPromise(function(o, u) {
                    r._prepareEvent(e, n, t).then(function(e) {
                        if (null !== e) {
                            var n = e;
                            if (t && t.data && !0 === t.data.__sentry__ || !a) return r._getBackend().sendEvent(n), 
                            void o(n);
                            var c = a(e, t);
                            if (void 0 === c) i.logger.error("`beforeSend` method has to return `null` or a valid event."); else if ((0, 
                            i.isThenable)(c)) r._handleAsyncBeforeSend(c, o, u); else {
                                if (null === (n = c)) return i.logger.log("`beforeSend` returned `null`, will not send event."), 
                                void o(null);
                                r._getBackend().sendEvent(n), o(n);
                            }
                        } else u("An event processor returned null, will not send event.");
                    }).then(null, function(e) {
                        r.captureException(e, {
                            data: {
                                __sentry__: !0
                            },
                            originalException: e
                        }), u("Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.\nReason: " + e);
                    });
                }) : i.SyncPromise.reject("SDK not enabled, will not send event.");
            }, e.prototype._handleAsyncBeforeSend = function(e, t, n) {
                var r = this;
                e.then(function(e) {
                    null !== e ? (r._getBackend().sendEvent(e), t(e)) : n("`beforeSend` returned `null`, will not send event.");
                }).then(null, function(e) {
                    n("beforeSend rejected with " + e);
                });
            }, e;
        }();
        t.BaseClient = s;
    },
    "84f2": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), Object.defineProperty(t, "GlobalHandlers", {
            enumerable: !0,
            get: function() {
                return r.GlobalHandlers;
            }
        }), Object.defineProperty(t, "TryCatch", {
            enumerable: !0,
            get: function() {
                return o.TryCatch;
            }
        }), Object.defineProperty(t, "LinkedErrors", {
            enumerable: !0,
            get: function() {
                return i.LinkedErrors;
            }
        }), Object.defineProperty(t, "System", {
            enumerable: !0,
            get: function() {
                return a.System;
            }
        }), Object.defineProperty(t, "Router", {
            enumerable: !0,
            get: function() {
                return u.Router;
            }
        }), Object.defineProperty(t, "IgnoreMpcrawlerErrors", {
            enumerable: !0,
            get: function() {
                return c.IgnoreMpcrawlerErrors;
            }
        });
        var r = n("4c2a"), o = n("1096"), i = n("1f13"), a = n("0afe"), u = n("3119"), c = n("2fce");
    },
    "938b": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.computeStackTrace = function(e) {
            var t = null, n = e && e.framesToPop;
            try {
                if (t = function(e) {
                    if (!e || !e.stacktrace) return null;
                    for (var t, n = e.stacktrace, r = / line (\d+).*script (?:in )?(\S+)(?:: in function (\S+))?$/i, i = / line (\d+), column (\d+)\s*(?:in (?:<anonymous function: ([^>]+)>|([^\)]+))\((.*)\))? in (.*):\s*$/i, a = n.split("\n"), u = [], c = 0; c < a.length; c += 2) {
                        var s = null;
                        (t = r.exec(a[c])) ? s = {
                            url: t[2],
                            func: t[3],
                            args: [],
                            line: +t[1],
                            column: null
                        } : (t = i.exec(a[c])) && (s = {
                            url: t[6],
                            func: t[3] || t[4],
                            args: t[5] ? t[5].split(",") : [],
                            line: +t[1],
                            column: +t[2]
                        }), s && (!s.func && s.line && (s.func = o), u.push(s));
                    }
                    return u.length ? {
                        message: p(e),
                        name: e.name,
                        stack: u
                    } : null;
                }(e)) return l(t, n);
            } catch (e) {}
            try {
                if (t = function(e) {
                    if (!e || !e.stack) return null;
                    for (var t, n, r, l = [], d = e.stack.split("\n"), h = 0; h < d.length; ++h) {
                        if (n = i.exec(d[h])) {
                            var v = n[2] && 0 === n[2].indexOf("native");
                            n[2] && 0 === n[2].indexOf("eval") && (t = s.exec(n[2])) && (n[2] = t[1], n[3] = t[2], 
                            n[4] = t[3]), r = {
                                url: n[2],
                                func: n[1] || o,
                                args: v ? [ n[2] ] : [],
                                line: n[3] ? +n[3] : null,
                                column: n[4] ? +n[4] : null
                            };
                        } else if (n = u.exec(d[h])) r = {
                            url: n[2],
                            func: n[1] || o,
                            args: [],
                            line: +n[3],
                            column: n[4] ? +n[4] : null
                        }; else if (n = a.exec(d[h])) n[3] && n[3].indexOf(" > eval") > -1 && (t = c.exec(n[3])) ? (n[1] = n[1] || "eval", 
                        n[3] = t[1], n[4] = t[2], n[5] = "") : 0 !== h || n[5] || void 0 === e.columnNumber || (l[0].column = e.columnNumber + 1), 
                        r = {
                            url: n[3],
                            func: n[1] || o,
                            args: n[2] ? n[2].split(",") : [],
                            line: n[4] ? +n[4] : null,
                            column: n[5] ? +n[5] : null
                        }; else {
                            if (!(n = f.exec(d[h]))) continue;
                            r = {
                                url: n[2],
                                func: n[1] || o,
                                args: [],
                                line: n[3] ? +n[3] : null,
                                column: n[4] ? +n[4] : null
                            };
                        }
                        !r.func && r.line && (r.func = o), l.push(r);
                    }
                    return l.length ? {
                        message: p(e),
                        name: e.name,
                        stack: l
                    } : null;
                }(e)) return l(t, n);
            } catch (e) {}
            return {
                message: p(e),
                name: e && e.name,
                stack: [],
                failed: !0
            };
        };
        var r = n("9ab4"), o = "?", i = /^\s*at (?:(.*?) ?\()?((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|[-a-z]+:|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, a = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:file|https?|blob|chrome|webpack|resource|moz-extension).*?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js))(?::(\d+))?(?::(\d+))?\s*$/i, u = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i, c = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, s = /\((\S*)(?::(\d+))(?::(\d+))\)/, f = /^\s*at (\w.*) \((\w*.js):(\d*):(\d*)/i;
        function l(e, t) {
            try {
                return (0, r.__assign)((0, r.__assign)({}, e), {
                    stack: e.stack.slice(t)
                });
            } catch (t) {
                return e;
            }
        }
        function p(e) {
            var t = e && e.message;
            return t ? t.error && "string" == typeof t.error.message ? t.error.message : t : "No error message";
        }
    },
    "93f4": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            signIn: function(e) {
                return (0, r.default)("post", "/api/wxapp/daily/signIn", e);
            },
            signInSearch: function(e) {
                return (0, r.default)("get", "/api/wxapp/daily/signInSearch", e, !1);
            },
            warnConfig: function(e) {
                return (0, r.default)("post", "/api/wxapp//daily/warnConfig", e, !1);
            }
        };
        t.default = o;
    },
    "94a1": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.XHRTransport = void 0;
        var r = n("9ab4"), o = n("507c"), i = n("6916"), a = function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this;
            }
            return (0, r.__extends)(t, e), t.prototype.sendEvent = function(e) {
                var t = this, n = i.sdk.request || i.sdk.httpRequest;
                return this._buffer.add(new Promise(function(r, i) {
                    n({
                        url: t.url,
                        method: "POST",
                        data: JSON.stringify(e),
                        header: {
                            "content-type": "application/json"
                        },
                        success: function(e) {
                            r({
                                status: o.Status.fromHttpCode(e.statusCode)
                            });
                        },
                        fail: function(e) {
                            i(e);
                        }
                    });
                }));
            }, t;
        }(n("7b45").BaseTransport);
        t.XHRTransport = a;
    },
    "95c7": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.setPrototypeOf = void 0;
        var r = Object.setPrototypeOf || ({
            __proto__: []
        } instanceof Array ? function(e, t) {
            return e.__proto__ = t, e;
        } : function(e, t) {
            for (var n in t) e.hasOwnProperty(n) || (e[n] = t[n]);
            return e;
        });
        t.setPrototypeOf = r;
    },
    "96cf": function(e, t) {
        !function(t) {
            var r, o = Object.prototype, i = o.hasOwnProperty, a = "function" == typeof Symbol ? Symbol : {}, u = a.iterator || "@@iterator", c = a.asyncIterator || "@@asyncIterator", s = a.toStringTag || "@@toStringTag", f = "object" === (0, 
            n.default)(e), l = t.regeneratorRuntime;
            if (l) f && (e.exports = l); else {
                (l = t.regeneratorRuntime = f ? e.exports : {}).wrap = w;
                var p = "suspendedStart", d = "suspendedYield", h = "executing", v = "completed", g = {}, y = {};
                y[u] = function() {
                    return this;
                };
                var b = Object.getPrototypeOf, m = b && b(b(D([])));
                m && m !== o && i.call(m, u) && (y = m);
                var _ = E.prototype = O.prototype = Object.create(y);
                S.prototype = _.constructor = E, E.constructor = S, E[s] = S.displayName = "GeneratorFunction", 
                l.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === S || "GeneratorFunction" === (t.displayName || t.name));
                }, l.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, E) : (e.__proto__ = E, s in e || (e[s] = "GeneratorFunction")), 
                    e.prototype = Object.create(_), e;
                }, l.awrap = function(e) {
                    return {
                        __await: e
                    };
                }, k(P.prototype), P.prototype[c] = function() {
                    return this;
                }, l.AsyncIterator = P, l.async = function(e, t, n, r) {
                    var o = new P(w(e, t, n, r));
                    return l.isGeneratorFunction(t) ? o : o.next().then(function(e) {
                        return e.done ? e.value : o.next();
                    });
                }, k(_), _[s] = "Generator", _[u] = function() {
                    return this;
                }, _.toString = function() {
                    return "[object Generator]";
                }, l.keys = function(e) {
                    var t = [];
                    for (var n in e) t.push(n);
                    return t.reverse(), function n() {
                        for (;t.length; ) {
                            var r = t.pop();
                            if (r in e) return n.value = r, n.done = !1, n;
                        }
                        return n.done = !0, n;
                    };
                }, l.values = D, T.prototype = {
                    constructor: T,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = r, this.done = !1, this.delegate = null, 
                        this.method = "next", this.arg = r, this.tryEntries.forEach(C), !e) for (var t in this) "t" === t.charAt(0) && i.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = r);
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval;
                    },
                    dispatchException: function(e) {
                        if (this.done) throw e;
                        var t = this;
                        function n(n, o) {
                            return u.type = "throw", u.arg = e, t.next = n, o && (t.method = "next", t.arg = r), 
                            !!o;
                        }
                        for (var o = this.tryEntries.length - 1; o >= 0; --o) {
                            var a = this.tryEntries[o], u = a.completion;
                            if ("root" === a.tryLoc) return n("end");
                            if (a.tryLoc <= this.prev) {
                                var c = i.call(a, "catchLoc"), s = i.call(a, "finallyLoc");
                                if (c && s) {
                                    if (this.prev < a.catchLoc) return n(a.catchLoc, !0);
                                    if (this.prev < a.finallyLoc) return n(a.finallyLoc);
                                } else if (c) {
                                    if (this.prev < a.catchLoc) return n(a.catchLoc, !0);
                                } else {
                                    if (!s) throw new Error("try statement without catch or finally");
                                    if (this.prev < a.finallyLoc) return n(a.finallyLoc);
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                            var r = this.tryEntries[n];
                            if (r.tryLoc <= this.prev && i.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                                var o = r;
                                break;
                            }
                        }
                        o && ("break" === e || "continue" === e) && o.tryLoc <= t && t <= o.finallyLoc && (o = null);
                        var a = o ? o.completion : {};
                        return a.type = e, a.arg = t, o ? (this.method = "next", this.next = o.finallyLoc, 
                        g) : this.complete(a);
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, 
                        this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), 
                        g;
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), C(n), g;
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var n = this.tryEntries[t];
                            if (n.tryLoc === e) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var o = r.arg;
                                    C(n);
                                }
                                return o;
                            }
                        }
                        throw new Error("illegal catch attempt");
                    },
                    delegateYield: function(e, t, n) {
                        return this.delegate = {
                            iterator: D(e),
                            resultName: t,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = r), g;
                    }
                };
            }
            function w(e, t, n, r) {
                var o = t && t.prototype instanceof O ? t : O, i = Object.create(o.prototype), a = new T(r || []);
                return i._invoke = function(e, t, n) {
                    var r = p;
                    return function(o, i) {
                        if (r === h) throw new Error("Generator is already running");
                        if (r === v) {
                            if ("throw" === o) throw i;
                            return M();
                        }
                        for (n.method = o, n.arg = i; ;) {
                            var a = n.delegate;
                            if (a) {
                                var u = j(a, n);
                                if (u) {
                                    if (u === g) continue;
                                    return u;
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg; else if ("throw" === n.method) {
                                if (r === p) throw r = v, n.arg;
                                n.dispatchException(n.arg);
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = h;
                            var c = x(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? v : d, c.arg === g) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                };
                            }
                            "throw" === c.type && (r = v, n.method = "throw", n.arg = c.arg);
                        }
                    };
                }(e, n, a), i;
            }
            function x(e, t, n) {
                try {
                    return {
                        type: "normal",
                        arg: e.call(t, n)
                    };
                } catch (e) {
                    return {
                        type: "throw",
                        arg: e
                    };
                }
            }
            function O() {}
            function S() {}
            function E() {}
            function k(e) {
                [ "next", "throw", "return" ].forEach(function(t) {
                    e[t] = function(e) {
                        return this._invoke(t, e);
                    };
                });
            }
            function P(e) {
                function t(r, o, a, u) {
                    var c = x(e[r], e, o);
                    if ("throw" !== c.type) {
                        var s = c.arg, f = s.value;
                        return f && "object" === (0, n.default)(f) && i.call(f, "__await") ? Promise.resolve(f.__await).then(function(e) {
                            t("next", e, a, u);
                        }, function(e) {
                            t("throw", e, a, u);
                        }) : Promise.resolve(f).then(function(e) {
                            s.value = e, a(s);
                        }, function(e) {
                            return t("throw", e, a, u);
                        });
                    }
                    u(c.arg);
                }
                var r;
                this._invoke = function(e, n) {
                    function o() {
                        return new Promise(function(r, o) {
                            t(e, n, r, o);
                        });
                    }
                    return r = r ? r.then(o, o) : o();
                };
            }
            function j(e, t) {
                var n = e.iterator[t.method];
                if (n === r) {
                    if (t.delegate = null, "throw" === t.method) {
                        if (e.iterator.return && (t.method = "return", t.arg = r, j(e, t), "throw" === t.method)) return g;
                        t.method = "throw", t.arg = new TypeError("The iterator does not provide a 'throw' method");
                    }
                    return g;
                }
                var o = x(n, e.iterator, t.arg);
                if ("throw" === o.type) return t.method = "throw", t.arg = o.arg, t.delegate = null, 
                g;
                var i = o.arg;
                return i ? i.done ? (t[e.resultName] = i.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", 
                t.arg = r), t.delegate = null, g) : i : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), 
                t.delegate = null, g);
            }
            function A(e) {
                var t = {
                    tryLoc: e[0]
                };
                1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), 
                this.tryEntries.push(t);
            }
            function C(e) {
                var t = e.completion || {};
                t.type = "normal", delete t.arg, e.completion = t;
            }
            function T(e) {
                this.tryEntries = [ {
                    tryLoc: "root"
                } ], e.forEach(A, this), this.reset(!0);
            }
            function D(e) {
                if (e) {
                    var t = e[u];
                    if (t) return t.call(e);
                    if ("function" == typeof e.next) return e;
                    if (!isNaN(e.length)) {
                        var n = -1, o = function t() {
                            for (;++n < e.length; ) if (i.call(e, n)) return t.value = e[n], t.done = !1, t;
                            return t.value = r, t.done = !0, t;
                        };
                        return o.next = o;
                    }
                }
                return {
                    next: M
                };
            }
            function M() {
                return {
                    value: r,
                    done: !0
                };
            }
        }(function() {
            return this || "object" === ("undefined" == typeof self ? "undefined" : (0, n.default)(self)) && self;
        }() || Function("return this")());
    },
    "9ab4": function(e, t, r) {
        r.r(t), r.d(t, "__extends", function() {
            return i;
        }), r.d(t, "__assign", function() {
            return a;
        }), r.d(t, "__rest", function() {
            return u;
        }), r.d(t, "__decorate", function() {
            return c;
        }), r.d(t, "__param", function() {
            return s;
        }), r.d(t, "__metadata", function() {
            return f;
        }), r.d(t, "__awaiter", function() {
            return l;
        }), r.d(t, "__generator", function() {
            return p;
        }), r.d(t, "__createBinding", function() {
            return d;
        }), r.d(t, "__exportStar", function() {
            return h;
        }), r.d(t, "__values", function() {
            return v;
        }), r.d(t, "__read", function() {
            return g;
        }), r.d(t, "__spread", function() {
            return y;
        }), r.d(t, "__spreadArrays", function() {
            return b;
        }), r.d(t, "__await", function() {
            return m;
        }), r.d(t, "__asyncGenerator", function() {
            return _;
        }), r.d(t, "__asyncDelegator", function() {
            return w;
        }), r.d(t, "__asyncValues", function() {
            return x;
        }), r.d(t, "__makeTemplateObject", function() {
            return O;
        }), r.d(t, "__importStar", function() {
            return S;
        }), r.d(t, "__importDefault", function() {
            return E;
        }), r.d(t, "__classPrivateFieldGet", function() {
            return k;
        }), r.d(t, "__classPrivateFieldSet", function() {
            return P;
        });
        /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.
    
    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.
    
    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */        var o = function(e, t) {
            return (o = Object.setPrototypeOf || {
                __proto__: []
            } instanceof Array && function(e, t) {
                e.__proto__ = t;
            } || function(e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
            })(e, t);
        };
        function i(e, t) {
            function n() {
                this.constructor = e;
            }
            o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, 
            new n());
        }
        var a = function() {
            return (a = Object.assign || function(e) {
                for (var t, n = 1, r = arguments.length; n < r; n++) for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                return e;
            }).apply(this, arguments);
        };
        function u(e, t) {
            var n = {};
            for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
            if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                var o = 0;
                for (r = Object.getOwnPropertySymbols(e); o < r.length; o++) t.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
            }
            return n;
        }
        function c(e, t, r, o) {
            var i, a = arguments.length, u = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : (0, n.default)(Reflect)) && "function" == typeof Reflect.decorate) u = Reflect.decorate(e, t, r, o); else for (var c = e.length - 1; c >= 0; c--) (i = e[c]) && (u = (a < 3 ? i(u) : a > 3 ? i(t, r, u) : i(t, r)) || u);
            return a > 3 && u && Object.defineProperty(t, r, u), u;
        }
        function s(e, t) {
            return function(n, r) {
                t(n, r, e);
            };
        }
        function f(e, t) {
            if ("object" === ("undefined" == typeof Reflect ? "undefined" : (0, n.default)(Reflect)) && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
        }
        function l(e, t, n, r) {
            function o(e) {
                return e instanceof n ? e : new n(function(t) {
                    t(e);
                });
            }
            return new (n || (n = Promise))(function(n, i) {
                function a(e) {
                    try {
                        c(r.next(e));
                    } catch (e) {
                        i(e);
                    }
                }
                function u(e) {
                    try {
                        c(r.throw(e));
                    } catch (e) {
                        i(e);
                    }
                }
                function c(e) {
                    e.done ? n(e.value) : o(e.value).then(a, u);
                }
                c((r = r.apply(e, t || [])).next());
            });
        }
        function p(e, t) {
            var n, r, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0]) throw o[1];
                    return o[1];
                },
                trys: [],
                ops: []
            };
            return i = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                return this;
            }), i;
            function u(e) {
                return function(t) {
                    return c([ e, t ]);
                };
            }
            function c(i) {
                if (n) throw new TypeError("Generator is already executing.");
                for (;a; ) try {
                    if (n = 1, r && (o = 2 & i[0] ? r.return : i[0] ? r.throw || ((o = r.return) && o.call(r), 
                    0) : r.next) && !(o = o.call(r, i[1])).done) return o;
                    switch (r = 0, o && (i = [ 2 & i[0], o.value ]), i[0]) {
                      case 0:
                      case 1:
                        o = i;
                        break;

                      case 4:
                        return a.label++, {
                            value: i[1],
                            done: !1
                        };

                      case 5:
                        a.label++, r = i[1], i = [ 0 ];
                        continue;

                      case 7:
                        i = a.ops.pop(), a.trys.pop();
                        continue;

                      default:
                        if (!(o = (o = a.trys).length > 0 && o[o.length - 1]) && (6 === i[0] || 2 === i[0])) {
                            a = 0;
                            continue;
                        }
                        if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                            a.label = i[1];
                            break;
                        }
                        if (6 === i[0] && a.label < o[1]) {
                            a.label = o[1], o = i;
                            break;
                        }
                        if (o && a.label < o[2]) {
                            a.label = o[2], a.ops.push(i);
                            break;
                        }
                        o[2] && a.ops.pop(), a.trys.pop();
                        continue;
                    }
                    i = t.call(e, a);
                } catch (e) {
                    i = [ 6, e ], r = 0;
                } finally {
                    n = o = 0;
                }
                if (5 & i[0]) throw i[1];
                return {
                    value: i[0] ? i[1] : void 0,
                    done: !0
                };
            }
        }
        function d(e, t, n, r) {
            void 0 === r && (r = n), e[r] = t[n];
        }
        function h(e, t) {
            for (var n in e) "default" === n || t.hasOwnProperty(n) || (t[n] = e[n]);
        }
        function v(e) {
            var t = "function" == typeof Symbol && Symbol.iterator, n = t && e[t], r = 0;
            if (n) return n.call(e);
            if (e && "number" == typeof e.length) return {
                next: function() {
                    return e && r >= e.length && (e = void 0), {
                        value: e && e[r++],
                        done: !e
                    };
                }
            };
            throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
        }
        function g(e, t) {
            var n = "function" == typeof Symbol && e[Symbol.iterator];
            if (!n) return e;
            var r, o, i = n.call(e), a = [];
            try {
                for (;(void 0 === t || t-- > 0) && !(r = i.next()).done; ) a.push(r.value);
            } catch (e) {
                o = {
                    error: e
                };
            } finally {
                try {
                    r && !r.done && (n = i.return) && n.call(i);
                } finally {
                    if (o) throw o.error;
                }
            }
            return a;
        }
        function y() {
            for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(g(arguments[t]));
            return e;
        }
        function b() {
            for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
            var r = Array(e), o = 0;
            for (t = 0; t < n; t++) for (var i = arguments[t], a = 0, u = i.length; a < u; a++, 
            o++) r[o] = i[a];
            return r;
        }
        function m(e) {
            return this instanceof m ? (this.v = e, this) : new m(e);
        }
        function _(e, t, n) {
            if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
            var r, o = n.apply(e, t || []), i = [];
            return r = {}, a("next"), a("throw"), a("return"), r[Symbol.asyncIterator] = function() {
                return this;
            }, r;
            function a(e) {
                o[e] && (r[e] = function(t) {
                    return new Promise(function(n, r) {
                        i.push([ e, t, n, r ]) > 1 || u(e, t);
                    });
                });
            }
            function u(e, t) {
                try {
                    !function(e) {
                        e.value instanceof m ? Promise.resolve(e.value.v).then(c, s) : f(i[0][2], e);
                    }(o[e](t));
                } catch (e) {
                    f(i[0][3], e);
                }
            }
            function c(e) {
                u("next", e);
            }
            function s(e) {
                u("throw", e);
            }
            function f(e, t) {
                e(t), i.shift(), i.length && u(i[0][0], i[0][1]);
            }
        }
        function w(e) {
            var t, n;
            return t = {}, r("next"), r("throw", function(e) {
                throw e;
            }), r("return"), t[Symbol.iterator] = function() {
                return this;
            }, t;
            function r(r, o) {
                t[r] = e[r] ? function(t) {
                    return (n = !n) ? {
                        value: m(e[r](t)),
                        done: "return" === r
                    } : o ? o(t) : t;
                } : o;
            }
        }
        function x(e) {
            if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
            var t, n = e[Symbol.asyncIterator];
            return n ? n.call(e) : (e = v(e), t = {}, r("next"), r("throw"), r("return"), t[Symbol.asyncIterator] = function() {
                return this;
            }, t);
            function r(n) {
                t[n] = e[n] && function(t) {
                    return new Promise(function(r, o) {
                        (function(e, t, n, r) {
                            Promise.resolve(r).then(function(t) {
                                e({
                                    value: t,
                                    done: n
                                });
                            }, t);
                        })(r, o, (t = e[n](t)).done, t.value);
                    });
                };
            }
        }
        function O(e, t) {
            return Object.defineProperty ? Object.defineProperty(e, "raw", {
                value: t
            }) : e.raw = t, e;
        }
        function S(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.default = e, t;
        }
        function E(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function k(e, t) {
            if (!t.has(e)) throw new TypeError("attempted to get private field on non-instance");
            return t.get(e);
        }
        function P(e, t, n) {
            if (!t.has(e)) throw new TypeError("attempted to set private field on non-instance");
            return t.set(e, n), n;
        }
    },
    a34a: function(e, t, n) {
        e.exports = n("bbdd");
    },
    aa8c: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        t.default = {
            cityArrMoon: [ {
                id: 1,
                name: "上海",
                codeSn: "021"
            }, {
                id: 2,
                name: "苏州",
                codeSn: "512"
            }, {
                id: 3,
                name: "常熟",
                codeSn: "610"
            }, {
                id: 4,
                name: "无锡",
                codeSn: "510"
            }, {
                id: 5,
                name: "张家港",
                codeSn: "608"
            }, {
                id: 6,
                name: "南通",
                codeSn: "513"
            }, {
                id: 7,
                name: "常州",
                codeSn: "519"
            }, {
                id: 8,
                name: "昆山",
                codeSn: "609"
            }, {
                id: 9,
                name: "扬州",
                codeSn: "514"
            }, {
                id: 10,
                name: "南京",
                codeSn: "025"
            }, {
                id: 11,
                name: "徐州",
                codeSn: "516"
            }, {
                id: 12,
                name: "济南",
                codeSn: "531"
            }, {
                id: 13,
                name: "淄博",
                codeSn: "533"
            }, {
                id: 14,
                name: "潍坊",
                codeSn: "536"
            }, {
                id: 15,
                name: "青岛",
                codeSn: "532"
            }, {
                id: 16,
                name: "烟台",
                codeSn: "535"
            }, {
                id: 17,
                name: "威海",
                codeSn: "631"
            }, {
                id: 18,
                name: "东营",
                codeSn: "546"
            }, {
                id: 19,
                name: "临沂",
                codeSn: "539"
            }, {
                id: 20,
                name: "温州",
                codeSn: "577"
            }, {
                id: 21,
                name: "杭州",
                codeSn: "571"
            }, {
                id: 22,
                name: "湖州",
                codeSn: "572"
            }, {
                id: 23,
                name: "嘉兴",
                codeSn: "573"
            }, {
                id: 24,
                name: "宁波",
                codeSn: "574"
            }, {
                id: 25,
                name: "绍兴",
                codeSn: "575"
            }, {
                id: 26,
                name: "上虞",
                codeSn: "603"
            }, {
                id: 27,
                name: "合肥",
                codeSn: "551"
            }, {
                id: 28,
                name: "西安",
                codeSn: "029"
            }, {
                id: 29,
                name: "兰州",
                codeSn: "931"
            }, {
                id: 30,
                name: "西宁",
                codeSn: "971"
            }, {
                id: 31,
                name: "郑州",
                codeSn: "371"
            }, {
                id: 32,
                name: "太原",
                codeSn: "351"
            }, {
                id: 33,
                name: "洛阳",
                codeSn: "379"
            }, {
                id: 34,
                name: "北京",
                codeSn: "010"
            }, {
                id: 35,
                name: "天津",
                codeSn: "022"
            }, {
                id: 36,
                name: "沈阳",
                codeSn: "024"
            }, {
                id: 37,
                name: "丹东",
                codeSn: "415"
            }, {
                id: 38,
                name: "抚顺",
                codeSn: "413"
            }, {
                id: 39,
                name: "大连",
                codeSn: "411"
            }, {
                id: 40,
                name: "长春",
                codeSn: "431"
            }, {
                id: 41,
                name: "吉林",
                codeSn: "432"
            }, {
                id: 42,
                name: "石家庄",
                codeSn: "311"
            }, {
                id: 43,
                name: "保定",
                codeSn: "312"
            }, {
                id: 44,
                name: "唐山",
                codeSn: "315"
            }, {
                id: 45,
                name: "哈尔滨",
                codeSn: "451"
            }, {
                id: 46,
                name: "呼和浩特",
                codeSn: "471"
            }, {
                id: 47,
                name: "包头",
                codeSn: "472"
            }, {
                id: 48,
                name: "南昌",
                codeSn: "791"
            }, {
                id: 49,
                name: "赣州",
                codeSn: "797"
            }, {
                id: 50,
                name: "成都",
                codeSn: "028"
            }, {
                id: 51,
                name: "绵阳",
                codeSn: "816"
            }, {
                id: 52,
                name: "海口",
                codeSn: "898"
            }, {
                id: 53,
                name: "三亚",
                codeSn: "899"
            }, {
                id: 54,
                name: "重庆",
                codeSn: "023"
            }, {
                id: 55,
                name: "贵阳",
                codeSn: "851"
            }, {
                id: 56,
                name: "昆明",
                codeSn: "871"
            }, {
                id: 57,
                name: "武汉",
                codeSn: "027"
            }, {
                id: 58,
                name: "宜昌",
                codeSn: "717"
            }, {
                id: 59,
                name: "长沙",
                codeSn: "731"
            }, {
                id: 61,
                name: "湘潭",
                codeSn: "602"
            }, {
                id: 62,
                name: "广州",
                codeSn: "020"
            }, {
                id: 63,
                name: "珠海",
                codeSn: "756"
            }, {
                id: 64,
                name: "佛山",
                codeSn: "757"
            }, {
                id: 65,
                name: "深圳",
                codeSn: "755"
            }, {
                id: 66,
                name: "东莞",
                codeSn: "769"
            }, {
                id: 67,
                name: "汕头",
                codeSn: "754"
            }, {
                id: 68,
                name: "泉州",
                codeSn: "595"
            }, {
                id: 69,
                name: "晋江",
                codeSn: "601"
            }, {
                id: 70,
                name: "福州",
                codeSn: "591"
            }, {
                id: 71,
                name: "厦门",
                codeSn: "592"
            }, {
                id: 72,
                name: "江门",
                codeSn: "750"
            }, {
                id: 73,
                name: "九江",
                codeSn: "792"
            }, {
                id: 74,
                name: "江阴",
                codeSn: "980"
            }, {
                id: 75,
                name: "银川",
                codeSn: "951"
            } ]
        };
    },
    b5b1: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = i(n("eb5f")), o = i(n("234f"));
        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var a = {
            info: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    id: e.id,
                    idType: e.idType
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("post", "/api/wxapp/member/update", e);
            }
        };
        t.default = a;
    },
    b999: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BaseBackend = void 0;
        var r = n("32f1"), o = n("0d25a"), i = function() {
            function e(e) {
                this._options = e, this._options.dsn || r.logger.warn("No DSN provided, backend will not do anything."), 
                this._transport = this._setupTransport();
            }
            return e.prototype._setupTransport = function() {
                return new o.NoopTransport();
            }, e.prototype.eventFromException = function(e, t) {
                throw new r.SentryError("Backend has to implement `eventFromException` method");
            }, e.prototype.eventFromMessage = function(e, t, n) {
                throw new r.SentryError("Backend has to implement `eventFromMessage` method");
            }, e.prototype.sendEvent = function(e) {
                this._transport.sendEvent(e).then(null, function(e) {
                    r.logger.error("Error while sending event: " + e);
                });
            }, e.prototype.getTransport = function() {
                return this._transport;
            }, e;
        }();
        t.BaseBackend = i;
    },
    bbdd: function(e, t, r) {
        var o = function() {
            return this || "object" === ("undefined" == typeof self ? "undefined" : (0, n.default)(self)) && self;
        }() || Function("return this")(), i = o.regeneratorRuntime && Object.getOwnPropertyNames(o).indexOf("regeneratorRuntime") >= 0, a = i && o.regeneratorRuntime;
        if (o.regeneratorRuntime = void 0, e.exports = r("96cf"), i) o.regeneratorRuntime = a; else try {
            delete o.regeneratorRuntime;
        } catch (e) {
            o.regeneratorRuntime = void 0;
        }
    },
    c0e2: function(e, t) {},
    c1f6: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = i(n("eb5f")), o = i(n("234f"));
        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var a = {
            point: function(e) {
                return (0, r.default)("get", "/api/wxapp/point/account", e, !1);
            },
            indexCouponList: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    idType: e.idType,
                    id: e.id,
                    state: e.state
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("get", "/api/wxapp/coupon/allCoupon/size", e, !1);
            },
            couponList: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    idType: e.idType,
                    id: e.id,
                    state: e.state
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("get", "/api/wxapp/coupon/coupon-list", e, !1);
            },
            getList: function(e) {
                return (0, r.default)("get", "/api/wxapp/gift/getList", e, !1);
            },
            getRuledesc: function(e) {
                return (0, r.default)("get", "/api/wxapp/ruleDesc/getList", e, !1);
            },
            getGiftCategory: function(e) {
                return (0, r.default)("get", "/api/wxapp/gift/category/".concat(e));
            },
            sortList: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, r.default)("get", "/api/wxapp/giftPointGear/sortList", e, !1);
            },
            findGet: function(e) {
                return (0, r.default)("post", "/api/wxapp/couponforward/find", e, !1);
            },
            getDetail: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/gift/getDetail/".concat(e), t, !1);
            },
            existsSignIn: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return (0, r.default)("get", "/api/wxapp/daily/existsSignIn/".concat(e), t, !1);
            },
            couponList_ebuy: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    status: e.status,
                    socialhubId: e.socialhubId
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("post", "/api/wxapp/coupon/ebuyCoupon-list", e, !1);
            }
        };
        t.default = a;
    },
    c26a: function(e, t, n) {
        function r(e, t) {
            for (var n = 0, r = e.length - 1; r >= 0; r--) {
                var o = e[r];
                "." === o ? e.splice(r, 1) : ".." === o ? (e.splice(r, 1), n++) : n && (e.splice(r, 1), 
                n--);
            }
            if (t) for (;n--; n) e.unshift("..");
            return e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.resolve = a, t.relative = function(e, t) {
            e = a(e).substr(1), t = a(t).substr(1);
            for (var n = u(e.split("/")), r = u(t.split("/")), o = Math.min(n.length, r.length), i = o, c = 0; c < o; c++) if (n[c] !== r[c]) {
                i = c;
                break;
            }
            var s = [];
            for (c = i; c < n.length; c++) s.push("..");
            return (s = s.concat(r.slice(i))).join("/");
        }, t.normalizePath = c, t.isAbsolute = s, t.join = function() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            return c(e.join("/"));
        }, t.dirname = function(e) {
            var t = i(e), n = t[0], r = t[1];
            return n || r ? (r && (r = r.substr(0, r.length - 1)), n + r) : ".";
        }, t.basename = function(e, t) {
            var n = i(e)[2];
            return t && n.substr(-1 * t.length) === t && (n = n.substr(0, n.length - t.length)), 
            n;
        };
        var o = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
        function i(e) {
            var t = o.exec(e);
            return t ? t.slice(1) : [];
        }
        function a() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            for (var n = "", o = !1, i = e.length - 1; i >= -1 && !o; i--) {
                var a = i >= 0 ? e[i] : "/";
                a && (n = a + "/" + n, o = "/" === a.charAt(0));
            }
            return (o ? "/" : "") + (n = r(n.split("/").filter(function(e) {
                return !!e;
            }), !o).join("/")) || ".";
        }
        function u(e) {
            for (var t = 0; t < e.length && "" === e[t]; t++) ;
            for (var n = e.length - 1; n >= 0 && "" === e[n]; n--) ;
            return t > n ? [] : e.slice(t, n - t + 1);
        }
        function c(e) {
            var t = s(e), n = "/" === e.substr(-1), o = r(e.split("/").filter(function(e) {
                return !!e;
            }), !t).join("/");
            return o || t || (o = "."), o && n && (o += "/"), (t ? "/" : "") + o;
        }
        function s(e) {
            return "/" === e.charAt(0);
        }
    },
    c344: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            exchange: function(e) {
                return (0, r.default)("get", "/api/wxapp/gift/exchange", e, !1);
            },
            ebuySendCoupon: function(e) {
                return (0, r.default)("post", "/api/wxapp/coupon/ebuySendCoupon", e, !1);
            },
            isbuy: function(e) {
                return (0, r.default)("get", "/api/wxapp/gift/isBuy", e, !1);
            },
            arpoints: function(e) {
                return (0, r.default)("post", "/api/wxapp/activity/points", e, !1);
            },
            getExchange: function(e) {
                return (0, r.default)("post", "/api/wxapp/activityCoupon/get", e, !1);
            },
            getBirthday: function(e) {
                return (0, r.default)("post", "/api/wxapp/activityCoupon/getBirthday", e, !1);
            }
        };
        t.default = o;
    },
    c63d: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.addInstrumentationHandler = function(e) {
            e && "string" == typeof e.type && "function" == typeof e.callback && (d[e.type] = d[e.type] || [], 
            d[e.type].push(e.callback), function(e) {
                if (!h[e]) switch (h[e] = !0, e) {
                  case "console":
                    "console" in p && [ "debug", "info", "warn", "error", "log", "assert" ].forEach(function(e) {
                        e in p.console && (0, c.fill)(p.console, e, function(t) {
                            return function() {
                                for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r];
                                v("console", {
                                    args: n,
                                    level: e
                                }), t && Function.prototype.apply.call(t, p.console, n);
                            };
                        });
                    });
                    break;

                  case "dom":
                    "document" in p && (p.document.addEventListener("click", w("click", v.bind(null, "dom")), !1), 
                    p.document.addEventListener("keypress", x(v.bind(null, "dom")), !1), [ "EventTarget", "Node" ].forEach(function(e) {
                        var t = p[e] && p[e].prototype;
                        t && t.hasOwnProperty && t.hasOwnProperty("addEventListener") && ((0, c.fill)(t, "addEventListener", function(e) {
                            return function(t, n, r) {
                                return n && n.handleEvent ? ("click" === t && (0, c.fill)(n, "handleEvent", function(e) {
                                    return function(t) {
                                        return w("click", v.bind(null, "dom"))(t), e.call(this, t);
                                    };
                                }), "keypress" === t && (0, c.fill)(n, "handleEvent", function(e) {
                                    return function(t) {
                                        return x(v.bind(null, "dom"))(t), e.call(this, t);
                                    };
                                })) : ("click" === t && w("click", v.bind(null, "dom"), !0)(this), "keypress" === t && x(v.bind(null, "dom"))(this)), 
                                e.call(this, t, n, r);
                            };
                        }), (0, c.fill)(t, "removeEventListener", function(e) {
                            return function(t, n, r) {
                                var o = n;
                                try {
                                    o = o && (o.__sentry_wrapped__ || o);
                                } catch (e) {}
                                return e.call(this, t, o, r);
                            };
                        }));
                    }));
                    break;

                  case "xhr":
                    !function() {
                        if ("XMLHttpRequest" in p) {
                            var e = XMLHttpRequest.prototype;
                            (0, c.fill)(e, "open", function(e) {
                                return function() {
                                    for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                                    var r = t[1];
                                    return this.__sentry_xhr__ = {
                                        method: (0, i.isString)(t[0]) ? t[0].toUpperCase() : t[0],
                                        url: t[1]
                                    }, (0, i.isString)(r) && "POST" === this.__sentry_xhr__.method && r.match(/sentry_key/) && (this.__sentry_own_request__ = !0), 
                                    e.apply(this, t);
                                };
                            }), (0, c.fill)(e, "send", function(e) {
                                return function() {
                                    for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                                    var r = this, i = {
                                        args: t,
                                        startTimestamp: Date.now(),
                                        xhr: r
                                    };
                                    return v("xhr", o.__assign({}, i)), r.addEventListener("readystatechange", function() {
                                        if (4 === r.readyState) {
                                            try {
                                                r.__sentry_xhr__ && (r.__sentry_xhr__.status_code = r.status);
                                            } catch (e) {}
                                            v("xhr", o.__assign({}, i, {
                                                endTimestamp: Date.now()
                                            }));
                                        }
                                    }), e.apply(this, t);
                                };
                            });
                        }
                    }();
                    break;

                  case "fetch":
                    (0, s.supportsNativeFetch)() && (0, c.fill)(p, "fetch", function(e) {
                        return function() {
                            for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                            var r = {
                                args: t,
                                fetchData: {
                                    method: g(t),
                                    url: y(t)
                                },
                                startTimestamp: Date.now()
                            };
                            return v("fetch", o.__assign({}, r)), e.apply(p, t).then(function(e) {
                                return v("fetch", o.__assign({}, r, {
                                    endTimestamp: Date.now(),
                                    response: e
                                })), e;
                            }, function(e) {
                                throw v("fetch", o.__assign({}, r, {
                                    endTimestamp: Date.now(),
                                    error: e
                                })), e;
                            });
                        };
                    });
                    break;

                  case "history":
                    !function() {
                        if ((0, s.supportsHistory)()) {
                            var e = p.onpopstate;
                            p.onpopstate = function() {
                                for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                                var r = p.location.href, o = l;
                                if (l = r, v("history", {
                                    from: o,
                                    to: r
                                }), e) return e.apply(this, t);
                            }, (0, c.fill)(p.history, "pushState", t), (0, c.fill)(p.history, "replaceState", t);
                        }
                        function t(e) {
                            return function() {
                                for (var t = [], n = 0; n < arguments.length; n++) t[n] = arguments[n];
                                var r = t.length > 2 ? t[2] : void 0;
                                if (r) {
                                    var o = l, i = String(r);
                                    l = i, v("history", {
                                        from: o,
                                        to: i
                                    });
                                }
                                return e.apply(this, t);
                            };
                        }
                    }();
                    break;

                  case "error":
                    O = p.onerror, p.onerror = function(e, t, n, r, o) {
                        return v("error", {
                            column: r,
                            error: o,
                            line: n,
                            msg: e,
                            url: t
                        }), !!O && O.apply(this, arguments);
                    };
                    break;

                  case "unhandledrejection":
                    S = p.onunhandledrejection, p.onunhandledrejection = function(e) {
                        return v("unhandledrejection", e), !S || S.apply(this, arguments);
                    };
                    break;

                  default:
                    a.logger.warn("unknown instrumentation type:", e);
                }
            }(e.type));
        };
        var o = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = f();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("9ab4")), i = r("670e"), a = r("807a"), u = r("f658"), c = r("2a13"), s = r("71dd");
        function f() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return f = function() {
                return e;
            }, e;
        }
        var l, p = (0, u.getGlobalObject)(), d = {}, h = {};
        function v(e, t) {
            var n, r;
            if (e && d[e]) try {
                for (var i = o.__values(d[e] || []), c = i.next(); !c.done; c = i.next()) {
                    var s = c.value;
                    try {
                        s(t);
                    } catch (t) {
                        a.logger.error("Error while triggering instrumentation handler.\nType: " + e + "\nName: " + (0, 
                        u.getFunctionName)(s) + "\nError: " + t);
                    }
                }
            } catch (e) {
                n = {
                    error: e
                };
            } finally {
                try {
                    c && !c.done && (r = i.return) && r.call(i);
                } finally {
                    if (n) throw n.error;
                }
            }
        }
        function g(e) {
            return void 0 === e && (e = []), "Request" in p && (0, i.isInstanceOf)(e[0], Request) && e[0].method ? String(e[0].method).toUpperCase() : e[1] && e[1].method ? String(e[1].method).toUpperCase() : "GET";
        }
        function y(e) {
            return void 0 === e && (e = []), "string" == typeof e[0] ? e[0] : "Request" in p && (0, 
            i.isInstanceOf)(e[0], Request) ? e[0].url : String(e[0]);
        }
        var b, m, _ = 0;
        function w(e, t, n) {
            return void 0 === n && (n = !1), function(r) {
                b = void 0, r && m !== r && (m = r, _ && clearTimeout(_), n ? _ = setTimeout(function() {
                    t({
                        event: r,
                        name: e
                    });
                }) : t({
                    event: r,
                    name: e
                }));
            };
        }
        function x(e) {
            return function(t) {
                var n;
                try {
                    n = t.target;
                } catch (e) {
                    return;
                }
                var r = n && n.tagName;
                r && ("INPUT" === r || "TEXTAREA" === r || n.isContentEditable) && (b || w("input", e)(t), 
                clearTimeout(b), b = setTimeout(function() {
                    b = void 0;
                }, 1e3));
            };
        }
        var O = null;
        var S = null;
    },
    c6ce: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), Object.defineProperty(t, "addBreadcrumb", {
            enumerable: !0,
            get: function() {
                return o.addBreadcrumb;
            }
        }), Object.defineProperty(t, "captureException", {
            enumerable: !0,
            get: function() {
                return o.captureException;
            }
        }), Object.defineProperty(t, "captureEvent", {
            enumerable: !0,
            get: function() {
                return o.captureEvent;
            }
        }), Object.defineProperty(t, "captureMessage", {
            enumerable: !0,
            get: function() {
                return o.captureMessage;
            }
        }), Object.defineProperty(t, "configureScope", {
            enumerable: !0,
            get: function() {
                return o.configureScope;
            }
        }), Object.defineProperty(t, "setContext", {
            enumerable: !0,
            get: function() {
                return o.setContext;
            }
        }), Object.defineProperty(t, "setExtra", {
            enumerable: !0,
            get: function() {
                return o.setExtra;
            }
        }), Object.defineProperty(t, "setExtras", {
            enumerable: !0,
            get: function() {
                return o.setExtras;
            }
        }), Object.defineProperty(t, "setTag", {
            enumerable: !0,
            get: function() {
                return o.setTag;
            }
        }), Object.defineProperty(t, "setTags", {
            enumerable: !0,
            get: function() {
                return o.setTags;
            }
        }), Object.defineProperty(t, "setUser", {
            enumerable: !0,
            get: function() {
                return o.setUser;
            }
        }), Object.defineProperty(t, "withScope", {
            enumerable: !0,
            get: function() {
                return o.withScope;
            }
        }), Object.defineProperty(t, "addGlobalEventProcessor", {
            enumerable: !0,
            get: function() {
                return i.addGlobalEventProcessor;
            }
        }), Object.defineProperty(t, "getCurrentHub", {
            enumerable: !0,
            get: function() {
                return i.getCurrentHub;
            }
        }), Object.defineProperty(t, "getHubFromCarrier", {
            enumerable: !0,
            get: function() {
                return i.getHubFromCarrier;
            }
        }), Object.defineProperty(t, "Hub", {
            enumerable: !0,
            get: function() {
                return i.Hub;
            }
        }), Object.defineProperty(t, "Scope", {
            enumerable: !0,
            get: function() {
                return i.Scope;
            }
        }), Object.defineProperty(t, "API", {
            enumerable: !0,
            get: function() {
                return a.API;
            }
        }), Object.defineProperty(t, "BaseClient", {
            enumerable: !0,
            get: function() {
                return u.BaseClient;
            }
        }), Object.defineProperty(t, "BaseBackend", {
            enumerable: !0,
            get: function() {
                return c.BaseBackend;
            }
        }), Object.defineProperty(t, "initAndBind", {
            enumerable: !0,
            get: function() {
                return s.initAndBind;
            }
        }), Object.defineProperty(t, "NoopTransport", {
            enumerable: !0,
            get: function() {
                return f.NoopTransport;
            }
        }), t.Integrations = void 0;
        var o = r("4251"), i = r("4820"), a = r("dc2f"), u = r("844c"), c = r("b999"), s = r("40a0"), f = r("0d25a"), l = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = p();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("8021"));
        function p() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return p = function() {
                return e;
            }, e;
        }
        t.Integrations = l;
    },
    c6fa: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.init = function(e) {
            void 0 === e && (e = {}), void 0 === e.defaultIntegrations && (e.defaultIntegrations = c), 
            e.normalizeDepth = e.normalizeDepth || 5, (0, r.initAndBind)(i.MiniappClient, e);
        }, t.showReportDialog = function(e) {
            void 0 === e && (e = {}), e.eventId || (e.eventId = (0, r.getCurrentHub)().lastEventId());
            var t = (0, r.getCurrentHub)().getClient();
            t && t.showReportDialog(e);
        }, t.lastEventId = function() {
            return (0, r.getCurrentHub)().lastEventId();
        }, t.flush = function(e) {
            var t = (0, r.getCurrentHub)().getClient();
            return t ? t.flush(e) : o.SyncPromise.reject(!1);
        }, t.close = function(e) {
            var t = (0, r.getCurrentHub)().getClient();
            return t ? t.close(e) : o.SyncPromise.reject(!1);
        }, t.wrap = function(e) {
            return (0, a.wrap)(e)();
        }, t.defaultIntegrations = void 0;
        var r = n("c6ce"), o = n("32f1"), i = n("35c8"), a = n("413f"), u = n("84f2"), c = [ new r.Integrations.InboundFilters(), new r.Integrations.FunctionToString(), new u.TryCatch(), new u.GlobalHandlers(), new u.LinkedErrors(), new u.System(), new u.Router(), new u.IgnoreMpcrawlerErrors() ];
        t.defaultIntegrations = c;
    },
    c886: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.getMainCarrier = s, t.makeMain = f, t.getCurrentHub = function() {
            var e = s();
            return l(e) && !p(e).isOlderThan(3) || d(e, new c()), (0, i.isNodeEnv)() ? function(e) {
                try {
                    var t = "domain", n = s().__SENTRY__;
                    if (!n || !n.extensions || !n.extensions[t]) return p(e);
                    var r = n.extensions[t].active;
                    if (!r) return p(e);
                    if (!l(r) || p(r).isOlderThan(3)) {
                        var o = p(e).getStackTop();
                        d(r, new c(o.client, a.Scope.clone(o.scope)));
                    }
                    return p(r);
                } catch (t) {
                    return p(e);
                }
            }(e) : p(e);
        }, t.getHubFromCarrier = p, t.setHubOnCarrier = d, t.Hub = t.API_VERSION = void 0;
        var o = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = u();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("9ab4")), i = r("32f1"), a = r("2ed3");
        function u() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return u = function() {
                return e;
            }, e;
        }
        t.API_VERSION = 3;
        var c = function() {
            function e(e, t, n) {
                void 0 === t && (t = new a.Scope()), void 0 === n && (n = 3), this._version = n, 
                this._stack = [], this._stack.push({
                    client: e,
                    scope: t
                });
            }
            return e.prototype._invokeClient = function(e) {
                for (var t, n = [], r = 1; r < arguments.length; r++) n[r - 1] = arguments[r];
                var i = this.getStackTop();
                i && i.client && i.client[e] && (t = i.client)[e].apply(t, o.__spread(n, [ i.scope ]));
            }, e.prototype.isOlderThan = function(e) {
                return this._version < e;
            }, e.prototype.bindClient = function(e) {
                this.getStackTop().client = e, e && e.setupIntegrations && e.setupIntegrations();
            }, e.prototype.pushScope = function() {
                var e = this.getStack(), t = e.length > 0 ? e[e.length - 1].scope : void 0, n = a.Scope.clone(t);
                return this.getStack().push({
                    client: this.getClient(),
                    scope: n
                }), n;
            }, e.prototype.popScope = function() {
                return void 0 !== this.getStack().pop();
            }, e.prototype.withScope = function(e) {
                var t = this.pushScope();
                try {
                    e(t);
                } finally {
                    this.popScope();
                }
            }, e.prototype.getClient = function() {
                return this.getStackTop().client;
            }, e.prototype.getScope = function() {
                return this.getStackTop().scope;
            }, e.prototype.getStack = function() {
                return this._stack;
            }, e.prototype.getStackTop = function() {
                return this._stack[this._stack.length - 1];
            }, e.prototype.captureException = function(e, t) {
                var n = this._lastEventId = (0, i.uuid4)(), r = t;
                if (!t) {
                    var a = void 0;
                    try {
                        throw new Error("Sentry syntheticException");
                    } catch (e) {
                        a = e;
                    }
                    r = {
                        originalException: e,
                        syntheticException: a
                    };
                }
                return this._invokeClient("captureException", e, o.__assign({}, r, {
                    event_id: n
                })), n;
            }, e.prototype.captureMessage = function(e, t, n) {
                var r = this._lastEventId = (0, i.uuid4)(), a = n;
                if (!n) {
                    var u = void 0;
                    try {
                        throw new Error(e);
                    } catch (e) {
                        u = e;
                    }
                    a = {
                        originalException: e,
                        syntheticException: u
                    };
                }
                return this._invokeClient("captureMessage", e, t, o.__assign({}, a, {
                    event_id: r
                })), r;
            }, e.prototype.captureEvent = function(e, t) {
                var n = this._lastEventId = (0, i.uuid4)();
                return this._invokeClient("captureEvent", e, o.__assign({}, t, {
                    event_id: n
                })), n;
            }, e.prototype.lastEventId = function() {
                return this._lastEventId;
            }, e.prototype.addBreadcrumb = function(e, t) {
                var n = this.getStackTop();
                if (n.scope && n.client) {
                    var r = n.client.getOptions && n.client.getOptions() || {}, a = r.beforeBreadcrumb, u = void 0 === a ? null : a, c = r.maxBreadcrumbs, s = void 0 === c ? 100 : c;
                    if (!(s <= 0)) {
                        var f = (0, i.timestampWithMs)(), l = o.__assign({
                            timestamp: f
                        }, e), p = u ? (0, i.consoleSandbox)(function() {
                            return u(l, t);
                        }) : l;
                        null !== p && n.scope.addBreadcrumb(p, Math.min(s, 100));
                    }
                }
            }, e.prototype.setUser = function(e) {
                var t = this.getStackTop();
                t.scope && t.scope.setUser(e);
            }, e.prototype.setTags = function(e) {
                var t = this.getStackTop();
                t.scope && t.scope.setTags(e);
            }, e.prototype.setExtras = function(e) {
                var t = this.getStackTop();
                t.scope && t.scope.setExtras(e);
            }, e.prototype.setTag = function(e, t) {
                var n = this.getStackTop();
                n.scope && n.scope.setTag(e, t);
            }, e.prototype.setExtra = function(e, t) {
                var n = this.getStackTop();
                n.scope && n.scope.setExtra(e, t);
            }, e.prototype.setContext = function(e, t) {
                var n = this.getStackTop();
                n.scope && n.scope.setContext(e, t);
            }, e.prototype.configureScope = function(e) {
                var t = this.getStackTop();
                t.scope && t.client && e(t.scope);
            }, e.prototype.run = function(e) {
                var t = f(this);
                try {
                    e(this);
                } finally {
                    f(t);
                }
            }, e.prototype.getIntegration = function(e) {
                var t = this.getClient();
                if (!t) return null;
                try {
                    return t.getIntegration(e);
                } catch (t) {
                    return i.logger.warn("Cannot retrieve integration " + e.id + " from the current Hub"), 
                    null;
                }
            }, e.prototype.startSpan = function(e, t) {
                return void 0 === t && (t = !1), this._callExtensionMethod("startSpan", e, t);
            }, e.prototype.traceHeaders = function() {
                return this._callExtensionMethod("traceHeaders");
            }, e.prototype._callExtensionMethod = function(e) {
                for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                var r = s(), o = r.__SENTRY__;
                if (o && o.extensions && "function" == typeof o.extensions[e]) return o.extensions[e].apply(this, t);
                i.logger.warn("Extension method " + e + " couldn't be found, doing nothing.");
            }, e;
        }();
        function s() {
            var e = (0, i.getGlobalObject)();
            return e.__SENTRY__ = e.__SENTRY__ || {
                extensions: {},
                hub: void 0
            }, e;
        }
        function f(e) {
            var t = s(), n = p(t);
            return d(t, e), n;
        }
        function l(e) {
            return !!(e && e.__SENTRY__ && e.__SENTRY__.hub);
        }
        function p(e) {
            return e && e.__SENTRY__ && e.__SENTRY__.hub || (e.__SENTRY__ = e.__SENTRY__ || {}, 
            e.__SENTRY__.hub = new c()), e.__SENTRY__.hub;
        }
        function d(e, t) {
            return !!e && (e.__SENTRY__ = e.__SENTRY__ || {}, e.__SENTRY__.hub = t, !0);
        }
        t.Hub = c;
    },
    c8ba: function(e, t) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (e) {
            "object" === ("undefined" == typeof window ? "undefined" : (0, n.default)(window)) && (r = window);
        }
        e.exports = r;
    },
    c8e8: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), Object.defineProperty(t, "Severity", {
            enumerable: !0,
            get: function() {
                return o.Severity;
            }
        }), Object.defineProperty(t, "Status", {
            enumerable: !0,
            get: function() {
                return o.Status;
            }
        }), Object.defineProperty(t, "addGlobalEventProcessor", {
            enumerable: !0,
            get: function() {
                return i.addGlobalEventProcessor;
            }
        }), Object.defineProperty(t, "addBreadcrumb", {
            enumerable: !0,
            get: function() {
                return i.addBreadcrumb;
            }
        }), Object.defineProperty(t, "captureException", {
            enumerable: !0,
            get: function() {
                return i.captureException;
            }
        }), Object.defineProperty(t, "captureEvent", {
            enumerable: !0,
            get: function() {
                return i.captureEvent;
            }
        }), Object.defineProperty(t, "captureMessage", {
            enumerable: !0,
            get: function() {
                return i.captureMessage;
            }
        }), Object.defineProperty(t, "configureScope", {
            enumerable: !0,
            get: function() {
                return i.configureScope;
            }
        }), Object.defineProperty(t, "getHubFromCarrier", {
            enumerable: !0,
            get: function() {
                return i.getHubFromCarrier;
            }
        }), Object.defineProperty(t, "getCurrentHub", {
            enumerable: !0,
            get: function() {
                return i.getCurrentHub;
            }
        }), Object.defineProperty(t, "Hub", {
            enumerable: !0,
            get: function() {
                return i.Hub;
            }
        }), Object.defineProperty(t, "Scope", {
            enumerable: !0,
            get: function() {
                return i.Scope;
            }
        }), Object.defineProperty(t, "setContext", {
            enumerable: !0,
            get: function() {
                return i.setContext;
            }
        }), Object.defineProperty(t, "setExtra", {
            enumerable: !0,
            get: function() {
                return i.setExtra;
            }
        }), Object.defineProperty(t, "setExtras", {
            enumerable: !0,
            get: function() {
                return i.setExtras;
            }
        }), Object.defineProperty(t, "setTag", {
            enumerable: !0,
            get: function() {
                return i.setTag;
            }
        }), Object.defineProperty(t, "setTags", {
            enumerable: !0,
            get: function() {
                return i.setTags;
            }
        }), Object.defineProperty(t, "setUser", {
            enumerable: !0,
            get: function() {
                return i.setUser;
            }
        }), Object.defineProperty(t, "withScope", {
            enumerable: !0,
            get: function() {
                return i.withScope;
            }
        }), Object.defineProperty(t, "SDK_NAME", {
            enumerable: !0,
            get: function() {
                return a.SDK_NAME;
            }
        }), Object.defineProperty(t, "SDK_VERSION", {
            enumerable: !0,
            get: function() {
                return a.SDK_VERSION;
            }
        }), Object.defineProperty(t, "defaultIntegrations", {
            enumerable: !0,
            get: function() {
                return u.defaultIntegrations;
            }
        }), Object.defineProperty(t, "init", {
            enumerable: !0,
            get: function() {
                return u.init;
            }
        }), Object.defineProperty(t, "lastEventId", {
            enumerable: !0,
            get: function() {
                return u.lastEventId;
            }
        }), Object.defineProperty(t, "showReportDialog", {
            enumerable: !0,
            get: function() {
                return u.showReportDialog;
            }
        }), Object.defineProperty(t, "flush", {
            enumerable: !0,
            get: function() {
                return u.flush;
            }
        }), Object.defineProperty(t, "close", {
            enumerable: !0,
            get: function() {
                return u.close;
            }
        }), Object.defineProperty(t, "wrap", {
            enumerable: !0,
            get: function() {
                return u.wrap;
            }
        }), Object.defineProperty(t, "MiniappClient", {
            enumerable: !0,
            get: function() {
                return c.MiniappClient;
            }
        }), t.Transports = t.Integrations = void 0;
        var o = r("507c"), i = r("c6ce"), a = r("1f9b"), u = r("c6fa"), c = r("35c8"), s = p(r("84f2"));
        t.Integrations = s;
        var f = p(r("11b6"));
        function l() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return l = function() {
                return e;
            }, e;
        }
        function p(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = l();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }
        t.Transports = f;
    },
    c917: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        t.default = {
            province: [ "安徽", "北京", "福建", "甘肃", "广东", "广西", "贵州", "海南", "河北", "河南", "黑龙江", "湖北", "湖南", "吉林", "江苏", "江西", "辽宁", "内蒙古", "宁夏", "青海", "山东", "山西", "陕西", "上海", "四川", "天津", "新疆", "云南", "浙江", "重庆" ],
            city: [ {
                "安徽": "合肥"
            }, {
                "北京": "北京"
            }, {
                "福建": "厦门"
            }, {
                "福建": "泉州"
            }, {
                "福建": "福州"
            }, {
                "甘肃": "兰州"
            }, {
                "广东": "珠海"
            }, {
                "广东": "深圳"
            }, {
                "广东": "汕头"
            }, {
                "广东": "江门"
            }, {
                "广东": "广州"
            }, {
                "广东": "佛山"
            }, {
                "广东": "东莞"
            }, {
                "广西": "南宁"
            }, {
                "贵州": "贵阳"
            }, {
                "海南": "三亚"
            }, {
                "海南": "海口"
            }, {
                "河北": "唐山"
            }, {
                "河北": "石家庄"
            }, {
                "河北": "保定"
            }, {
                "河南": "郑州"
            }, {
                "河南": "洛阳"
            }, {
                "黑龙江": "哈尔滨"
            }, {
                "湖北": "宜昌"
            }, {
                "湖北": "武汉"
            }, {
                "湖南": "湘潭"
            }, {
                "湖南": "长沙"
            }, {
                "吉林": "吉林"
            }, {
                "吉林": "长春"
            }, {
                "江苏": "张家港"
            }, {
                "江苏": "扬州"
            }, {
                "江苏": "徐州"
            }, {
                "江苏": "无锡"
            }, {
                "江苏": "泰州"
            }, {
                "江苏": "苏州"
            }, {
                "江苏": "南通"
            }, {
                "江苏": "南京"
            }, {
                "江苏": "常州"
            }, {
                "江苏": "宜兴"
            }, {
                "江苏": "苏州"
            }, {
                "江苏": "昆山"
            }, {
                "江苏": "江阴"
            }, {
                "江苏": "常熟"
            }, {
                "江西": "南昌"
            }, {
                "江西": "九江"
            }, {
                "江西": "赣州"
            }, {
                "辽宁": "沈阳"
            }, {
                "辽宁": "抚顺"
            }, {
                "辽宁": "大连"
            }, {
                "辽宁": "丹东"
            }, {
                "内蒙古": "呼和浩特"
            }, {
                "内蒙古": "包头"
            }, {
                "宁夏": "银川"
            }, {
                "青海": "西宁"
            }, {
                "山东": "淄博"
            }, {
                "山东": "烟台"
            }, {
                "山东": "潍坊"
            }, {
                "山东": "威海"
            }, {
                "山东": "青岛"
            }, {
                "山东": "临沂"
            }, {
                "山东": "济南"
            }, {
                "山东": "东营"
            }, {
                "山西": "太原"
            }, {
                "陕西": "西安"
            }, {
                "上海": "上海"
            }, {
                "四川": "绵阳"
            }, {
                "四川": "成都"
            }, {
                "天津": "天津"
            }, {
                "新疆": "乌鲁木齐"
            }, {
                "云南": "昆明"
            }, {
                "浙江": "余姚"
            }, {
                "浙江": "温州"
            }, {
                "浙江": "台州"
            }, {
                "浙江": "绍兴"
            }, {
                "浙江": "瑞安"
            }, {
                "浙江": "宁波"
            }, {
                "浙江": "嘉兴"
            }, {
                "浙江": "杭州"
            }, {
                "浙江": "湖州"
            }, {
                "重庆": "重庆"
            } ]
        };
    },
    cc66: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Dsn = void 0;
        var o = function(e) {
            if (e && e.__esModule) return e;
            if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                default: e
            };
            var t = a();
            if (t && t.has(e)) return t.get(e);
            var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                var u = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                u && (u.get || u.set) ? Object.defineProperty(r, i, u) : r[i] = e[i];
            }
            return r.default = e, t && t.set(e, r), r;
        }(r("9ab4")), i = r("745c");
        function a() {
            if ("function" != typeof WeakMap) return null;
            var e = new WeakMap();
            return a = function() {
                return e;
            }, e;
        }
        var u = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+))?@)([\w\.-]+)(?::(\d+))?\/(.+)/, c = "Invalid Dsn", s = function() {
            function e(e) {
                "string" == typeof e ? this._fromString(e) : this._fromComponents(e), this._validate();
            }
            return e.prototype.toString = function(e) {
                void 0 === e && (e = !1);
                var t = this, n = t.host, r = t.path, o = t.pass, i = t.port, a = t.projectId;
                return t.protocol + "://" + t.user + (e && o ? ":" + o : "") + "@" + n + (i ? ":" + i : "") + "/" + (r ? r + "/" : r) + a;
            }, e.prototype._fromString = function(e) {
                var t = u.exec(e);
                if (!t) throw new i.SentryError(c);
                var n = o.__read(t.slice(1), 6), r = n[0], a = n[1], s = n[2], f = void 0 === s ? "" : s, l = n[3], p = n[4], d = void 0 === p ? "" : p, h = "", v = n[5], g = v.split("/");
                g.length > 1 && (h = g.slice(0, -1).join("/"), v = g.pop()), this._fromComponents({
                    host: l,
                    pass: f,
                    path: h,
                    projectId: v,
                    port: d,
                    protocol: r,
                    user: a
                });
            }, e.prototype._fromComponents = function(e) {
                this.protocol = e.protocol, this.user = e.user, this.pass = e.pass || "", this.host = e.host, 
                this.port = e.port || "", this.path = e.path || "", this.projectId = e.projectId;
            }, e.prototype._validate = function() {
                var e = this;
                if ([ "protocol", "user", "host", "projectId" ].forEach(function(t) {
                    if (!e[t]) throw new i.SentryError(c);
                }), "http" !== this.protocol && "https" !== this.protocol) throw new i.SentryError(c);
                if (this.port && isNaN(parseInt(this.port, 10))) throw new i.SentryError(c);
            }, e;
        }();
        t.Dsn = s;
    },
    d1a8: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            getCouponsId: function(e, t) {
                return (0, r.default)("get", "/api/wxapp/gift/getCouponsByActivityId?activityId=" + e, t);
            }
        };
        t.default = o;
    },
    d34a: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.truncate = function(e, t) {
            return void 0 === t && (t = 0), "string" != typeof e || 0 === t || e.length <= t ? e : e.substr(0, t) + "...";
        }, t.snipLine = function(e, t) {
            var n = e, r = n.length;
            if (r <= 150) return n;
            t > r && (t = r);
            var o = Math.max(t - 60, 0);
            o < 5 && (o = 0);
            var i = Math.min(o + 140, r);
            return i > r - 5 && (i = r), i === r && (o = Math.max(i - 140, 0)), n = n.slice(o, i), 
            o > 0 && (n = "'{snip} " + n), i < r && (n += " {snip}"), n;
        }, t.safeJoin = function(e, t) {
            if (!Array.isArray(e)) return "";
            for (var n = [], r = 0; r < e.length; r++) {
                var o = e[r];
                try {
                    n.push(String(o));
                } catch (e) {
                    n.push("[value cannot be serialized]");
                }
            }
            return n.join(t);
        }, t.isMatchingPattern = function(e, t) {
            return (0, r.isRegExp)(t) ? t.test(e) : "string" == typeof t && -1 !== e.indexOf(t);
        };
        var r = n("670e");
    },
    dc2f: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.API = void 0;
        var r = n("32f1"), o = function() {
            function e(e) {
                this.dsn = e, this._dsnObject = new r.Dsn(e);
            }
            return e.prototype.getDsn = function() {
                return this._dsnObject;
            }, e.prototype.getStoreEndpoint = function() {
                return "" + this._getBaseUrl() + this.getStoreEndpointPath();
            }, e.prototype.getStoreEndpointWithUrlEncodedAuth = function() {
                var e = {
                    sentry_key: this._dsnObject.user,
                    sentry_version: "7"
                };
                return this.getStoreEndpoint() + "?" + (0, r.urlEncode)(e);
            }, e.prototype._getBaseUrl = function() {
                var e = this._dsnObject, t = e.protocol ? e.protocol + ":" : "", n = e.port ? ":" + e.port : "";
                return t + "//" + e.host + n;
            }, e.prototype.getStoreEndpointPath = function() {
                var e = this._dsnObject;
                return (e.path ? "/" + e.path : "") + "/api/" + e.projectId + "/store/";
            }, e.prototype.getRequestHeaders = function(e, t) {
                var n = this._dsnObject, r = [ "Sentry sentry_version=7" ];
                return r.push("sentry_client=" + e + "/" + t), r.push("sentry_key=" + n.user), n.pass && r.push("sentry_secret=" + n.pass), 
                {
                    "Content-Type": "application/json",
                    "X-Sentry-Auth": r.join(", ")
                };
            }, e.prototype.getReportDialogEndpoint = function(e) {
                void 0 === e && (e = {});
                var t = this._dsnObject, n = this._getBaseUrl() + (t.path ? "/" + t.path : "") + "/api/embed/error-page/", r = [];
                for (var o in r.push("dsn=" + t.toString()), e) if ("user" === o) {
                    if (!e.user) continue;
                    e.user.name && r.push("name=" + encodeURIComponent(e.user.name)), e.user.email && r.push("email=" + encodeURIComponent(e.user.email));
                } else r.push(encodeURIComponent(o) + "=" + encodeURIComponent(e[o]));
                return r.length ? n + "?" + r.join("&") : n;
            }, e;
        }();
        t.API = o;
    },
    df7c: function(e, t, n) {
        (function(e) {
            function n(e, t) {
                for (var n = 0, r = e.length - 1; r >= 0; r--) {
                    var o = e[r];
                    "." === o ? e.splice(r, 1) : ".." === o ? (e.splice(r, 1), n++) : n && (e.splice(r, 1), 
                    n--);
                }
                if (t) for (;n--; n) e.unshift("..");
                return e;
            }
            function r(e, t) {
                if (e.filter) return e.filter(t);
                for (var n = [], r = 0; r < e.length; r++) t(e[r], r, e) && n.push(e[r]);
                return n;
            }
            t.resolve = function() {
                for (var t = "", o = !1, i = arguments.length - 1; i >= -1 && !o; i--) {
                    var a = i >= 0 ? arguments[i] : e.cwd();
                    if ("string" != typeof a) throw new TypeError("Arguments to path.resolve must be strings");
                    a && (t = a + "/" + t, o = "/" === a.charAt(0));
                }
                return (o ? "/" : "") + (t = n(r(t.split("/"), function(e) {
                    return !!e;
                }), !o).join("/")) || ".";
            }, t.normalize = function(e) {
                var i = t.isAbsolute(e), a = "/" === o(e, -1);
                return (e = n(r(e.split("/"), function(e) {
                    return !!e;
                }), !i).join("/")) || i || (e = "."), e && a && (e += "/"), (i ? "/" : "") + e;
            }, t.isAbsolute = function(e) {
                return "/" === e.charAt(0);
            }, t.join = function() {
                var e = Array.prototype.slice.call(arguments, 0);
                return t.normalize(r(e, function(e, t) {
                    if ("string" != typeof e) throw new TypeError("Arguments to path.join must be strings");
                    return e;
                }).join("/"));
            }, t.relative = function(e, n) {
                function r(e) {
                    for (var t = 0; t < e.length && "" === e[t]; t++) ;
                    for (var n = e.length - 1; n >= 0 && "" === e[n]; n--) ;
                    return t > n ? [] : e.slice(t, n - t + 1);
                }
                e = t.resolve(e).substr(1), n = t.resolve(n).substr(1);
                for (var o = r(e.split("/")), i = r(n.split("/")), a = Math.min(o.length, i.length), u = a, c = 0; c < a; c++) if (o[c] !== i[c]) {
                    u = c;
                    break;
                }
                var s = [];
                for (c = u; c < o.length; c++) s.push("..");
                return (s = s.concat(i.slice(u))).join("/");
            }, t.sep = "/", t.delimiter = ":", t.dirname = function(e) {
                if ("string" != typeof e && (e += ""), 0 === e.length) return ".";
                for (var t = e.charCodeAt(0), n = 47 === t, r = -1, o = !0, i = e.length - 1; i >= 1; --i) if (47 === (t = e.charCodeAt(i))) {
                    if (!o) {
                        r = i;
                        break;
                    }
                } else o = !1;
                return -1 === r ? n ? "/" : "." : n && 1 === r ? "/" : e.slice(0, r);
            }, t.basename = function(e, t) {
                var n = function(e) {
                    "string" != typeof e && (e += "");
                    var t, n = 0, r = -1, o = !0;
                    for (t = e.length - 1; t >= 0; --t) if (47 === e.charCodeAt(t)) {
                        if (!o) {
                            n = t + 1;
                            break;
                        }
                    } else -1 === r && (o = !1, r = t + 1);
                    return -1 === r ? "" : e.slice(n, r);
                }(e);
                return t && n.substr(-1 * t.length) === t && (n = n.substr(0, n.length - t.length)), 
                n;
            }, t.extname = function(e) {
                "string" != typeof e && (e += "");
                for (var t = -1, n = 0, r = -1, o = !0, i = 0, a = e.length - 1; a >= 0; --a) {
                    var u = e.charCodeAt(a);
                    if (47 !== u) -1 === r && (o = !1, r = a + 1), 46 === u ? -1 === t ? t = a : 1 !== i && (i = 1) : -1 !== t && (i = -1); else if (!o) {
                        n = a + 1;
                        break;
                    }
                }
                return -1 === t || -1 === r || 0 === i || 1 === i && t === r - 1 && t === n + 1 ? "" : e.slice(t, r);
            };
            var o = "b" === "ab".substr(-1) ? function(e, t, n) {
                return e.substr(t, n);
            } : function(e, t, n) {
                return t < 0 && (t = e.length + t), e.substr(t, n);
            };
        }).call(this, n("4362"));
    },
    e53f: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        var o = {
            detail: function(e) {
                return (0, r.default)("get", "/api/wxapp/delivery/clause/detail/" + e, "", !1);
            },
            add: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/clause/save", e, !1);
            },
            getBanner: function(e) {
                return (0, r.default)("post", "/api/wxapp/activityBanner/getByType/" + e);
            },
            sendMessage: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/sms/send/" + e);
            },
            register: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/registerMember", e, !1);
            },
            addressList: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchAllMemberAddress", e, !1);
            },
            addressAdd: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/updateMemberAddress", e, !1);
            },
            addressDetail: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchMemberAddressDetail", e, !1);
            },
            deleteAddress: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/deleteMemberAddress", e, !1);
            },
            getCard: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchMyMemberCard", e, !1);
            },
            deleteCard: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/deleteMemberCard", e, !1);
            },
            initCard: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/initCardInfo", e, !1);
            },
            bindCard: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/bindMemberCard", e, !1);
            },
            deliveryCity: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchAllCityByCodeSn", e, !1);
            },
            myOrders: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchMyMemberOrderList", e, !1);
            },
            orderDetail: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchMyMemberOrderDetail", e, !1);
            },
            saveOrder: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/updateMemberOrder", e, !1);
            },
            cancelOrder: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/cancelMemberOrder", e, !1);
            },
            orderLogistics: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchOrderLogistics", e, !1);
            },
            complaints: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/updateMemberComplaint", e, !1);
            },
            searchPickUpOrder: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/updateMemberComplaint", e, !1);
            },
            searchShopName: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchAllPickShopByCodeSnAndCity", e, !1);
            },
            pickUpInfo: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/updatePickOrder", e, !1);
            },
            pickUpOrders: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchMyPickOrderList", e, !1);
            },
            pickUpCancel: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/cancelPickOrder", e, !1);
            },
            searchDevlivery: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/getDeliveryTimesByCodeSn", e, !1);
            },
            searchCity: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchAllPickCityByCodeSn", e, !1);
            },
            searchInventoryByCodeSnAndShop: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/searchInventoryByCodeSnAndShop", e, !1);
            },
            getMemberOrderDeliveryDate: function(e) {
                return (0, r.default)("post", "/api/wxapp/delivery/ebuy/getMemberOrderDeliveryDate", e, !1);
            },
            activityGet: function(e, t) {
                return (0, r.default)("get", "/api/wxapp/activity/get/".concat(e), t, !1);
            },
            getNotice: function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return (0, r.default)("get", "/api/wxapp/deliveryMoonOrder/getNotice/1", e, !1);
            }
        };
        t.default = o;
    },
    eb5f: function(t, r, o) {
        (function(t) {
            Object.defineProperty(r, "__esModule", {
                value: !0
            }), r.default = void 0;
            var i = s(o("a34a")), a = s(o("f0fd")), u = function(e) {
                if (e && e.__esModule) return e;
                if (null === e || "object" !== (0, n.default)(e) && "function" != typeof e) return {
                    default: e
                };
                var t = c();
                if (t && t.has(e)) return t.get(e);
                var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var i in e) if (Object.prototype.hasOwnProperty.call(e, i)) {
                    var a = o ? Object.getOwnPropertyDescriptor(e, i) : null;
                    a && (a.get || a.set) ? Object.defineProperty(r, i, a) : r[i] = e[i];
                }
                return r.default = e, t && t.set(e, r), r;
            }(o("c8e8"));
            function c() {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap();
                return c = function() {
                    return e;
                }, e;
            }
            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function f(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e;
                }(e) || function(e, t) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                        var n = [], r = !0, o = !1, i = void 0;
                        try {
                            for (var a, u = e[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), 
                            !t || n.length !== t); r = !0) ;
                        } catch (e) {
                            o = !0, i = e;
                        } finally {
                            try {
                                r || null == u.return || u.return();
                            } finally {
                                if (o) throw i;
                            }
                        }
                        return n;
                    }
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" == typeof e) return l(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(e, t) : void 0;
                    }
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function l(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r;
            }
            function p(e, t, n, r, o, i, a) {
                try {
                    var u = e[i](a), c = u.value;
                } catch (e) {
                    return void n(e);
                }
                u.done ? t(c) : Promise.resolve(c).then(r, o);
            }
            function d(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(r, o) {
                        var i = e.apply(t, n);
                        function a(e) {
                            p(i, r, o, a, u, "next", e);
                        }
                        function u(e) {
                            p(i, r, o, a, u, "throw", e);
                        }
                        a(void 0);
                    });
                };
            }
            var h = a.default.apiRoot, v = "";
            function g() {
                return new Promise(function(n, r) {
                    t.request({
                        method: "POST",
                        url: h + "/api/token",
                        data: {
                            partner: "apitest",
                            secret: "Ou0HT@0W6e",
                            openid: a.default.openid,
                            "app-id": "wx3656c2a2353eb377"
                        },
                        success: function(e) {
                            console.log("token_get", e), n(e.data.data);
                        },
                        fail: function(t) {
                            console.log("存token失败"), r(e);
                        }
                    });
                });
            }
            r.default = function(e, n, r) {
                var o = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3], a = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4], c = {};
                return new Promise(function() {
                    var s = d(i.default.mark(function s(l, p) {
                        var y, b, m, _, w, x, O, S, E, k, P;
                        return i.default.wrap(function(s) {
                            for (;;) switch (s.prev = s.next) {
                              case 0:
                                if (console.log(getApp().globalData.globalNetWork), o && t.showLoading({
                                    title: "正在加载...",
                                    duration: 1e4,
                                    mask: !0
                                }), t.getStorageSync("firstTokenTime") && t.getStorageSync("token") ? (y = t.getStorageSync("firstTokenTime"), 
                                b = new Date().getTime(), _ = (m = b - y) / 1e3 / 60 / 60 / 24, w = Math.floor(_), 
                                x = m / 1e3 / 60 / 60 - 24 * w, O = Math.floor(x), S = m / 1e3 / 60 - 1440 * w - 60 * O, 
                                E = Math.floor(S), k = m / 1e3 - 86400 * w - 3600 * O - 60 * E, console.log("转换时间:", w + "天", O + "时", E + "分", k + "秒"), 
                                P = O + ":" + E + ":" + k, console.log(P), O >= 2 && (console.log("超时了"), t.removeStorageSync("token"))) : t.removeStorageSync("token"), 
                                t.getStorageSync("token")) {
                                    s.next = 6;
                                    break;
                                }
                                return s.next = 6, g().then(function(e) {
                                    var n = new Date();
                                    t.setStorageSync("firstTokenTime", n.getTime()), t.setStorageSync("token", e);
                                }).catch(function(e) {
                                    t.showToast({
                                        title: "token获取失败，请稍后重试",
                                        icon: "none"
                                    });
                                });

                              case 6:
                                v = a ? {
                                    Authorization: "Bearer " + t.getStorageSync("token")
                                } : {
                                    Authorization: "Bearer " + t.getStorageSync("token"),
                                    "content-type": "application/x-www-form-urlencoded"
                                }, t.request({
                                    url: h + n,
                                    data: r,
                                    method: e,
                                    header: v
                                }).then(function() {
                                    var e = d(i.default.mark(function e(n) {
                                        var r, a, u, c, s, d, h, v, y, b, m, _;
                                        return i.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                if ((r = f(n, 2))[0], a = r[1], 2 != (u = a.statusCode.toString()).charAt(0)) {
                                                    e.next = 28;
                                                    break;
                                                }
                                                if (200 != u) {
                                                    e.next = 25;
                                                    break;
                                                }
                                                if (1005 != a.data.code) {
                                                    e.next = 22;
                                                    break;
                                                }
                                                return t.removeStorageSync("token"), e.next = 8, g();

                                              case 8:
                                                if (c = e.sent, console.log("result", c), t.setStorageSync("token", c), !t.getStorageSync("token")) {
                                                    e.next = 19;
                                                    break;
                                                }
                                                if (s = getCurrentPages(), d = s[s.length - 1].route, h = s[s.length - 1].options, 
                                                console.log("curParam", h), 0 == Object.keys(h).length) console.log(1111, d), t.reLaunch({
                                                    url: "/" + d
                                                }); else {
                                                    for (y in v = "", h) v += ("" == v ? "" : "&") + y + "=" + h[y];
                                                    b = "/" + d + "?" + v, console.log(222, b), m = [ "pages/index/index" ], console.log(d), 
                                                    m.indexOf(d) >= 0 ? t.reLaunch({
                                                        url: b
                                                    }) : t.redirectTo({
                                                        url: b
                                                    });
                                                }
                                                e.next = 20;
                                                break;

                                              case 19:
                                                return e.abrupt("return", !1);

                                              case 20:
                                                e.next = 23;
                                                break;

                                              case 22:
                                                l(a.data);

                                              case 23:
                                                e.next = 26;
                                                break;

                                              case 25:
                                                o && t.showToast({
                                                    title: a.data.msg,
                                                    icon: "none"
                                                });

                                              case 26:
                                                e.next = 38;
                                                break;

                                              case 28:
                                                if (!o) {
                                                    e.next = 37;
                                                    break;
                                                }
                                                if (401 != u) {
                                                    e.next = 32;
                                                    break;
                                                }
                                                return t.showToast({
                                                    title: "登录失效",
                                                    icon: "none"
                                                }), e.abrupt("return");

                                              case 32:
                                                console.log("400:", a.data.msg), _ = a.data.msg ? a.data.msg : "请求错误", p({
                                                    data: 404,
                                                    msg: _
                                                }), e.next = 38;
                                                break;

                                              case 37:
                                                p({
                                                    data: u
                                                });

                                              case 38:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    }));
                                    return function(t) {
                                        return e.apply(this, arguments);
                                    };
                                }()).catch(function(e) {
                                    c.failData = e, console.log("请求异常:", e), u.captureMessage("NetworkError: " + JSON.stringify(e)), 
                                    p(e);
                                }).finally(function() {
                                    console.log("请求"), o && t.hideLoading();
                                });

                              case 8:
                              case "end":
                                return s.stop();
                            }
                        }, s);
                    }));
                    return function(e, t) {
                        return s.apply(this, arguments);
                    };
                }());
            };
        }).call(this, o("543d").default);
    },
    ec2e: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        t.default = [ {
            text: "包头",
            code: "472"
        }, {
            text: "保定",
            code: "312"
        }, {
            text: "北京",
            code: "010"
        }, {
            text: "常熟",
            code: "610"
        }, {
            text: "常州",
            code: "519"
        }, {
            text: "成都",
            code: "028"
        }, {
            text: "大连",
            code: "411"
        }, {
            text: "丹东",
            code: "415"
        }, {
            text: "东莞",
            code: "769"
        }, {
            text: "东营",
            code: "546"
        }, {
            text: "佛山",
            code: "757"
        }, {
            text: "福州",
            code: "591"
        }, {
            text: "抚顺",
            code: "413"
        }, {
            text: "赣州",
            code: "797"
        }, {
            text: "广州",
            code: "020"
        }, {
            text: "贵阳",
            code: "851"
        }, {
            text: "哈尔滨",
            code: "451"
        }, {
            text: "海口",
            code: "898"
        }, {
            text: "杭州",
            code: "571"
        }, {
            text: "合肥",
            code: "551"
        }, {
            text: "呼和浩特",
            code: "471"
        }, {
            text: "湖州",
            code: "572"
        }, {
            text: "吉林",
            code: "432"
        }, {
            text: "济南",
            code: "531"
        }, {
            text: "嘉兴",
            code: "573"
        }, {
            text: "江门",
            code: "750"
        }, {
            text: "晋江",
            code: "601"
        }, {
            text: "九江",
            code: "792"
        }, {
            text: "昆明",
            code: "871"
        }, {
            text: "昆山",
            code: "609"
        }, {
            text: "兰州",
            code: "931"
        }, {
            text: "临沂",
            code: "539"
        }, {
            text: "洛阳",
            code: "379"
        }, {
            text: "绵阳",
            code: "816"
        }, {
            text: "南昌",
            code: "791"
        }, {
            text: "南京",
            code: "025"
        }, {
            text: "南宁",
            code: "771"
        }, {
            text: "南通",
            code: "513"
        }, {
            text: "宁波",
            code: "574"
        }, {
            text: "青岛",
            code: "532"
        }, {
            text: "泉州",
            code: "595"
        }, {
            text: "三亚",
            code: "899"
        }, {
            text: "厦门",
            code: "592"
        }, {
            text: "汕头",
            code: "754"
        }, {
            text: "上海",
            code: "021"
        }, {
            text: "上虞",
            code: "603"
        }, {
            text: "绍兴",
            code: "575"
        }, {
            text: "深圳",
            code: "755"
        }, {
            text: "沈阳",
            code: "024"
        }, {
            text: "石家庄",
            code: "311"
        }, {
            text: "苏州",
            code: "512"
        }, {
            text: "太原",
            code: "351"
        }, {
            text: "泰州",
            code: "523"
        }, {
            text: "唐山",
            code: "315"
        }, {
            text: "天津",
            code: "022"
        }, {
            text: "威海",
            code: "631"
        }, {
            text: "潍坊",
            code: "536"
        }, {
            text: "温州",
            code: "577"
        }, {
            text: "无锡",
            code: "510"
        }, {
            text: "武汉",
            code: "027"
        }, {
            text: "西安",
            code: "029"
        }, {
            text: "西宁",
            code: "971"
        }, {
            text: "湘潭",
            code: "602"
        }, {
            text: "徐州",
            code: "516"
        }, {
            text: "烟台",
            code: "535"
        }, {
            text: "扬州",
            code: "514"
        }, {
            text: "宜昌",
            code: "717"
        }, {
            text: "宜兴",
            code: "607"
        }, {
            text: "余姚",
            code: "604"
        }, {
            text: "张家港",
            code: "608"
        }, {
            text: "长春",
            code: "431"
        }, {
            text: "长沙",
            code: "731"
        }, {
            text: "郑州",
            code: "371"
        }, {
            text: "重庆",
            code: "023"
        }, {
            text: "珠海",
            code: "756"
        }, {
            text: "淄博",
            code: "533"
        } ];
    },
    f0a9: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = i(n("eb5f")), o = i(n("234f"));
        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var a = {
            pointexchangeList: function(e) {
                var t = new Date().getTime(), n = o.default.mdString(t, {
                    id: e.id,
                    idType: e.idType,
                    pointAccountId: e.pointAccountId
                });
                return e.sign = n, e.timestamp = t, (0, r.default)("get", "/api/wxapp/point/pointexchange-list", e);
            }
        };
        t.default = a;
    },
    f0c5: function(e, t, n) {
        function r(e, t, n, r, o, i, a, u, c, s) {
            var f, l = "function" == typeof e ? e.options : e;
            if (c) {
                l.components || (l.components = {});
                var p = Object.prototype.hasOwnProperty;
                for (var d in c) p.call(c, d) && !p.call(l.components, d) && (l.components[d] = c[d]);
            }
            if (s && ((s.beforeCreate || (s.beforeCreate = [])).unshift(function() {
                this[s.__module] = this;
            }), (l.mixins || (l.mixins = [])).push(s)), t && (l.render = t, l.staticRenderFns = n, 
            l._compiled = !0), r && (l.functional = !0), i && (l._scopeId = "data-v-" + i), 
            a ? (f = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), 
                o && o.call(this, e), e && e._registeredComponents && e._registeredComponents.add(a);
            }, l._ssrRegister = f) : o && (f = u ? function() {
                o.call(this, this.$root.$options.shadowRoot);
            } : o), f) if (l.functional) {
                l._injectStyles = f;
                var h = l.render;
                l.render = function(e, t) {
                    return f.call(t), h(e, t);
                };
            } else {
                var v = l.beforeCreate;
                l.beforeCreate = v ? [].concat(v, f) : [ f ];
            }
            return {
                exports: e,
                options: l
            };
        }
        n.d(t, "a", function() {
            return r;
        });
    },
    f0fd: function(e, t, n) {
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                apiRoot: "https://haagendazs.smarket.com.cn/v1",
                appId: "wx3656c2a2353eb377",
                openid: "gh_68065de13ad5",
                assetsRoot: "https://haagendazs.smarket.com.cn",
                envVersion: "release",
                ossurl: "https://haagendazs-oss.smarket.com.cn/"
            }, r = e.getAccountInfoSync();
            console.log("当前环境", r.miniProgram.envVersion), "develop" == r.miniProgram.envVersion || "trial" == r.miniProgram.envVersion ? (n.apiRoot = "https://uatscrm-haagendazs.smarket.com.cn/v1", 
            n.openid = "gh_ac555f44563e", n.assetsRoot = "https://uatscrm-haagendazs.smarket.com.cn", 
            n.envVersion = "develop", n.ossurl = "https://haagendazs-oss.smarket.com.cn/") : "release" == r.miniProgram.envVersion && (n.apiRoot = "https://haagendazs.smarket.com.cn/v1", 
            n.openid = "gh_68065de13ad5", n.assetsRoot = "https://haagendazs.smarket.com.cn", 
            n.envVersion = "release", n.ossurl = "https://haagendazs-oss.smarket.com.cn/");
            var o = n;
            t.default = o;
        }).call(this, n("543d").default);
    },
    f322: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("0b33"), o = {
            type: "text",
            mask: !1,
            message: "",
            show: !0,
            zIndex: 1e3,
            duration: 2e3,
            position: "middle",
            forbidClick: !1,
            loadingType: "circular",
            selector: "#van-toast"
        }, i = [], a = Object.assign({}, o);
        function u(e) {
            return (0, r.isObj)(e) ? e : {
                message: e
            };
        }
        function c(e) {
            var t = Object.assign(Object.assign({}, a), u(e)), n = (t.context || function() {
                var e = getCurrentPages();
                return e[e.length - 1];
            }()).selectComponent(t.selector);
            if (n) return delete t.context, delete t.selector, n.clear = function() {
                n.setData({
                    show: !1
                }), t.onClose && t.onClose();
            }, i.push(n), n.setData(t), clearTimeout(n.timer), t.duration > 0 && (n.timer = setTimeout(function() {
                n.clear(), i = i.filter(function(e) {
                    return e !== n;
                });
            }, t.duration)), n;
            console.warn("未找到 van-toast 节点，请确认 selector 及 context 是否正确");
        }
        var s = function(e) {
            return function(t) {
                return c(Object.assign({
                    type: e
                }, u(t)));
            };
        };
        c.loading = s("loading"), c.success = s("success"), c.fail = s("fail"), c.clear = function() {
            i.forEach(function(e) {
                e.clear();
            }), i = [];
        }, c.setDefaultOptions = function(e) {
            Object.assign(a, e);
        }, c.resetDefaultOptions = function() {
            a = Object.assign({}, o);
        };
        var f = c;
        t.default = f;
    },
    f3d6: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r, o = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("eb5f"));
        function i(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        var a = (i(r = {
            into: function(e) {
                return (0, o.default)("post", "/api/wxapp/activity/into", e, !1);
            },
            storeList: function(e) {
                return (0, o.default)("post", "/api/wxapp/store/list", e);
            },
            activityDraw: function(e, t) {
                return (0, o.default)("post", "/api/wxapp/activity/draw/".concat(t), e);
            },
            upload: function(e) {
                return (0, o.default)("post", "/api/wxapp/activity/upload", e);
            },
            getList: function(e) {
                return (0, o.default)("get", "/api/wxapp/lotteryRecord/getList", e);
            },
            activityExchange: function(e) {
                return (0, o.default)("post", "/api/wxapp/activity/exchange", e);
            },
            activityInvited: function(e) {
                return (0, o.default)("post", "/api/wxapp/activity/invited", e);
            },
            giftSendMessage: function(e) {
                return (0, o.default)("post", "/api/wxapp/lottery/giftSendMessage", e, !0, !1);
            },
            getsupriceList: function(e) {
                return (0, o.default)("get", "/api/wxapp/gift/getList", e);
            },
            supriceExchange: function(e) {
                return (0, o.default)("get", "/api/wxapp/gift/exchange", e);
            },
            activityGetList: function(e) {
                return (0, o.default)("get", "/api/wxapp/lotteryGift/getList", e);
            }
        }, "activityDraw", function(e, t) {
            return (0, o.default)("post", "/api/wxapp/activity/draw/" + t, e);
        }), i(r, "activityGet", function(e, t) {
            return (0, o.default)("get", "/api/wxapp/activity/get/".concat(e), t);
        }), i(r, "sendCoupon", function(e) {
            return (0, o.default)("post", "/api/wxapp/gratitudeRecord/sendCoupon", e, !1);
        }), i(r, "existsCoupon", function(e) {
            return (0, o.default)("post", "/api/wxapp/gratitudeRecord/existsCoupon", e, !1);
        }), i(r, "switches", function(e) {
            return (0, o.default)("get", "/api/wxapp/activity/switches", e, !1);
        }), i(r, "existsCouponSpring", function(e) {
            return (0, o.default)("post", "/api/wxapp/spring40gRecord/existsCoupon", e, !1);
        }), i(r, "sendCouponSpring", function(e) {
            return (0, o.default)("post", "/api/wxapp/spring40gRecord/sendCoupon", e, !1);
        }), r);
        t.default = a;
    },
    f658: function(e, t, n) {
        (function(e, r, o) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.dynamicRequire = u, t.isNodeEnv = c, t.getGlobalObject = f, t.uuid4 = function() {
                var e = f(), t = e.crypto || e.msCrypto;
                if (void 0 !== t && t.getRandomValues) {
                    var n = new Uint16Array(8);
                    t.getRandomValues(n), n[3] = 4095 & n[3] | 16384, n[4] = 16383 & n[4] | 32768;
                    var r = function(e) {
                        for (var t = e.toString(16); t.length < 4; ) t = "0" + t;
                        return t;
                    };
                    return r(n[0]) + r(n[1]) + r(n[2]) + r(n[3]) + r(n[4]) + r(n[5]) + r(n[6]) + r(n[7]);
                }
                return "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                    var t = 16 * Math.random() | 0;
                    return ("x" === e ? t : 3 & t | 8).toString(16);
                });
            }, t.parseUrl = function(e) {
                if (!e) return {};
                var t = e.match(/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
                if (!t) return {};
                var n = t[6] || "", r = t[8] || "";
                return {
                    host: t[4],
                    path: t[5],
                    protocol: t[2],
                    relative: t[5] + n + r
                };
            }, t.getEventDescription = function(e) {
                if (e.message) return e.message;
                if (e.exception && e.exception.values && e.exception.values[0]) {
                    var t = e.exception.values[0];
                    return t.type && t.value ? t.type + ": " + t.value : t.type || t.value || e.event_id || "<unknown>";
                }
                return e.event_id || "<unknown>";
            }, t.consoleSandbox = function(e) {
                var t = f();
                if (!("console" in t)) return e();
                var n = t.console, r = {};
                [ "debug", "info", "warn", "error", "log", "assert" ].forEach(function(e) {
                    e in t.console && n[e].__sentry_original__ && (r[e] = n[e], n[e] = n[e].__sentry_original__);
                });
                var o = e();
                return Object.keys(r).forEach(function(e) {
                    n[e] = r[e];
                }), o;
            }, t.addExceptionTypeValue = function(e, t, n) {
                e.exception = e.exception || {}, e.exception.values = e.exception.values || [], 
                e.exception.values[0] = e.exception.values[0] || {}, e.exception.values[0].value = e.exception.values[0].value || t || "", 
                e.exception.values[0].type = e.exception.values[0].type || n || "Error";
            }, t.addExceptionMechanism = function(e, t) {
                void 0 === t && (t = {});
                try {
                    e.exception.values[0].mechanism = e.exception.values[0].mechanism || {}, Object.keys(t).forEach(function(n) {
                        e.exception.values[0].mechanism[n] = t[n];
                    });
                } catch (e) {}
            }, t.getLocationHref = function() {
                try {
                    return document.location.href;
                } catch (e) {
                    return "";
                }
            }, t.htmlTreeAsString = function(e) {
                try {
                    for (var t = e, n = [], r = 0, o = 0, i = " > ".length, a = void 0; t && r++ < 5 && !("html" === (a = l(t)) || r > 1 && o + n.length * i + a.length >= 80); ) n.push(a), 
                    o += a.length, t = t.parentNode;
                    return n.reverse().join(" > ");
                } catch (e) {
                    return "<unknown>";
                }
            }, t.timestampWithMs = function() {
                return (v.timeOrigin + v.now()) / 1e3;
            }, t.parseSemver = function(e) {
                var t = e.match(g) || [], n = parseInt(t[1], 10), r = parseInt(t[2], 10), o = parseInt(t[3], 10);
                return {
                    buildmetadata: t[5],
                    major: isNaN(n) ? void 0 : n,
                    minor: isNaN(r) ? void 0 : r,
                    patch: isNaN(o) ? void 0 : o,
                    prerelease: t[4]
                };
            }, t.parseRetryAfterHeader = function(e, t) {
                if (!t) return 6e4;
                var n = parseInt("" + t, 10);
                if (!isNaN(n)) return 1e3 * n;
                var r = Date.parse("" + t);
                return isNaN(r) ? 6e4 : r - e;
            }, t.getFunctionName = function(e) {
                try {
                    return e && "function" == typeof e && e.name || y;
                } catch (e) {
                    return y;
                }
            }, t.addContextToFrame = function(e, t, n) {
                void 0 === n && (n = 5);
                var r = t.lineno || 0, o = e.length, i = Math.max(Math.min(o, r - 1), 0);
                t.pre_context = e.slice(Math.max(0, i - n), i).map(function(e) {
                    return (0, a.snipLine)(e, 0);
                }), t.context_line = (0, a.snipLine)(e[Math.min(o - 1, i)], t.colno || 0), t.post_context = e.slice(Math.min(i + 1, o), i + 1 + n).map(function(e) {
                    return (0, a.snipLine)(e, 0);
                });
            }, t.crossPlatformPerformance = void 0;
            var i = n("670e"), a = n("d34a");
            function u(e, t) {
                return e.require(t);
            }
            function c() {
                return "[object process]" === Object.prototype.toString.call(void 0 !== e ? e : 0);
            }
            var s = {};
            function f() {
                return c() ? r : "undefined" != typeof window ? window : "undefined" != typeof self ? self : s;
            }
            function l(e) {
                var t, n, r, o, a, u = e, c = [];
                if (!u || !u.tagName) return "";
                if (c.push(u.tagName.toLowerCase()), u.id && c.push("#" + u.id), (t = u.className) && (0, 
                i.isString)(t)) for (n = t.split(/\s+/), a = 0; a < n.length; a++) c.push("." + n[a]);
                var s = [ "type", "name", "title", "alt" ];
                for (a = 0; a < s.length; a++) r = s[a], (o = u.getAttribute(r)) && c.push("[" + r + '="' + o + '"]');
                return c.join("");
            }
            var p = Date.now(), d = 0, h = {
                now: function() {
                    var e = Date.now() - p;
                    return e < d && (e = d), d = e, e;
                },
                timeOrigin: p
            }, v = function() {
                if (c()) try {
                    return u(o, "perf_hooks").performance;
                } catch (e) {
                    return h;
                }
                return f().performance && void 0 === performance.timeOrigin && (performance.timeOrigin = performance.timing && performance.timing.navigationStart || p), 
                f().performance || h;
            }();
            t.crossPlatformPerformance = v;
            var g = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+([0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$/;
            var y = "<anonymous>";
        }).call(this, n("4362"), n("c8ba"), n("62e4")(e));
    },
    ff36: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.exceptionFromStacktrace = i, t.eventFromPlainObject = function(e, t, n) {
            var i = {
                exception: {
                    values: [ {
                        type: (0, r.isEvent)(e) ? e.constructor.name : n ? "UnhandledRejection" : "Error",
                        value: "Non-Error " + (n ? "promise rejection" : "exception") + " captured with keys: " + (0, 
                        r.extractExceptionKeysForMessage)(e)
                    } ]
                },
                extra: {
                    __serialized__: (0, r.normalizeToSize)(e)
                }
            };
            if (t) {
                var u = a((0, o.computeStackTrace)(t).stack);
                i.stacktrace = {
                    frames: u
                };
            }
            return i;
        }, t.eventFromStacktrace = function(e) {
            return {
                exception: {
                    values: [ i(e) ]
                }
            };
        }, t.prepareFramesForEvent = a;
        var r = n("32f1"), o = n("938b");
        function i(e) {
            var t = a(e.stack), n = {
                type: e.name,
                value: e.message
            };
            return t && t.length && (n.stacktrace = {
                frames: t
            }), void 0 === n.type && "" === n.value && (n.value = "Unrecoverable error caught"), 
            n;
        }
        function a(e) {
            if (!e || !e.length) return [];
            var t = e, n = t[0].func || "", r = t[t.length - 1].func || "";
            return -1 === n.indexOf("captureMessage") && -1 === n.indexOf("captureException") || (t = t.slice(1)), 
            -1 !== r.indexOf("sentryWrapped") && (t = t.slice(0, -1)), t.map(function(e) {
                return {
                    colno: null === e.column ? void 0 : e.column,
                    filename: e.url || t[0].url,
                    function: e.func || "?",
                    in_app: !0,
                    lineno: null === e.line ? void 0 : e.line
                };
            }).slice(0, 100).reverse();
        }
    }
} ]);