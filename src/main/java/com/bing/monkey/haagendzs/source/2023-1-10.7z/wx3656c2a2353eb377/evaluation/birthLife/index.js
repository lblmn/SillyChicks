// evaluation/birthLife/index.js
Page({data: {}})